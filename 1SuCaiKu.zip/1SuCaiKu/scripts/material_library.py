#!/usr/bin/env python3
"""Single deterministic entry point for the local video material library."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path


USER_ROOT = Path(os.environ.get("INFOFLOW_USER_ROOT", Path.home())).expanduser().resolve()
CONFIG_ROOT = Path(os.environ.get("INFOFLOW_CONFIG_ROOT", USER_ROOT / ".codex")).expanduser().resolve()
ROOT = Path(os.environ.get("INFOFLOW_MATERIAL_LIBRARY_ROOT", CONFIG_ROOT / "000SuCaiKu")).expanduser().resolve()
INDEX = ROOT / "2026-08-13_文档_素材库统一索引.json"
USAGE = ROOT / "2026-08-13_文档_素材库统一使用台账.json"
REJECTIONS = ROOT / "2026-08-14_文档_素材库永久排除清单.json"
DELIVERIES_ROOT = Path(os.environ.get("INFOFLOW_DOCUMENT_OUTPUT_DIR", USER_ROOT / "Documents" / "Codex")).expanduser().resolve()
VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv", ".mxf", ".webm", ".avi", ".m4v", ".ogv"}
CATEGORIES = (
    "1. 商业航天与卫星", "2. 半导体与芯片", "3. AI 算力与大模型", "4. 宏观与大宗商品",
    "5. 股市与市场", "6. 机器人", "7. 军事",
)
TOKEN_RE = re.compile(r"[\w\u4e00-\u9fff]+", re.UNICODE)
SOURCE_ID_RE = re.compile(r"(?:pexels|pixabay|nasa|id)[_-]?(\d{4,})", re.I)
SEMANTIC_FIELDS = ("subject", "action", "location", "equipment", "keywords")
MIN_DURATION = 4.0
MIN_WIDTH, MIN_HEIGHT = 1280, 720
ASPECT_RATIO = 16 / 9


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def read_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def quick_hash(path: Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    size = path.stat().st_size
    with path.open("rb") as handle:
        digest.update(handle.read(block_size))
        if size > block_size:
            handle.seek(max(0, size - block_size))
            digest.update(handle.read(block_size))
    digest.update(str(size).encode("ascii"))
    return digest.hexdigest()


def full_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_sha256(path: Path) -> str:
    return full_hash(path)


def find_ffprobe(explicit: str | None = None) -> str:
    value = explicit or shutil.which("ffprobe")
    if not value or not (Path(value).is_file() if explicit else True):
        raise RuntimeError("ffprobe is required")
    return value


def find_ffmpeg() -> str:
    value = shutil.which("ffmpeg")
    if not value:
        raise RuntimeError("ffmpeg is required to prepare candidate previews")
    return value


def probe(path: Path, ffprobe: str) -> dict:
    command = [
        ffprobe, "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=codec_name,width,height,r_frame_rate:stream_tags=rotate:stream_side_data=rotation:format=duration",
        "-of", "json", str(path),
    ]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode:
        return {"probe_ok": False, "probe_error": result.stderr.strip()[:500]}
    try:
        raw = json.loads(result.stdout)
        stream = raw["streams"][0]
        width, height = int(stream["width"]), int(stream["height"])
        rotation = int((stream.get("tags") or {}).get("rotate", 0))
        for side in stream.get("side_data_list", []):
            if side.get("rotation") is not None:
                rotation = int(side["rotation"])
                break
        if rotation % 180:
            width, height = height, width
        rate = str(stream.get("r_frame_rate") or "0/1").split("/", 1)
        fps = float(rate[0]) / float(rate[1]) if float(rate[1]) else 0.0
        return {
            "probe_ok": True, "duration": float(raw["format"]["duration"]),
            "codec": stream.get("codec_name"), "width": width, "height": height,
            "fps": round(fps, 3), "rotation": rotation,
            "orientation": "portrait" if height > width else "landscape" if width > height else "square",
        }
    except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
        return {"probe_ok": False, "probe_error": str(exc)}


def media_files(root: Path):
    for current, dirs, files in os.walk(root):
        dirs[:] = [name for name in dirs if not name.startswith(".")]
        for name in files:
            path = Path(current) / name
            if path.suffix.casefold() in VIDEO_EXTENSIONS:
                yield path.resolve()


def category_for(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).parts[0]
    except (ValueError, IndexError):
        return path.parent.name


def tokens(path: Path, metadata: dict | None = None) -> list[str]:
    values = " ".join(path.parts[-3:]) + " " + json.dumps(metadata or {}, ensure_ascii=False)
    return sorted({item.casefold() for item in TOKEN_RE.findall(values.replace("_", " ")) if len(item) > 1})


def semantic_score(query: str, item: dict) -> float:
    text = json.dumps(item, ensure_ascii=False).casefold()
    query = query.casefold().strip()
    if query in text:
        return 1.0
    wanted = {part for token in TOKEN_RE.findall(query) for part in ((token,) if not re.search(r"[\u4e00-\u9fff]", token) else (token[index:index + 2] for index in range(len(token) - 1))) if len(part) > 1}
    available = {part for token in TOKEN_RE.findall(text) for part in ((token,) if not re.search(r"[\u4e00-\u9fff]", token) else (token[index:index + 2] for index in range(len(token) - 1))) if len(part) > 1}
    return len(wanted & available) / len(wanted) if wanted else 0.0


def field_score(query: str, item: dict, field: str) -> float:
    """Match only the declared field plus keywords; paths and categories are not evidence."""
    return semantic_score(query, {field: item.get(field, ""), "keywords": item.get("keywords", [])})


def quality_errors(item: dict, min_duration: float = MIN_DURATION) -> list[str]:
    errors = []
    if not item.get("probe_ok"):
        errors.append("not_decodable")
    if item.get("orientation") != "landscape":
        errors.append("not_landscape")
    if float(item.get("duration") or 0) <= min_duration:
        errors.append("too_short")
    if int(item.get("width") or 0) < MIN_WIDTH or int(item.get("height") or 0) < MIN_HEIGHT:
        errors.append("low_resolution")
    height = int(item.get("height") or 0)
    if height and abs(int(item.get("width") or 0) / height - ASPECT_RATIO) > 0.01:
        errors.append("not_16_9")
    if not all(item.get(key) is True for key in ("watermark_free", "embedded_subtitles_free", "platform_overlay_free")):
        errors.append("cleanliness_not_verified")
    if any(not item.get(field) for field in SEMANTIC_FIELDS):
        errors.append("incomplete_semantics")
    return errors


def source_family(path: str) -> str:
    value = Path(path)
    stem = re.sub(r"(?:[_-](?:\d{1,3}|[0-9a-f]{12,}))+$", "", value.stem.casefold())
    return str(value.parent).casefold() + "|" + stem


def index_assets(root: Path, index_path: Path, ffprobe: str, workers: int = 8) -> dict:
    old = read_json(index_path, {"assets": []})
    old_by_path = {str(item.get("path", "")).casefold(): item for item in old.get("assets", [])}
    assets, changed = [], []
    for path in sorted(set(media_files(root)), key=lambda item: str(item).casefold()):
        stat = path.stat()
        previous = old_by_path.get(str(path).casefold())
        if previous and previous.get("size") == stat.st_size and previous.get("mtime_ns") == stat.st_mtime_ns:
            assets.append(previous)
        else:
            changed.append((path, stat.st_size, stat.st_mtime_ns))

    def inspect(entry) -> dict:
        path, size, mtime_ns = entry
        digest = quick_hash(path)
        item = {
            "id": "asset-" + digest[:12], "path": str(path), "size": size, "mtime_ns": mtime_ns,
            "quick_hash": digest, "primary_category": category_for(path, root),
        }
        item.update(probe(path, ffprobe))
        item["keywords"] = tokens(path)
        match = SOURCE_ID_RE.search(path.stem)
        if match:
            item["source_id"] = match.group(1)
        return item

    if changed:
        with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
            assets.extend(pool.map(inspect, changed))
    assets = [enrich_with_sidecar(item) for item in assets]
    assets.sort(key=lambda item: item["path"].casefold())
    result = {"schema_version": 1, "generated_at": now_iso(), "root": str(root), "assets": assets}
    write_json(index_path, result)
    return result


def load_usage(path: Path) -> dict:
    raw = read_json(path, {"schema_version": 1, "uses": []})
    raw.setdefault("schema_version", 1)
    raw.setdefault("uses", [])
    return raw


def recent_identities(usage: dict, hours: int, current_project: Path | None = None) -> set[str]:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    current = current_project.resolve() if current_project else None
    values: set[str] = set()
    for use in usage.get("uses", []):
        try:
            if current and use.get("project") and Path(use["project"]).resolve() == current:
                continue
        except (OSError, ValueError):
            pass
        try:
            used_at = datetime.fromisoformat(str(use["used_at"]).replace("Z", "+00:00")).astimezone(timezone.utc)
        except (KeyError, TypeError, ValueError):
            continue
        if used_at < cutoff:
            continue
        for key in ("asset_id", "quick_hash", "sha256", "source_url", "source_id", "source_family"):
            if use.get(key):
                values.add(f"{key}:{str(use[key]).casefold()}")
    return values


def delivered_identities(root: Path, hours: int, current_project: Path | None = None) -> set[str]:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    current = current_project.resolve() if current_project else None
    values: set[str] = set()
    reports = {*root.rglob("*门禁*.json"), *root.rglob("*gate*.json")}
    for report_path in reports:
        if current and (report_path.parent.resolve() == current or current in report_path.parents):
            continue
        try:
            report = read_json(report_path, {})
            checked = datetime.fromisoformat(str(report["checked_at"]).replace("Z", "+00:00")).astimezone(timezone.utc)
            expected = report.get("sha256", {}).get("ledger")
        except (KeyError, TypeError, ValueError, json.JSONDecodeError, OSError):
            continue
        if report.get("terminal_allowed") is not True or checked < cutoff or not expected:
            continue
        for ledger_path in report_path.parent.glob("*asset-ledger.json"):
            try:
                if file_sha256(ledger_path) != expected:
                    continue
                raw = read_json(ledger_path, {})
            except (OSError, json.JSONDecodeError):
                continue
            for asset in raw if isinstance(raw, list) else raw.get("assets", []):
                mapping = {
                    "id": "asset_id", "quick_hash": "quick_hash", "sha256": "sha256",
                    "source_url": "source_url", "source_id": "source_id",
                }
                for source_key, identity_key in mapping.items():
                    if asset.get(source_key):
                        values.add(f"{identity_key}:{str(asset[source_key]).casefold()}")
                local = asset.get("local_path") or asset.get("path")
                if local:
                    values.add("source_family:" + source_family(str(local)))
    return values


def identities(asset: dict) -> set[str]:
    result = set()
    for key in ("id", "asset_id", "quick_hash", "sha256", "source_url", "source_id"):
        if asset.get(key):
            result.add(f"{'asset_id' if key == 'id' else key}:{str(asset[key]).casefold()}")
    result.add("source_family:" + source_family(str(asset.get("path", ""))))
    return result


def recent_material_identities(
    usage_path: Path = USAGE,
    deliveries_root: Path = DELIVERIES_ROOT,
    lookback_hours: int = 168,
    current_project: Path | None = None,
) -> set[str]:
    return recent_identities(load_usage(usage_path), lookback_hours, current_project) | delivered_identities(
        deliveries_root, lookback_hours, current_project
    )


def distinct_sources(assets: list[dict]) -> list[dict]:
    result, seen = [], set()
    for asset in assets:
        key = str(asset.get("source_id") or source_family(str(asset.get("path", "")))).casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(asset)
    return result


def rejected_identities(path: Path = REJECTIONS) -> set[str]:
    raw = read_json(path, {"items": []})
    items = raw if isinstance(raw, list) else raw.get("items", [])
    return set().union(*(identities(item) for item in items)) if items else set()


def filter_candidates(
    candidates: list[dict],
    index_path: Path = INDEX,
    usage_path: Path = USAGE,
    deliveries_root: Path = DELIVERIES_ROOT,
    current_project: Path | None = None,
    rejected_asset_ids: set[str] | None = None,
    lookback_hours: int = 168,
    require_provenance: bool = False,
    min_duration: float = 0.0,
    rejection_path: Path | None = REJECTIONS,
) -> list[dict]:
    """Apply the canonical library and reuse gates to visually ranked candidates."""
    index = read_json(index_path, {"assets": []})
    by_path = {str(Path(item["path"]).resolve()).casefold(): item for item in index.get("assets", [])}
    recent = recent_material_identities(usage_path, deliveries_root, lookback_hours, current_project)
    permanently_rejected = rejected_identities(rejection_path) if rejection_path else set()
    rejected = {str(value) for value in (rejected_asset_ids or set())}
    eligible = []
    for candidate in candidates:
        path = Path(candidate.get("path", ""))
        if not path.is_file():
            continue
        canonical = by_path.get(str(path.resolve()).casefold())
        if not canonical or quality_errors(canonical, max(MIN_DURATION, min_duration)):
            continue
        item = {**canonical, **candidate}
        item["asset_id"] = candidate.get("asset_id") or candidate.get("id") or canonical.get("id")
        item["quick_hash"] = canonical.get("quick_hash")
        item["source_id"] = candidate.get("source_id") or canonical.get("source_id")
        item["source_url"] = candidate.get("source_url") or canonical.get("source_url")
        if str(item.get("asset_id")) in rejected or identities(item) & (recent | permanently_rejected):
            continue
        if require_provenance and not all(item.get(key) for key in ("source_url", "publisher", "source_description")):
            continue
        item["sha256"] = candidate.get("sha256") or full_hash(path)
        item["seven_day_eligible"] = True
        eligible.append(item)
    return distinct_sources(eligible)


def commit_ledger(
    ledger_path: Path,
    project: Path,
    usage_path: Path = USAGE,
    library_root: Path = ROOT,
) -> int:
    """Register a delivered asset ledger in the canonical usage ledger once."""
    raw = read_json(ledger_path, {})
    assets = {str(item.get("id")): item for item in (raw if isinstance(raw, list) else raw.get("assets", []))}
    uses = [] if isinstance(raw, list) else raw.get("uses", [])
    usage = load_usage(usage_path)
    existing = {
        (str(item.get("project")), str(item.get("asset_id")), item.get("source_in"), item.get("source_out"))
        for item in usage.get("uses", [])
    }
    used_at, added = now_iso(), 0
    for use in uses or ({"asset_id": key} for key in assets):
        asset_id = str(use.get("asset_id"))
        asset = assets.get(asset_id, {})
        local = asset.get("local_path") or asset.get("path")
        key = (str(project.resolve()), asset_id, use.get("source_in"), use.get("source_out"))
        try:
            is_library_asset = Path(local).resolve().is_relative_to(library_root.resolve()) if local else False
        except (OSError, ValueError):
            is_library_asset = False
        if not is_library_asset or key in existing:
            continue
        usage["uses"].append({
            "asset_id": asset_id, "path": str(local),
            "quick_hash": asset.get("quick_hash"), "sha256": asset.get("sha256"),
            "source_url": asset.get("source_url"), "source_id": asset.get("source_id"),
            "source_family": source_family(str(local)), "project": str(project.resolve()),
            "source_in": use.get("source_in"), "source_out": use.get("source_out"), "used_at": used_at,
        })
        existing.add(key)
        added += 1
    if added:
        usage["updated_at"] = used_at
        write_json(usage_path, usage)
    return added


def audit(args) -> int:
    root, index_path = Path(args.root).resolve(), Path(args.index).resolve()
    old = read_json(index_path, {"assets": []})
    old_paths = {str(item.get("path", "")).casefold() for item in old.get("assets", [])}
    disk_paths = {str(path).casefold() for path in media_files(root)}
    data = index_assets(root, index_path, find_ffprobe(args.ffprobe), args.workers)
    assets = data["assets"]
    paths = {str(item["path"]).casefold() for item in assets}
    hash_groups: dict[str, list[str]] = {}
    for item in assets:
        hash_groups.setdefault(str(item.get("quick_hash")), []).append(item["path"])
    report = {
        "checked_at": now_iso(), "root": str(root), "indexed_count": len(assets),
        "removed_from_index": len(old_paths - disk_paths),
        "missing_count": sum(not Path(item["path"]).exists() for item in assets),
        "unindexed_count": sum(str(path).casefold() not in paths for path in media_files(root)),
        "probe_failed": [item["path"] for item in assets if not item.get("probe_ok")],
        "portrait": [item["path"] for item in assets if item.get("orientation") == "portrait"],
        "invalid_categories": sorted({item["primary_category"] for item in assets if item["primary_category"] not in CATEGORIES}),
        "duplicate_content": [group for group in hash_groups.values() if len(group) > 1],
        "quality_eligible_count": sum(not quality_errors(item) for item in assets),
        "quality_incomplete_count": sum(bool(quality_errors(item)) for item in assets),
        "quality_incomplete_sample": [item["path"] for item in assets if quality_errors(item)][:20],
    }
    if args.output:
        write_json(Path(args.output), report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if report["missing_count"] or report["unindexed_count"] or report["probe_failed"] or report["portrait"] or report["quality_incomplete_count"] else 0


def ingest(args) -> int:
    source = Path(args.file).resolve()
    root, index_path = Path(args.root).resolve(), Path(args.index).resolve()
    if not source.is_file() or source.suffix.casefold() not in VIDEO_EXTENSIONS:
        raise ValueError("input must be a supported video file")
    if args.category not in CATEGORIES:
        raise ValueError("category must be one of: " + ", ".join(CATEGORIES))
    ffprobe = find_ffprobe(args.ffprobe)
    metadata = probe(source, ffprobe)
    if not metadata.get("probe_ok"):
        raise ValueError("video is not decodable: " + str(metadata.get("probe_error")))
    if metadata["orientation"] != "landscape":
        raise ValueError("only landscape video is accepted")
    evidence = Path(args.frame_evidence).resolve()
    if not evidence.is_file() or not args.cleanliness_evidence.strip():
        raise ValueError("frame evidence and cleanliness evidence are required")
    candidate = {**metadata, "subject": args.subject, "action": args.action, "location": args.location, "equipment": args.equipment, "keywords": args.keyword, "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True}
    errors = quality_errors(candidate)
    if errors:
        raise ValueError("material quality rejected: " + ", ".join(errors))
    digest = full_hash(source)
    current = index_assets(root, index_path, ffprobe, args.workers)
    for item in current["assets"]:
        existing = Path(item["path"])
        if existing.stat().st_size == source.stat().st_size and full_hash(existing) == digest:
            print(json.dumps({"status": "existing", "asset": item}, ensure_ascii=False, indent=2))
            return 0
    candidate_identity = {
        "path": str(source), "quick_hash": quick_hash(source), "sha256": digest,
        "source_url": args.source_url, "source_id": args.source_id,
    }
    blocked = recent_material_identities() | rejected_identities(Path(getattr(args, "rejections", REJECTIONS)))
    if identities(candidate_identity) & blocked:
        raise ValueError("material identity is recently used or permanently rejected")
    safe_title = re.sub(r'[<>:"/\\|?*]+', "_", args.title).strip(" ._")
    if not safe_title:
        raise ValueError("title is empty after sanitizing")
    match = SOURCE_ID_RE.search(source.stem)
    source_id = args.source_id or (match.group(1) if match else digest[:12])
    date = datetime.now().astimezone().date().isoformat()
    destination = root / args.category / f"{date}_视频_{safe_title}_{source_id}{source.suffix.casefold()}"
    if destination.exists():
        raise FileExistsError(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    if full_hash(destination) != digest:
        destination.unlink(missing_ok=True)
        raise IOError("copied file hash mismatch")
    evidence_destination = destination.with_suffix(destination.suffix + ".review" + evidence.suffix.casefold())
    shutil.copy2(evidence, evidence_destination)
    write_json(destination.with_suffix(destination.suffix + ".json"), {
        "path": str(destination), "sha256": digest, "primary_category": args.category,
        "subject": args.subject, "action": args.action, "location": args.location,
        "equipment": args.equipment, "keywords": args.keyword,
        "source_url": args.source_url, "publisher": args.publisher, "source_id": source_id,
        "frame_evidence": str(evidence_destination), "cleanliness_evidence": args.cleanliness_evidence,
        "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
        "cleanliness_checked_at": now_iso(),
        "downloaded_at": now_iso(), "status": "available", **metadata,
    })
    current = index_assets(root, index_path, ffprobe, args.workers)
    print(json.dumps({"status": "ingested", "path": str(destination), "index_count": len(current["assets"])}, ensure_ascii=False, indent=2))
    return 0


def enrich_with_sidecar(asset: dict) -> dict:
    result = dict(asset)
    path = Path(asset["path"])
    sidecar = read_json(path.with_suffix(path.suffix + ".json"), {})
    for key, value in sidecar.items():
        if key not in {"id", "path", "size", "mtime_ns", "quick_hash", "sha256", "primary_category", "probe_ok", "duration", "codec", "width", "height", "fps", "rotation", "orientation"} and value not in (None, "", []):
            result[key] = value
    result["keywords"] = sorted(set(result.get("keywords", [])) | set(sidecar.get("keywords", [])))
    return result


def backfill_metadata(args) -> int:
    root = Path(args.root).resolve()
    written = 0
    for path in media_files(root):
        sidecar_path = path.with_suffix(path.suffix + ".json")
        sidecar = read_json(sidecar_path, {})
        derived = {
            "subject": category_for(path, root),
            "keywords": tokens(path),
            "filename_title": path.stem,
            "metadata_basis": "filename_category",
        }
        changed = {key: value for key, value in derived.items() if not sidecar.get(key)}
        if changed:
            write_json(sidecar_path, {**sidecar, **changed})
            written += 1
    data = index_assets(root, Path(args.index).resolve(), find_ffprobe(args.ffprobe), args.workers)
    result = {"status": "backfilled", "written": written, "indexed_count": len(data["assets"])}
    if args.output:
        write_json(Path(args.output), result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def review_queue(args) -> int:
    """Persist human frame-review findings, or remove the unapproved remainder."""
    queue = read_json(Path(args.queue), {})
    candidates = queue.get("candidates", [])
    positions = {int(value) for value in args.position.split(",") if value.strip()}
    if args.delete_unreviewed:
        reviewed = 0
        deleted = 0
        for row in candidates:
            path = Path(row["path"])
            sidecar = read_json(path.with_suffix(path.suffix + ".json"), {})
            if sidecar.get("review_status") == "frame_reviewed":
                reviewed += 1
                continue
            if path.exists():
                path.unlink()
            path.with_suffix(path.suffix + ".json").unlink(missing_ok=True)
            deleted += 1
        print(json.dumps({"reviewed": reviewed, "deleted": deleted}, ensure_ascii=False))
        return 0
    if not positions or not all((1 <= value <= len(candidates)) for value in positions):
        raise ValueError("--position must contain queue positions")
    for position in positions:
        row = candidates[position - 1]
        path = Path(row["path"])
        sidecar_path = path.with_suffix(path.suffix + ".json")
        sidecar = read_json(sidecar_path, {})
        sidecar.update({
            "subject": args.subject, "action": args.action, "location": args.location,
            "equipment": args.equipment, "keywords": args.keyword,
            "frame_evidence": row["frame_evidence"],
            "cleanliness_evidence": f"human frame review at {row['timestamp']:.3f}s: no watermark, embedded subtitles, or platform overlay visible",
            "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
            "cleanliness_checked_at": now_iso(), "review_status": "frame_reviewed", "reviewed_at": now_iso(),
        })
        write_json(sidecar_path, sidecar)
    print(json.dumps({"reviewed": len(positions)}, ensure_ascii=False))
    return 0


def prepare_candidate_preview(item: dict, review_dir: Path, ffmpeg: str) -> dict:
    """Make the visual evidence that turns a metadata hit into a reviewable candidate."""
    duration = float(item["duration"])
    clip_length = min(3.0, duration)
    start = max(0.0, min(duration - clip_length, duration / 2 - clip_length / 2))
    stem = f"{item['id']}_{str(item.get('quick_hash', ''))[:12]}"
    folder = review_dir / stem
    folder.mkdir(parents=True, exist_ok=True)
    clip = folder / "preview.mp4"
    subprocess.run([ffmpeg, "-y", "-ss", f"{start:.3f}", "-i", item["path"], "-t", f"{clip_length:.3f}", "-an", "-vf", "scale=640:-2", "-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-movflags", "+faststart", str(clip)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    frames = []
    for label, offset in (("A", 0.2), ("M", 0.5), ("B", 0.8)):
        timestamp = start + clip_length * offset
        frame = folder / f"{label}.jpg"
        subprocess.run([ffmpeg, "-y", "-ss", f"{timestamp:.3f}", "-i", item["path"], "-frames:v", "1", "-update", "1", "-vf", "scale=640:-2", str(frame)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        frames.append({"label": label, "timestamp": round(timestamp, 3), "path": str(frame.resolve())})
    return {"prepared_visual": True, "review_clip_path": str(clip.resolve()), "review_frames": frames}


def search(args) -> int:
    data = index_assets(Path(args.root).resolve(), Path(args.index).resolve(), find_ffprobe(args.ffprobe), args.workers)
    # Keep candidate eligibility identical to the formal preflight gate.
    recent = recent_material_identities(
        Path(args.usage), Path(args.deliveries_root), args.lookback_hours,
        Path(getattr(args, "current_project", "")).resolve() if getattr(args, "current_project", "") else None,
    )
    permanently_rejected = rejected_identities(Path(args.rejections))
    groups = [(field, [term for term in getattr(args, field) if term.strip()]) for field in ("subject", "action", "location", "equipment", "keyword")]
    groups = [(field, group) for field, group in groups if group]
    if not groups:
        raise ValueError("provide at least one semantic search field")
    ranked = []
    for raw in data["assets"]:
        item = enrich_with_sidecar(raw)
        if quality_errors(item, max(MIN_DURATION, args.min_duration)):
            continue
        matched = [max(field_score(term, item, "keywords" if field == "keyword" else field) for term in group) for field, group in groups]
        if args.require_all and any(score < 0.5 for score in matched):
            continue
        score = sum(matched)
        if not score:
            continue
        # Legacy index rows may lack sha256 while delivered ledgers carry only it.
        # Hash only semantic matches so search and preflight cannot disagree.
        item.setdefault("sha256", file_sha256(Path(item["path"])))
        if identities(item) & (recent | permanently_rejected):
            continue
        item["semantic_score"] = round(score, 6)
        item["quality_gate"] = "pass"
        item["seven_day_eligible"] = True
        ranked.append(item)
    ranked.sort(key=lambda item: (-item["semantic_score"], item.get("duration") or 10**9, item["path"].casefold()))
    ranked = distinct_sources(ranked)
    selected = ranked[:args.limit]
    prepare_review = getattr(args, "prepare_review", True)
    if prepare_review:
        review_dir_value = getattr(args, "review_dir", None)
        if not review_dir_value and args.output:
            review_dir_value = str(Path(args.output).resolve().with_suffix("")) + "_候选预览"
        if not review_dir_value:
            raise ValueError("prepared search requires --review-dir or --output")
        review_dir, ffmpeg = Path(review_dir_value).resolve(), find_ffmpeg()
        prepared = []
        for item in selected:
            try:
                prepared.append({**item, **prepare_candidate_preview(item, review_dir, ffmpeg)})
            except (OSError, subprocess.CalledProcessError):
                continue
        selected = prepared
    result = {"checked_at": now_iso(), "lookback_hours": args.lookback_hours, "min_duration": args.min_duration, "prepared_visual": prepare_review, "count": len(selected), "candidates": selected}
    if args.output:
        write_json(Path(args.output), result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def reject(args) -> int:
    path = Path(args.rejections)
    data = read_json(path, {"items": []})
    item = {
        key: value for key, value in {
            "source_url": args.source_url, "source_id": args.source_id,
            "quick_hash": args.quick_hash, "sha256": args.sha256,
            "publisher": args.publisher,
        }.items() if value
    }
    if not any(item.get(key) for key in ("source_url", "source_id", "quick_hash", "sha256")):
        raise ValueError("provide at least one source or content identity")
    item.update({"reason": args.reason, "rejected_at": now_iso()})
    fields = ("source_url", "source_id", "quick_hash", "sha256")
    exists = any(any(item.get(key) and old.get(key) == item[key] for key in fields) for old in data.get("items", []))
    if not exists:
        data.setdefault("items", []).append(item)
        data["updated_at"] = now_iso()
        write_json(path, data)
    print(json.dumps({"status": "existing" if exists else "rejected", "item": item, "rejections": str(path)}, ensure_ascii=False, indent=2))
    return 0


def commit(args) -> int:
    index = read_json(Path(args.index), {"assets": []})
    by_id = {item["id"]: enrich_with_sidecar(item) for item in index.get("assets", [])}
    missing = [value for value in args.asset_id if value not in by_id]
    if missing:
        raise ValueError("unknown asset ids: " + ", ".join(missing))
    usage_path = Path(args.usage)
    usage = load_usage(usage_path)
    used_at = now_iso()
    for asset_id in args.asset_id:
        asset = by_id[asset_id]
        usage["uses"].append({
            "asset_id": asset_id, "path": asset["path"], "quick_hash": asset.get("quick_hash"),
            "source_url": asset.get("source_url"), "source_id": asset.get("source_id"),
            "source_family": source_family(asset["path"]), "project": args.project,
            "source_in": args.source_in, "source_out": args.source_out, "used_at": used_at,
        })
    usage["updated_at"] = used_at
    write_json(usage_path, usage)
    print(json.dumps({"committed": len(args.asset_id), "used_at": used_at, "usage": str(usage_path)}, ensure_ascii=False, indent=2))
    return 0


def parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--root", default=str(ROOT))
    common.add_argument("--index", default=str(INDEX))
    common.add_argument("--ffprobe")
    common.add_argument("--workers", type=int, default=8)
    common.add_argument("--rejections", default=str(REJECTIONS))
    main = argparse.ArgumentParser(description=__doc__)
    commands = main.add_subparsers(dest="command", required=True)
    audit_p = commands.add_parser("audit", parents=[common])
    audit_p.add_argument("--output")
    audit_p.set_defaults(func=audit)
    backfill_p = commands.add_parser("backfill-metadata", parents=[common])
    backfill_p.add_argument("--output")
    backfill_p.set_defaults(func=backfill_metadata)
    review_p = commands.add_parser("review-queue", parents=[common])
    review_p.add_argument("--queue", required=True)
    review_p.add_argument("--position", default="")
    review_p.add_argument("--delete-unreviewed", action="store_true")
    for field in ("subject", "action", "location", "equipment"):
        review_p.add_argument("--" + field, default="")
    review_p.add_argument("--keyword", action="append", default=[])
    review_p.set_defaults(func=review_queue)
    ingest_p = commands.add_parser("ingest", parents=[common])
    ingest_p.add_argument("--file", required=True)
    ingest_p.add_argument("--category", required=True)
    ingest_p.add_argument("--title", required=True)
    for field in ("subject", "action", "location", "equipment", "source-url", "publisher", "source-id"):
        ingest_p.add_argument("--" + field, default="")
    ingest_p.add_argument("--keyword", action="append", default=[])
    ingest_p.add_argument("--frame-evidence", required=True)
    ingest_p.add_argument("--cleanliness-evidence", required=True)
    ingest_p.set_defaults(func=ingest)
    search_p = commands.add_parser("search", parents=[common])
    search_p.add_argument("--usage", default=str(USAGE))
    search_p.add_argument("--deliveries-root", default=str(DELIVERIES_ROOT))
    search_p.add_argument("--current-project")
    for field in ("subject", "action", "location", "equipment", "keyword"):
        search_p.add_argument("--" + field, action="append", default=[])
    search_p.add_argument("--lookback-hours", type=int, default=168)
    search_p.add_argument("--min-duration", type=float, default=MIN_DURATION)
    search_p.add_argument("--limit", type=int, default=20)
    search_p.add_argument("--require-all", action=argparse.BooleanOptionalAction, default=True)
    search_p.add_argument("--prepare-review", action=argparse.BooleanOptionalAction, default=True, help="emit a 3-second review MP4 plus A/M/B frames for every returned candidate")
    search_p.add_argument("--review-dir", help="project-local folder for prepared candidate previews")
    search_p.add_argument("--output")
    search_p.set_defaults(func=search)
    commit_p = commands.add_parser("commit", parents=[common])
    commit_p.add_argument("--usage", default=str(USAGE))
    commit_p.add_argument("--asset-id", action="append", required=True)
    commit_p.add_argument("--project", required=True)
    commit_p.add_argument("--source-in", type=float)
    commit_p.add_argument("--source-out", type=float)
    commit_p.set_defaults(func=commit)
    reject_p = commands.add_parser("reject", parents=[common])
    for field in ("source-url", "source-id", "quick-hash", "sha256", "publisher"):
        reject_p.add_argument("--" + field, default="")
    reject_p.add_argument("--reason", required=True)
    reject_p.set_defaults(func=reject)
    return main


def main() -> int:
    args = parser().parse_args()
    try:
        return args.func(args)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
