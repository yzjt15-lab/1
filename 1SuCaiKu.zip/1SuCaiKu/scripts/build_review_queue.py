#!/usr/bin/env python3
"""Build an evidence-backed metadata review queue from the shared thumbnail index."""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from material_library import INDEX, quality_errors, read_json, write_json


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--visual-manifest", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    assets = read_json(INDEX, {"assets": []}).get("assets", [])
    rows = read_json(Path(args.visual_manifest), {}).get("rows", [])
    thumbnails = {str(row.get("path", "")).casefold(): row for row in rows if row.get("thumbnail")}
    queue = []
    for asset in assets:
        errors = set(quality_errors(asset))
        if errors & {"not_decodable", "not_landscape", "too_short", "low_resolution", "not_16_9"}:
            continue
        if not errors:
            continue
        row = thumbnails.get(str(asset["path"]).casefold())
        if not row or not Path(row["thumbnail"]).is_file():
            queue.append({"asset_id": asset["id"], "path": asset["path"], "frame_evidence": None, "timestamp": None, "status": "unreviewable", "errors": sorted(errors)})
            continue
        queue.append({"asset_id": asset["id"], "path": asset["path"], "frame_evidence": row["thumbnail"], "timestamp": row["timestamp"], "status": "pending_review", "errors": sorted(errors)})
    write_json(Path(args.output), {"count": len(queue), "candidates": queue})
    print(json.dumps({"count": len(queue), "output": args.output}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
