from __future__ import annotations

import tempfile
from datetime import datetime, timezone
from pathlib import Path

from material_library import commit_ledger, delivered_identities, distinct_sources, file_sha256, filter_candidates, identities, load_usage, recent_identities, recent_material_identities, source_family, write_json


def main() -> None:
    assert source_family(r"C:\库\片段_001.mp4") == source_family(r"C:\库\片段_002.mp4")
    asset = {"id": "a1", "path": r"C:\库\片段_001.mp4", "quick_hash": "h1", "source_id": "42"}
    assert "asset_id:a1" in identities(asset)
    assert [item["id"] for item in distinct_sources([
        {"id": "x1", "source_id": "42", "path": "x_001.mp4"},
        {"id": "x2", "source_id": "42", "path": "x_002.mp4"},
        {"id": "y1", "source_id": "43", "path": "y_001.mp4"},
    ])] == ["x1", "y1"]
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        path = root / "usage.json"
        write_json(path, {"uses": [{"asset_id": "a1", "sha256": "full-1", "used_at": datetime.now(timezone.utc).isoformat()}]})
        assert "asset_id:a1" in recent_identities(load_usage(path), 168)
        assert "sha256:full-1" in recent_material_identities(path, root / "empty-deliveries")
        project = root / "project"
        project.mkdir()
        ledger = project / "x_asset-ledger.json"
        write_json(ledger, {"assets": [{"id": "a2", "local_path": r"C:\库\来源_001.mp4"}]})
        write_json(project / "x_门禁.json", {
            "checked_at": datetime.now(timezone.utc).isoformat(), "terminal_allowed": True,
            "sha256": {"ledger": file_sha256(ledger)},
        })
        history = delivered_identities(root, 168)
        assert "asset_id:a2" in history
        assert "source_family:" + source_family(r"C:\库\来源_001.mp4") in history
        video = root / "candidate.mp4"
        video.write_bytes(b"video")
        index = root / "index.json"
        write_json(index, {"assets": [{
            "id": "canonical", "path": str(video), "probe_ok": True, "orientation": "landscape",
            "quick_hash": "qh", "source_id": "source-1",
        }]})
        filtered = filter_candidates(
            [{"asset_id": "visual", "path": str(video), "score": 1}], index, root / "empty-usage.json",
            root / "empty-deliveries", current_project=root / "current",
        )
        assert [item["asset_id"] for item in filtered] == ["visual"]
        assert filtered[0]["seven_day_eligible"] is True and filtered[0]["sha256"] == file_sha256(video)
        delivered_ledger = root / "delivered_asset-ledger.json"
        write_json(delivered_ledger, {"assets": [{"id": "visual", "local_path": str(video), "sha256": filtered[0]["sha256"]}], "uses": [{"asset_id": "visual", "source_in": 0, "source_out": 2}]})
        usage_path = root / "committed-usage.json"
        assert commit_ledger(delivered_ledger, root / "project-a", usage_path, root) == 1
        assert commit_ledger(delivered_ledger, root / "project-a", usage_path, root) == 0
        assert filter_candidates([{"asset_id": "visual", "path": str(video)}], index, usage_path, root / "empty-deliveries") == []
    print("ok")


if __name__ == "__main__":
    main()
