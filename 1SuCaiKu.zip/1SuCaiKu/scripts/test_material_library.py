from __future__ import annotations

import tempfile
from unittest.mock import patch
from datetime import datetime, timezone
from pathlib import Path

from material_library import backfill_metadata, commit_ledger, delivered_identities, distinct_sources, enrich_with_sidecar, file_sha256, filter_candidates, identities, ingest, load_usage, quality_errors, read_json, recent_identities, recent_material_identities, rejected_identities, review_queue, source_family, write_json


def main() -> None:
    assert source_family(r"C:\库\片段_001.mp4") == source_family(r"C:\库\片段_002.mp4")
    asset = {"id": "a1", "path": r"C:\库\片段_001.mp4", "quick_hash": "h1", "source_id": "42"}
    assert "asset_id:a1" in identities(asset)
    assert [item["id"] for item in distinct_sources([
        {"id": "x1", "source_id": "42", "path": "x_001.mp4"},
        {"id": "x2", "source_id": "42", "path": "x_002.mp4"},
        {"id": "y1", "source_id": "43", "path": "y_001.mp4"},
    ])] == ["x1", "y1"]
    clean = {"probe_ok": True, "orientation": "landscape", "duration": 4.1, "width": 1280, "height": 720, "subject": "x", "action": "x", "location": "x", "equipment": "x", "keywords": ["x"], "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True}
    assert quality_errors(clean) == []
    assert "too_short" in quality_errors({**clean, "duration": 4.0})
    assert "not_16_9" in quality_errors({**clean, "width": 1440, "height": 900})
    assert "cleanliness_not_verified" in quality_errors({**clean, "watermark_free": False})
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        args = type("Args", (), {"file": str(root / "portrait.mp4"), "root": str(root), "index": str(root / "index.json"), "ffprobe": None, "workers": 1, "category": "1. 商业航天与卫星"})()
        (root / "portrait.mp4").write_bytes(b"x")
        with patch("material_library.probe", return_value={"probe_ok": True, "orientation": "portrait"}):
            try:
                ingest(args)
                raise AssertionError("portrait ingest was accepted")
            except ValueError as error:
                assert str(error) == "only landscape video is accepted"
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        canonical = root / "canonical.mp4"
        canonical.write_bytes(b"video")
        write_json(canonical.with_suffix(".mp4.json"), {"path": "stale.mp4", "width": 1, "subject": "reviewed"})
        enriched = enrich_with_sidecar({"path": str(canonical), "width": 1280, "subject": "indexed", "keywords": []})
        assert enriched["path"] == str(canonical) and enriched["width"] == 1280 and enriched["subject"] == "reviewed"
        path = root / "usage.json"
        write_json(path, {"uses": [{"asset_id": "a1", "sha256": "full-1", "used_at": datetime.now(timezone.utc).isoformat()}]})
        assert "asset_id:a1" in recent_identities(load_usage(path), 168)
        assert "sha256:full-1" in recent_material_identities(path, root / "empty-deliveries")
        project = root / "project"
        project.mkdir()
        ledger = project / "x_asset-ledger.json"
        write_json(ledger, {"assets": [{"id": "a2", "local_path": r"C:\库\来源_001.mp4"}]})
        write_json(project / "x_门禁.json", {
            "checked_at": datetime.now(timezone.utc).isoformat(), "terminal_allowed": True,
            "sha256": {"ledger": file_sha256(ledger)},
        })
        history = delivered_identities(root, 168)
        assert "asset_id:a2" in history
        assert "source_family:" + source_family(r"C:\库\来源_001.mp4") in history
        video = root / "candidate.mp4"
        video.write_bytes(b"video")
        index = root / "index.json"
        write_json(index, {"assets": [{
            "id": "canonical", "path": str(video), "probe_ok": True, "orientation": "landscape",
            "quick_hash": "qh", "source_id": "source-1", "duration": 5, "width": 1280, "height": 720,
            "subject": "market", "action": "moves", "location": "exchange", "equipment": "screen", "keywords": ["market"], "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
        }]})
        filtered = filter_candidates(
            [{"asset_id": "visual", "path": str(video), "score": 1}], index, root / "empty-usage.json",
            root / "empty-deliveries", current_project=root / "current",
        )
        assert [item["asset_id"] for item in filtered] == ["visual"]
        assert filtered[0]["seven_day_eligible"] is True and filtered[0]["sha256"] == file_sha256(video)
        rejection_path = root / "rejections.json"
        write_json(rejection_path, {"items": [{"quick_hash": "qh", "reason": "overused"}]})
        assert "quick_hash:qh" in rejected_identities(rejection_path)
        assert filter_candidates(
            [{"asset_id": "visual", "path": str(video)}], index, root / "empty-usage.json",
            root / "empty-deliveries", rejection_path=rejection_path,
        ) == []
        evidence = root / "ingest-frame.jpg"
        evidence.write_bytes(b"frame")
        ingest_args = type("Args", (), {
            "file": str(video), "root": str(root / "ingest-root"), "index": str(root / "ingest-index.json"),
            "ffprobe": None, "workers": 1, "category": "5. 股市与市场", "title": "market",
            "subject": "market", "action": "moves", "location": "exchange", "equipment": "screen",
            "keyword": ["market"], "source_url": "", "publisher": "", "source_id": "",
            "frame_evidence": str(evidence), "cleanliness_evidence": "reviewed", "rejections": str(root / "empty-rejections.json"),
        })()
        with patch("material_library.probe", return_value={"probe_ok": True, "orientation": "landscape", "duration": 5, "width": 1280, "height": 720}), patch(
            "material_library.recent_material_identities", return_value={"sha256:" + file_sha256(video)}
        ):
            try:
                ingest(ingest_args)
                raise AssertionError("recently used material was ingested")
            except ValueError as error:
                assert "recently used" in str(error)
        assert filter_candidates([{"asset_id": "visual", "path": str(video)}], index, root / "empty-usage.json", root / "empty-deliveries", min_duration=6) == []
        delivered_ledger = root / "delivered_asset-ledger.json"
        write_json(delivered_ledger, {"assets": [{"id": "visual", "local_path": str(video), "sha256": filtered[0]["sha256"]}], "uses": [{"asset_id": "visual", "source_in": 0, "source_out": 2}]})
        usage_path = root / "committed-usage.json"
        assert commit_ledger(delivered_ledger, root / "project-a", usage_path, root) == 1
        assert commit_ledger(delivered_ledger, root / "project-a", usage_path, root) == 0
        assert filter_candidates([{"asset_id": "visual", "path": str(video)}], index, usage_path, root / "empty-deliveries") == []
        media = root / "1. 商业航天与卫星" / "火箭发射.mp4"
        media.parent.mkdir()
        media.write_bytes(b"metadata only")
        args = type("Args", (), {"root": str(root), "index": str(root / "backfill-index.json"), "ffprobe": None, "workers": 1, "output": None})()
        backfill_metadata(args)
        sidecar = media.with_suffix(".mp4.json")
        assert read_json(sidecar, {})["metadata_basis"] == "filename_category"
        evidence = root / "frame.jpg"
        evidence.write_bytes(b"frame")
        review_media = root / "review.mp4"
        review_media.write_bytes(b"video")
        queue = root / "queue.json"
        write_json(queue, {"candidates": [{"path": str(review_media), "frame_evidence": str(evidence), "timestamp": 1.0}]})
        args = type("Args", (), {"queue": str(queue), "position": "1", "delete_unreviewed": False, "subject": "robot", "action": "moves", "location": "lab", "equipment": "arm", "keyword": ["robot"]})()
        review_queue(args)
        reviewed = read_json(review_media.with_suffix(".mp4.json"), {})
        assert reviewed["frame_evidence"] == str(evidence) and reviewed["cleanliness_checked_at"] and reviewed["watermark_free"]
    print("ok")


if __name__ == "__main__":
    main()
