import json
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent))
from material_library import field_score, filter_candidate_groups, parser, prepare_candidate_preview, prepare_candidate_previews, search, semantic_score


if __name__ == "__main__":
    tagged = {"subject": "半导体", "location": "无尘车间", "equipment": "芯片制造设备"}
    pcb = {"path": "PCB电路板芯片微距.mp4"}
    assert semantic_score("半导体无尘车间芯片制造设备", tagged) >= 0.5
    assert semantic_score("半导体无尘车间芯片制造设备", pcb) < 0.5
    assert field_score("无尘车间", {"location": "无尘车间", "keywords": []}, "location") == 1.0
    assert field_score("无尘车间", {"location": "机房", "keywords": []}, "location") == 0.0
    parsed = parser().parse_args(["search", "--keyword", "market", "--current-project", "project"])
    assert parsed.limit == 8 and not hasattr(parsed, "prepare_review")
    try:
        search(SimpleNamespace(limit=0))
        raise AssertionError("zero search limit was accepted")
    except ValueError as error:
        assert "at least 1" in str(error)
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        source = root / "source.mp4"
        source.write_bytes(b"source")
        item = {"id": "asset-a", "path": str(source), "duration": 10.0, "quick_hash": "abc", "source_in": 2.0, "source_out": 7.0}

        def write_fake_output(command, **_kwargs):
            time.sleep(0.005)
            for value in command:
                path = Path(value)
                if ".part." in path.name:
                    path.write_bytes(b"generated")
            return SimpleNamespace(returncode=0)

        with patch("material_library._decode_preview_bundle", return_value=True), patch("material_library.subprocess.run", side_effect=write_fake_output) as run:
            first = prepare_candidate_preview(item, root / "review", "ffmpeg")
            second = prepare_candidate_preview(item, root / "review", "ffmpeg")
            assert first["preview_cache_hit"] is False and second["preview_cache_hit"] is True
            first_command = run.call_args_list[0].args[0]
            assert first_command[first_command.index("-ss") + 1] == "3.000"
            assert "split=4" in first_command[first_command.index("-filter_complex") + 1]
            assert [row["timestamp"] for row in first["review_frames"]] == [3.6, 4.5, 5.4]
            assert run.call_count == 1
            manifest = Path(first["review_clip_path"]).with_name("preview-manifest.json")
            manifest.write_text("{", encoding="utf-8")
            rebuilt = prepare_candidate_preview(item, root / "review", "ffmpeg")
            assert rebuilt["preview_cache_hit"] is False and run.call_count == 2
            manifest.write_text("[]", encoding="utf-8")
            rebuilt = prepare_candidate_preview(item, root / "review", "ffmpeg")
            assert rebuilt["preview_cache_hit"] is False and run.call_count == 3
            Path(first["review_frames"][0]["path"]).write_bytes(b"")
            rebuilt = prepare_candidate_preview(item, root / "review", "ffmpeg")
            assert rebuilt["preview_cache_hit"] is False and run.call_count == 4

            run.reset_mock()
            with ThreadPoolExecutor(max_workers=2) as pool:
                concurrent = list(pool.map(lambda _value: prepare_candidate_preview(item, root / "concurrent", "ffmpeg"), range(2)))
            assert run.call_count == 1
            assert sorted(row["preview_cache_hit"] for row in concurrent) == [False, True]

        candidates = [{"id": value, "path": str(root / f"{value}.mp4"), "duration": 5.0} for value in ("a", "b", "c")]
        for candidate in candidates:
            Path(candidate["path"]).write_bytes(candidate["id"].encode("ascii"))
        candidates.insert(1, {"id": "a-later", "path": candidates[0]["path"], "duration": 5.0, "source_in": 2.0, "source_out": 5.0})

        def prepare_or_fail(candidate, *_args, **_kwargs):
            if candidate["id"] == "b":
                raise subprocess.CalledProcessError(1, "ffmpeg")
            return {"prepared_visual": True, "review_clip_path": candidate["path"], "review_frames": [{"label": label} for label in "AMB"]}

        with patch("material_library.prepare_candidate_preview", side_effect=prepare_or_fail):
            prepared = prepare_candidate_previews(candidates, root / "review", ffmpeg="ffmpeg", workers=3)
        assert [item["id"] for item in prepared] == ["a", "a-later", "c"]
        assert all([frame["label"] for frame in item["review_frames"]] == list("AMB") for item in prepared)

        indexed = {
            "id": "shared", "path": str(source), "probe_ok": True, "orientation": "landscape",
            "duration": 10.0, "width": 1280, "height": 720, "subject": "market", "action": "moves",
            "location": "exchange", "equipment": "screen", "keywords": ["market"],
            "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
        }
        index = root / "index.json"
        index.write_text(json.dumps({"assets": [indexed]}), encoding="utf-8")
        groups = [[
            {"path": str(source), "duration": 10.0, "source_in": 1.0, "source_out": 6.0},
            {"path": str(source), "duration": 10.0, "source_in": 2.0, "source_out": 7.0},
        ], [{"path": str(source), "duration": 10.0, "source_in": 4.0, "source_out": 9.0}]]
        with patch("material_library.full_hash", return_value="f" * 64) as full_hash:
            filtered = filter_candidate_groups(groups, index_path=index, usage_path=root / "usage.json", deliveries_root=root / "deliveries", current_project=root, rejection_path=None)
        assert full_hash.call_count == 1
        assert [[item["source_in"] for item in group] for group in filtered] == [[1.0], [4.0]]
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        video, output = root / "market.mp4", root / "result.json"
        video.write_bytes(b"market")
        args = SimpleNamespace(
            root=str(root), index=str(root / "index.json"), ffprobe=None, workers=1,
            usage=str(root / "usage.json"), deliveries_root=str(root / "deliveries"),
            rejections=str(root / "rejections.json"),
            lookback_hours=168, subject=[], action=[], location=[], equipment=[],
            keyword=["market"], min_duration=1.0, require_all=True, limit=10, output=str(output),
            current_project=str(root / "project"), review_dir=None,
        )
        asset = {"id": "a", "path": str(video), "probe_ok": True, "orientation": "landscape", "duration": 5.0, "width": 1280, "height": 720, "subject": "market", "action": "moves", "location": "exchange", "equipment": "screen", "keywords": ["market"], "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True}
        with patch("material_library.index_assets", return_value={"assets": [asset]}), patch("material_library.recent_material_identities", return_value={"sha256:" + __import__("hashlib").sha256(b"market").hexdigest()}):
            assert search(args) == 0
        assert json.loads(output.read_text(encoding="utf-8"))["count"] == 0
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        assets = []
        for index in range(5):
            path = root / f"{chr(97 + index)}-market.mp4"
            path.write_bytes(str(index).encode("ascii"))
            assets.append({"id": str(index), "path": str(path), "probe_ok": True, "orientation": "landscape", "duration": 5.0, "width": 1280, "height": 720, "subject": "market", "action": "moves", "location": "exchange", "equipment": "screen", "keywords": ["market"], "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True})
        args = SimpleNamespace(root=str(root), index=str(root / "index.json"), ffprobe=None, workers=1, usage=str(root / "usage.json"), deliveries_root=str(root / "deliveries"), rejections=str(root / "rejections.json"), lookback_hours=168, subject=[], action=[], location=[], equipment=[], keyword=["market"], min_duration=1.0, require_all=True, limit=2, output=None, current_project=str(root / "project"), review_dir=None)
        with patch("material_library.index_assets", return_value={"assets": assets}), patch("material_library.recent_material_identities", return_value=set()), patch("material_library.rejected_identities", return_value=set()), patch("material_library.file_sha256", return_value="f" * 64) as hashes, patch("material_library.prepare_candidate_previews", side_effect=lambda items, *_args, **_kwargs: items):
            assert search(args) == 0
        assert hashes.call_count == 2
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        first, fallback = root / "market-0.mp4", root / "market-1.mp4"
        first.write_bytes(b"old")
        fallback.write_bytes(b"fresh")
        assets = [
            {"id": "old", "path": str(first), "probe_ok": True, "orientation": "landscape", "duration": 5.0, "width": 1280, "height": 720, "subject": "market", "action": "moves", "location": "exchange", "equipment": "screen", "keywords": ["market"], "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True},
            {"id": "fresh", "path": str(fallback), "probe_ok": True, "orientation": "landscape", "duration": 5.0, "width": 1280, "height": 720, "subject": "market", "action": "moves", "location": "exchange", "equipment": "screen", "keywords": ["market"], "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True},
        ]
        args = SimpleNamespace(root=str(root), index=str(root / "index.json"), ffprobe=None, workers=1, usage=str(root / "usage.json"), deliveries_root=str(root / "deliveries"), rejections=str(root / "rejections.json"), lookback_hours=168, subject=[], action=[], location=[], equipment=[], keyword=["market"], min_duration=1.0, require_all=True, limit=1, output=None, current_project=str(root / "project"), review_dir=None)
        old_hash = __import__("hashlib").sha256(b"old").hexdigest()
        with patch("material_library.index_assets", return_value={"assets": assets}), patch("material_library.recent_material_identities", return_value={"sha256:" + old_hash}), patch("material_library.rejected_identities", return_value=set()), patch("material_library.file_sha256", side_effect=[old_hash, __import__("hashlib").sha256(b"fresh").hexdigest()]), patch("material_library.prepare_candidate_previews", side_effect=lambda items, *_args, **_kwargs: items) as previews:
            assert search(args) == 0
        assert [item["id"] for item in previews.call_args.args[0]] == ["fresh"]
    print("ok")
