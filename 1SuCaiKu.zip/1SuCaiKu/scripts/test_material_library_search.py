import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent))
from material_library import field_score, search, semantic_score


if __name__ == "__main__":
    tagged = {"subject": "半导体", "location": "无尘车间", "equipment": "芯片制造设备"}
    pcb = {"path": "PCB电路板芯片微距.mp4"}
    assert semantic_score("半导体无尘车间芯片制造设备", tagged) >= 0.5
    assert semantic_score("半导体无尘车间芯片制造设备", pcb) < 0.5
    assert field_score("无尘车间", {"location": "无尘车间", "keywords": []}, "location") == 1.0
    assert field_score("无尘车间", {"location": "机房", "keywords": []}, "location") == 0.0
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        video, output = root / "market.mp4", root / "result.json"
        video.write_bytes(b"market")
        args = SimpleNamespace(
            root=str(root), index=str(root / "index.json"), ffprobe=None, workers=1,
            usage=str(root / "usage.json"), deliveries_root=str(root / "deliveries"),
            rejections=str(root / "rejections.json"),
            lookback_hours=168, subject=[], action=[], location=[], equipment=[],
            keyword=["market"], min_duration=1.0, require_all=True, limit=10, output=str(output),
            current_project=None, prepare_review=False, review_dir=None,
        )
        asset = {"id": "a", "path": str(video), "probe_ok": True, "orientation": "landscape", "duration": 5.0, "width": 1280, "height": 720, "subject": "market", "action": "moves", "location": "exchange", "equipment": "screen", "keywords": ["market"], "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True}
        with patch("material_library.index_assets", return_value={"assets": [asset]}), patch("material_library.recent_material_identities", return_value={"sha256:" + __import__("hashlib").sha256(b"market").hexdigest()}):
            assert search(args) == 0
        assert json.loads(output.read_text(encoding="utf-8"))["count"] == 0
    print("ok")
