---
name: manage-material-library
description: Manage the configured local SuCaiKu video library through one verified workflow for ingesting downloads, refreshing the canonical index, five-field semantic search, 168-hour deduplication, usage registration, and integrity auditing. Use whenever Codex downloads, imports, searches, selects, cites, deletes, or audits reusable video material, including video-production tasks that need library candidates.
---

# 素材库统一管理

所有素材库写入、检索和正式引用都通过 `scripts/material_library.py`。不要复制索引算法或另建使用台账。

默认从当前用户目录推导素材库和交付文档目录；迁移时用 `INFOFLOW_USER_ROOT`、`INFOFLOW_CONFIG_ROOT`、`INFOFLOW_MATERIAL_LIBRARY_ROOT`、`INFOFLOW_DOCUMENT_OUTPUT_DIR` 覆盖，不要在脚本中新增个人绝对路径。

## 固定顺序

1. 下载或收到新文件后运行 `ingest`，不要直接复制进素材库。
2. 选材前运行 `audit`；内容有增删时它会增量刷新统一索引。
3. 用五项语义运行 `search`。默认排除竖屏、不可解码和近 168 小时已用素材。
4. 逐段目检最终候选后才能入轴；语义标签不等于画面验收。
5. 只有正式成片采用素材后运行 `commit`，预览和候选不得登记为已用。

上层视频 Skill 已有视觉语义索引时，保留其排序能力，但必须将结果传给 `scripts/material_library.py` 的 `filter_candidates()`；正式交付后调用 `commit_ledger()`。上层不得自行实现素材资格或七日去重。

先完整阅读 `references/schema.md`，再执行对应命令。所有示例都从本 Skill 根目录运行。

## 质量硬门槛

- 入库只接受：可解码、横屏、至少 1280x720、源片至少 4 秒，以及完整的 `subject/action/location/equipment/keywords`。
- 严格检索只在对应语义字段和 `keywords` 内匹配；文件名、路径和分类目录不是画面证据。
- 返回项必须带 `quality_gate=pass`。标签命中不等于画面验收，入轴仍须由上层 Skill 保存实际选段和帧证据。
- 历史素材缺标签时，先运行 `scripts/build_review_queue.py` 生成真实抽帧复核队列；不得从文件名批量补造五项语义。
- 入库源片必须 **大于** 4 秒、至少 1280x720、16:9；必须提交实际帧证据，并在该帧确认无水印、无内嵌字幕、无平台覆盖。缺任一项即拒绝。
- 分类仅可使用七个标准类；按 `references/classification.md` 的画面定义归类，类别与帧证据不一致即拒绝入库。

## 命令

```powershell
python scripts/material_library.py audit --output <审计.json>
```

`audit` 返回 1 表示存在不可解码、竖屏或索引漂移；报告异常未处理前不得引用相关文件。非法分类只报告，不自动移动或删除。

```powershell
python scripts/material_library.py ingest --file <下载文件> --category "2. 半导体与芯片" --title <标题> --subject <主体> --action <动作> --location <地点> --equipment <设备> --keyword <关键词> [--source-url <URL>] [--publisher <发布者>] [--source-id <来源ID>]
```

一律拒绝竖屏，不提供例外。复制后重新计算完整 SHA-256。相同内容已存在时返回现有资产，不再复制。

```powershell
python scripts/material_library.py search --subject <主体> --action <动作> --location <地点> --equipment <设备> --keyword <关键词> --limit 20 --output <候选.json>
```

默认要求每个提供的语义字段组均命中。确需探索性召回时才使用 `--no-require-all`，且不得直接入轴。

```powershell
python scripts/material_library.py commit --asset-id <asset-id> --project <工程完整路径> [--source-in <秒>] [--source-out <秒>]
```

一次采用多个素材时重复传 `--asset-id`。提交前确认工程确为正式采用版本。

长期高频、审美疲劳或明确停用的素材，登记到永久排除清单；后续检索和 `filter_candidates()` 会自动拦截：

```powershell
python scripts/material_library.py reject --source-url <URL> --quick-hash <quick_hash> --reason <原因>
```

## 强制边界

- 不直接编辑统一索引和使用台账。
- 不以目录名、文件名或前 N 条结果代替五项语义和逐段目检。
- 不把来源字段缺失伪装为已有来源；来源尽力登记但不得编造。
- 不自动删除、移动、改名异常素材；先报告精确目标，删除需用户明确授权。
- 素材库发生增删后先 `audit`，旧候选清单立即失效。
- 其他视频 Skill 若与本 Skill 的素材索引或七日去重规则冲突，以本 Skill 为唯一入口；视频成片自身的视觉、语义和交付门禁仍由对应视频 Skill 负责。
