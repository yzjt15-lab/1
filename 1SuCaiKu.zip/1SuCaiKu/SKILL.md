---
name: manage-material-library
description: Manage the configured local SuCaiKu video library through one verified workflow for ingesting downloads, maintaining the Chinese-CLIP visual semantic index, five-field semantic search, 168-hour deduplication, usage registration, and integrity auditing. Use whenever Codex downloads, imports, searches, selects, cites, deletes, or audits reusable video material, including video-production tasks that need library candidates.
---

# 素材库统一管理

所有素材库写入、检索和正式引用都通过 `scripts/material_library.py`。不要复制索引算法或另建使用台账。

默认从当前用户目录推导素材库和交付文档目录；迁移时用 `INFOFLOW_USER_ROOT`、`INFOFLOW_CONFIG_ROOT`、`INFOFLOW_MATERIAL_LIBRARY_ROOT`、`INFOFLOW_DOCUMENT_OUTPUT_DIR` 覆盖，不要在脚本中新增个人绝对路径。

## 固定顺序

1. 下载或收到新文件后运行 `ingest`，不要直接复制进素材库。
2. 每次 `ingest` 成功后，立即按新资产完整路径增量更新 Chinese-CLIP 画面语义索引；不得只刷新统一 JSON 索引。批量入库时一次传入本批全部新增路径，只加载一次模型。
3. 选材或宣布补库完成前同时运行素材 `audit` 与画面语义索引覆盖审计。统一索引中的每个合格资产都必须在向量索引中有有效行或明确失败记录；存在未索引、抽帧失败、向量与清单行数不一致或异常缩水时即未完成。
4. 用五项语义运行 `search --current-project <工程> [--review-dir <工程/候选预览>]`。未显式指定预览目录时固定使用 `<当前工程>/候选预览`，同一工程的全部查询共用该目录；默认最多返回 8 条，并排除竖屏、不可解码和近 168 小时已用素材。每条返回候选必须同时具备语义命中区间内的 3 秒预览 MP4 与 A/M/B 三帧；素材身份、命中区间和截取参数未变化且整包哈希、完整解码仍有效时复用缓存，否则整包重建。候选包最多四路并行生成，不得省略任一证据文件，也不存在无预览的生产搜索开关。
5. 逐段目检检索时已生成的预览包后才能入轴；语义标签或向量相似度都不等于画面验收，预览生成失败的候选不得返回。
6. 只有正式成片采用素材后运行 `commit`，预览和候选不得登记为已用。

画面语义索引是素材库必备索引，不再是上层视频 Skill 的可选能力。索引维护、增量与全量重建、覆盖审计和失败规则见 [references/visual-index.md](references/visual-index.md)。上层视频 Skill 可保留排序与查询编排，但必须把全部查询一次传给 `scripts/material_library.py` 的 `filter_candidate_groups()`；它只加载一次统一索引、去重历史和源文件哈希，并复用同一套 `filter_candidates()` 权威门禁。正式交付后调用 `commit_ledger()`。上层不得自行实现素材资格或七日去重。

先完整阅读 `references/schema.md`，再执行对应命令。所有示例都从本 Skill 根目录运行。

## 质量硬门槛

- 入库只接受：可解码、横屏、至少 1280x720、源片至少 4 秒，以及完整的 `subject/action/location/equipment/keywords`。
- 严格检索只在对应语义字段和 `keywords` 内匹配；文件名、路径和分类目录不是画面证据。
- 返回项必须带 `quality_gate=pass`。标签命中不等于画面验收，入轴仍须由上层 Skill 保存实际选段和帧证据。
- 历史素材缺标签时，先运行 `scripts/build_review_queue.py` 生成真实抽帧复核队列；不得从文件名批量补造五项语义。
- 入库完成门禁同时要求画面语义索引覆盖率为 100%，`asset_count` 与统一索引合格资产数一致，`frame_count` 与向量行数一致，且 `failure_count=0`、`excluded_asset_count=0`。未达标时继续修复或明确报告，不得声称素材库已补齐。
- 入库源片必须 **大于** 4 秒、至少 1280x720、16:9；必须提交实际帧证据，并在该帧确认无水印、无内嵌字幕、无平台覆盖。缺任一项即拒绝。
- 分类仅可使用六个标准类；按 `references/classification.md` 的画面定义归类，类别与帧证据不一致即拒绝入库。

## 命令

```powershell
python scripts/material_library.py audit --output <审计.json>
```

`audit` 返回 1 表示存在不可解码、竖屏或索引漂移；报告异常未处理前不得引用相关文件。非法分类只报告，不自动移动或删除。

```powershell
python scripts/material_library.py ingest --file <下载文件> --category "2. 半导体与芯片" --title <标题> --subject <主体> --action <动作> --location <地点> --equipment <设备> --keyword <关键词> [--source-url <URL>] [--publisher <发布者>] [--source-id <来源ID>]
```

一律拒绝竖屏，不提供例外。复制后重新计算完整 SHA-256。相同内容已存在时返回现有资产，不再复制。

```powershell
python scripts/material_library.py search --subject <主体> --action <动作> --location <地点> --equipment <设备> --keyword <关键词> --current-project <工程完整路径> --limit 8 --review-dir <工程工作区/候选预览> --output <候选.json>
```

默认要求每个提供的语义字段组均命中。确需探索性召回时才使用 `--no-require-all`，且不得直接入轴。

```powershell
python scripts/material_library.py commit --asset-id <asset-id> --project <工程完整路径> [--source-in <秒>] [--source-out <秒>]
```

一次采用多个素材时重复传 `--asset-id`。提交前确认工程确为正式采用版本。

长期高频、审美疲劳或明确停用的素材，登记到永久排除清单；后续检索和 `filter_candidates()` 会自动拦截：

```powershell
python scripts/material_library.py reject --source-url <URL> --quick-hash <quick_hash> --reason <原因>
```

## 强制边界

- 不直接编辑统一索引和使用台账。
- 不以目录名、文件名或前 N 条结果代替五项语义和逐段目检。
- 不把来源字段缺失伪装为已有来源；来源尽力登记但不得编造。
- 不自动删除、移动、改名异常素材；先报告精确目标，删除需用户明确授权。
- 素材库发生增删后先 `audit`，旧候选清单立即失效。
- 素材库发生增删后必须同步增量更新画面语义索引；只完成 `audit` 或统一 JSON 索引不算完成。
- 其他视频 Skill 若与本 Skill 的素材索引或七日去重规则冲突，以本 Skill 为唯一入口；视频成片自身的视觉、语义和交付门禁仍由对应视频 Skill 负责。
