# 画面语义索引维护合同

## 固定实现与位置

- 模型：`OFA-Sys/chinese-clip-vit-base-patch16`。
- 资产输入：素材库统一索引 `2026-08-13_文档_素材库统一索引.json`。
- 默认输出：`<素材库>/.cache/visual-semantic-index`。
- 复用现有 `1QuXian/scripts/visual_semantic_index.py` 实现；可用 `INFOFLOW_VISUAL_SEMANTIC_INDEX` 显式覆盖。不要复制或另写一套向量算法。

## 日常增量

`ingest` 成功并刷新统一索引后，把本批所有新资产的库内完整路径作为重复的 `--path` 参数一次传入。模型、文件大小和 `mtime_ns` 未变化的资产必须复用既有向量。

```powershell
python <visual_semantic_index.py> build --asset-index <统一索引.json> --output-dir <素材库/.cache/visual-semantic-index> --path <新增资产一.mp4> --path <新增资产二.mp4> --interval 3 --max-samples 24 --batch-size 32
```

索引缺失、异常缩水或未索引资产超过 12 条时，增量命令必须停止；只有独立维护任务或用户明确要求补齐索引时才能运行 `--full-rebuild`。不得在视频生产任务中静默冷建全库。

## 完成审计

完成前先运行统一素材 `audit`，再核对画面索引：

1. `manifest.asset_count` 等于统一索引中可解码合格资产数。
2. `manifest.frame_count` 等于 `len(manifest.rows)`，也等于 `embeddings.npy.shape[0]`。
3. 每个统一索引资产路径都在 `manifest.assets` 中，且文件大小、`mtime_ns` 与当前资产一致。
4. `failure_count=0`、`excluded_asset_count=0`，每个资产至少有一个 `row_indices`。
5. 用至少一个与本批分类对应的查询做检索冒烟测试，返回结果路径必须属于当前素材库；该测试只证明索引可查询，不替代人工画面验收。

任一条件不满足即为未完成。只刷新统一 JSON 索引、只生成缩略图或只得到可搜索结果，都不能宣告画面语义索引完成。

## 抽帧失败处置

- 首次抽帧失败时，只对失败资产以 `--workers 1` 重新构建并保留原时间点，不得通过偏移时间点或复制邻帧伪造覆盖。
- 单线程仍失败时，用 FFmpeg 对该资产执行从头到尾的完整解码检查；`ffprobe` 能读取时长不等于视频完整可解码。
- 完整解码失败即按损坏资产上报准确路径和失败时间点，保留正式库原件，准备经过 A/M/B 复核的等价候选；只有用户明确同意后才能替换或删除原资产。
- 损坏资产未处置前，`excluded_asset_count` 不得归零，也不得宣告全库画面语义索引完成。

## 全量维护

```powershell
python <visual_semantic_index.py> build --asset-index <统一索引.json> --output-dir <素材库/.cache/visual-semantic-index> --interval 3 --max-samples 24 --batch-size 32 --full-rebuild
```

全量任务完成后必须执行上面的完成审计，并保存统计与查询冒烟测试结果。
