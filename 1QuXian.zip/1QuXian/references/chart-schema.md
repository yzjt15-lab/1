# 曲线图表配置合同

`scripts/render_market_chart.py` 只使用用户文案、用户时间轴或用户已经接受的上下文数据，不自行检索或修正数据。支持的 `chart_kind`：

所有图表固定使用 `assets/reference-pages/` 的黑金桌面版视觉。可选字段：`labels[]` 提供横轴标签，`left_axis_label`、`right_axis_label` 提供双轴名称，`annotations[]` 提供有数据依据的关键标注，`reference_lines[] = [{value,label}]` 提供 K 线压力/支撑线。`dual_axis_trend` 必须恰好两组序列并分别按左右轴独立缩放。

- `relative_return`：分时或区间相对涨跌折线
- `futures_position`：股指期货会员持仓柱形图
- `dual_axis_trend`：双轴历史趋势图
- `kline_wave`：K 线波浪标注底图
- `kline_fibonacci`：带 0.236/0.382/0.5/0.618 回撤线的 K 线图

折线、柱形或双轴图配置：

```json
{
  "id": "chart-c01-01",
  "chart_kind": "relative_return",
  "title": "主要指数区间表现",
  "data_interval": "2026年1月至7月",
  "data_metric": "累计涨跌幅",
  "series": [
    {"label": "指数甲", "values": [0, 1.2, 0.8, 2.4]},
    {"label": "指数乙", "values": [0, -0.4, 0.5, 1.1]}
  ],
  "source": ""
}
```

K 线图配置：

```json
{
  "id": "chart-c02-01",
  "chart_kind": "kline_fibonacci",
  "title": "标的回撤结构",
  "data_interval": "日线",
  "data_metric": "价格",
  "ohlc": [
    {"open": 10.0, "high": 10.8, "low": 9.7, "close": 10.5},
    {"open": 10.5, "high": 11.2, "low": 10.2, "close": 10.9}
  ],
  "source": ""
}
```

生成命令：

```powershell
python "<SKILL_ROOT>\scripts\render_market_chart.py" --config <图表配置.json> --output-dir <叠层目录>
```

时间轴中的对应 overlay 必须使用 `type: "chart"`，固定 4.5 秒；这是对信息页 4.0 秒默认值的显式特例与覆盖。overlay `type` 只允许 `hook|news|chart`；`fact|data|number|comparison|causal` 只允许作为图表的 `information_task`，若写入 `type`，`preflight.py` 必须失败。图表页还须保存：`information_task`、`chart_kind`、`data_chain_id`、`data_interval`、`data_metric`、`source_state`、`chapter_id`、`evidence_id`、`background_shot_id`、`image_path` 与非空 `chinese_text`。`information_task` 必须与章节证据任务相同。顶层 `chart_inventory[]` 必须覆盖全部五种 `chart_kind`，生成项用 `overlay_ids[]` 绑定图表页，跳过项写明 `skip_reason`。
