# 提速工作流

## 固定环境

- Python：`C:\Users\28723\Documents\Codex\2026-07-09\yon\work\voice-clone-env\Scripts\python.exe`
- FFmpeg：优先 PATH；找不到时使用 `C:\Users\28723\Documents\Codex\2026-07-09\yon\work\bin\ffmpeg.exe`
- 持久缓存：`C:\Users\28723\Documents\Codex\2026-08-01_工程_1XinXiLiu_持久缓存`
- 画面语义索引：`持久缓存\visual-semantic-index`
- 中文字体：依次查找 `C:\Windows\Fonts\msyhbd.ttc`、`msyh.ttc`、`simhei.ttf`

不要每个任务重新搜索 Python、FFmpeg、字体或编码参数。缓存可以删除后重建，但不得把缓存文件当作来源台账。

## 端到端计时与预算

完整输入一到齐就启动墙钟计时，不得等到渲染才计时；生产耗时扣除已记录的用户确认等待。第 10 分钟尚未进入正式渲染时，停止并报告唯一阻塞点；第 20 分钟未通过交付门禁时，停止后续生产。默认并行分支阈值如下，不能相加为端到端承诺：

| 阶段 | 预算 | 超时时动作 |
|---|---:|---|
| `semantic_index` 素材向量更新 | 60 秒 | 仅允许小批增量；缺索引、异常缩水或超过 12 条新增时转入独立维护。 |
| `news` 新闻核验与截图 | 120 秒 | 记录受限网页、争议事实或缺失来源；立即汇报，不降低核验标准。 |
| `assets` 镜头级素材匹配 | 180 秒 | 记录缺失关键词段；改用有来源的官方同主题替代并登记原因。 |
| `timeline` 时间线与信息页 | 120 秒 | 停止重新设计，保留已冻结的镜头与页面清单。 |
| `render_review` 渲染与复审 | 600 秒 | 第 10 分钟仍未启动时不再进入正式渲染；报告唯一阻塞点。 |

使用 `workflow_metrics.py` 的 `start/stage-start/stage-end/wait-start/wait-end/budget-check/report` 子命令。仅在实际请求用户确认前后记录等待。`stage-end --note` 记录超时原因。端到端墙钟从收到文案、时长和标题开始，到 `deliver` 门禁通过结束；报告必须分别给出生产耗时和等待用户确认耗时，不得用索引、编码或解码的局部基准代表总体耗时。

## 固定结构与单一入口

- 55.0–60.24 秒、用户未指定其他分镜结构：使用 `assets/templates/fast-60s-13-shots.json`。13 个槽位只承载真实视频、钩子、新闻和图表节点；所有页面仍以真实视频为底。
- 其他时长：使用通用语义拆分，但仍保持单镜不超过 5 秒。
- `fast_pipeline.py init`：只生成任务状态和端到端计时文件；语义、章节、证据和图表规划完成后才建立时间线。
- `fast_pipeline.py finalize`：语义和素材确认后，一次完成准备、预检、渲染、台账和首次联系表。
- `fast_pipeline.py approve`：代理目检联系表后，一次完成视觉批准和全片解码。
- `fast_pipeline.py deliver`：核验终片、时间线、预检、台账和最终复审，生成绑定 SHA-256 的终态门禁报告；只有退出码 `0` 才允许交付。

这四个子命令是同一入口的质量关口，不允许把新闻核验、人工语义确认、后台进程启动或首审生成伪装为自动完成。

## 画面语义索引

## 高频真实素材包、新闻事实卡与并行研究

- 入轴前按主体、动作、地点、设备、关键词筛选真实视频；每条必须有 `local_path` 和源文件哈希。来源字段可记录但不是入轴条件。
- 使用 `build_provenance_pack.py` 合并历史 `asset-ledger`，生成可复用来源素材包；`build_asset_index.py` 构建索引时必须带入该包，并排除缓存、虚拟环境、工作树、测试结果和渲染产物。
- 新闻事实卡必须含标题、发布日期、关键事实、原始链接、发布者、截图路径和适用关键词。写入、校验和检索都按 `trusted-news-sources.json` 校验来源域名。
- 收到文案后，使用 `fast_pipeline.py research` 同时检索画面和事实卡。人工只从 `eligible_visual_candidates` 与有效 `fact_cards` 选择；每个候选已含缩略图、建议 5 秒区间、URL、发布者和来源说明，不再逐个打开无来源视频查找。

```powershell
python scripts/build_provenance_pack.py --ledger <asset-ledger-1.json> --ledger <asset-ledger-2.json> --output <日期_文档_高频真实素材_来源素材包.json>
python scripts/news_fact_cards.py validate --cache <日期_文档_新闻事实卡_缓存.json>
python scripts/fast_pipeline.py research --index-dir <持久缓存\visual-semantic-index> --fact-cache <日期_文档_新闻事实卡_缓存.json> --query <关键词一> --category <分类一> --query <关键词二> --category <分类二> --delivery-root <历史工程根目录> --current-project <当前工程> --reject-asset-id <人工拒绝素材ID> --top-k 12 --output <日期_文档_并行研究包.json>
```

使用 `OFA-Sys/chinese-clip-vit-base-patch16` 对视频代表帧建立中文图文向量索引。先查画面语义，再查文件名与人工标签：

```powershell
python scripts/fast_pipeline.py search --index-dir <持久缓存\visual-semantic-index> --query "晶圆制造设备" --top-k 12 --clip-duration 5 --output <候选.json>
```

候选返回缩略图、时间点、相似度和可入轴 `source_in/source_out`。来源字段缺失不影响入轴；仍须通过五项语义、连续解码、时长与源文件哈希去重校验。模型、文件大小和 `mtime_ns` 未变化时复用已有向量；新增或修改素材才重新抽帧编码。

建立或增量更新索引。日常生产只传入当天新增/修改的精确 `--path`；`--path` 会保留其余有效向量。索引缺失、异常缩水或未索引素材超过 12 条时，脚本会拒绝静默全量重建，只有明确维护窗口才允许 `--full-rebuild`：

```powershell
python scripts/visual_semantic_index.py build --asset-index <asset-index.json> --output-dir <持久缓存\visual-semantic-index> --path <新增素材.mp4> --interval 3 --max-samples 24 --batch-size 32 --metrics <端到端耗时.json>
```

全库冷建只允许在独立维护窗口执行，不能占用视频生产的 20 分钟预算。未变素材应复用已有向量；新增素材只增量处理。把同一条视频的所有镜头查询作为一次 `fast_pipeline.py research` 调用传入，以共享一次模型加载；相同查询还会复用 manifest 绑定的本地查询缓存。

网络规则：若 `huggingface.co` 连接超时，可设置 `HF_ENDPOINT=https://hf-mirror.com`、`HF_HUB_DISABLE_XET=1` 后首次下载模型；模型进入本地缓存后，不再依赖网络完成检索。不得因为网络受限跳过来源核验。

来源字段只作为素材说明；所有语义命中均可按五项语义、连续解码、时长和源文件哈希去重结果进入时间线。

## 两种执行模式

| 用户表达 | 模式 | 复审方式 |
|---|---|---|
| “直接做”“视频做出来”“直接渲染” | 直接模式 | 代理内部审查静态联系表；只有运动不确定时制作不超过 2 秒的动态预览，不等待用户确认。 |
| 未明确要求直接出片，且版式/文案/颜色仍可能修改 | 审批模式 | 一次性提交静态联系表或不超过 2 秒的预览，汇总确认后只渲染一次终版。 |

任何模式都不得跳过来源、时间轴预检、全片解码和逐镜复审。

## 冷缓存流程

1. 保存文案并初始化任务状态。约 60 秒视频只能在完成语义、章节、证据和图表规划后，把固定结构作为实拍切换时长骨架：

```powershell
python scripts/fast_pipeline.py init --script <文案.md> --duration <秒> --title <标题> --output-dir <工程目录>
```

2. 同时执行两条独立检索：一条查询本地素材库，一条用可用浏览器工具查询官方新闻/公开视频。新闻先加载 `assets/templates/trusted-news-sources.json`：一手公告/监管/交易所优先，其次 Reuters、AP、CNBC 等白名单来源；原始英文页面允许使用。两家独立可信来源一致后停止继续搜索，事实仍有分歧时继续核验。行情和盘中动态默认只接受 24 小时内页面并记录报价时间；财报、政策和公司公告使用最新一份一手来源；历史事实记录原始发布日期，不伪装为实时新闻。
3. 对素材库做一次增量索引。排除缓存、依赖、帧序列、渲染产物、代理和临时目录：

```powershell
python scripts/build_asset_index.py --root <素材库> --index <缓存\asset-index.json> --ledger <已有台账.json> --workers 8 --search-keyword <关键词> --search-segments --search-output <候选.json>
```

4. 根据关键词从索引筛选有来源台账的镜头段。`segments[]` 直接返回 `source_in/source_out`，优先使用；没有段级登记时才为该候选生成一次联系表并补录段级关键词。匹配分相同时，优先持续时间短、体积小的来源；下载前先查时长和体积，避免下载长直播或整场发布会。
5. 候选池冻结后，只对最终 shortlist 生成联系表和代理：

```powershell
python scripts/make_contact_sheet.py --source <候选.mp4> --cache-dir <缓存\contact-sheets>
python scripts/prepare_proxy.py --source <入选.mp4> --cache-dir <缓存\proxies>
```

6. 逐项完成五类 `chart_inventory`，只为 `generated` 项调用专属图表渲染器：

```powershell
python scripts/render_market_chart.py --config <图表.json> --output-dir <缓存\overlays>
```

新闻截图先登记到 `news[]`，包含 `screenshot_path/headline/start/end/background_shot_id`。随后一次生成标题栏/免责声明并把新闻转为 4 秒 overlay：

```powershell
python scripts/prepare_timeline_assets.py --timeline <时间轴.json> --overlay-dir <缓存\overlays> --output <准备后时间轴.json>
```

后续只使用准备后时间轴。该工具生成顶层 `chrome_path` 和 `type: news` overlay；二者由连续渲染器直接接入。短时间线直接输出成片；长时间线将准备后时间轴按镜头边界分段后输出中间分段，绝不拆成单镜头文件。预检会拒绝缺失的 `chrome_path`、`image_path`、间隙、重叠和越界选段。

7. 完成人工语义确认：把时间线中的 `待语义确认` 和 `pending-*` 全部替换为真实的主体、动作、结果、关键词、素材和来源。自动生成器只负责准确分段与时长，不替代编辑判断。
8. 运行统一预检；不得人工忽略 error：

```powershell
python scripts/preflight.py --timeline <时间轴.json> --asset-index <缓存\asset-index.json> --report <预检报告.json>
```

9. 先审静态联系表。只有裁切、转场或显隐时序无法静态判断时，才调用硬限制为 2 秒的预览工具；不得为了看版式渲染完整 720p 视频：

```powershell
python scripts/render_motion_preview.py --source <候选.mp4> --overlay <叠层.png> --start <秒> --duration 2 --output <预览.mp4>
```
10. 先选择渲染模式。总时长少于 `90` 秒且真实视频输入不超过 `12` 条时，使用单一入口完成连续主时间线、台账与首次联系表：

```powershell
python scripts/fast_pipeline.py finalize --timeline <时间轴.json> --asset-index <索引.json> --overlay-dir <叠层缓存> --output-video <日期_视频_标题.mp4> --project-dir <工程目录> --metrics <端到端耗时.json>
```

达到任一阈值时，使用分段模式：每段 `4–5` 镜头、最多 `25.0` 秒，只在镜头边界切段。顺序调用连续渲染器生成分段；每段可解码后才开始下一段。所有分段使用同一已探测通过的编码器与参数，再使用 concat demuxer 与 `-c copy` 无损拼接。禁止按镜头拆分，禁止并行分段渲染，禁止拼接后重编码全片。

11. `finalize` 或分段拼接完成后，均必须导出独立台账，不再单独手工调用导出命令。

```text
输出：准备后时间轴、预检报告、asset-ledger、首次复审报告和联系表。
```

12. 第一次运行 `review_render.py` 只快速探测并生成每镜开头/中点/结尾三帧的带 ID 联系表，不执行全片解码，也不得把未看的镜头标记完成。代理查看联系表后生成绑定成片、时间线和联系表 SHA-256 的批准文件：

```powershell
python scripts/make_visual_approval.py --video <成片.mp4> --timeline <时间轴.json> --contact-sheet <联系表.jpg> --review-notes <逐镜观察记录.json> --output <批准.json>
```

再次运行 `review_render.py --visual-approval <批准.json>`；此时只执行一次全片解码。任何像素、时间线或联系表变化都会使旧批准失效。

代理实际查看联系表后，用单一入口完成批准、最终复审并冻结端到端耗时：

```powershell
python scripts/fast_pipeline.py approve --video <成片.mp4> --timeline <准备后时间轴.json> --contact-sheet <联系表.jpg> --review-notes <逐镜观察记录.json> --approval <视觉批准.json> --final-report <最终复审.json> --metrics <端到端耗时.json> [--reference-audio <参考音频>] [--source-audio <旁白音频>]
```

批准和最终复审完成后，必须执行程序级终态门禁：

```powershell
python scripts/fast_pipeline.py deliver --video <成片.mp4> --timeline <准备后时间轴.json> --preflight <预检报告.json> --ledger <asset-ledger.json> --final-review <最终复审.json> --status <执行状态.json> --gate-report <终态门禁.json> --metrics <端到端耗时.json>
```

门禁采用失败关闭：缺文件、空视频、预检失败、台账缺少本地路径或源文件哈希、镜头/素材覆盖不一致、素材重复、最终复审未通过、存在未检查镜头、复审指向旧视频或时长不一致，均返回非零并把执行状态写回 `in_progress`。启动后台任务、60 秒命令包装超时、文件开始增长、首审联系表生成都不属于终态。只有最新门禁报告 `terminal_allowed=true` 且五个 SHA-256 与当前文件一致，才允许最终交付。

## 热缓存流程

- 索引按绝对路径、文件大小和 `mtime_ns` 复用；文件变化才重新探测和计算快速哈希。
- 联系表和代理按源文件签名加参数签名复用。
- 叠层按规范化内容哈希复用。
- 新闻页面若日期、标题或页面内容变化，重新截图并更新台账；不得复用过期事实。
- 只改台账或报告且像素未变化时不重渲染。任何影响画面的终版修改都必须重新完整渲染并完整复审。

## 编码器基准

每台机器只需重新安装驱动、更换显卡或更新 FFmpeg 后重测：

```powershell
python scripts/benchmark_encoder.py --output <缓存\encoder-benchmark.json>
```

先读取 `assets/templates/verified-encoder.json`。当前机器的 RTX 4060 Laptop / 驱动 591.74 / FFmpeg 7.1 已验证 `h264_nvenc -preset p4 -tune hq -rc vbr -cq 23 -b:v 0`：50.23 秒样片编码 3.268 秒，全片解码通过，SSIM 0.994356。`render_continuous_timeline.py --encoder auto` 会自动比对三项签名；一致时使用该档，签名变化或出现可见画质回归立即回退 `libx264 / veryfast / CRF 19` 并重测。

硬件编码器只有基准成功且画质已明确批准时才写入 `quality_approved: true` 并用于终版；仅检测到编码器不代表可用。使用下列命令只能批准已经完成真实素材画质核验的单个编码器：

```powershell
python scripts/benchmark_encoder.py --approve-encoder h264_nvenc --output <缓存\encoder-benchmark.json>
```

## 失败即停

- 索引发现来源字段缺失：保留本地路径与源文件哈希，按五项语义、连续解码和时长继续验收。
- 代理/联系表生成失败：检查源文件可解码性，不得用静态图片填充时长。
- 时间线仍有 `pending-*`：不渲染。
- 镜头时间有间隙/重叠、选段越界、缺少标题栏或任一叠层图片：不渲染。
- 图表页不是精确 4.5 秒、钩子/新闻页不是精确 4.0 秒、出现其他页面类型、或同链路图表不相邻：不渲染。
- 终版出现时间戳、补帧、黑场、底部免责声明或解码异常：不交付。免责声明必须固定在顶部黑栏最右侧。

## 当前机器实测基线

测试样片：`2026-08-01_视频_存储板块盘中分歧.mp4`，`1920x1080 / 30fps / 50.23 秒`。

| 环节 | 冷缓存 | 热缓存 |
|---|---:|---:|
| 全工作区 1284 个视频素材索引 | 29.481 秒 | 0.668 秒 |
| 单条 50.23 秒视频联系表 | 1.210 秒 | 0.137 秒 |
| 单条 50.23 秒视频 720p 代理 | 4.421 秒 | 0.116 秒 |
| 单张参数化新闻叠层 | 0.178 秒 | 0.168 秒 |

终版编码对比：旧流程 `libx264 medium / CRF 18` 约 41 秒；固定软件档 `veryfast / CRF 19` 实测 10.412 秒；已验证 NVENC 档实测 3.268 秒，完整解码 1.969 秒。驱动、GPU、FFmpeg 或输入规格改变后不得沿用这些数字，必须重测。

同源复测（2026-08-01 的 60.24 秒、1920×1080 成片，重编码且不含音频）：旧档 `libx264 medium / CRF 18` 用时 13.387 秒；当前 `h264_nvenc p4 / CQ 23` 用时 3.654 秒，编码阶段快 3.66 倍。两份输出均已完整解码。此测试只衡量编码，不能代替端到端制作耗时；冷建 Chinese-CLIP 画面索引约 16.5 分钟是一次性成本，后续无变化热更新约 0.104 秒。

以上仅为本机已有合规素材、网络正常且事实来源可直接核验时的实测基线，不是固定耗时上限。新闻需要多源核验、网页访问受限，或素材库完全没有与关键词匹配的真实视频而必须另行检索、下载和登记来源时，制作耗时可能超过预估范围；汇报进度时必须说明具体受限环节，不得为满足时间估算而降低来源核验或画面匹配标准。

历史 34 分钟项目说明素材匹配和时间线整理是主瓶颈，不是编码。它是旧流程基线，不得作为当前生产承诺；当前流程以 10 分钟渲染启动门槛和 20 分钟交付门槛为准。

## 编码快速失败规则

正式渲染前，用最终时间线、分辨率、叠层和目标编码器先渲染 `3.0` 秒探测片段。只有命令成功、输出非零并可完整解码，才允许启动整片硬件编码。探测失败、超时或驱动初始化异常时，立即使用 `libx264 / preset veryfast / CRF 19`，不得让硬件编码在整片运行几十秒后才回退。

本机 2026-08-02 实例：两分钟、24 输入、5 个叠层的连续时间线使用 `h264_nvenc` 运行约 31 秒后退出；回退 `libx264 / veryfast / CRF 19` 后约 66 秒完成。以后必须用包含同等输入数量与叠层复杂度的 3 秒探测，不能以简单样片的历史 NVENC 基准替代任务级探测。

## 三路并行扇出与汇合

时间线骨架完成后立刻扇出，不再串行等待：

```text
真实视频素材检索与来源检查 ─┐
真实新闻检索、核验与截图   ─┼─→ 一次性合并时间线 → 语义确认 → 预检 → 编码探测 → 正式渲染
五类数据图生成             ─┘
```

第三路逐项判定文案数据能否支持五类数据图，并生成可支持的图表；第二路按文案制作新闻页并按内容哈希重建对应叠层。三路各自计时，汇合前互不阻塞；任何一路失败只重试该分支，不重新执行已经成功的另外两路。
