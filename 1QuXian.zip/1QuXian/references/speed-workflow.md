# 提速工作流

- [可移植环境](#可移植环境)
- [端到端计时与预算](#端到端计时与预算)
- [固定结构与单一入口](#固定结构与单一入口)
- [画面语义索引与并行研究](#画面语义索引)
- [四阶段生产](#四阶段生产)
- [缓存、编码与失败规则](#热缓存流程)
- [并行边界](#并行边界)

## 可移植环境

- Python：使用当前解释器。
- FFmpeg：优先使用 `--ffmpeg`，其次 `CURVE_FFMPEG`，最后查找 PATH；均不可用时显式停止。
- 素材库脚本：优先使用 `CURVE_MATERIAL_LIBRARY_SCRIPTS`，否则使用与本 skill 同级的 `1SuCaiKu/scripts`。
- 持久缓存与画面语义索引：由项目显式传入，不绑定用户目录。
- 中文字体：从当前系统字体目录查找中文字体；找不到时用 `CURVE_FONT_REGULAR` 和 `CURVE_FONT_BOLD` 显式指定字体文件，禁止静默使用不支持中文的默认字体。

不要每个任务重新搜索 Python、FFmpeg、字体或编码参数。缓存可以删除后重建，但不得把缓存文件当作来源台账。

## 端到端计时与预算

完整文案和音频一到齐就启动墙钟计时，不得等到渲染才计时。视频请求已提供连续自动制作授权，中途不请求用户确认、不记录等待；第 5 分钟尚未进入正式渲染或第 12 分钟仍未通过交付门禁时，记录最后恢复点与唯一阻塞点并继续生产。默认并行分支目标如下，不能相加为端到端承诺：

| 阶段 | 预算 | 超时时动作 |
|---|---:|---|
| `semantic_index` 素材向量更新 | 60 秒 | 仅允许小批增量；缺索引、异常缩水或超过 12 条新增时转入独立维护。 |
| `news` 新闻核验与截图 | 120 秒 | 未取得真实截图时跳过新闻页；章节与视频镜头继续。 |
| `assets` 镜头级素材匹配 | 90 秒 | 全章节只做一次批量检索；缺口自动开放本工程七日去重后补一次。 |
| `timeline` 时间线与信息页 | 60 秒 | 使用最少页面并一次冻结，不重新设计。 |
| `render_review` 渲染与复审 | 360 秒 | 从最近检查点继续，不重复已通过步骤。 |

使用 `workflow_metrics.py` 的 `start/stage-start/stage-end/budget-check/report` 子命令；正常生产不使用 `wait-start/wait-end`。`stage-end --note` 记录超时原因。端到端墙钟从收到文案和音频开始，到 `approve` 自动交付通过结束；不得用索引、编码或解码的局部基准代表总体耗时。

## 语义结构与单一入口

- 所有时长均按文案语义和目标时长或音频节奏建立时间线，单镜不超过 5 秒；不得用固定槽位模板先切割文案。
- `fast_pipeline.py init`：完整输入到齐后立即生成任务状态和端到端计时文件。
- `fast_pipeline.py research`：一次接收全部章节查询，固定输出全部合格候选的 A/M/B 批量联系表；3 秒预览只作为疑难项备用。
- `fast_pipeline.py timeline`：固定接收文案、音频、研究包和可选页面清单，自动生成动态钩子并输出可直接预检的最终时间线；禁止项目临时脚本。
- `fast_pipeline.py finalize`：接收 `init` 返回的同一 `--status`，一次完成准备、预检、渲染、台账和首次联系表，并逐步写入可恢复检查点。
- `fast_pipeline.py approve`：接收同一 `--status`，代理目检后一次完成视觉批准、唯一一次全片解码、五文件终态门禁、素材使用提交和 `complete`。
- `fast_pipeline.py status`：只在用户取消时写 `cancelled`，或一次纠正已耗尽且仍依赖外部素材、权限或服务时写 `blocked_external`。

生产子命令统一收口到 `fast_pipeline.py`；`status` 只负责失败关闭的异常终态。代理连续执行，不把页面、素材、时间线、渲染或导出作为用户确认点。

## 高频真实素材包、新闻事实卡与并行研究

- 入轴前按主体、动作、地点、设备、关键词筛选真实视频；每条必须有 `local_path` 和源文件哈希。来源字段可记录但不是入轴条件。
- 素材入库、统一索引、来源侧车、168 小时使用台账和交付历史身份均由配置后的 `material_library.py` 管理；本 Skill 不再保留平行素材库实现。
- 新闻事实卡必须含页面原文、发布日期、关键事实、原始链接、发布者、截图路径和适用关键词。写入、校验和检索都按 `trusted-news-sources.json` 校验来源域名。
- 收到文案后，把全部章节查询一次传给阶段 2 的 `fast_pipeline.py research`，同时检索画面和事实卡。研究包必须返回 `candidate_contact_sheet` 及其 SHA-256；正常审核只查看这一张批量联系表。每个候选仍保存建议 5 秒区间、A/M/B 和备用 3 秒预览，同一工程共用一个 `候选预览` 目录。

`research` 中的事实卡检索只读本地缓存，不代表真实新闻截图检索，也不得启动或结束 `news` 计时。开始浏览网页查找新闻截图前单独执行 `workflow_metrics.py stage-start --state <端到端耗时.json> --stage news`；取得合格截图后执行对应 `stage-end`。累计 120 秒仍无合格截图时不加入 `overlays[]`，章节和视频镜头继续；`finalize` 不得修改已经冻结的页面清单。

使用 `OFA-Sys/chinese-clip-vit-base-patch16` 对视频代表帧建立中文图文向量索引。生产候选只从 `fast_pipeline.py research` 返回；底层 `visual_semantic_index.py search` 仅用于索引维护诊断，它没有素材资格、168 小时去重或 A/M/B，不得直接入轴。`research` 候选返回缩略图、时间点、相似度和可入轴 `source_in/source_out`；来源字段缺失不影响入轴，仍须通过五项语义、连续解码、时长与源文件哈希去重校验。模型、文件大小和 `mtime_ns` 未变化时复用已有向量；新增或修改素材才重新抽帧编码。

建立或增量更新索引。日常生产只传入当天新增/修改的精确 `--path`；`--path` 会保留其余有效向量。索引缺失、异常缩水或未索引素材超过 12 条时，脚本会拒绝静默全量重建，只有明确维护窗口才允许 `--full-rebuild`：

```powershell
python scripts/visual_semantic_index.py build --asset-index <asset-index.json> --output-dir <持久缓存\visual-semantic-index> --path <新增素材.mp4> --interval 3 --max-samples 24 --batch-size 32 --metrics <端到端耗时.json>
```

全库冷建只允许在独立维护窗口执行，不能占用视频生产的 12 分钟目标。未变素材应复用已有向量；新增素材只增量处理。把同一条视频的所有镜头查询作为一次 `fast_pipeline.py research` 调用传入，以共享一次模型加载；相同查询还会复用 manifest 绑定的本地查询缓存。

网络规则：若 `huggingface.co` 连接超时，可设置 `HF_ENDPOINT=https://hf-mirror.com`、`HF_HUB_DISABLE_XET=1` 后首次下载模型；模型进入本地缓存后，不再依赖网络完成检索。不得因为网络受限跳过来源核验。

来源字段只作为素材说明；所有语义命中均可按五项语义、连续解码、时长和源文件哈希去重结果进入时间线。

## 四阶段生产

### 1. 输入冻结

完整文案和目标时长或音频到齐后立即初始化，不等检索或页面分析：

```powershell
python scripts/fast_pipeline.py init --script <文案.md> (--duration <秒> | --audio <音频>) --output-dir <工程目录>
```

页面分支自动生成最少必要页面并直接写入 `overlays[]`。音频只写 `timing_audio` 字段用于测时和语义对齐。不得发样图等待确认。

### 2. 检索定轴

素材分支先按素材库 Skill 执行一次 `audit`，再把全部章节查询放进同一次 `research`。只从 `eligible_visual_candidates` 选片，候选 A/M/B 先合成一张批量联系表审核，只有疑难候选才单独打开 3 秒预览。168 小时候选不足时不询问，当前工程自动改用 `lookback_hours:0` 补一次；不再做第三次检索。

```powershell
python scripts/fast_pipeline.py research --index-dir <持久缓存\visual-semantic-index> --fact-cache <日期_文档_新闻事实卡_缓存.json> --query <关键词一> --category <分类一> --query <关键词二> --category <分类二> --delivery-root <历史工程根目录> --current-project <当前工程> --review-dir <当前工程\候选预览> --metrics <端到端耗时.json> --required-candidates <音频秒数除以5向上取整> --top-k 4 --output <日期_文档_并行研究包.json>
```

新闻截图并行核验；累计 120 秒仍无合格截图时，在冻结前放弃该新闻页，不影响章节实拍。查看研究包的唯一批量联系表后，直接调用固定时间线入口：

```powershell
python scripts/fast_pipeline.py timeline --script <文案.md> --audio <音频> --research <研究包.json> --page-dir <页面缓存> --project-dir <工程目录> [--overlays <附加页面.json>] --output <正式时间线.json>
```

该入口自动完成语义章节、精确音频时长、2–5 秒镜头、唯一素材、五字段、来源区间、动态钩子和研究包哈希绑定；不得再创建 `build_timeline.py`、PowerShell 拼接或其他工程临时编排文件。

### 3. 自动制作

单一入口先确认状态仍为 `in_progress`，再依次核验现有页面、生成透明 `chrome_path`、正式预检、3 秒编码探测、渲染、资产台账和首次联系表：

```powershell
python scripts/fast_pipeline.py finalize --timeline <时间轴.json> --asset-index <索引.json> --overlay-dir <叠层缓存> --output-video <日期_视频_文案文件名.mp4> --project-dir <工程目录> --metrics <端到端耗时.json> --status <执行状态.json>
```

总时长少于 90 秒且真实视频输入不超过 12 条时连续渲染；达到任一阈值时按镜头边界顺序分段，每段 1–5 镜头且不超过 25 秒，逐段可解码后再无损拼接。输出固定包括准备后时间线、预检报告、资产台账、首次复审报告、A/M/B 联系表和目检记录模板；这些步骤不得再手工重复调用。

### 4. 复审交付

实际查看每镜 A/M/B 并填写目检记录；只有裁切、转场或显隐时序无法判断时，才看不超过 2 秒的动态预览。随后一次完成批准、唯一一次自动全片解码、五文件终态门禁、素材使用登记、耗时冻结和 `complete`：

```powershell
python scripts/fast_pipeline.py approve --video <成片.mp4> --timeline <准备后时间轴.json> --preflight <预检报告.json> --ledger <asset-ledger.json> --contact-sheet <联系表.jpg> --review-notes <逐镜观察记录.json> --approval <视觉批准.json> --final-report <最终复审.json> --gate-report <终态门禁.json> --metrics <端到端耗时.json> --status <执行状态.json>
```

`approve` 失败或提交使用台账失败时保持 `in_progress`；任何像素、时间线、联系表或报告变化都使旧批准失效。只有最新门禁报告中五个 SHA-256 与当前文件一致且 `terminal_allowed=true`，才允许交付。

外部阻塞只能在一次纠正失败后写入；用户取消不带纠正标记：

```powershell
python scripts/fast_pipeline.py status --status <执行状态.json> --state blocked_external --reason <唯一外部阻塞点> --correction-exhausted
python scripts/fast_pipeline.py status --status <执行状态.json> --state cancelled --reason <用户取消原因>
```

## 热缓存流程

- 索引按绝对路径、文件大小和 `mtime_ns` 复用；文件变化才重新探测和计算快速哈希。
- 联系表和代理按源文件签名加参数签名复用。
- 候选 3 秒预览与 A/M/B 按素材身份、源文件状态和截取参数复用；任一文件哈希或完整解码失效时整包重建。
- 叠层按规范化内容哈希复用。
- 新闻页面若日期或页面内容变化，重新截图并更新台账；不得复用过期事实。
- 只改台账或报告且像素未变化时不重渲染。任何影响画面的终版修改都必须重新完整渲染并完整复审。

## 编码器基准

安装驱动、更换显卡或更新 FFmpeg 后重新测试：

```powershell
python scripts/benchmark_encoder.py --output <缓存\encoder-benchmark.json>
```

先读取 `assets/templates/verified-encoder.json`。`render_continuous_timeline.py --encoder auto` 只使用与当前驱动、GPU、FFmpeg 签名一致且 `quality_approved:true` 的编码器；签名变化或画质不通过时使用 `libx264 / veryfast / CRF 19`。

硬件编码器只有基准成功且画质已明确批准时才写入 `quality_approved: true` 并用于终版；仅检测到编码器不代表可用。使用下列命令只能批准已经完成真实素材画质核验的单个编码器：

```powershell
python scripts/benchmark_encoder.py --approve-encoder h264_nvenc --output <缓存\encoder-benchmark.json>
```

## 失败即停

- 索引发现来源字段缺失：保留本地路径与源文件哈希，按五项语义、连续解码和时长继续验收。
- 代理/联系表生成失败：检查源文件可解码性，不得用静态图片填充时长。
- 时间线仍有 `pending-*`：不渲染。
- 镜头时间有间隙/重叠、选段越界或缺少任一叠层图片：不渲染。
- 图表页不是精确 4.5 秒、钩子/新闻页不是精确 4.0 秒、出现其他页面类型、或同链路图表不相邻：不渲染。
- 终版不是 1080×1920、中央窗口不是 `1080×830@y=604`、上下非同帧模糊投影，或出现时间戳、补帧、黑场、底栏、底部免责声明和解码异常：不交付。免责声明必须固定在中央窗口上方。

## 编码快速失败规则

正式渲染前，用最终时间线、分辨率、叠层和目标编码器先渲染 `3.0` 秒探测片段。只有命令成功、输出非零并可完整解码，才允许启动整片硬件编码。探测失败、超时或驱动初始化异常时，立即使用 `libx264 / preset veryfast / CRF 19`，不得让硬件编码在整片运行几十秒后才回退。

## 并行边界

时间线骨架完成后立刻扇出，不再串行等待：

```text
真实视频素材检索与来源检查 ─┐
真实新闻检索、核验与截图   ─┼─→ 一次性合并时间线 → 语义确认 → 预检 → 编码探测 → 正式渲染
自动页面生成与参考图核验     ─┘
```

页面分支只生成并核验 `overlays[]` 列出的文件及匹配参考图；新闻分支只取得并核验真实截图。三路汇合前互不阻塞：素材最多一次纠正，新闻累计 120 秒后在冻结前放弃缺图页，已成功分支不重新执行。
