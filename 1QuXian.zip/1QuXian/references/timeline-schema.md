# 时间轴合同：钩子、新闻与图表

时间轴只允许三种 overlay `type`：`hook`、`news`、`chart`。`fact/data/number/comparison/causal` 只能出现在 `information_task` 中表达信息语义；任一值作为 overlay `type` 时，`preflight.py` 必须失败。`hook/news` 固定 `4.0` 秒；图表和结构信息页固定 `4.5` 秒。每张页面的唯一 `reference_template` 必须匹配 `references/曲线页面固定标准.json` 当前绑定的批准页文件名；`page_reference_contract.py` 是程序侧映射，禁止在本合同重复维护另一套文件名。视频流程只能使用在冻结时间线前已自动生成或由用户提供、且已通过合同检查的 `image_path`；缺少匹配批准页、文件、SHA-256 校验或可核实证据必须失败，终版由透明全局层统一显示一条警示语。

## 顶层必填

- `script_path`、`duration_seconds`、`audio_delivery_mode`
- `chapters[]`、`assets[]`、`shots[]`、`overlays[]`
- `dedupe_audit={lookback_hours:168,checked_at:<带时区时间>}`；仅当用户明确授权某一工程例外时，允许 `lookback_hours:0`，且必须同时记录 `user_authorized_exception:true` 与非空 `exception_reason`。该例外不修改全局默认规则。
- `overlays[]` 是页面唯一清单；不得再创建单独的页面确认对象、数量副本或 ID 清单

## 章节、镜头与素材

每章须有唯一 `id`、连续 `start/end` 和非空 `thesis`。页面直接在 `overlays[]` 中以 `chapter_id`、`information_task` 和 `script_range` 绑定原文章节。

每个镜头必须保存：

- `id`、`asset_id`、`chapter_id`、`start/end`、`source_in/source_out`
- `script_range`、`information_task`、`selection_mode: semantic_index`
- `candidate_asset_ids[]` 与非空 `selection_reason`
- `semantic_fields`，含非空 `subject/action/location/equipment/keywords`

素材必须记录 `local_path`、源文件哈希、洁净检查和七日去重结果。来源字段可选。同一素材只能入轴一次；真实 `broll` 镜头为 2–5 秒，所有镜头不得超过 5 秒；时间轴连续并精确结束于 `duration_seconds`。

## 固定参考页与三种页面

`reference_template` 是页面语义的强制映射，具体文件名只从 `references/曲线页面固定标准.json` 读取。不得以任意项目图片或未列入当前标准清单的图片代替批准页。

钩子页固定 4.0 秒，从 0.0 秒开始，且全片恰好一张：

```json
{
  "id": "hook-01", "type": "hook", "role": "hook", "start": 0.0, "end": 4.0,
  "chapter_id": "c01", "background_shot_id": "s01",
  "chinese_text": "主旨、判断和证据", "image_path": "C:/工程/已确认钩子首帧.png", "frame_pattern": "C:/工程/已确认钩子/%04d.png",
  "reference_template": "<从曲线页面固定标准.json读取>"
}
```

新闻页固定 4.0 秒，必须绑定真实截图和 `task: news` 的同章证据：

```json
{
  "id": "news-01", "type": "news", "start": 8.0, "end": 12.0,
  "chapter_id": "c02", "information_task": "news", "script_range": {"start": 8.0, "end": 12.0},
  "background_shot_id": "s03", "chinese_text": "新闻内容", "screenshot_path": "news-01.png", "image_path": "C:/工程/已确认新闻页.png",
  "reference_template": "<从曲线页面固定标准.json读取>"
}
```

图表页固定 4.5 秒；这是对信息页 4.0 秒默认值的显式特例与覆盖。字段合同与配置格式见 `chart-schema.md`：

```json
{
  "id": "chart-01", "type": "chart", "information_task": "data",
  "chart_kind": "relative_return", "data_chain_id": "chain-01",
  "data_interval": "一月至七月", "data_metric": "累计涨跌幅", "source_state": "user_copy",
  "source_excerpt": "原文中支持此页的完整句子",
  "start": 12.0, "end": 16.5, "chapter_id": "c03", "script_range": {"start": 12.0, "end": 16.5},
  "background_shot_id": "s04", "chinese_text": "指数相对表现", "image_path": "chart-01.png",
  "reference_template": "<从曲线页面固定标准.json读取>"
}
```

每张新闻页和信息页必须通过 `chapter_id/information_task/script_range` 直接绑定同章原文。信息页还必须保存非空 `source_excerpt`，且该摘录原样存在于对应章节 `thesis`。预测页必须增加 `source_state:user_authorized_prediction`、`prediction_corpus_date:YYYY-MM-DD` 和非空 `prediction_basis[]`；依据只来自当前文本及同日用户文本。所有页面必须在入轴前已存在；准备器只核验文件与参考版式，绝不重新渲染。新闻页必须提供真实 `screenshot_path`；页面必须有真实视频背景；`chinese_text`、图像路径和内容哈希全片唯一。钩子/新闻页相邻可无缝衔接，同链信息页必须无缝衔接，页面不得重叠。

`audio_delivery_mode` 固定为 `silent`，且不得设置 `audio_path`。输入音频只可作为 `timing_audio_path` 用于测时和语义对齐；存在该路径时必须提供非空 `timing_audio_segments[]`，每个镜头和非钩子页面分别保存有效 `timing_audio_range`，页面另存 `timing_audio_text` 与 `audio_semantic_match:true`。音频永远不进入渲染命令、成片或终版复审；成片不得有任何音频流。
