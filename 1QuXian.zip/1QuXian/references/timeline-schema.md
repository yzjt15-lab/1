# 时间轴合同：钩子、新闻与图表

时间轴只允许三种 overlay：`hook`、`news`、`chart`。`fact/data/number/comparison/causal` 只能出现在 `information_task` 中表达图表语义，禁止作为 overlay `type`。

## 顶层必填

- `title`、`script_path`、`main_thesis`、`main_evidence_id`、`evidence_kind`、`duration_seconds`
- `chapters[]`、`assets[]`、`shots[]`、`overlays[]`
- `dedupe_audit={lookback_hours:168,checked_at:<带时区时间>}`
- `chart_inventory[]`：必须恰好覆盖五个图表种类，每项为 `generated` 或带原因的 `skipped`

```json
{
  "chart_inventory": [
    {"chart_kind": "relative_return", "status": "generated", "overlay_ids": ["chart-01"]},
    {"chart_kind": "futures_position", "status": "skipped", "skip_reason": "用户文案没有持仓数据"},
    {"chart_kind": "dual_axis_trend", "status": "skipped", "skip_reason": "用户文案没有双指标时间序列"},
    {"chart_kind": "kline_wave", "status": "skipped", "skip_reason": "用户文案没有波浪结构或K线范围"},
    {"chart_kind": "kline_fibonacci", "status": "skipped", "skip_reason": "用户文案没有高低点或回撤位"}
  ]
}
```

## 章节、镜头与素材

每章须有唯一 `id`、连续 `start/end`、非空 `thesis` 和 `information_plan[]`。计划任务可为 `news`、`fact`、`data`、`number`、`comparison`、`causal` 或 `broll`：`news` 只能绑定新闻页；前五种非新闻任务只能绑定图表页；`broll` 必须有非空 `reason`。

每个镜头必须保存：

- `id`、`asset_id`、`chapter_id`、`start/end`、`source_in/source_out`
- `script_range`、`information_task`、`selection_mode: semantic_index`
- `candidate_asset_ids[]` 与非空 `selection_reason`
- `script_semantics`、`semantic_fields`、`theme_mapping`，三者均含 `subject/action/location/equipment/keywords` 且逐项一致

素材必须记录 `local_path`、源文件哈希、洁净检查和七日去重结果。来源字段可选。同一素材只能入轴一次；真实 `broll` 镜头为 2–5 秒，所有镜头不得超过 5 秒；时间轴连续并精确结束于 `duration_seconds`。

## 三种页面

钩子页固定 4.0 秒，从 0.0 秒开始，且全片恰好一张：

```json
{
  "id": "hook-01", "type": "hook", "role": "hook", "start": 0.0, "end": 4.0,
  "chapter_id": "c01", "evidence_id": "e01", "background_shot_id": "s01",
  "chinese_text": "主旨、判断和证据", "frame_pattern": "hook-01/%04d.png"
}
```

新闻页固定 4.0 秒，必须绑定真实截图和 `task: news` 的同章证据：

```json
{
  "id": "news-01", "type": "news", "start": 8.0, "end": 12.0,
  "chapter_id": "c02", "evidence_id": "e02", "background_shot_id": "s03",
  "chinese_text": "新闻标题", "image_path": "news-01.png"
}
```

图表页固定 4.5 秒，字段合同与配置格式见 `chart-schema.md`：

```json
{
  "id": "chart-01", "type": "chart", "information_task": "data",
  "chart_kind": "relative_return", "data_chain_id": "chain-01",
  "data_interval": "一月至七月", "data_metric": "累计涨跌幅", "source_state": "user_copy",
  "start": 12.0, "end": 16.5, "chapter_id": "c03", "evidence_id": "e03",
  "background_shot_id": "s04", "chinese_text": "指数相对表现", "image_path": "chart-01.png"
}
```

每张新闻页和图表页必须通过 `chapter_id/evidence_id` 绑定同章、同任务证据。页面必须有真实视频背景；`chinese_text`、图像路径和内容哈希全片唯一。钩子/新闻页相邻可无缝衔接，图表同链必须无缝衔接，页面不得重叠。

存在 `reference_audio_path` 时，保存 `reference_audio_segments[]`，每个镜头保存 `reference_audio_range`，每张非钩子页保存 `reference_audio_range`、`reference_audio_text` 和 `audio_semantic_match: true`。`audio_path` 只保存旁白音频。
