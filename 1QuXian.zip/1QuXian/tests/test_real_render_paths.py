import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from render_continuous_timeline import _decode_ok, build_ffmpeg_command, run_encoder_probe
from render_segmented_timeline import _segment_fingerprint, split_timeline


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "ffmpeg and ffprobe are required")
class RealRenderPathTests(unittest.TestCase):
    def test_continuous_probe_renders_real_dynamic_mp4(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source.mp4"
            subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=30:duration=3", "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(source)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            timeline = {"duration_seconds": 3.0, "assets": [{"id": "a", "local_path": str(source)}], "shots": [{"id": "s", "asset_id": "a", "start": 0.0, "end": 3.0, "source_in": 0.0}], "overlays": []}
            attempts = []
            self.assertTrue(run_encoder_probe(timeline, "ffmpeg", "libx264", attempts))
            self.assertTrue(attempts[0]["ok"])

    def test_segment_fingerprint_changes_only_when_segment_input_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source.mp4"
            source.write_bytes(b"source")
            timeline = {"duration_seconds": 25.0, "assets": [{"id": f"a{i}", "local_path": str(source), "sha256": str(i) * 64} for i in range(5)], "shots": [{"id": f"s{i}", "asset_id": f"a{i}", "start": i * 5.0, "end": (i + 1) * 5.0} for i in range(5)], "overlays": []}
            segment = split_timeline(timeline)[0]
            first = _segment_fingerprint(segment, "libx264")
            changed = json.loads(json.dumps(segment)); changed["shots"][0]["end"] = 4.9
            self.assertNotEqual(first, _segment_fingerprint(changed, "libx264"))

    def test_segmented_path_renders_and_losslessly_joins_real_mp4(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source.mp4"
            subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=30:duration=5", "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(source)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            timeline = {
                "duration_seconds": 65.0,
                "assets": [{"id": f"a{i}", "local_path": str(source), "sha256": f"{i:064x}"} for i in range(13)],
                "shots": [{"id": f"s{i}", "asset_id": f"a{i}", "start": i * 5.0, "end": (i + 1) * 5.0, "source_in": 0.0} for i in range(13)],
                "overlays": [],
            }
            outputs = []
            for index, segment in enumerate(split_timeline(timeline)):
                output = root / f"segment-{index}.mp4"
                subprocess.run(build_ffmpeg_command(segment, str(output), "final", "ffmpeg", "libx264"), check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.assertTrue(_decode_ok("ffmpeg", output))
                outputs.append(output)
            concat = root / "concat.txt"
            concat.write_text("".join(f"file '{item.as_posix()}'\n" for item in outputs), encoding="utf-8")
            final = root / "final.mp4"
            subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-c", "copy", str(final)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.assertTrue(_decode_ok("ffmpeg", final))

    def test_pcm_audio_uses_aac_in_real_mp4(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, audio, output = root / "source.mp4", root / "voice.wav", root / "output.mp4"
            subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=30:duration=3", "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(source)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=3", "-c:a", "pcm_s16le", str(audio)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            timeline = {"duration_seconds": 3.0, "audio_path": str(audio), "assets": [{"id": "a", "local_path": str(source)}], "shots": [{"id": "s", "asset_id": "a", "start": 0.0, "end": 3.0, "source_in": 0.0}], "overlays": []}
            subprocess.run(build_ffmpeg_command(timeline, str(output), "final", "ffmpeg", "libx264"), check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.assertTrue(_decode_ok("ffmpeg", output))
            codec = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_name", "-of", "default=nw=1:nk=1", str(output)], text=True, encoding="utf-8").strip()
            self.assertEqual("aac", codec)


if __name__ == "__main__":
    unittest.main()
