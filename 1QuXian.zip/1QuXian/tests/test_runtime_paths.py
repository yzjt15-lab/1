import os
import subprocess
import sys
import tempfile
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from runtime_paths import env_path
from speed_common import find_chinese_font, find_ffmpeg


def test_runtime_path_environment_override():
    previous = os.environ.get("CURVE_TEST_PATH")
    try:
        os.environ["CURVE_TEST_PATH"] = "C:/curve-test-output"
        assert env_path("CURVE_TEST_PATH", Path("C:/ignored")) == Path("C:/curve-test-output").resolve()
    finally:
        if previous is None:
            os.environ.pop("CURVE_TEST_PATH", None)
        else:
            os.environ["CURVE_TEST_PATH"] = previous


def test_preflight_and_pipeline_share_material_library_override():
    with tempfile.TemporaryDirectory() as directory:
        library = Path(directory)
        (library / "material_library.py").write_text(
            "from pathlib import Path\n"
            "DELIVERIES_ROOT=INDEX=USAGE=Path(__file__).parent\n"
            "def identities(*a, **k): return set()\n"
            "def recent_material_identities(*a, **k): return set()\n"
            "def full_hash(*a, **k): return ''\n"
            "def commit_ledger(*a, **k): pass\n"
            "def candidate_preview_key(item): return (item.get('path'), item.get('source_in'), item.get('source_out'))\n"
            "def filter_candidate_groups(groups, **k): return [[] for _ in groups]\n"
            "def prepare_candidate_previews(*a, **k): return []\n",
            encoding="utf-8",
        )
        env = {**os.environ, "CURVE_MATERIAL_LIBRARY_SCRIPTS": str(library), "PYTHONPATH": str(SCRIPTS)}
        result = subprocess.run(
            [sys.executable, "-c", "import preflight, fast_pipeline; print(preflight.MATERIAL_LIBRARY_SCRIPTS); print(fast_pipeline.MATERIAL_LIBRARY_SCRIPTS)"],
            capture_output=True, text=True, encoding="utf-8", env=env,
        )
        assert result.returncode == 0, result.stderr
        assert result.stdout.strip().splitlines() == [str(library.resolve()), str(library.resolve())]


def test_ffmpeg_environment_override():
    with tempfile.TemporaryDirectory() as directory:
        executable = Path(directory) / "ffmpeg.exe"
        executable.write_bytes(b"fixture")
        previous = os.environ.get("CURVE_FFMPEG")
        try:
            os.environ["CURVE_FFMPEG"] = str(executable)
            assert find_ffmpeg() == str(executable.resolve())
        finally:
            if previous is None:
                os.environ.pop("CURVE_FFMPEG", None)
            else:
                os.environ["CURVE_FFMPEG"] = previous


def test_chinese_font_override_is_explicit_and_fail_closed():
    with tempfile.TemporaryDirectory() as directory:
        font = Path(directory) / "font.ttc"
        font.write_bytes(b"fixture")
        previous = os.environ.get("CURVE_FONT_REGULAR")
        try:
            os.environ["CURVE_FONT_REGULAR"] = str(font)
            assert find_chinese_font() == str(font.resolve())
            os.environ["CURVE_FONT_REGULAR"] = str(font.with_name("missing.ttc"))
            try:
                find_chinese_font()
            except FileNotFoundError as error:
                assert "CURVE_FONT_REGULAR" in str(error)
            else:
                raise AssertionError("missing configured font must fail")
        finally:
            if previous is None:
                os.environ.pop("CURVE_FONT_REGULAR", None)
            else:
                os.environ["CURVE_FONT_REGULAR"] = previous
