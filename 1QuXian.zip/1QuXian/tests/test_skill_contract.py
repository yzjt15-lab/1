from pathlib import Path


SKILL = Path(__file__).resolve().parents[1] / "SKILL.md"


def test_skill_has_one_material_authority_and_nonblocking_service_target():
    text = SKILL.read_text(encoding="utf-8")
    assert text.count("manage-material-library") == 1
    assert "20 \u5206\u949f" in text
    assert "\u786c\u95e8\u69db" not in text
    assert text.count("\u5176\u4ed6\u7ae0\u8282\u53ea\u80fd\u5f15\u7528\u672c\u89c4\u5219") == 0
    for token in ("CURVE_VIDEO_OUTPUT_DIR", "CURVE_MATERIAL_LIBRARY_SCRIPTS", "\u4e3b\u4f53\u3001\u52a8\u4f5c\u3001\u5730\u70b9\u3001\u8bbe\u5907\u3001\u5173\u952e\u8bcd", "blocked_external", "split_timeline()", "\u8d22\u7ecf\u77ed\u89c6\u9891", "audio_delivery_mode", "render_segmented_timeline.py", "3 \u79d2", "terminal_allowed=true", "SHA-256", "in_progress", "4.5:1", "\u4e03\u65e5\u53bb\u91cd", "chrome_path", "\u6709\u6548\u753b\u9762", "\u6e05\u6d01\u5ea6"):
        assert token in text


def test_speed_workflow_has_no_machine_paths_or_legacy_news_registry():
    text = (SKILL.parent / "references" / "speed-workflow.md").read_text(encoding="utf-8")
    assert "C:\\Users\\28723" not in text
    assert "登记到 `news[]`" not in text
    assert "停止后续生产" not in text
    assert "不得继续正式渲染" not in text
    assert "fast_pipeline.py finalize" in text and "fast_pipeline.py approve" in text
    assert text.count("--status <执行状态.json>") >= 4
