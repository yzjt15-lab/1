from pathlib import Path


SKILL = Path(__file__).resolve().parents[1] / "SKILL.md"


def test_skill_has_one_material_authority_and_nonblocking_service_target():
    text = SKILL.read_text(encoding="utf-8")
    chart_schema = (SKILL.parent / "references" / "chart-schema.md").read_text(encoding="utf-8")
    assert text.count("manage-material-library") == 1
    assert "12 \u5206\u949f" in text
    assert "\u6536\u5230\u5b8c\u6574\u4e2d\u6587\u6587\u6848\u548c\u97f3\u9891" in text
    assert "\u4e0d\u5f97\u5728\u7d20\u6750\u9009\u62e9\u3001\u4e03\u65e5\u53bb\u91cd\u4f8b\u5916\u3001\u9875\u9762\u7c7b\u578b\u4e0e\u6570\u91cf\u3001\u65f6\u95f4\u7ebf\u3001\u5f00\u59cb\u6e32\u67d3\u6216\u5bfc\u51fa\u4e4b\u95f4\u8be2\u95ee\u7528\u6237" in text
    assert "\u786c\u95e8\u69db" not in text
    assert text.count("\u5176\u4ed6\u7ae0\u8282\u53ea\u80fd\u5f15\u7528\u672c\u89c4\u5219") == 0
    for token in ("CURVE_VIDEO_OUTPUT_DIR", "CURVE_MATERIAL_LIBRARY_SCRIPTS", "\u4e3b\u4f53\u3001\u52a8\u4f5c\u3001\u5730\u70b9\u3001\u8bbe\u5907\u3001\u5173\u952e\u8bcd", "blocked_external", "split_timeline()", "\u8d22\u7ecf\u77ed\u89c6\u9891", "audio_delivery_mode", "render_segmented_timeline.py", "3 \u79d2", "terminal_allowed=true", "SHA-256", "in_progress", "4.5:1", "\u4e03\u65e5\u53bb\u91cd", "chrome_path", "\u6709\u6548\u753b\u9762", "\u6e05\u6d01\u5ea6"):
        assert token in text
    for token in ("contract_comparison", "hedge_mechanism", "financial_loop", "three_stage_trend", "prediction_corpus_date", "prediction_basis[]", "同日文本"):
        assert token in chart_schema
    for token in ("输入冻结", "检索定轴", "自动制作", "复审交付"):
        assert token in text
    for stale in ("chart_inventory", "reference_audio", "source_audio", "六步"):
        assert stale not in text


def test_speed_workflow_has_no_machine_paths_or_parallel_news_registry():
    text = (SKILL.parent / "references" / "speed-workflow.md").read_text(encoding="utf-8")
    assert "C:\\Users\\28723" not in text
    assert "登记到 `news[]`" not in text
    assert "停止后续生产" not in text
    assert "不得继续正式渲染" not in text
    for command in ("fast_pipeline.py init", "fast_pipeline.py research", "fast_pipeline.py timeline", "fast_pipeline.py finalize", "fast_pipeline.py approve"):
        assert command in text
    assert "fast_pipeline.py deliver" not in text
    assert "--source-audio" not in text and "--reference-audio" not in text
    assert "--preflight <预检报告.json>" in text and "--gate-report <终态门禁.json>" in text


def test_old_page_confirmation_gate_is_gone():
    for path in (SKILL, SKILL.parent / "scripts" / "preflight.py", SKILL.parent / "scripts" / "validate_timeline.py", SKILL.parent / "scripts" / "prepare_timeline_assets.py"):
        assert "page_confirmation" not in path.read_text(encoding="utf-8")
