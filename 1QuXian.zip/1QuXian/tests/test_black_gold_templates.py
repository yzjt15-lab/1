import sys
import tempfile
import unittest
import json
import hashlib
from pathlib import Path
from unittest.mock import patch

from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from render_market_chart import GOLD, _candle_ohlc, render
from render_overlay_templates import render_hook_frames, render_news_page
from page_reference_contract import PAGE_REFERENCE_FILENAMES, approved_reference_path, verify_page_reference_assets
import page_reference_contract


class BlackGoldTemplatesTest(unittest.TestCase):
    def test_all_approved_chart_golden_pages_exist(self):
        reference = ROOT / "assets" / "approved-pages"
        self.assertEqual(set(PAGE_REFERENCE_FILENAMES.values()), {path.name for path in reference.glob("*.png")})
        for path in reference.glob("*.png"):
            with Image.open(path) as sample:
                self.assertEqual(sample.size, (1080, 830))
        manifest = json.loads((ROOT / "references" / "曲线页面固定标准.json").read_text(encoding="utf-8"))
        self.assertEqual(5, manifest["schema_version"])
        self.assertEqual(12, len(manifest["templates"]))
        for item in manifest["templates"].values():
            self.assertEqual({"file", "sha256", "width", "height", "role"}, set(item))
        self.assertEqual([], verify_page_reference_assets())
        self.assertFalse((ROOT / "scripts" / "build_approved_page_samples.py").exists())

    def test_reference_binding_rejects_other_names_and_paths(self):
        with self.assertRaisesRegex(ValueError, "reference_template must be"):
            approved_reference_path("hook", "old-hook.png")
        with self.assertRaisesRegex(ValueError, "reference_template_path must be"):
            approved_reference_path("hook", reference_template_path=ROOT / "other" / PAGE_REFERENCE_FILENAMES["hook"])

    def test_production_checks_only_the_reference_types_used_by_this_video(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reference = root / "assets" / "approved-pages"
            reference.mkdir(parents=True)
            hook = reference / "hook.png"
            image = Image.new("RGBA", (1080, 830), (0, 0, 0, 0))
            image.putpixel((0, 0), (0, 0, 0, 255))
            image.save(hook)
            templates = {
                page_type: {
                    "file": f"assets/approved-pages/{page_type}.png",
                    "sha256": hashlib.sha256(hook.read_bytes()).hexdigest() if page_type == "hook" else "0" * 64,
                    "width": 1080, "height": 830, "role": "central_clear_window",
                }
                for page_type in page_reference_contract.PAGE_TYPES
            }
            manifest = root / "manifest.json"
            manifest.write_text(json.dumps({
                "schema_version": 5,
                "central_window": {"width": 1080, "height": 830, "top": 604},
                "composition_mode": page_reference_contract.COMPOSITION_MODE,
                "templates": templates,
            }), encoding="utf-8")
            with patch.object(page_reference_contract, "SKILL_ROOT", root), patch.object(page_reference_contract, "REFERENCE_PAGES", reference):
                self.assertEqual([], verify_page_reference_assets(manifest, {"hook"}))

    def test_reference_pages_and_renderers(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            stable, pattern = render_hook_frames({"hook_lines": ["机构继续加多", "3960 是关键压力位", "资金结构仍偏多"]}, out)
            with Image.open(stable) as sample:
                self.assertEqual(sample.size, (1080, 830))
            self.assertNotEqual((Path(pattern.replace("%04d", "0000"))).read_bytes(), stable.read_bytes())
            screenshot = out / "real.png"
            original = Image.new("RGBA", (1080, 830), (17, 43, 91, 255)); original.save(screenshot)
            with Image.open(render_news_page({}, screenshot, out)) as sample:
                self.assertIsNone(ImageChops.difference(original, sample.convert("RGBA")).getbbox())
            configs = {
                "relative_return": {"series": [{"label": "上证", "values": [0, -2, 3]}, {"label": "沪深300", "values": [0, -1, 2]}]},
                "futures_position": {"series": [{"label": "多头", "values": [10, 20]}, {"label": "空头", "values": [8, 16]}], "labels": ["IF", "IH"], "annotations": [{"text": "净多增加"}]},
                "grouped_comparison": {"series": [{"label": "指数", "values": [100, 98]}, {"label": "成交额", "values": [100, 84]}], "labels": ["首日", "次日"], "annotations": [{"text": "指数与成交额变化"}]},
                "dual_axis_trend": {"series": [{"label": "估值", "values": [25, 15, 20]}, {"label": "盈利", "values": [-20, 0, 40]}]},
                "kline_wave": {"price_points": [9, 11, 10, 13], "annotations": [{"text": "关键点位已突破"}]},
                "kline_fibonacci": {"price_points": [9, 11, 10, 13], "fib_low": 9, "fib_high": 13},
            }
            for kind, payload in configs.items():
                config = {"id": kind, "chart_kind": kind, "data_metric": "数值", "data_interval": "区间", **payload}
                with Image.open(render(config, out)) as sample:
                    self.assertEqual(sample.size, (1080, 830))
                    gold = sum(1 for pixel in sample.convert("RGBA").crop((180, 45, 900, 125)).get_flattened_data() if pixel[:3] == GOLD[:3] and pixel[3])
                    self.assertGreater(gold, 100)
                    alpha = sample.convert("RGBA").getchannel("A")
                    self.assertIsNone(alpha.crop((0, 0, 43, 830)).getbbox(), f"{kind} crossed the left panel boundary")
                    self.assertIsNone(alpha.crop((1037, 0, 1080, 830)).getbbox(), f"{kind} crossed the right panel boundary")

    def test_dynamic_labels_and_explicit_waves_do_not_fall_back_to_sample_content(self):
        with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
            relative = {"id": "relative", "chart_kind": "relative_return", "data_metric": "累计涨跌幅", "data_interval": "区间", "series": [{"label": "对象", "values": [0, 1, 2.5]}]}
            implicit = render(relative, Path(first))
            explicit = render({**relative, "endpoint_label": "2.5%"}, Path(second))
            self.assertEqual(implicit.read_bytes(), explicit.read_bytes())

            wave = {"id": "wave", "chart_kind": "kline_wave", "data_metric": "关键点位", "data_interval": "区间", "price_points": [9, 11, 10, 13]}
            plain = render(wave, Path(first))
            marked = render({**wave, "wave_points": [0, 3], "wave_labels": ["起", "止"]}, Path(second))
            self.assertNotEqual(plain.read_bytes(), marked.read_bytes())

    def test_grouped_comparison_accepts_only_bounded_predictions_from_a_range(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            predicted = {
                "id": "predicted", "chart_kind": "grouped_comparison", "data_metric": "市场份额（%）", "data_interval": "同日文本预测",
                "labels": ["短期", "中期"], "series": [{"label": "系列甲", "values": [11, 13]}, {"label": "系列乙", "values": [18, 19]}],
                "prediction_bounds": [10, 20], "source_state": "user_authorized_prediction", "prediction_basis": ["文本给出明确区间"],
            }
            self.assertTrue(render(predicted, out).is_file())
            predicted["series"][1]["values"][1] = 21
            with self.assertRaisesRegex(ValueError, "inside prediction_bounds"):
                render(predicted, out)

    def test_kline_wave_supports_dense_series_with_ma_and_volume(self):
        with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
            prices = [100 + ((index % 5) - 2) + index * .4 for index in range(30)]
            base = {"id": "wave", "chart_kind": "kline_wave", "data_metric": "点位", "data_interval": "日线", "price_points": prices}
            plain = render(base, Path(first))
            detailed = render({**base, "ma_periods": [3, 5, 8], "volume_values": [20 + index for index in range(30)]}, Path(second))
            self.assertNotEqual(plain.read_bytes(), detailed.read_bytes())

    def test_kline_candles_have_bodies_and_two_sided_wicks(self):
        prices = [100, 104, 101, 107]
        candles = [_candle_ohlc(prices, index) for index in range(len(prices))]
        self.assertTrue(all(high > max(opening, closing) and low < min(opening, closing) for opening, high, low, closing in candles))
        self.assertTrue(any(closing > opening for opening, _, _, closing in candles))
        self.assertTrue(any(closing < opening for opening, _, _, closing in candles))


if __name__ == "__main__":
    unittest.main()
