import hashlib
import inspect
import json
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import call, patch
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from PIL import Image

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from make_visual_approval import make_approval
import fast_pipeline
from material_library import delivered_identities, filter_candidates, source_family, write_json
from render_market_chart import render as render_market_chart
from review_render import make_shot_contact_sheet
from speed_common import find_ffmpeg
from visual_semantic_index import build_index, extract_thumbnail, rank_embeddings, search_many, sync_metadata
from workflow_metrics import DEFAULT_BUDGETS, build_report, complete_run, end_stage, end_user_wait, start_run, start_stage, start_user_wait
from validate_timeline import validate

class PipelineRegressionTests(unittest.TestCase):
    def test_initialize_does_not_duplicate_a_compliant_filename_prefix(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            script = root / "2026-08-25_文档_测试文案.md"
            script.write_text("市场正在变化。", encoding="utf-8")
            result = fast_pipeline.initialize(script, root, duration=8.0, date_text="2026-08-25")
        self.assertEqual("2026-08-25_文档_测试文案_执行状态.json", Path(result["status_path"]).name)
        self.assertEqual("2026-08-25_文档_测试文案_端到端耗时.json", Path(result["metrics_path"]).name)

    def test_contact_sheet_extracts_all_shot_frames_in_one_ffmpeg_process(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "sheet.jpg"
            def render_sheet(command, **_kwargs):
                Image.new("RGB", (1280, 360), "black").save(command[-1])
                return subprocess.CompletedProcess(command, 0)
            with patch("review_render.subprocess.run", side_effect=render_sheet) as run:
                make_shot_contact_sheet("video.mp4", [{"id": "s1", "start": 0, "end": 2}, {"id": "s2", "start": 2, "end": 4}], str(output), "ffmpeg")
            self.assertEqual(1, run.call_count)
            self.assertIn("tile=4x2", run.call_args.args[0][run.call_args.args[0].index("-vf") + 1])

    def test_contact_sheet_uses_compact_grid_for_long_timelines(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "sheet.jpg"
            shots = [{"id": f"s{i:02d}", "start": i * 5, "end": (i + 1) * 5} for i in range(42)]
            def render_sheet(command, **_kwargs):
                Image.new("RGB", (1440, 1920), "black").save(command[-1])
                return subprocess.CompletedProcess(command, 0)
            with patch("review_render.subprocess.run", side_effect=render_sheet) as run:
                make_shot_contact_sheet("video.mp4", shots, str(output), "ffmpeg")
            self.assertEqual(3, run.call_count)
            filters = [item.args[0][item.args[0].index("-vf") + 1] for item in run.call_args_list]
            self.assertIn("scale=180:-2,tile=8x6", filters[0])
            self.assertIn("scale=180:-2,tile=8x4", filters[-1])

    def test_news_search_budget_is_two_minutes(self):
        self.assertEqual(120.0, DEFAULT_BUDGETS["news"])

    def test_chart_duration_is_strict_and_renderer_accepts_windows_utf8_bom(self):
        data = {
            "script_path": "script.md", "duration_seconds": 10,
            "chapters": [{"id": "c1", "start": 0, "end": 10, "thesis": "判断"}],
            "shots": [], "assets": [],
            "overlays": [{"id": "c", "type": "chart", "information_task": "data", "chart_kind": "relative_return", "data_chain_id": "d1", "data_interval": "日线", "data_metric": "涨跌幅", "source_state": "user_copy", "source_excerpt": "判断", "chart_config_path": "C:/project/chart.json", "chapter_id": "c1", "script_range": {"start": 0, "end": 4}, "start": 0, "end": 4, "background_shot_id": "s1", "chinese_text": "走势"}],
        }
        self.assertTrue(any("duration must equal 4.5 seconds" in item for item in validate(data)))
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "chart.json"
            config.write_text(json.dumps({"id": "chart", "chart_kind": "relative_return", "data_interval": "日线", "data_metric": "涨跌幅", "series": [{"label": "指数", "values": [0, 1, 2]}]}, ensure_ascii=False), encoding="utf-8-sig")
            output = render_market_chart(json.loads(config.read_text(encoding="utf-8-sig")), Path(directory), (640, 360))
            self.assertTrue(output.is_file() and output.stat().st_size > 0)

    def test_all_six_chart_layouts_render_as_independent_png_files(self):
        series = [{"label": "甲", "values": [1, 2, 1.5]}, {"label": "乙", "values": [2, 1, 2.5]}]
        price_points = [10, 10.7, 10.4, 11.8]
        kinds = ("relative_return", "futures_position", "grouped_comparison", "dual_axis_trend", "kline_wave", "kline_fibonacci")
        with tempfile.TemporaryDirectory() as directory:
            outputs = []
            for kind in kinds:
                config = {"id": kind, "chart_kind": kind, "data_interval": "日线", "data_metric": "数值"}
                config["price_points" if kind.startswith("kline_") else "series"] = price_points if kind.startswith("kline_") else series
                if kind in {"futures_position", "grouped_comparison"}:
                    config["labels"] = ["甲", "乙", "丙"]
                    config["left_axis_label"] = "净变化（单位）"
                if kind == "kline_fibonacci":
                    config.update({"fib_low": 10, "fib_high": 11.8})
                outputs.append(render_market_chart(config, Path(directory), (640, 360)))
            self.assertEqual(6, len({path.name for path in outputs}))
            self.assertTrue(all(path.is_file() and path.stat().st_size > 0 for path in outputs))

    def test_kline_pages_reject_missing_script_price_points(self):
        with tempfile.TemporaryDirectory() as directory:
            config = {"id": "wave", "chart_kind": "kline_wave", "data_interval": "盘中", "data_metric": "关键点位"}
            with self.assertRaisesRegex(ValueError, "price_points"):
                render_market_chart(config, Path(directory), (640, 360))

    def test_fibonacci_requires_explicit_script_anchors(self):
        with tempfile.TemporaryDirectory() as directory:
            config = {"id": "fib", "chart_kind": "kline_fibonacci", "data_interval": "盘中", "data_metric": "关键点位", "price_points": [10, 12]}
            with self.assertRaisesRegex(ValueError, "fib_high and fib_low"):
                render_market_chart(config, Path(directory), (640, 360))

    def test_chart_bounds_reject_silent_clipping_or_anchor_conflicts(self):
        cases = [
            ({"id": "bars", "chart_kind": "futures_position", "data_interval": "同一时期", "data_metric": "数值", "labels": ["甲"], "series": [{"label": "本期", "values": [-10]}, {"label": "上期", "values": [8]}], "y_limits": [-5, 5]}, "include every plotted value"),
            ({"id": "bars", "chart_kind": "futures_position", "data_interval": "同一时期", "data_metric": "数值", "labels": list("甲乙丙丁戊"), "series": [{"label": "多头", "values": [1] * 5}, {"label": "空头", "values": [2] * 5}]}, "at most 4"),
            ({"id": "grouped", "chart_kind": "grouped_comparison", "data_interval": "同一时期", "data_metric": "数值", "labels": list("甲乙丙丁戊己庚"), "series": [{"label": "甲组", "values": [1] * 7}, {"label": "乙组", "values": [2] * 7}]}, "at most 6"),
            ({"id": "bars", "chart_kind": "futures_position", "data_interval": "同一时期", "data_metric": "数值", "left_axis_label": "过长轴名" * 50, "labels": ["甲"], "series": [{"label": "本期", "values": [1]}, {"label": "上期", "values": [2]}]}, "text exceeds"),
            ({"id": "relative", "chart_kind": "relative_return", "data_interval": "区间", "data_metric": "涨跌幅", "series": [{"label": "甲", "values": [1, 2]}], "y_limits": [1, 3]}, "include every plotted value"),
            ({"id": "relative", "chart_kind": "relative_return", "data_interval": "区间", "data_metric": "涨跌幅", "series": [{"label": "甲", "values": [0, "NaN"]}]}, "finite"),
            ({"id": "axis", "chart_kind": "dual_axis_trend", "data_interval": "同一时期", "data_metric": "趋势", "series": [{"label": "甲", "values": [1, 2, 3]}, {"label": "乙", "values": [3, 2, 1]}], "annotations": [{"text": "拐点", "series_index": .9}]}, "series_index"),
            ({"id": "wave", "chart_kind": "kline_wave", "data_interval": "区间", "data_metric": "价格", "price_points": [10, 12, 11], "wave_points": [2, 0]}, "strictly increasing"),
            ({"id": "wave", "chart_kind": "kline_wave", "data_interval": "区间", "data_metric": "价格", "price_points": [10, 12], "wave_points": [0, 1], "wave_labels": ["起点", "过长波浪名" * 50]}, "text exceeds"),
            ({"id": "wave", "chart_kind": "kline_wave", "data_interval": "区间", "data_metric": "价格", "price_points": [1] * 1000}, "pixel capacity"),
            ({"id": "fib", "chart_kind": "kline_fibonacci", "data_interval": "区间", "data_metric": "价格", "price_points": [0, 50, 100], "fib_low": 0, "fib_high": 100, "fib_levels": {"0.618": 90}}, "agree with"),
            ({"id": "fib", "chart_kind": "kline_fibonacci", "data_interval": "区间", "data_metric": "价格", "price_points": [0, 50, 100], "fib_low": 0, "fib_high": 100, "fib_low_index": 0, "fib_high_index": 3}, "existing price_points"),
            ({"id": "fib", "chart_kind": "kline_fibonacci", "data_interval": "区间", "data_metric": "价格", "price_points": list(range(1000)), "fib_low": 0, "fib_high": 999}, "pixel capacity"),
        ]
        with tempfile.TemporaryDirectory() as directory:
            for config, message in cases:
                with self.subTest(chart_kind=config["chart_kind"]):
                    with self.assertRaisesRegex(ValueError, message):
                        render_market_chart(config, Path(directory), (640, 360))

    def test_grouped_auto_axis_keeps_zero_on_the_outer_edge(self):
        config = {"id": "bars", "chart_kind": "futures_position", "data_interval": "同一时期", "data_metric": "数值", "labels": ["甲"], "series": [{"label": "本期", "values": [8]}, {"label": "上期", "values": [20]}]}
        with tempfile.TemporaryDirectory() as directory, patch("render_market_chart._grid") as grid:
            render_market_chart(config, Path(directory), (640, 360))
            self.assertEqual(0, grid.call_args.args[2][0])
            config["series"] = [{"label": "本期", "values": [-8]}, {"label": "上期", "values": [-20]}]
            render_market_chart(config, Path(directory), (640, 360))
            self.assertEqual(0, grid.call_args.args[2][1])

    def test_dynamic_text_and_fibonacci_annotation_stay_inside_the_panel(self):
        with tempfile.TemporaryDirectory() as directory:
            long_label = "过长标签" * 50
            config = {"id": "relative", "chart_kind": "relative_return", "data_interval": "区间", "data_metric": "涨跌幅", "labels": [long_label, "终点"], "series": [{"label": "对象", "values": [0, 1]}]}
            with self.assertRaisesRegex(ValueError, "text exceeds"):
                render_market_chart(config, Path(directory), (640, 360))

            config["id"] = "relative-safe"
            config["labels"] = ["边界标签" * 4, "终点"]
            output = render_market_chart(config, Path(directory), (640, 360))
            alpha = Image.open(output).convert("RGBA").getchannel("A")
            self.assertIsNone(alpha.crop((0, 14, 25, 346)).getbbox())

            fib = {"id": "fib-safe", "chart_kind": "kline_fibonacci", "data_interval": "区间", "data_metric": "价格", "price_points": [0, 50, 100], "fib_low": 0, "fib_high": 100, "annotations": [{"text": "0.618 区域"}]}
            output = render_market_chart(fib, Path(directory), (640, 360))
            alpha = Image.open(output).convert("RGBA").getchannel("A")
            self.assertIsNone(alpha.crop((0, 346, 640, 360)).getbbox())
            self.assertIsNone(alpha.crop((615, 0, 640, 360)).getbbox())

            with self.assertRaisesRegex(ValueError, "readable spacing"):
                render_market_chart({**fib, "id": "fib-compressed", "y_limits": [0, 100000]}, Path(directory), (640, 360))
            with self.assertRaisesRegex(ValueError, "text exceeds"):
                render_market_chart({"id": "wave-wide-ticks", "chart_kind": "kline_wave", "data_interval": "区间", "data_metric": "价格", "price_points": [5e99, 1e100]}, Path(directory), (1080, 830))

    def test_research_filters_and_prepares_all_queries_as_one_batch(self):
        self.assertEqual(4, fast_pipeline.DEFAULT_CANDIDATE_LIMIT)
        self.assertEqual(8, inspect.signature(search_many).parameters["top_k"].default)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video = root / "a.mp4"
            video.write_bytes(b"video")
            candidate = {"id": "a", "asset_id": "a", "path": str(video)}
            visual = {"model_id": "test", "queries": [{"query": "服务器", "category": "AI", "candidates": [candidate]}]}
            prepared = [{**candidate, "prepared_visual": True, "preview_cache_hit": False, "review_clip_path": "preview.mp4", "review_frames": [{"label": label} for label in "AMB"]}]
            metrics = root / "metrics.json"
            with patch.object(fast_pipeline, "search_many", return_value=visual) as semantic, patch.object(fast_pipeline, "search_cards", return_value=[]), patch.object(fast_pipeline, "filter_candidate_groups", return_value=[[candidate]]) as gate, patch.object(fast_pipeline, "prepare_candidate_previews", return_value=prepared) as preview, patch.object(fast_pipeline, "start_stage") as stage_start, patch.object(fast_pipeline, "end_stage") as stage_end:
                result = fast_pipeline.research(root, root / "facts.json", ["服务器"], 4, 5, None, "cpu", categories=["AI"], current_project=root, review_dir=root / "review", metrics_path=metrics)
            semantic.assert_called_once()
            gate.assert_called_once()
            preview.assert_called_once()
            self.assertEqual([call(metrics, "assets")], stage_start.call_args_list)
            self.assertEqual([call(metrics, "assets")], stage_end.call_args_list)
            returned = result["eligible_visual_candidates"]["queries"][0]["candidates"][0]
            self.assertTrue(returned["prepared_visual"])
            self.assertEqual(list("AMB"), [frame["label"] for frame in returned["review_frames"]])
            self.assertTrue(Path(result["candidate_contact_sheet"]).is_file())

    def test_candidate_contact_sheet_contains_every_unique_amb_row(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            frames = []
            for label, color in zip("AMB", ("red", "green", "blue")):
                path = root / f"{label}.jpg"
                Image.new("RGB", (160, 90), color).save(path)
                frames.append({"label": label, "path": str(path)})
            queries = [{"query": "市场", "eligible_candidates": [{"asset_id": "asset-1", "review_frames": frames}]}]
            output = fast_pipeline.make_candidate_contact_sheet(queries, root)
            self.assertEqual((960, 222), Image.open(output).size)

    def test_research_automatically_opens_only_the_current_project_dedupe_when_needed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video = root / "a.mp4"; video.write_bytes(b"video")
            frames = []
            for label in "AMB":
                path = root / f"{label}.jpg"; Image.new("RGB", (160, 90), "blue").save(path)
                frames.append({"label": label, "path": str(path)})
            candidate = {"id": "a", "asset_id": "a", "path": str(video)}
            prepared = [{**candidate, "prepared_visual": True, "preview_cache_hit": False, "review_clip_path": "preview.mp4", "review_frames": frames}]
            visual = {"model_id": "test", "queries": [{"query": "市场", "candidates": [candidate]}]}
            with patch.object(fast_pipeline, "search_many", return_value=visual), patch.object(fast_pipeline, "search_cards", return_value=[]), patch.object(fast_pipeline, "filter_candidate_groups", side_effect=[[], [[candidate]]]) as gate, patch.object(fast_pipeline, "prepare_candidate_previews", return_value=prepared):
                result = fast_pipeline.research(root, root / "facts.json", ["市场"], 4, 5, None, "cpu", current_project=root, review_dir=root, required_candidates=1)
            self.assertEqual(2, gate.call_count)
            self.assertEqual(0, gate.call_args_list[1].kwargs["lookback_hours"])
            self.assertEqual(0, result["dedupe_audit"]["lookback_hours"])

    def test_fixed_timeline_entry_binds_audio_research_assets_and_hook(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            script, audio, research = root / "script.md", root / "audio.wav", root / "research.json"
            script.write_text("市场放量。科技走强。", encoding="utf-8")
            subprocess.run([find_ffmpeg(), "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", "8", str(audio)], check=True, capture_output=True)
            groups = []
            for index, query in enumerate(("市场", "科技"), 1):
                video = root / f"a{index}.mp4"; video.write_bytes(f"asset-{index}".encode())
                candidate = {
                    "id": f"a{index}", "asset_id": f"a{index}", "path": str(video), "sha256": str(index) * 64,
                    "quick_hash": str(index + 2) * 64, "source_in": 0.0, "source_out": 5.0,
                    "subject": "行情屏", "action": "展示", "location": "交易室", "equipment": "显示器", "keywords": [query],
                    "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
                    "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "批量联系表已复核",
                }
                groups.append({"query": query, "candidates": [candidate]})
            payload = {
                "source": "fast_pipeline research", "candidate_contact_sheet": str(root / "sheet.jpg"),
                "dedupe_audit": {"lookback_hours": 0, "checked_at": datetime.now(timezone.utc).isoformat(), "user_authorized_exception": True, "exception_reason": "连续制作"},
                "eligible_visual_candidates": {"queries": groups},
            }
            research.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            timeline = fast_pipeline.build_production_timeline(script, audio, research, root / "pages", root)
            self.assertEqual(8.0, timeline["duration_seconds"])
            self.assertEqual(2, len(timeline["shots"]))
            self.assertEqual("hook", timeline["overlays"][0]["type"])
            self.assertNotIn("page_confirmation", timeline)
            self.assertFalse(validate(timeline), validate(timeline))

    def test_semantic_index_build_rejects_missing_asset_index(self):
        script = SCRIPTS / "visual_semantic_index.py"
        result = subprocess.run([sys.executable, str(script), "build", "--asset-index", "missing.json", "--output-dir", "missing"], capture_output=True, text=True, encoding="utf-8")
        self.assertNotEqual(0, result.returncode)
        self.assertIn("asset index not found", result.stderr)

    def test_incremental_semantic_build_preserves_untargeted_assets(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first, second = root / "first.mp4", root / "second.mp4"
            first.write_bytes(b"first")
            second.write_bytes(b"second")
            assets = [{"id": "first", "path": str(first), "probe_ok": True, "duration": 3, "size": 5, "mtime_ns": 1}, {"id": "second", "path": str(second), "probe_ok": True, "duration": 3, "size": 6, "mtime_ns": 2}]
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": assets}), encoding="utf-8")
            index = root / "index"
            index.mkdir()
            rows = [{"asset_id": "first", "path": str(first), "timestamp": 1, "duration": 3}, {"asset_id": "second", "path": str(second), "timestamp": 1, "duration": 3}]
            manifest = {"model_id": "test", "assets": [{"path": str(first), "size": 5, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}, {"path": str(second), "size": 6, "mtime_ns": 2, "model_id": "test", "row_indices": [1]}], "rows": rows, "failures": []}
            (index / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32))
            result = build_index(source, index, model_id="test", selected_paths={str(first)})
            self.assertEqual(2, result["asset_count"])
            self.assertEqual(["first", "second"], [row["asset_id"] for row in result["rows"]])
            self.assertTrue(np.array_equal(np.load(index / "embeddings.npy"), np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32)))

    def test_unchanged_asset_with_failed_sample_is_not_retried_forever(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video = root / "first.mp4"; video.write_bytes(b"first")
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": [{"id": "first", "path": str(video), "probe_ok": True, "duration": 3, "size": 5, "mtime_ns": 1}]}), encoding="utf-8")
            index = root / "index"; index.mkdir()
            failure = {"path": str(video), "timestamp": 2, "error": "decode failed"}
            (index / "manifest.json").write_text(json.dumps({"model_id": "test", "assets": [{"path": str(video), "size": 5, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}], "rows": [{"asset_id": "first", "path": str(video), "timestamp": 1, "duration": 3}], "failures": [failure]}), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0]], dtype=np.float32))
            with patch("visual_semantic_index.extract_thumbnail", side_effect=AssertionError("unchanged failed sample retried")):
                result = build_index(source, index, model_id="test")
            self.assertEqual(1, result["reused_asset_count"])
            self.assertEqual([], result["failures"])
            self.assertEqual([], result["rows"])
            self.assertEqual("thumbnail_extraction_failed", result["excluded_assets"][0]["reason"])
            self.assertEqual([failure], result["excluded_assets"][0]["failures"])
            with patch("visual_semantic_index.extract_thumbnail", side_effect=AssertionError("unchanged exclusion retried")):
                reused = build_index(source, index, model_id="test")
            self.assertEqual(1, reused["reused_asset_count"])
            self.assertEqual(1, reused["excluded_asset_count"])

            fake = type("FakeEmbedder", (), {"encode_images": lambda self, paths, _batch: np.asarray([[1.0, 0.0]], dtype=np.float32)})()
            with patch("visual_semantic_index.extract_thumbnail", return_value=root / "thumb.jpg"), patch("visual_semantic_index.ChineseClipEmbedder", return_value=fake):
                retried = build_index(source, index, model_id="test", selected_paths={str(video)})
            self.assertEqual([], retried["excluded_assets"])
            self.assertEqual(["first"], [row["asset_id"] for row in retried["rows"]])

    def test_failed_thumbnail_excludes_every_row_and_vector_for_the_asset(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video = root / "first.mp4"; video.write_bytes(b"first")
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": [{"id": "first", "path": str(video), "probe_ok": True, "duration": 6, "size": 5, "mtime_ns": 1}]}), encoding="utf-8")

            def extract(_path, timestamp, destination):
                if timestamp > 3:
                    raise RuntimeError("decode failed")
                return destination

            with patch("visual_semantic_index.extract_thumbnail", side_effect=extract), patch("visual_semantic_index.ChineseClipEmbedder", side_effect=AssertionError("excluded asset was embedded")):
                result = build_index(source, root / "index", model_id="test", full_rebuild=True)
            self.assertEqual(0, result["failure_count"])
            self.assertEqual(1, result["excluded_asset_count"])
            self.assertEqual([], result["rows"])
            self.assertEqual([], result["assets"][0]["row_indices"])
            self.assertEqual("decode failed", result["excluded_assets"][0]["failures"][0]["error"])
            self.assertEqual((0, 0), np.load(root / "index" / "embeddings.npy").shape)

    def test_incremental_semantic_build_removes_assets_absent_from_asset_index(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first, removed = root / "first.mp4", root / "removed.mp4"
            first.write_bytes(b"first")
            removed.write_bytes(b"removed")
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": [{"id": "first", "path": str(first), "probe_ok": True, "duration": 3, "size": 5, "mtime_ns": 1}]}), encoding="utf-8")
            index = root / "index"; index.mkdir()
            rows = [{"asset_id": "first", "path": str(first), "timestamp": 1, "duration": 3}, {"asset_id": "removed", "path": str(removed), "timestamp": 1, "duration": 3}]
            manifest = {"model_id": "test", "assets": [{"path": str(first), "size": 5, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}, {"path": str(removed), "size": 7, "mtime_ns": 2, "model_id": "test", "row_indices": [1]}], "rows": rows, "failures": []}
            (index / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32))
            result = build_index(source, index, model_id="test", selected_paths={str(first)})
            self.assertEqual(["first"], [row["asset_id"] for row in result["rows"]])

    def test_full_rebuild_does_not_reuse_old_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video = root / "first.mp4"; video.write_bytes(b"first")
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": [{"id": "first", "path": str(video), "probe_ok": True, "duration": 3, "size": 5, "mtime_ns": 1}]}), encoding="utf-8")
            index = root / "index"; index.mkdir()
            (index / "manifest.json").write_text(json.dumps({"model_id": "test", "assets": [{"path": str(video), "size": 5, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}], "rows": [{"asset_id": "old", "path": str(video), "timestamp": 1, "duration": 3}], "failures": []}), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0]], dtype=np.float32))
            with patch("visual_semantic_index.extract_thumbnail", return_value=root / "thumb.jpg"), patch("visual_semantic_index.ChineseClipEmbedder") as embedder:
                embedder.return_value.encode_images.return_value = np.asarray([[0.0, 1.0]], dtype=np.float32)
                result = build_index(source, index, model_id="test", full_rebuild=True)
            self.assertEqual(0, result["reused_asset_count"])
            self.assertEqual("first", result["rows"][0]["asset_id"])

    def test_metadata_sync_refreshes_existing_rows_and_reports_missing_vectors(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first, extra = root / "first.mp4", root / "extra.mp4"
            first.write_bytes(b"first"); extra.write_bytes(b"extra")
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": [{"path": str(first), "subject": "服务器", "keywords": ["机房"]}, {"path": str(extra)}]}), encoding="utf-8")
            index = root / "index"; index.mkdir()
            (index / "manifest.json").write_text(json.dumps({"rows": [{"path": str(first)}]}), encoding="utf-8")
            result = sync_metadata(source, index)
            row = json.loads((index / "manifest.json").read_text(encoding="utf-8"))["rows"][0]
            self.assertIn("服务器", row["metadata_text"])
            self.assertEqual(1, result["unindexed_asset_count"])

    def test_semantic_query_cache_avoids_model_reload(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            index = root / "index"; index.mkdir()
            manifest = {"model_id": "test", "rows": [{"asset_id": "a", "path": "a.mp4", "timestamp": 1, "duration": 5}], "assets": [], "failures": []}
            manifest_path = index / "manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0]], dtype=np.float32))
            cache = {"version": 1, "model_id": "test", "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(), "entries": {json.dumps({"query": "市场", "top_k": 8, "clip_duration": 5.0, "category": None, "ranker": 4}, ensure_ascii=False, sort_keys=True): {"query": "市场", "category": None, "candidates": [{"asset_id": "a"}], "eligible_candidates": [{"asset_id": "a"}]}}}
            (index / "query-cache.json").write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
            with patch("visual_semantic_index.ChineseClipEmbedder", side_effect=AssertionError("model loaded")):
                result = search_many(index, ["市场"])
            self.assertEqual("a", result["queries"][0]["candidates"][0]["asset_id"])

    def test_corrupt_semantic_query_cache_is_rebuilt(self):
        with tempfile.TemporaryDirectory() as directory:
            index = Path(directory)
            manifest = {"model_id": "test", "rows": [{"asset_id": "a", "path": "a.mp4", "timestamp": 1, "duration": 5}], "assets": [], "failures": []}
            (index / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0]], dtype=np.float32))
            (index / "query-cache.json").write_text("{", encoding="utf-8")
            fake = type("FakeEmbedder", (), {"encode_texts": lambda self, texts: np.asarray([[1.0, 0.0] for _ in texts], dtype=np.float32)})()
            with patch("visual_semantic_index.ChineseClipEmbedder", return_value=fake):
                result = search_many(index, ["市场"])
            self.assertEqual("a", result["queries"][0]["candidates"][0]["asset_id"])
            self.assertTrue(json.loads((index / "query-cache.json").read_text(encoding="utf-8"))["entries"])

    def test_semantic_index_build_records_metric_stage(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, metrics = root / "assets.json", root / "metrics.json"
            video = root / "existing.mp4"
            video.write_bytes(b"existing")
            asset = {"id": "existing", "path": str(video), "probe_ok": True, "duration": 3, "size": 8, "mtime_ns": 1}
            source.write_text(json.dumps({"assets": [asset]}), encoding="utf-8")
            index = root / "index"
            index.mkdir()
            (index / "manifest.json").write_text(json.dumps({"model_id": "test", "assets": [{"path": str(video), "size": 8, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}], "rows": [{"asset_id": "existing", "path": str(video), "timestamp": 1, "duration": 3}], "failures": []}), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0]], dtype=np.float32))
            start_run(metrics, 10, now=time.time())
            build_index(source, index, model_id="test", metrics_path=metrics)
            self.assertIn("semantic_index", json.loads(metrics.read_text(encoding="utf-8"))["stages"])

    def test_semantic_index_requires_explicit_full_rebuild_when_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": []}), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "--full-rebuild"):
                build_index(source, root / "index", model_id="test")
            self.assertEqual(0, build_index(source, root / "index", model_id="test", full_rebuild=True)["asset_count"])

    def test_full_rebuild_cannot_consume_production_budget(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, metrics = root / "assets.json", root / "metrics.json"
            source.write_text(json.dumps({"assets": []}), encoding="utf-8")
            start_run(metrics, 10, now=time.time())
            with self.assertRaisesRegex(ValueError, "maintenance-only"):
                build_index(source, root / "index", model_id="test", metrics_path=metrics, full_rebuild=True)

    def test_semantic_index_rejects_large_unbounded_increment(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            assets = [{"id": str(index), "path": str(root / f"{index}.mp4"), "probe_ok": True, "duration": 3, "size": 1, "mtime_ns": index} for index in range(13)]
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": assets}), encoding="utf-8")
            index = root / "index"; index.mkdir()
            (index / "manifest.json").write_text(json.dumps({"model_id": "test", "assets": [], "rows": [], "failures": []}), encoding="utf-8")
            np.save(index / "embeddings.npy", np.empty((0, 0), dtype=np.float32))
            with self.assertRaisesRegex(RuntimeError, "13 assets are unindexed"):
                build_index(source, index, model_id="test")
            with self.assertRaisesRegex(RuntimeError, "13 assets are unindexed"):
                build_index(source, index, model_id="test", selected_paths={item["path"] for item in assets})

    def test_category_filter_runs_before_top_k(self):
        matrix = np.asarray([[1.0, 0.0], [0.8, 0.2]], dtype=np.float32)
        rows = [
            {"asset_id": "space", "path": "space.mp4", "timestamp": 1, "duration": 5, "primary_category": "航天"},
            {"asset_id": "market", "path": "market.mp4", "timestamp": 1, "duration": 5, "primary_category": "市场"},
        ]
        result = rank_embeddings(matrix, np.asarray([1.0, 0.0]), rows, top_k=1, allowed_categories={"市场"})
        self.assertEqual("market", result[0]["asset_id"])

    def test_category_filter_accepts_numbered_library_folder(self):
        matrix = np.asarray([[1.0, 0.0]], dtype=np.float32)
        rows = [{"asset_id": "market", "path": "market.mp4", "timestamp": 1, "duration": 5, "primary_category": "5. 股市与市场"}]
        result = rank_embeddings(matrix, np.asarray([1.0, 0.0]), rows, allowed_categories={"股市与市场"})
        self.assertEqual("market", result[0]["asset_id"])

    def test_seven_day_history_only_accepts_hash_bound_deliveries(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            delivered = root / "delivered"
            delivered.mkdir()
            ledger = delivered / "x_asset-ledger.json"
            ledger.write_text(json.dumps({"assets": [{"id": "used", "local_path": "B2_001.mp4", "quick_hash": "abc"}]}), encoding="utf-8")
            digest = hashlib.sha256(ledger.read_bytes()).hexdigest()
            (delivered / "x_门禁.json").write_text(json.dumps({"terminal_allowed": True, "checked_at": datetime.now(timezone.utc).isoformat(), "sha256": {"ledger": digest}}), encoding="utf-8")
            failed = root / "failed"
            failed.mkdir()
            (failed / "y_asset-ledger.json").write_text(json.dumps({"assets": [{"id": "keep", "local_path": "other.mp4"}]}), encoding="utf-8")
            (failed / "y_门禁.json").write_text(json.dumps({"terminal_allowed": False, "checked_at": datetime.now(timezone.utc).isoformat(), "sha256": {"ledger": "bad"}}), encoding="utf-8")
            history = delivered_identities(root, 168)
            self.assertIn("asset_id:used", history)
            self.assertIn("source_family:" + source_family("B2_001.mp4"), history)

    def test_rejected_fresh_asset_does_not_allow_recent_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            fresh, old = root / "fresh.mp4", root / "old.mp4"
            fresh.write_bytes(b"fresh"); old.write_bytes(b"old")
            index = root / "index.json"
            write_json(index, {"assets": [
                {"id": "fresh", "path": str(fresh), "probe_ok": True, "orientation": "landscape", "quick_hash": "fresh-hash"},
                {"id": "old", "path": str(old), "probe_ok": True, "orientation": "landscape", "quick_hash": "old-hash"},
            ]})
            usage = root / "usage.json"
            write_json(usage, {"uses": [{"asset_id": "old", "used_at": datetime.now(timezone.utc).isoformat()}]})
            result = filter_candidates(
                [{"asset_id": "fresh", "path": str(fresh)}, {"asset_id": "old", "path": str(old)}],
                index, usage, root / "deliveries", rejected_asset_ids={"fresh"},
            )
            self.assertEqual([], result)

    def test_metrics_complete_only_when_delivery_calls_it(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "metrics.json"
            start_run(path, 10, now=0)
            start_stage(path, "timeline", now=1)
            self.assertTrue(complete_run(path, now=2)["completed"])

    def test_metrics_separates_user_wait_from_production_time(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "metrics.json"
            start_run(path, 10, now=0)
            start_user_wait(path, now=2)
            end_user_wait(path, now=7)
            complete_run(path, now=10)
            report = build_report(path)
            self.assertEqual(10.0, report["total_elapsed_seconds"])
            self.assertEqual(5.0, report["waiting_for_user_seconds"])
            self.assertEqual(5.0, report["production_elapsed_seconds"])

    def test_budget_reports_late_render_start_and_late_delivery_without_blocking(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "metrics.json"
            start_run(path, 10, now=0)
            start_stage(path, "timeline", now=1)
            end_stage(path, "timeline", now=2)
            start_stage(path, "render_review", now=300)
            alert = json.loads(path.read_text(encoding="utf-8"))["service_alert"]
            self.assertEqual("render_review", alert["stage"])
            self.assertEqual("timeline", alert["last_completed_checkpoint"])
            self.assertEqual(alert["reason"], alert["unique_blocking_point"])
            self.assertEqual("report_progress_and_continue", alert["next_action"])
            self.assertTrue(alert["formal_render_allowed"])
            start_stage(path, "assets", now=720)
            self.assertIn("12-minute", json.loads(path.read_text(encoding="utf-8"))["service_alert"]["reason"])

    def test_visual_approval_rejects_notes_copied_from_timeline(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video, contact, timeline, notes = (root / name for name in ("v.mp4", "c.jpg", "t.json", "n.json"))
            video.write_bytes(b"video")
            contact.write_bytes(b"sheet")
            semantics = {"subject": "市场", "action": "上涨", "location": "终端", "equipment": "K线"}
            timeline.write_text(json.dumps({"shots": [{"id": "s01", "semantic_fields": semantics}]}), encoding="utf-8")
            observation = {"semantic_match": True, "evidence_frames": ["s01-M"], **{f"visible_{key}": value for key, value in semantics.items()}}
            notes.write_text(json.dumps({"contact_sheet_sha256": hashlib.sha256(contact.read_bytes()).hexdigest(), "shots": {"s01": observation}, "checks": {name: True for name in ("vertical_layout", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder")}}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "copied"):
                make_approval(video, timeline, contact, notes)

    def test_review_notes_template_matches_current_approval_schema(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            timeline, contact = root / "timeline.json", root / "contact.jpg"
            timeline.write_text(json.dumps({"shots": [{"id": "s01"}, {"id": "s02"}]}), encoding="utf-8")
            contact.write_bytes(b"sheet")
            from make_review_notes_template import build_template
            template = build_template(timeline, contact)
            self.assertEqual({"s01", "s02"}, set(template["shots"]))
            self.assertEqual(["s01-A", "s01-M", "s01-B"], template["shots"]["s01"]["evidence_frames"])
            self.assertFalse(template["shots"]["s01"]["semantic_match"])

    def test_metadata_rerank_beats_visual_near_match(self):
        matrix = np.asarray([[1.0, 0.0], [0.98, 0.02]], dtype=np.float32)
        rows = [
            {"asset_id": "near", "path": "chip-closeup.mp4", "timestamp": 2, "duration": 8, "metadata_text": "PCB 芯片 微距"},
            {"asset_id": "factory", "path": "fab.mp4", "timestamp": 2, "duration": 8, "metadata_text": "半导体 无尘车间 芯片 制造设备"},
        ]
        result = rank_embeddings(matrix, np.asarray([1.0, 0.0]), rows, top_k=2, clip_duration=4, query_text="半导体无尘车间芯片制造设备")
        self.assertEqual("factory", result[0]["asset_id"])
        self.assertGreater(result[0]["metadata_score"], 0)

    def test_semantic_rank_excludes_assets_shorter_than_requested_clip(self):
        matrix = np.asarray([[1.0, 0.0], [0.9, 0.1]], dtype=np.float32)
        rows = [
            {"asset_id": "short", "path": "short.mp4", "timestamp": 1, "duration": 2.1},
            {"asset_id": "long", "path": "long.mp4", "timestamp": 2, "duration": 8},
        ]
        result = rank_embeddings(matrix, np.asarray([1.0, 0.0]), rows, top_k=2, clip_duration=4)
        self.assertEqual(["long"], [item["asset_id"] for item in result])

    def test_ffmpeg_thumbnail_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video, image = root / "test.mp4", root / "frame.jpg"
            subprocess.run([find_ffmpeg(), "-y", "-f", "lavfi", "-i", "color=blue:s=160x90:d=1", "-c:v", "libx264", str(video)], check=True, capture_output=True)
            self.assertTrue(extract_thumbnail(video, 0.2, image).is_file())


if __name__ == "__main__":
    unittest.main()
