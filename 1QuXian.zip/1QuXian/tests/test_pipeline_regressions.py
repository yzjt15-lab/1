import hashlib
import json
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from make_visual_approval import make_approval
import fast_pipeline
from material_selection import delivered_history, prefer_fresh, remove_recent
from render_market_chart import render as render_market_chart
from speed_common import find_ffmpeg
from visual_semantic_index import build_index, extract_thumbnail, rank_embeddings, search_many
from workflow_metrics import BudgetExceeded, build_report, complete_run, end_stage, end_user_wait, start_run, start_stage, start_user_wait
from validate_timeline import validate


class PipelineRegressionTests(unittest.TestCase):
    def test_curve_contract_rejects_missing_supported_chart_but_allows_mapped_broll_gap(self):
        kinds = ("relative_return", "futures_position", "dual_axis_trend", "kline_wave", "kline_fibonacci")
        data = {
            "title": "测试", "script_path": "script.md", "duration_seconds": 10, "main_thesis": "判断", "main_evidence_id": "e1", "evidence_kind": "data",
            "chapters": [{"id": "c1", "thesis": "判断", "script_range": {"start": 0, "end": 10}, "information_plan": [{"evidence_id": "e1", "task": "data"}]}],
            "chart_inventory": [{"chart_kind": kind, "status": "generated" if kind == "kline_wave" else "skipped", **({"overlay_ids": ["missing-wave"]} if kind == "kline_wave" else {"skip_reason": "无数据"})} for kind in kinds],
            "shots": [], "assets": [],
            "overlays": [
                {"id": "h", "type": "hook", "role": "hook", "chapter_id": "c1", "evidence_id": "e1", "start": 0, "end": 4, "background_shot_id": "s1", "chinese_text": "判断"},
                {"id": "n", "type": "news", "chapter_id": "c1", "evidence_id": "e1", "start": 8, "end": 12, "background_shot_id": "s1", "chinese_text": "新闻"},
            ],
        }
        errors = validate(data)
        self.assertTrue(any("overlay_id must bind a matching chart overlay" in item for item in errors))
        self.assertFalse(any("gap exceeds 3.0 seconds" in item for item in errors))

    def test_chart_duration_is_strict_and_renderer_accepts_windows_utf8_bom(self):
        data = {
            "title": "测试", "script_path": "script.md", "duration_seconds": 10, "main_thesis": "判断", "main_evidence_id": "e1", "evidence_kind": "data",
            "chapters": [{"id": "c1", "thesis": "判断", "script_range": {"start": 0, "end": 10}, "information_plan": [{"evidence_id": "e1", "task": "data"}]}],
            "chart_inventory": [{"chart_kind": kind, "status": "generated" if kind == "relative_return" else "skipped", **({"overlay_ids": ["c"]} if kind == "relative_return" else {"skip_reason": "无数据"})} for kind in ("relative_return", "futures_position", "dual_axis_trend", "kline_wave", "kline_fibonacci")],
            "shots": [], "assets": [],
            "overlays": [{"id": "c", "type": "chart", "information_task": "data", "chart_kind": "relative_return", "data_chain_id": "d1", "data_interval": "日线", "data_metric": "涨跌幅", "source_state": "user_copy", "chapter_id": "c1", "evidence_id": "e1", "start": 0, "end": 4, "background_shot_id": "s1", "chinese_text": "走势"}],
        }
        self.assertTrue(any("duration must equal 4.5 seconds" in item for item in validate(data)))
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "chart.json"
            config.write_text(json.dumps({"id": "chart", "chart_kind": "relative_return", "title": "走势", "data_interval": "日线", "data_metric": "涨跌幅", "series": [{"label": "指数", "values": [0, 1, 2]}]}, ensure_ascii=False), encoding="utf-8-sig")
            output = render_market_chart(json.loads(config.read_text(encoding="utf-8-sig")), Path(directory), (640, 360))
            self.assertTrue(output.is_file() and output.stat().st_size > 0)

    def test_all_five_chart_layouts_render_as_independent_png_files(self):
        series = [{"label": "甲", "values": [1, 2, 1.5]}, {"label": "乙", "values": [2, 1, 2.5]}]
        ohlc = [{"open": 10, "high": 11, "low": 9.5, "close": 10.7}, {"open": 10.7, "high": 11.4, "low": 10.2, "close": 10.4}, {"open": 10.4, "high": 12, "low": 10.1, "close": 11.8}]
        kinds = ("relative_return", "futures_position", "dual_axis_trend", "kline_wave", "kline_fibonacci")
        with tempfile.TemporaryDirectory() as directory:
            outputs = []
            for kind in kinds:
                config = {"id": kind, "chart_kind": kind, "title": "图表", "data_interval": "日线", "data_metric": "数值"}
                config["ohlc" if kind.startswith("kline_") else "series"] = ohlc if kind.startswith("kline_") else series
                outputs.append(render_market_chart(config, Path(directory), (640, 360)))
            self.assertEqual(5, len({path.name for path in outputs}))
            self.assertTrue(all(path.is_file() and path.stat().st_size > 0 for path in outputs))

    def test_cached_research_does_not_load_semantic_model(self):
        cached = {"model_id": "test", "queries": [{"query": "服务器", "category": "AI", "candidates": [{"asset_id": "a", "path": "a.mp4"}]}]}
        with tempfile.TemporaryDirectory() as directory, patch.object(fast_pipeline, "search_many", side_effect=AssertionError("model loaded")):
            result = fast_pipeline.research(Path(directory), Path(directory) / "facts.json", ["服务器"], 12, 5, None, "cpu", categories=["AI"], cached_visual_candidates=cached)
        self.assertEqual("cache", result["search_execution"])
        self.assertEqual("a", result["eligible_visual_candidates"]["queries"][0]["candidates"][0]["asset_id"])

    def test_semantic_index_build_rejects_missing_asset_index(self):
        script = SCRIPTS / "visual_semantic_index.py"
        result = subprocess.run([sys.executable, str(script), "build", "--asset-index", "missing.json", "--output-dir", "missing"], capture_output=True, text=True, encoding="utf-8")
        self.assertNotEqual(0, result.returncode)
        self.assertIn("asset index not found", result.stderr)

    def test_incremental_semantic_build_preserves_untargeted_assets(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first, second = root / "first.mp4", root / "second.mp4"
            first.write_bytes(b"first")
            second.write_bytes(b"second")
            assets = [{"id": "first", "path": str(first), "probe_ok": True, "duration": 3, "size": 5, "mtime_ns": 1}, {"id": "second", "path": str(second), "probe_ok": True, "duration": 3, "size": 6, "mtime_ns": 2}]
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": assets}), encoding="utf-8")
            index = root / "index"
            index.mkdir()
            rows = [{"asset_id": "first", "path": str(first), "timestamp": 1, "duration": 3}, {"asset_id": "second", "path": str(second), "timestamp": 1, "duration": 3}]
            manifest = {"model_id": "test", "assets": [{"path": str(first), "size": 5, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}, {"path": str(second), "size": 6, "mtime_ns": 2, "model_id": "test", "row_indices": [1]}], "rows": rows, "failures": []}
            (index / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32))
            result = build_index(source, index, model_id="test", selected_paths={str(first)})
            self.assertEqual(2, result["asset_count"])
            self.assertEqual(["first", "second"], [row["asset_id"] for row in result["rows"]])
            self.assertTrue(np.array_equal(np.load(index / "embeddings.npy"), np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32)))

    def test_incremental_semantic_build_removes_assets_absent_from_asset_index(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first, removed = root / "first.mp4", root / "removed.mp4"
            first.write_bytes(b"first")
            removed.write_bytes(b"removed")
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": [{"id": "first", "path": str(first), "probe_ok": True, "duration": 3, "size": 5, "mtime_ns": 1}]}), encoding="utf-8")
            index = root / "index"; index.mkdir()
            rows = [{"asset_id": "first", "path": str(first), "timestamp": 1, "duration": 3}, {"asset_id": "removed", "path": str(removed), "timestamp": 1, "duration": 3}]
            manifest = {"model_id": "test", "assets": [{"path": str(first), "size": 5, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}, {"path": str(removed), "size": 7, "mtime_ns": 2, "model_id": "test", "row_indices": [1]}], "rows": rows, "failures": []}
            (index / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32))
            result = build_index(source, index, model_id="test", selected_paths={str(first)})
            self.assertEqual(["first"], [row["asset_id"] for row in result["rows"]])

    def test_semantic_query_cache_avoids_model_reload(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            index = root / "index"; index.mkdir()
            manifest = {"model_id": "test", "rows": [{"asset_id": "a", "path": "a.mp4", "timestamp": 1, "duration": 5}], "assets": [], "failures": []}
            manifest_path = index / "manifest.json"
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0]], dtype=np.float32))
            cache = {"version": 1, "model_id": "test", "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(), "entries": {json.dumps({"query": "市场", "top_k": 12, "clip_duration": 5.0, "category": None}, ensure_ascii=False, sort_keys=True): {"query": "市场", "category": None, "candidates": [{"asset_id": "a"}], "eligible_candidates": [{"asset_id": "a"}]}}}
            (index / "query-cache.json").write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
            with patch("visual_semantic_index.ChineseClipEmbedder", side_effect=AssertionError("model loaded")):
                result = search_many(index, ["市场"])
            self.assertEqual("a", result["queries"][0]["candidates"][0]["asset_id"])

    def test_semantic_index_build_records_metric_stage(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, metrics = root / "assets.json", root / "metrics.json"
            video = root / "existing.mp4"
            video.write_bytes(b"existing")
            asset = {"id": "existing", "path": str(video), "probe_ok": True, "duration": 3, "size": 8, "mtime_ns": 1}
            source.write_text(json.dumps({"assets": [asset]}), encoding="utf-8")
            index = root / "index"
            index.mkdir()
            (index / "manifest.json").write_text(json.dumps({"model_id": "test", "assets": [{"path": str(video), "size": 8, "mtime_ns": 1, "model_id": "test", "row_indices": [0]}], "rows": [{"asset_id": "existing", "path": str(video), "timestamp": 1, "duration": 3}], "failures": []}), encoding="utf-8")
            np.save(index / "embeddings.npy", np.asarray([[1.0, 0.0]], dtype=np.float32))
            start_run(metrics, "x", 10, now=time.time())
            build_index(source, index, model_id="test", metrics_path=metrics)
            self.assertIn("semantic_index", json.loads(metrics.read_text(encoding="utf-8"))["stages"])

    def test_semantic_index_requires_explicit_full_rebuild_when_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": []}), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "--full-rebuild"):
                build_index(source, root / "index", model_id="test")
            self.assertEqual(0, build_index(source, root / "index", model_id="test", full_rebuild=True)["asset_count"])

    def test_full_rebuild_cannot_consume_production_budget(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, metrics = root / "assets.json", root / "metrics.json"
            source.write_text(json.dumps({"assets": []}), encoding="utf-8")
            start_run(metrics, "x", 10, now=time.time())
            with self.assertRaisesRegex(ValueError, "maintenance-only"):
                build_index(source, root / "index", model_id="test", metrics_path=metrics, full_rebuild=True)

    def test_semantic_index_rejects_large_unbounded_increment(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            assets = [{"id": str(index), "path": str(root / f"{index}.mp4"), "probe_ok": True, "duration": 3, "size": 1, "mtime_ns": index} for index in range(13)]
            source = root / "assets.json"
            source.write_text(json.dumps({"assets": assets}), encoding="utf-8")
            index = root / "index"; index.mkdir()
            (index / "manifest.json").write_text(json.dumps({"model_id": "test", "assets": [], "rows": [], "failures": []}), encoding="utf-8")
            np.save(index / "embeddings.npy", np.empty((0, 0), dtype=np.float32))
            with self.assertRaisesRegex(RuntimeError, "13 assets are unindexed"):
                build_index(source, index, model_id="test")
            with self.assertRaisesRegex(RuntimeError, "13 assets are unindexed"):
                build_index(source, index, model_id="test", selected_paths={item["path"] for item in assets})

    def test_project_session_preserves_completed_results_for_append(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            index = root / "index"
            index.mkdir()
            (index / "manifest.json").write_text("{}", encoding="utf-8")
            output = root / "research.json"
            output.write_text(json.dumps({"visual_candidates": {"queries": []}}), encoding="utf-8")
            state = fast_pipeline._research_session_path(root)
            state.write_text(json.dumps({"key": {"index_dir": str(index.resolve()), "manifest_sha256": fast_pipeline._sha256(index / "manifest.json"), "queries": ["A"], "categories": ["市场"]}, "output": str(output)}), encoding="utf-8")
            session = fast_pipeline.load_research_session(root, index)
            self.assertEqual(2, session["version"])
            self.assertEqual(["A"], session["searched_queries"])
            merged = fast_pipeline._merge_visual_candidates(session["visual_candidates"], {"queries": [{"query": "B", "category": "市场", "candidates": []}]})
            self.assertEqual(["B"], [item["query"] for item in merged["queries"]])

    def test_cached_research_cli_finishes_under_three_seconds(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            index = root / "index"
            index.mkdir()
            (index / "manifest.json").write_text("{}", encoding="utf-8")
            output = root / "research.json"
            output.write_text(json.dumps({"visual_candidates": {"model_id": "test", "queries": [{"query": "A", "category": "市场", "candidates": [{"asset_id": "a", "path": "a.mp4"}]}]}}), encoding="utf-8")
            fast_pipeline._research_session_path(root).write_text(json.dumps({"key": fast_pipeline._research_key(index, ["A"], ["市场"]), "output": str(output)}), encoding="utf-8")
            started = time.perf_counter()
            result = subprocess.run([sys.executable, str(SCRIPTS / "fast_pipeline.py"), "research", "--index-dir", str(index), "--fact-cache", str(root / "facts.json"), "--query", "A", "--category", "市场", "--current-project", str(root), "--output", str(output)], capture_output=True, text=True, encoding="utf-8")
            elapsed = time.perf_counter() - started
            self.assertEqual(0, result.returncode, result.stderr)
            self.assertLess(elapsed, 3.0)
            self.assertEqual("cache", json.loads(result.stdout)["search_execution"])

    def test_category_filter_runs_before_top_k(self):
        matrix = np.asarray([[1.0, 0.0], [0.8, 0.2]], dtype=np.float32)
        rows = [
            {"asset_id": "space", "path": "space.mp4", "timestamp": 1, "duration": 5, "primary_category": "航天"},
            {"asset_id": "market", "path": "market.mp4", "timestamp": 1, "duration": 5, "primary_category": "市场"},
        ]
        result = rank_embeddings(matrix, np.asarray([1.0, 0.0]), rows, top_k=1, allowed_categories={"市场"})
        self.assertEqual("market", result[0]["asset_id"])

    def test_category_filter_accepts_numbered_library_folder(self):
        matrix = np.asarray([[1.0, 0.0]], dtype=np.float32)
        rows = [{"asset_id": "market", "path": "market.mp4", "timestamp": 1, "duration": 5, "primary_category": "5. 股市与市场"}]
        result = rank_embeddings(matrix, np.asarray([1.0, 0.0]), rows, allowed_categories={"股市与市场"})
        self.assertEqual("market", result[0]["asset_id"])

    def test_seven_day_history_only_accepts_hash_bound_deliveries(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            delivered = root / "delivered"
            delivered.mkdir()
            ledger = delivered / "x_asset-ledger.json"
            ledger.write_text(json.dumps({"assets": [{"id": "used", "local_path": "B2_001.mp4", "quick_hash": "abc"}]}), encoding="utf-8")
            digest = hashlib.sha256(ledger.read_bytes()).hexdigest()
            (delivered / "x_门禁.json").write_text(json.dumps({"terminal_allowed": True, "checked_at": datetime.now(timezone.utc).isoformat(), "sha256": {"ledger": digest}}), encoding="utf-8")
            failed = root / "failed"
            failed.mkdir()
            (failed / "y_asset-ledger.json").write_text(json.dumps({"assets": [{"id": "keep", "local_path": "other.mp4"}]}), encoding="utf-8")
            (failed / "y_门禁.json").write_text(json.dumps({"terminal_allowed": False, "checked_at": datetime.now(timezone.utc).isoformat(), "sha256": {"ledger": "bad"}}), encoding="utf-8")
            history = delivered_history(root)
            self.assertEqual(["keep"], [item["asset_id"] for item in remove_recent([{"asset_id": "used", "path": "B2_002.mp4"}, {"asset_id": "keep", "path": "other.mp4"}], history)])

    def test_rejected_fresh_asset_does_not_allow_recent_fallback(self):
        used = {"ids": {"old"}, "hashes": set(), "urls": set(), "families": set(), "last_used": {"old": 10}}
        candidates = [{"asset_id": "fresh", "path": "fresh.mp4"}, {"asset_id": "old", "path": "old.mp4"}]
        result = prefer_fresh(candidates, used, {"fresh"})
        self.assertEqual([], result)

    def test_metrics_complete_only_when_delivery_calls_it(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "metrics.json"
            start_run(path, "x", 10, now=0)
            start_stage(path, "timeline", now=1)
            self.assertTrue(complete_run(path, now=2)["completed"])

    def test_metrics_separates_user_wait_from_production_time(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "metrics.json"
            start_run(path, "x", 10, now=0)
            start_user_wait(path, now=2)
            end_user_wait(path, now=7)
            complete_run(path, now=10)
            report = build_report(path)
            self.assertEqual(10.0, report["total_elapsed_seconds"])
            self.assertEqual(5.0, report["waiting_for_user_seconds"])
            self.assertEqual(5.0, report["production_elapsed_seconds"])

    def test_budget_blocks_late_render_start_and_late_delivery(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "metrics.json"
            start_run(path, "x", 10, now=0)
            with self.assertRaisesRegex(BudgetExceeded, "render-start"):
                start_stage(path, "render_review", now=600)
            blocked = json.loads(path.read_text(encoding="utf-8"))["blocked"]
            self.assertEqual("render_review", blocked["stage"])
            with self.assertRaisesRegex(BudgetExceeded, "20-minute"):
                start_stage(path, "assets", now=1200)

    def test_visual_approval_rejects_notes_copied_from_timeline(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video, contact, timeline, notes = (root / name for name in ("v.mp4", "c.jpg", "t.json", "n.json"))
            video.write_bytes(b"video")
            contact.write_bytes(b"sheet")
            semantics = {"subject": "市场", "action": "上涨", "location": "终端", "equipment": "K线"}
            timeline.write_text(json.dumps({"shots": [{"id": "s01", "script_semantics": semantics}]}), encoding="utf-8")
            observation = {"semantic_match": True, "evidence_frames": ["s01-M"], **{f"visible_{key}": value for key, value in semantics.items()}}
            notes.write_text(json.dumps({"contact_sheet_sha256": hashlib.sha256(contact.read_bytes()).hexdigest(), "shots": {"s01": observation}, "checks": {name: True for name in ("title_bar", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder")}}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "copied"):
                make_approval(video, timeline, contact, notes)

    def test_ffmpeg_thumbnail_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video, image = root / "test.mp4", root / "frame.jpg"
            subprocess.run([find_ffmpeg(), "-y", "-f", "lavfi", "-i", "color=blue:s=160x90:d=1", "-c:v", "libx264", str(video)], check=True, capture_output=True)
            self.assertTrue(extract_thumbnail(video, 0.2, image).is_file())


if __name__ == "__main__":
    unittest.main()
