#!/usr/bin/env python3
"""Contract checks for the production timeline gates."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

SCRIPT_DIR = Path(__file__).resolve().parents[1] / "scripts"
SKILL_ROOT = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from preflight import derived_source_id, has_pillarbox, run_preflight, validate_selection_manifest
from fast_pipeline import close_status, renderer_script, update_progress
from render_continuous_timeline import build_ffmpeg_command
from render_market_chart import render as render_market_chart
from render_overlay_templates import render_hook_frames
from prepare_timeline_assets import prepare
from page_reference_contract import PAGE_REFERENCE_FILENAMES
from review_render import duration_matches
from render_segmented_timeline import split_timeline
from speed_common import quick_hash
from validate_timeline import validate


def timeline(duration: float = 8.5) -> dict:
    assets = []
    shots = []
    for index in range(2):
        asset_id = f"a{index}"
        assets.append({
            "id": asset_id, "local_path": f"asset-{index}.mp4", "sha256": str(index) * 64,
            "status": "unused", "use_count": 0, "seven_day_eligible": True, "dedupe_clear": True,
            "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
            "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
            "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
        })
        start = 0.0 if index == 0 else 4.0
        end = 4.0 if index == 0 else duration
        shots.append({
            "id": f"s{index}", "start": start, "end": end,
            "source_in": 0.0, "source_out": end - start, "keyword": "行情",
            "subject": "市场", "action": "变化", "result": "形成信号",
            "asset_id": asset_id, "selection_mode": "semantic_index",
            "semantic_fields": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "information_task": "data",
            "script_range": {"start": start, "end": end},
            "chapter_id": "c01",
            "selection_reason": "主体、动作、地点、设备与当前文案匹配",
            "candidate_asset_ids": [asset_id, f"candidate-{index}"],
        })
    return {
        "script_path": "script.md", "duration_seconds": duration, "audio_delivery_mode": "silent", "assets": assets, "shots": shots,
        "chapters": [{
            "id": "c01", "start": 0.0, "end": duration, "thesis": "市场信号",
        }],
        "dedupe_audit": {"lookback_hours": 168, "checked_at": datetime.now(timezone.utc).isoformat()},
        "overlays": [
            {
                "id": "hook", "type": "hook", "role": "hook", "start": 0.0, "end": 4.0,
                "chapter_id": "c01",
                "background_shot_id": "s0", "image_path": str(SKILL_ROOT / "assets" / "approved-pages" / PAGE_REFERENCE_FILENAMES["hook"]), "frame_pattern": "hook/%04d.png",
                "chinese_text": "市场信号", "hook_color_fallback": "white",
                "reference_template": PAGE_REFERENCE_FILENAMES["hook"],
                "hook_text_colors": {line: {"color": "#FFFFFF", "opacity": 1.0} for line in ("thesis", "judgment", "evidence")},
                "hook_contrast": {line: {"background_luminance": 0.02, "contrast_ratio": 17.5} for line in ("thesis", "judgment", "evidence")},
            },
            {
                "id": "chart", "type": "chart", "information_task": "data", "start": 4.0, "end": 8.5,
                "chapter_id": "c01", "script_range": {"start": 4.0, "end": 8.5},
                "background_shot_id": "s1", "image_path": str(SKILL_ROOT / "assets" / "approved-pages" / PAGE_REFERENCE_FILENAMES["relative_return"]), "chinese_text": "资金正在进场",
                "chart_kind": "relative_return", "data_chain_id": "chain-1",
                "data_interval": "一月至七月", "data_metric": "累计涨跌幅", "source_state": "user_copy",
                "chart_config_path": "C:/project/chart.json", "source_excerpt": "市场信号",
                "reference_template": PAGE_REFERENCE_FILENAMES["relative_return"],
            },
        ],
    }


class TimelineGuardTests(unittest.TestCase):
    def test_seamless_information_pages_are_allowed(self):
        self.assertFalse(validate(timeline()))

    def test_duplicate_information_text_is_rejected(self):
        data = timeline()
        data["overlays"][1]["chinese_text"] = data["overlays"][0]["chinese_text"]
        self.assertTrue(any("duplicate information content" in error for error in validate(data)))

    def test_page_semantics_require_the_unique_reference_template(self):
        data = timeline()
        data["overlays"][1]["reference_template"] = PAGE_REFERENCE_FILENAMES["news"]
        self.assertTrue(any("reference_template must be" in error for error in validate(data)))

    def test_overlay_type_must_match_current_contract(self):
        data = timeline()
        data["overlays"][1]["type"] = "info"
        self.assertTrue(any("invalid type" in error for error in validate(data)))

    def test_hook_requires_dynamic_frame_pattern(self):
        data = timeline()
        del data["overlays"][0]["frame_pattern"]
        self.assertTrue(any("frame_pattern" in error for error in validate(data)))

    def test_audio_delivery_mode_must_be_explicit_and_consistent(self):
        data = timeline()
        data.pop("audio_delivery_mode")
        self.assertTrue(any("audio_delivery_mode" in error for error in validate(data)))
        data = timeline()
        data["audio_delivery_mode"] = "narration"
        self.assertTrue(any("must be silent" in error for error in validate(data)))

    def test_timing_audio_uses_one_field_family_and_never_changes_delivery_mode(self):
        data = timeline()
        data["timing_audio_path"] = "timing.mp3"
        self.assertTrue(any("timing_audio_segments" in error for error in validate(data)))
        data["timing_audio_segments"] = [{"start": 0.0, "end": 8.5, "text": "市场信号"}]
        for shot in data["shots"]:
            shot["timing_audio_range"] = {"start": shot["start"], "end": shot["end"]}
        data["overlays"][1].update({
            "timing_audio_range": {"start": 4.0, "end": 8.5},
            "timing_audio_text": "市场信号",
            "audio_semantic_match": True,
        })
        self.assertFalse(any("timing audio" in error or "timing_audio" in error for error in validate(data)))
        self.assertEqual("silent", data["audio_delivery_mode"])

    def test_source_excerpt_must_be_verbatim(self):
        data = timeline()
        del data["overlays"][1]["source_excerpt"]
        self.assertTrue(any("source_excerpt" in error for error in validate(data)))
        data = timeline()
        data["overlays"][1]["source_excerpt"] = "原文中不存在"
        self.assertTrue(any("source_excerpt must appear" in error for error in validate(data)))

    def test_missing_seven_day_audit_is_rejected(self):
        data = timeline()
        del data["dedupe_audit"]
        self.assertTrue(any("seven-day dedupe audit" in error for error in validate(data)))

    def test_explicit_single_project_dedupe_exception_is_allowed(self):
        data = timeline()
        data["dedupe_audit"] = {
            "lookback_hours": 0,
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "user_authorized_exception": True,
            "exception_reason": "用户明确授权本片绕过七日去重",
        }
        self.assertFalse(any("seven-day dedupe audit" in error for error in validate(data)))

    def test_unclean_asset_is_rejected(self):
        data = timeline()
        data["assets"][0]["embedded_subtitles_free"] = False
        self.assertTrue(any("visual cleanliness gate" in error for error in validate(data)))

    def test_shot_semantic_fields_are_required(self):
        for field in ("semantic_fields", "information_task", "script_range", "chapter_id", "selection_reason"):
            data = timeline()
            del data["shots"][0][field]
            self.assertTrue(any(field in error for error in validate(data)), field)

    def test_every_chapter_requires_a_covering_shot(self):
        data = timeline()
        data["chapters"].append({
            "id": "c02", "start": 8.5, "end": 9.5, "thesis": "未承载章节",
        })
        self.assertTrue(any("chapters without any covering shot: c02" in error for error in validate(data)))

    def test_non_chart_page_types_are_rejected(self):
        for page_type in ("fact", "data", "number", "comparison", "causal"):
            data = timeline()
            data["overlays"][1]["type"] = page_type
            self.assertTrue(any("invalid type" in error for error in validate(data)), page_type)

    def test_preflight_propagates_invalid_overlay_type(self):
        data = timeline()
        data["overlays"][1]["type"] = "fact"
        self.assertTrue(any("invalid type" in error for error in run_preflight(data, require_files=False)))

    def test_hook_and_news_use_four_seconds(self):
        hook = timeline()
        hook["overlays"][0]["end"] = 4.5
        self.assertTrue(any("4.0 seconds" in error for error in validate(hook)))

        news = timeline(8.0)
        news["chapters"][0]["end"] = 8.0
        news["shots"][1].update({"end": 8.0, "source_out": 4.0, "script_range": {"start": 4.0, "end": 8.0}})
        news["overlays"][1] = {
            "id": "info", "type": "news", "start": 4.0, "end": 8.5,
            "chapter_id": "c01", "information_task": "news", "script_range": {"start": 4.0, "end": 8.0},
            "background_shot_id": "s1", "image_path": "info.png", "chinese_text": "新闻证据",
            "reference_template": PAGE_REFERENCE_FILENAMES["news"],
        }
        self.assertTrue(any("4.0 seconds" in error for error in validate(news)))
        self.assertTrue(any("screenshot_path is required" in error for error in validate(news)))

    def test_chart_page_uses_existing_information_task_and_4_5_seconds(self):
        data = timeline()
        data["overlays"][1].update({
            "type": "chart", "information_task": "data", "end": 8.5,
            "chart_kind": "relative_return", "data_chain_id": "chain-1",
            "data_interval": "一月至七月", "data_metric": "累计涨跌幅",
            "source_state": "user_copy",
        })
        self.assertFalse(validate(data))

    def test_chart_page_rejects_four_second_duration(self):
        data = timeline(8.0)
        data["chapters"][0]["end"] = 8.0
        data["shots"][1]["end"] = 8.0
        data["shots"][1]["source_out"] = 4.0
        data["shots"][1]["script_range"]["end"] = 8.0
        data["overlays"][1]["end"] = 8.0
        data["overlays"][1]["script_range"]["end"] = 8.0
        data["overlays"][1].update({
            "type": "chart", "information_task": "data",
            "chart_kind": "relative_return", "data_chain_id": "chain-1",
            "data_interval": "一月至七月", "data_metric": "累计涨跌幅",
            "source_state": "user_copy",
        })
        self.assertTrue(any("4.5 seconds" in error for error in validate(data)))

    def test_market_chart_renderer_creates_png(self):
        config = {
            "id": "chart-test", "chart_kind": "relative_return",
            "data_interval": "一月至七月", "data_metric": "累计涨跌幅",
            "series": [{"label": "指数甲", "values": [0, 1, 0.5, 2]}],
        }
        with tempfile.TemporaryDirectory() as folder:
            output = render_market_chart(config, Path(folder), (640, 360))
            self.assertTrue(output.is_file())

    def test_chart_renderer_does_not_embed_disclaimer(self):
        source = (SCRIPT_DIR / "render_market_chart.py").read_text(encoding="utf-8")
        self.assertNotIn("内容仅为个人观点，不构成投资建议", source)

    def test_global_disclaimer_filter_is_not_disabled_for_chart_pages(self):
        command = build_ffmpeg_command(timeline(), "preview.mp4", profile="final", ffmpeg="ffmpeg", encoder="libx264")
        filter_complex = command[command.index("-filter_complex") + 1]
        self.assertNotIn("enable='not(", filter_complex)

    def test_hook_renderer_is_transparent_and_uses_reference_palette(self):
        config = timeline()["overlays"][0]
        config.pop("hook_color_fallback")
        config["hook_text_colors"] = {
            "thesis": {"color": "#F2C86B", "opacity": 1.0},
            "judgment": {"color": "#F8F9FB", "opacity": 0.95},
            "evidence": {"color": "#C6CCD3", "opacity": 0.8},
        }
        with tempfile.TemporaryDirectory() as folder:
            output, _ = render_hook_frames(config, Path(folder), (640, 360))
            from PIL import Image
            image = Image.open(output).convert("RGBA")
            self.assertEqual(0, image.getpixel((0, 0))[3])

    def test_white_hook_fallback_still_requires_measured_contrast(self):
        data = timeline()
        del data["overlays"][0]["hook_contrast"]
        self.assertTrue(any("white fallback" in error for error in validate(data)))

    def test_information_page_requires_script_range(self):
        data = timeline()
        del data["overlays"][1]["script_range"]
        self.assertTrue(any("script_range" in error for error in validate(data)))

    def test_information_page_range_must_stay_in_chapter(self):
        data = timeline()
        data["chapters"].append({
            "id": "c02", "start": 8.0, "end": 9.0, "thesis": "第二章",
        })
        data["overlays"][1]["chapter_id"] = "c02"
        self.assertTrue(any("script_range must stay within chapter" in error for error in validate(data)))

    def test_long_broll_run_is_allowed_when_each_cut_is_2_to_5_seconds(self):
        data = timeline(12.0)
        data["shots"] = []
        data["assets"] = []
        for index in range(3):
            asset_id = f"b{index}"
            data["assets"].append({
                "id": asset_id, "local_path": f"{asset_id}.mp4", "sha256": str(index + 3) * 64,
                "status": "unused", "use_count": 0, "seven_day_eligible": True, "dedupe_clear": True,
                "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
                "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
                "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
            })
            data["shots"].append({
                "id": f"b{index}", "start": index * 4.0, "end": (index + 1) * 4.0, "source_in": 0.0, "source_out": 4.0,
                "keyword": "市场", "subject": "交易员", "action": "观察", "result": "形成信号", "asset_id": asset_id,
                "selection_mode": "semantic_index",
                "semantic_fields": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "information_task": "broll", "script_range": {"start": index * 4.0, "end": (index + 1) * 4.0}, "chapter_id": "c01",
                "selection_reason": "当前章节的交易员观察行情实拍", "candidate_asset_ids": [asset_id, f"candidate-{index}"],
            })
        data["overlays"][0]["background_shot_id"] = "b0"
        data["overlays"][1]["background_shot_id"] = "b1"
        self.assertFalse(validate(data))

    def test_broll_cut_shorter_than_two_seconds_is_rejected(self):
        data = timeline()
        data["shots"][0]["information_task"] = "broll"
        data["shots"][0]["end"] = 1.5
        data["shots"][0]["source_out"] = 1.5
        data["shots"][1]["start"] = 1.5
        self.assertTrue(any("broll duration" in error for error in validate(data)))

    def test_false_global_eligibility_credential_is_rejected(self):
        data = timeline()
        asset = data["assets"][1]
        asset["seven_day_eligible"] = False
        self.assertTrue(any("seven-day dedupe status" in error for error in validate(data)))

    def test_historical_delivered_hash_is_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            ledger = root / "2026-08-06_文档_旧片_asset-ledger.json"
            ledger.write_text('{"assets":[{"sha256":"' + "0" * 64 + '"}]}', encoding="utf-8")
            import hashlib, json
            gate = {
                "terminal_allowed": True,
                "checked_at": datetime.now(timezone.utc).isoformat(),
                "sha256": {"ledger": hashlib.sha256(ledger.read_bytes()).hexdigest()},
            }
            (root / "2026-08-06_文档_旧片_交付门禁.json").write_text(json.dumps(gate), encoding="utf-8")
            errors = run_preflight(data, require_files=False, history_root=root)
        self.assertTrue(any("material identity was used" in error for error in errors))

    def test_same_project_revision_is_not_treated_as_cross_project_reuse(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            data["project_path"] = str(root)
            ledger = root / "旧版_asset-ledger.json"
            ledger.write_text('{"assets":[{"sha256":"' + "0" * 64 + '"}]}', encoding="utf-8")
            import hashlib
            gate = {"terminal_allowed": True, "checked_at": datetime.now(timezone.utc).isoformat(), "sha256": {"ledger": hashlib.sha256(ledger.read_bytes()).hexdigest()}}
            (root / "旧版_交付门禁.json").write_text(json.dumps(gate), encoding="utf-8")
            errors = run_preflight(data, require_files=False, history_root=root)
        self.assertFalse(any("material identity was used" in error for error in errors))

    def test_research_manifest_requires_frame_evidence_for_selected_assets(self):
        data = timeline()
        manifest = {
            "source": "fast_pipeline research",
            "eligible_visual_candidates": {"queries": [{"candidates": [
                {"asset_id": asset["id"], "path": asset["local_path"], "sha256": asset["sha256"], "thumbnail": f"{asset['id']}.jpg", "source_in": shot["source_in"], "source_out": shot["source_out"]}
                for asset, shot in zip(data["assets"], data["shots"])
            ]}]},
        }
        self.assertFalse(validate_selection_manifest(manifest, data["assets"], data["shots"]))
        manifest["eligible_visual_candidates"]["queries"][0]["candidates"][0].pop("thumbnail")
        self.assertTrue(validate_selection_manifest(manifest, data["assets"], data["shots"]))

    def test_selection_manifest_cannot_authorize_a_substituted_file_or_range(self):
        data = timeline()
        candidate = {"asset_id": "a0", "path": "approved.mp4", "sha256": "f" * 64, "thumbnail": "approved.jpg", "source_in": 0.0, "source_out": 4.0}
        manifest = {"source": "fast_pipeline research", "eligible_visual_candidates": {"queries": [{"candidates": [candidate]}]}}
        errors = validate_selection_manifest(manifest, [data["assets"][0]], [data["shots"][0]])
        self.assertTrue(any("path/hash" in error for error in errors))
        candidate.update({"path": data["assets"][0]["local_path"], "sha256": data["assets"][0]["sha256"], "source_in": 10.0, "source_out": 14.0})
        errors = validate_selection_manifest(manifest, [data["assets"][0]], [data["shots"][0]])
        self.assertTrue(any("reviewed range" in error for error in errors))

    def test_preflight_recomputes_indexed_file_hash(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            index_assets = []
            for asset in data["assets"]:
                path = root / f"{asset['id']}.mp4"
                path.write_bytes(asset["id"].encode("ascii"))
                digest = quick_hash(path)
                asset.update({"local_path": str(path), "quick_hash": digest})
                asset.pop("sha256", None)
                index_assets.append({
                    "id": asset["id"], "path": str(path), "quick_hash": digest,
                    "subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": ["行情"],
                    "frame_evidence": "frame.jpg", "cleanliness_evidence": "reviewed",
                    "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
                })
            Path(data["assets"][0]["local_path"]).write_bytes(b"changed after indexing")
            with patch("preflight.has_pillarbox", return_value=False):
                errors = run_preflight(data, require_files=True, asset_index={"assets": index_assets})
        self.assertTrue(any("quick hash does not match indexed file" in error for error in errors))

    def test_predicted_page_requires_same_day_basis(self):
        data = timeline()
        data["overlays"][1]["source_state"] = "user_authorized_prediction"
        errors = validate(data)
        self.assertTrue(any("prediction_basis" in error for error in errors))
        self.assertTrue(any("prediction_corpus_date" in error for error in errors))
        data["overlays"][1].update({"prediction_basis": ["文本给出明确区间与方向"], "prediction_corpus_date": "2026-08-27"})
        self.assertFalse(any("predicted page requires" in error for error in validate(data)))

    def test_duplicate_overlay_files_are_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            duplicate = Path(folder) / "same.png"
            duplicate.write_bytes(b"same")
            data["overlays"][0]["image_path"] = str(duplicate)
            data["overlays"][1]["image_path"] = str(duplicate)
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("duplicate information image" in error for error in errors))

    def test_preflight_requires_real_dynamic_hook_frames(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            data["overlays"][0]["frame_pattern"] = str(root / "%04d.png")
            (root / "0000.png").write_bytes(b"same")
            (root / "0030.png").write_bytes(b"same")
            errors = run_preflight(data, require_files=True)
            self.assertTrue(any("must differ" in error for error in errors))
            (root / "0030.png").unlink()
            errors = run_preflight(data, require_files=True)
            self.assertTrue(any("0000 and 0030" in error for error in errors))

    def test_continuous_renderer_rejects_long_timeline(self):
        data = timeline(120.0)
        data["shots"][-1]["end"] = 120.0
        with self.assertRaisesRegex(ValueError, "segmented"):
            build_ffmpeg_command(data, "out.mp4", ffmpeg="ffmpeg")

    def test_renderer_requests_exact_frame_count(self):
        command = build_ffmpeg_command(timeline(), "out.mp4", ffmpeg="ffmpeg")
        frames_index = command.index("-frames:v")
        self.assertEqual(command[frames_index + 1], "255")

    def test_renderer_blurs_raw_video_before_center_page_overlay(self):
        command = build_ffmpeg_command(timeline(), "out.mp4", ffmpeg="ffmpeg")
        filters = command[command.index("-filter_complex") + 1]
        self.assertIn("[base]split=2[bgsrc][centersrc]", filters)
        self.assertIn("[center][img0]overlay=0:0", filters)
        self.assertIn("[blurred][ov1]overlay=0:604[vertical]", filters)
        self.assertNotIn("pagebg", filters)

    def test_external_disclaimer_stays_at_boundary_during_chart_pages(self):
        data = timeline()
        data["chrome_path"] = "chrome.png"
        command = build_ffmpeg_command(data, "out.mp4", ffmpeg="ffmpeg")
        filters = command[command.index("-filter_complex") + 1]
        self.assertIn("[vertical][chrome]overlay=0:0[composed]", filters)
        self.assertNotIn("enable='not(between(t,4.0,8.5))'", filters)

    def test_duration_tolerance_is_two_frames(self):
        self.assertTrue(duration_matches(120.0, 120.06))
        self.assertFalse(duration_matches(120.0, 120.07))

    def test_file_identity_uses_publisher_id(self):
        self.assertEqual(derived_source_id(Path("Pexels_36435763_001.mp4"), None), derived_source_id(Path("Pexels_36435763_002.mp4"), None))

    def test_embedded_vertical_frame_is_detected(self):
        with tempfile.TemporaryDirectory() as directory:
            video = Path(directory) / "embedded.mp4"
            subprocess.run([
                "ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=black:s=1280x720:d=1",
                "-vf", "drawbox=x=460:y=0:w=360:h=720:color=red:t=fill", "-c:v", "libx264", str(video),
            ], check=True)
            self.assertTrue(has_pillarbox(video, 0, 0.8))

    def test_formal_entry_selects_segmented_renderer_for_long_timeline(self):
        self.assertEqual(renderer_script(timeline(120.0)), "render_segmented_timeline.py")
        self.assertEqual(renderer_script(timeline()), "render_continuous_timeline.py")

    def test_segmenter_preserves_all_shots_without_large_segments(self):
        data = timeline(100.0)
        data["shots"] = []
        data["assets"] = []
        data["overlays"] = []
        for index in range(20):
            data["shots"].append({"id": f"s{index}", "start": index * 5.0, "end": (index + 1) * 5.0, "asset_id": f"a{index}"})
            data["assets"].append({"id": f"a{index}", "local_path": f"a{index}.mp4"})
        segments = split_timeline(data)
        self.assertEqual(sum(len(item["shots"]) for item in segments), 20)
        self.assertTrue(all(len(item["shots"]) <= 5 and item["duration_seconds"] <= 25.0 for item in segments))

    def test_segmenter_rejects_when_every_boundary_splits_an_overlay(self):
        data = {"duration_seconds": 30.0, "shots": [], "assets": [], "overlays": [{"start": 0.0, "end": 30.0}]}
        for index in range(6):
            data["shots"].append({"id": f"s{index}", "start": index * 5.0, "end": (index + 1) * 5.0, "asset_id": f"a{index}"})
            data["assets"].append({"id": f"a{index}", "local_path": f"a{index}.mp4"})
        with self.assertRaisesRegex(ValueError, "no safe segmented rendering boundary after shot s0"):
            split_timeline(data)

    def test_status_controller_requires_exhausted_correction_before_blocking(self):
        with tempfile.TemporaryDirectory() as directory:
            status = Path(directory) / "status.json"
            status.write_text(json.dumps({"state": "in_progress"}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "exhausted correction"):
                close_status(status, "blocked_external", "缺少合格素材")
            result = close_status(status, "blocked_external", "缺少合格素材", correction_exhausted=True)
            self.assertEqual("blocked_external", result["state"])
            self.assertFalse(result["terminal_allowed"])

    def test_progress_checkpoint_stays_non_terminal_and_matches_task(self):
        with tempfile.TemporaryDirectory() as directory:
            status = Path(directory) / "status.json"
            status.write_text(json.dumps({"state": "in_progress", "terminal_allowed": False, "target_duration_seconds": 8.5}), encoding="utf-8")
            result = update_progress(status, "first_review_ready", 8.5, contact_sheet=Path(directory) / "sheet.jpg")
            self.assertEqual("first_review_ready", result["current_stage"])
            self.assertEqual("in_progress", result["state"])
            self.assertFalse(result["terminal_allowed"])
            with self.assertRaisesRegex(ValueError, "duration"):
                update_progress(status, "preflight_passed", 9.0)


if __name__ == "__main__":
    unittest.main()
