import json
import hashlib
import subprocess
import sys
import tempfile
import time
import unittest
import shutil
from pathlib import Path
from unittest.mock import patch


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "delivery_gate.py"
FAST_PIPELINE = Path(__file__).resolve().parents[1] / "scripts" / "fast_pipeline.py"
REVIEW_RENDER = Path(__file__).resolve().parents[1] / "scripts" / "review_render.py"
sys.path.insert(0, str(SCRIPT.parent))
from validate_timeline import validate
import fast_pipeline


class DeliveryGateCliTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.video = self.root / "final.mp4"
        self.timeline = self.root / "timeline.json"
        self.preflight = self.root / "preflight.json"
        self.ledger = self.root / "ledger.json"
        self.review = self.root / "review.json"
        self.status = self.root / "status.json"
        self.report = self.root / "gate.json"
        self.permit = self.root / "permit.json"
        self.metrics = self.root / "metrics.json"
        self.asset_index = self.root / "asset-index.json"
        self.contact = self.root / "contact.jpg"
        self.approval = self.root / "approval.json"

        self.metrics.write_text(json.dumps({"started_at_epoch": time.time(), "stages": {}, "budgets_seconds": {}}), encoding="utf-8")
        self.status.write_text(json.dumps({"state": "in_progress", "terminal_allowed": False, "target_duration_seconds": 10.0}), encoding="utf-8")
        self.asset_index.write_text(json.dumps({"assets": []}), encoding="utf-8")
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            self.skipTest("ffmpeg is required")
        subprocess.run([ffmpeg, "-y", "-f", "lavfi", "-i", "color=blue:s=32x32:r=30:d=10", "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(self.video)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        timeline = {
            "duration_seconds": 10.0,
            "finalize_permit_path": str(self.permit),
            "shots": [
                {"id": "s01", "start": 0.0, "end": 5.0, "asset_id": "a01"},
                {"id": "s02", "start": 5.0, "end": 10.0, "asset_id": "a02"},
            ],
        }
        self.timeline.write_text(json.dumps(timeline), encoding="utf-8")
        self.permit.write_text(json.dumps({
            "source": "fast_pipeline finalize",
            "profile": "final",
            "output_video_path": str(self.video),
            "timeline_sha256": hashlib.sha256(self.timeline.read_bytes()).hexdigest(),
        }), encoding="utf-8")
        timeline_hash = hashlib.sha256(self.timeline.read_bytes()).hexdigest()
        self.preflight.write_text(json.dumps({"timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash, "asset_index": str(self.asset_index.resolve()), "asset_index_sha256": hashlib.sha256(self.asset_index.read_bytes()).hexdigest(), "ok": True, "errors": []}), encoding="utf-8")
        self.ledger.write_text(json.dumps({
            "asset_count": 2,
            "assets": [
                {"id": "a01", "local_path": "a.mp4", "sha256": "1" * 64},
                {"id": "a02", "local_path": "b.mp4", "sha256": "2" * 64},
            ],
            "uses": [
                {"shot_id": "s01", "asset_id": "a01", "keyword": "芯片"},
                {"shot_id": "s02", "asset_id": "a02", "keyword": "数据中心"},
            ], "timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash,
        }), encoding="utf-8")
        self.contact.write_bytes(b"sheet")
        self.approval.write_text(json.dumps({"hashes": {"video_sha256": hashlib.sha256(self.video.read_bytes()).hexdigest(), "timeline_sha256": timeline_hash, "contact_sheet_sha256": hashlib.sha256(self.contact.read_bytes()).hexdigest()}}), encoding="utf-8")
        self.review.write_text(json.dumps({
            "video": str(self.video),
            "timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash,
            "video_duration": 10.0,
            "target_duration": 10.0,
            "shots": [
                {"id": "s01", "checked": True, "semantic_checked": True},
                {"id": "s02", "checked": True, "semantic_checked": True},
            ],
            "contact_sheet": str(self.contact), "contact_sheet_sha256": hashlib.sha256(self.contact.read_bytes()).hexdigest(),
            "visual_approval": str(self.approval), "visual_approval_sha256": hashlib.sha256(self.approval.read_bytes()).hexdigest(),
            "errors": [],
            "ok": True,
        }), encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def run_gate(self):
        return subprocess.run([
            sys.executable, str(SCRIPT),
            "--video", str(self.video),
            "--timeline", str(self.timeline),
            "--preflight", str(self.preflight),
            "--ledger", str(self.ledger),
            "--final-review", str(self.review),
            "--output", str(self.report),
        ], capture_output=True, text=True, encoding="utf-8")

    def test_complete_artifacts_open_terminal_gate_and_hash_every_input(self):
        result = self.run_gate()
        self.assertEqual(0, result.returncode, result.stderr)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(report["ok"])
        self.assertTrue(report["terminal_allowed"])
        self.assertEqual({"video", "timeline", "preflight", "ledger", "final_review"}, set(report["sha256"]))
        self.assertEqual("in_progress", json.loads(self.status.read_text(encoding="utf-8"))["state"])

    def test_failed_final_review_keeps_workflow_in_progress(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review.update({"ok": False, "errors": ["black frame"]})
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertFalse(report["terminal_allowed"])
        status = json.loads(self.status.read_text(encoding="utf-8"))
        self.assertEqual("in_progress", status["state"])

    def test_missing_per_shot_semantic_observation_blocks_delivery(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review["shots"][1]["semantic_checked"] = False
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("semantic visual observations" in item for item in report["errors"]))

    def test_missing_source_hash_blocks_delivery(self):
        ledger = json.loads(self.ledger.read_text(encoding="utf-8"))
        ledger["assets"][1].pop("sha256")
        self.ledger.write_text(json.dumps(ledger), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("source file hash" in item for item in report["errors"]))

    def test_source_metadata_is_optional(self):
        ledger = json.loads(self.ledger.read_text(encoding="utf-8"))
        ledger["assets"][0] = {
            "id": "a01", "local_path": "a.mp4", "source_type": "local_library",
            "quick_hash": "abc",
        }
        self.ledger.write_text(json.dumps(ledger), encoding="utf-8")
        result = self.run_gate()
        self.assertEqual(0, result.returncode, result.stderr)

    def test_review_for_another_video_blocks_delivery(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review["video"] = str(self.root / "old.mp4")
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("different video" in item for item in report["errors"]))

    def test_fast_pipeline_approve_automatically_calls_the_delivery_gate(self):
        gate = {"terminal_allowed": True, "sha256": {"video": "x"}}
        with patch.object(fast_pipeline, "_run", return_value=subprocess.CompletedProcess([], 0, stdout="", stderr="")), patch.object(fast_pipeline, "deliver", return_value=gate) as delivery:
            result = fast_pipeline.approve(
                self.video, self.timeline, self.preflight, self.ledger, self.contact,
                self.root / "notes.json", self.approval, self.review, self.report,
                self.status, self.metrics,
            )
        self.assertTrue(result["terminal_allowed"])
        self.assertEqual("x", result["sha256"]["video"])
        delivery.assert_called_once_with(self.video, self.timeline, self.preflight, self.ledger, self.review, self.status, self.report, self.metrics)

    def test_failed_final_review_never_calls_delivery(self):
        with patch.object(fast_pipeline, "_run", side_effect=[subprocess.CompletedProcess([], 0), RuntimeError("review failed")]), patch.object(fast_pipeline, "deliver") as delivery:
            with self.assertRaisesRegex(RuntimeError, "review failed"):
                fast_pipeline.approve(
                    self.video, self.timeline, self.preflight, self.ledger, self.contact,
                    self.root / "notes.json", self.approval, self.review, self.report,
                    self.status, self.metrics,
                )
        delivery.assert_not_called()
        self.assertEqual("in_progress", json.loads(self.status.read_text(encoding="utf-8"))["state"])

    def test_completed_status_blocks_approval_before_outputs_are_touched(self):
        self.status.write_text(json.dumps({"state": "complete", "terminal_allowed": True, "target_duration_seconds": 10.0}), encoding="utf-8")
        with patch.object(fast_pipeline, "_run") as runner:
            with self.assertRaisesRegex(ValueError, "only in_progress"):
                fast_pipeline.approve(
                    self.video, self.timeline, self.preflight, self.ledger, self.contact,
                    self.root / "notes.json", self.approval, self.review, self.report,
                    self.status, self.metrics,
                )
        runner.assert_not_called()

    def test_completed_status_blocks_finalize_before_project_outputs_are_created(self):
        self.status.write_text(json.dumps({"state": "complete", "terminal_allowed": True, "target_duration_seconds": 10.0}), encoding="utf-8")
        project = self.root / "new-project-output"
        with patch.object(fast_pipeline, "OFFICIAL_OUTPUT_DIR", self.root.resolve()), patch.object(fast_pipeline, "_run") as runner:
            with self.assertRaisesRegex(ValueError, "only in_progress"):
                fast_pipeline.finalize(
                    self.timeline, self.asset_index, self.root / "overlays", self.root / "out.mp4",
                    project, self.metrics, self.status,
                )
        self.assertFalse(project.exists())
        runner.assert_not_called()

    def test_commit_failure_cannot_leave_a_complete_status(self):
        completed_gate = subprocess.CompletedProcess([], 0, stdout=json.dumps({"terminal_allowed": True, "sha256": {"video": "x"}}), stderr="")
        with patch.object(fast_pipeline, "_run", return_value=completed_gate), patch.object(fast_pipeline, "commit_ledger", side_effect=RuntimeError("ledger write failed")):
            with self.assertRaisesRegex(RuntimeError, "ledger write failed"):
                fast_pipeline.deliver(self.video, self.timeline, self.preflight, self.ledger, self.review, self.status, self.report, self.metrics)
        self.assertEqual("in_progress", json.loads(self.status.read_text(encoding="utf-8"))["state"])

    def test_corrupt_video_is_blocked(self):
        self.video.write_bytes(b"not-an-mp4")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        self.assertTrue(any("probeable MP4" in item for item in json.loads(self.report.read_text(encoding="utf-8"))["errors"]))

    def test_valid_but_changed_video_hash_is_blocked(self):
        changed = self.root / "changed.mp4"
        subprocess.run([shutil.which("ffmpeg"), "-y", "-i", str(self.video), "-c", "copy", "-metadata", "comment=changed", str(changed)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        changed.replace(self.video)
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        self.assertTrue(any("current video" in item for item in json.loads(self.report.read_text(encoding="utf-8"))["errors"]))

    def test_modified_approval_is_blocked(self):
        payload = json.loads(self.approval.read_text(encoding="utf-8")); payload["tampered"] = True
        self.approval.write_text(json.dumps(payload), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        self.assertTrue(any("visual approval hash" in item for item in json.loads(self.report.read_text(encoding="utf-8"))["errors"]))

    def test_stricter_approval_may_bind_review_notes_too(self):
        payload = json.loads(self.approval.read_text(encoding="utf-8"))
        payload["hashes"]["review_notes_sha256"] = "3" * 64
        self.approval.write_text(json.dumps(payload), encoding="utf-8")
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review["visual_approval_sha256"] = hashlib.sha256(self.approval.read_bytes()).hexdigest()
        self.review.write_text(json.dumps(review), encoding="utf-8")
        self.assertEqual(0, self.run_gate().returncode)

    def test_review_cli_has_no_audio_input(self):
        result = subprocess.run([sys.executable, str(REVIEW_RENDER), "--help"], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertNotIn("--source-audio", result.stdout)
        self.assertNotIn("--reference-audio", result.stdout)

    def test_fast_pipeline_has_four_production_commands_and_no_public_deliver(self):
        result = subprocess.run([sys.executable, str(FAST_PIPELINE), "--help"], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(0, result.returncode, result.stderr)
        for command in ("init", "research", "finalize", "approve"):
            self.assertIn(command, result.stdout)
        self.assertNotIn("deliver", result.stdout)


if __name__ == "__main__":
    unittest.main()
