import json
import hashlib
import subprocess
import sys
import tempfile
import time
import unittest
import shutil
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "delivery_gate.py"
FAST_PIPELINE = Path(__file__).resolve().parents[1] / "scripts" / "fast_pipeline.py"
REVIEW_RENDER = Path(__file__).resolve().parents[1] / "scripts" / "review_render.py"
sys.path.insert(0, str(SCRIPT.parent))
from validate_timeline import validate


class DeliveryGateCliTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.video = self.root / "final.mp4"
        self.timeline = self.root / "timeline.json"
        self.preflight = self.root / "preflight.json"
        self.ledger = self.root / "ledger.json"
        self.review = self.root / "review.json"
        self.status = self.root / "status.json"
        self.report = self.root / "gate.json"
        self.permit = self.root / "permit.json"
        self.metrics = self.root / "metrics.json"
        self.contact = self.root / "contact.jpg"
        self.approval = self.root / "approval.json"

        self.metrics.write_text(json.dumps({"started_at_epoch": time.time(), "stages": {}, "budgets_seconds": {}}), encoding="utf-8")
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            self.skipTest("ffmpeg is required")
        subprocess.run([ffmpeg, "-y", "-f", "lavfi", "-i", "color=blue:s=32x32:r=30:d=10", "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(self.video)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        timeline = {
            "duration_seconds": 10.0,
            "finalize_permit_path": str(self.permit),
            "shots": [
                {"id": "s01", "start": 0.0, "end": 5.0, "asset_id": "a01"},
                {"id": "s02", "start": 5.0, "end": 10.0, "asset_id": "a02"},
            ],
        }
        self.timeline.write_text(json.dumps(timeline), encoding="utf-8")
        self.permit.write_text(json.dumps({
            "source": "fast_pipeline finalize",
            "profile": "final",
            "output_video_path": str(self.video),
            "timeline_sha256": hashlib.sha256(self.timeline.read_bytes()).hexdigest(),
        }), encoding="utf-8")
        timeline_hash = hashlib.sha256(self.timeline.read_bytes()).hexdigest()
        self.preflight.write_text(json.dumps({"timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash, "ok": True, "errors": []}), encoding="utf-8")
        self.ledger.write_text(json.dumps({
            "asset_count": 2,
            "assets": [
                {"id": "a01", "local_path": "a.mp4", "sha256": "1" * 64},
                {"id": "a02", "local_path": "b.mp4", "sha256": "2" * 64},
            ],
            "uses": [
                {"shot_id": "s01", "asset_id": "a01", "keyword": "芯片"},
                {"shot_id": "s02", "asset_id": "a02", "keyword": "数据中心"},
            ], "timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash,
        }), encoding="utf-8")
        self.contact.write_bytes(b"sheet")
        self.approval.write_text(json.dumps({"hashes": {"video_sha256": hashlib.sha256(self.video.read_bytes()).hexdigest(), "timeline_sha256": timeline_hash, "contact_sheet_sha256": hashlib.sha256(self.contact.read_bytes()).hexdigest()}}), encoding="utf-8")
        self.review.write_text(json.dumps({
            "video": str(self.video),
            "timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash,
            "video_duration": 10.0,
            "target_duration": 10.0,
            "shots": [
                {"id": "s01", "checked": True, "semantic_checked": True},
                {"id": "s02", "checked": True, "semantic_checked": True},
            ],
            "contact_sheet": str(self.contact), "contact_sheet_sha256": hashlib.sha256(self.contact.read_bytes()).hexdigest(),
            "visual_approval": str(self.approval), "visual_approval_sha256": hashlib.sha256(self.approval.read_bytes()).hexdigest(),
            "errors": [],
            "ok": True,
        }), encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def run_gate(self):
        return subprocess.run([
            sys.executable, str(SCRIPT),
            "--video", str(self.video),
            "--timeline", str(self.timeline),
            "--preflight", str(self.preflight),
            "--ledger", str(self.ledger),
            "--final-review", str(self.review),
            "--status", str(self.status),
            "--output", str(self.report),
        ], capture_output=True, text=True, encoding="utf-8")

    def test_complete_artifacts_open_terminal_gate_and_hash_every_input(self):
        result = self.run_gate()
        self.assertEqual(0, result.returncode, result.stderr)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(report["ok"])
        self.assertTrue(report["terminal_allowed"])
        self.assertEqual({"video", "timeline", "preflight", "ledger", "final_review"}, set(report["sha256"]))
        status = json.loads(self.status.read_text(encoding="utf-8"))
        self.assertEqual("complete", status["state"])
        self.assertTrue(status["terminal_allowed"])

    def test_failed_final_review_keeps_workflow_in_progress(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review.update({"ok": False, "errors": ["black frame"]})
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertFalse(report["terminal_allowed"])
        status = json.loads(self.status.read_text(encoding="utf-8"))
        self.assertEqual("in_progress", status["state"])

    def test_missing_per_shot_semantic_observation_blocks_delivery(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review["shots"][1]["semantic_checked"] = False
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("semantic visual observations" in item for item in report["errors"]))

    def test_single_visual_candidate_is_rejected_before_render(self):
        errors = validate({"assets": [], "shots": [{"id": "s01", "asset_id": "a01", "candidate_asset_ids": ["a01"]}]})
        self.assertTrue(any("at least two distinct candidates" in item for item in errors))

    def test_missing_source_hash_blocks_delivery(self):
        ledger = json.loads(self.ledger.read_text(encoding="utf-8"))
        ledger["assets"][1].pop("sha256")
        self.ledger.write_text(json.dumps(ledger), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("source file hash" in item for item in report["errors"]))

    def test_source_metadata_is_optional(self):
        ledger = json.loads(self.ledger.read_text(encoding="utf-8"))
        ledger["assets"][0] = {
            "id": "a01", "local_path": "a.mp4", "source_type": "local_library",
            "quick_hash": "abc",
        }
        self.ledger.write_text(json.dumps(ledger), encoding="utf-8")
        result = self.run_gate()
        self.assertEqual(0, result.returncode, result.stderr)

    def test_review_for_another_video_blocks_delivery(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review["video"] = str(self.root / "old.mp4")
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("different video" in item for item in report["errors"]))

    def test_fast_pipeline_deliver_is_guarded_by_the_same_gate(self):
        result = subprocess.run([
            sys.executable, str(FAST_PIPELINE), "deliver",
            "--video", str(self.video),
            "--timeline", str(self.timeline),
            "--preflight", str(self.preflight),
            "--ledger", str(self.ledger),
            "--final-review", str(self.review),
            "--status", str(self.status),
            "--gate-report", str(self.report),
            "--metrics", str(self.metrics),
        ], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["terminal_allowed"])

    def test_corrupt_video_is_blocked(self):
        self.video.write_bytes(b"not-an-mp4")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        self.assertTrue(any("probeable MP4" in item for item in json.loads(self.report.read_text(encoding="utf-8"))["errors"]))

    def test_modified_approval_is_blocked(self):
        payload = json.loads(self.approval.read_text(encoding="utf-8")); payload["tampered"] = True
        self.approval.write_text(json.dumps(payload), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        self.assertTrue(any("visual approval hash" in item for item in json.loads(self.report.read_text(encoding="utf-8"))["errors"]))

    def test_stricter_approval_may_bind_review_notes_too(self):
        payload = json.loads(self.approval.read_text(encoding="utf-8"))
        payload["hashes"]["review_notes_sha256"] = "3" * 64
        self.approval.write_text(json.dumps(payload), encoding="utf-8")
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review["visual_approval_sha256"] = hashlib.sha256(self.approval.read_bytes()).hexdigest()
        self.review.write_text(json.dumps(review), encoding="utf-8")
        self.assertEqual(0, self.run_gate().returncode)

    def test_review_with_narration_keeps_timeline_target_duration(self):
        audio = self.root / "narration.mp3"
        report = self.root / "narration-review.json"
        ffmpeg = shutil.which("ffmpeg")
        subprocess.run([ffmpeg, "-y", "-f", "lavfi", "-i", "sine=frequency=440:duration=10", "-c:a", "libmp3lame", str(audio)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        result = subprocess.run([sys.executable, str(REVIEW_RENDER), "--video", str(self.video), "--timeline", str(self.timeline), "--source-audio", str(audio), "--report", str(report)], capture_output=True, text=True, encoding="utf-8")
        self.assertNotEqual(0, result.returncode)  # Test video intentionally has no audio stream.
        self.assertEqual(10.0, json.loads(report.read_text(encoding="utf-8"))["target_duration"])


if __name__ == "__main__":
    unittest.main()
