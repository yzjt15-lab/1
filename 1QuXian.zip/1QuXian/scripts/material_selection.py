#!/usr/bin/env python3
"""Shared category and seven-day reuse guards for local material selection."""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path


def source_family(path: str) -> str:
    stem = Path(path).stem.casefold()
    stem = re.sub(r"(?:[_-](?:\d{1,3}|[0-9a-f]{12,}))+$", "", stem)
    return str(Path(path).parent).casefold() + "|" + stem


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def delivered_history(root: Path, current_project: Path | None = None, days: int = 7, now: datetime | None = None) -> dict:
    cutoff = (now or datetime.now(timezone.utc)) - timedelta(days=days)
    used = {key: set() for key in ("ids", "hashes", "urls", "families")}
    used["last_used"] = {}
    current = current_project.resolve() if current_project else None
    reports = {*root.rglob("*门禁*.json"), *root.rglob("*gate*.json")}
    for report_path in reports:
        if current and (report_path.parent.resolve() == current or current in report_path.parents):
            continue
        try:
            report = json.loads(report_path.read_text(encoding="utf-8-sig"))
            checked = datetime.fromisoformat(str(report["checked_at"]).replace("Z", "+00:00"))
        except (OSError, KeyError, ValueError, json.JSONDecodeError):
            continue
        expected = report.get("sha256", {}).get("ledger")
        if report.get("terminal_allowed") is not True or checked < cutoff or not expected:
            continue
        for ledger_path in report_path.parent.glob("*asset-ledger.json"):
            if _sha256(ledger_path) != expected:
                continue
            raw = json.loads(ledger_path.read_text(encoding="utf-8-sig"))
            assets = raw if isinstance(raw, list) else raw.get("assets", [])
            for asset in assets:
                identities = []
                for field, bucket in (("id", "ids"), ("source_url", "urls")):
                    if asset.get(field):
                        value = str(asset[field]); used[bucket].add(value); identities.append(value)
                digest = asset.get("quick_hash") or asset.get("sha256")
                if digest:
                    value = str(digest); used["hashes"].add(value); identities.append(value)
                if asset.get("local_path") or asset.get("path"):
                    value = source_family(str(asset.get("local_path") or asset["path"])); used["families"].add(value); identities.append(value)
                for value in identities:
                    used["last_used"][value] = max(checked.timestamp(), used["last_used"].get(value, 0))
    return used


def remove_recent(candidates: list[dict], used: dict[str, set[str]]) -> list[dict]:
    return [item for item in candidates if not (
        str(item.get("asset_id") or item.get("id")) in used["ids"]
        or str(item.get("quick_hash", "")) in used["hashes"]
        or str(item.get("source_url", "")) in used["urls"]
        or source_family(str(item.get("path", ""))) in used["families"]
    )]


def prefer_fresh(candidates: list[dict], used: dict, rejected_asset_ids: set[str] | None = None) -> list[dict]:
    rejected = rejected_asset_ids or set()
    candidates = [item for item in candidates if str(item.get("asset_id") or item.get("id")) not in rejected]
    return remove_recent(candidates, used)
