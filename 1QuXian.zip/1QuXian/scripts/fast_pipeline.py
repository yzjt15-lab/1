#!/usr/bin/env python3
"""Single entrypoint for deterministic infoflow setup, render, and approval."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from pathlib import Path

MATERIAL_LIBRARY_SCRIPTS = Path(r"C:\Users\28723\.codex\skills\1SuCaiKu\scripts")
if str(MATERIAL_LIBRARY_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(MATERIAL_LIBRARY_SCRIPTS))

from material_library import DELIVERIES_ROOT as MATERIAL_DELIVERIES_ROOT, INDEX as MATERIAL_INDEX, USAGE as MATERIAL_USAGE, commit_ledger, filter_candidates
from news_fact_cards import load_cache, search_cards
from speed_common import write_json
from workflow_metrics import complete_run, end_stage, require_within_budget, start_run, start_stage
from visual_semantic_index import search_many


SCRIPT_DIR = Path(__file__).resolve().parent
OFFICIAL_OUTPUT_DIR = Path(r"C:\Users\28723\Videos\Codex").resolve()


def _safe_title(title: str) -> str:
    value = re.sub(r'[<>:"/\\|?*]+', "", title).strip().replace(" ", "")
    if not value:
        raise ValueError("title becomes empty after filename sanitization")
    return value


def _json_ready(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {key: _json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_ready(item) for item in value]
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _run(script: str, arguments: list[str], allowed_codes: set[int] | None = None) -> subprocess.CompletedProcess:
    command = [sys.executable, str(SCRIPT_DIR / script), *arguments]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode not in (allowed_codes or {0}):
        raise RuntimeError(f"{' '.join(command)}\n{result.stdout}\n{result.stderr}")
    return result


def validate_first_review(report_path: Path) -> None:
    report = json.loads(report_path.read_text(encoding="utf-8"))
    expected_prefixes = ("visual approval missing", "visual checks missing")
    unexpected = [error for error in report.get("errors", []) if not str(error).startswith(expected_prefixes)]
    if unexpected:
        raise RuntimeError("first review contains non-approval errors: " + "; ".join(unexpected))


def renderer_script(timeline: dict) -> str:
    return "render_segmented_timeline.py" if float(timeline.get("duration_seconds", 0)) >= 90.0 or len(timeline.get("shots", [])) > 12 else "render_continuous_timeline.py"


def initialize(
    script_path: Path,
    duration: float,
    title: str,
    output_dir: Path,
    structure_template: Path | None = None,
    date_text: str | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    if duration <= 0:
        raise ValueError("duration must be > 0")
    if not script_path.is_file() or not script_path.read_text(encoding="utf-8").strip():
        raise ValueError("script is missing or empty")
    if structure_template:
        raise ValueError("structure templates are applied only after semantic and chart planning, not during init")
    stamp = date_text or date.today().isoformat()
    stem = _safe_title(title)
    metrics_path = output_dir / f"{stamp}_文档_{stem}_端到端耗时.json"
    status_path = output_dir / f"{stamp}_文档_{stem}_执行状态.json"
    start_run(metrics_path, title, duration)
    write_json(status_path, {
        "state": "in_progress", "terminal_allowed": False,
        "current_stage": "initialized_waiting_for_semantic_and_chart_planning",
        "script_path": str(script_path.resolve()), "target_duration_seconds": float(duration), "title": title,
    })
    return {"status_path": status_path, "metrics_path": metrics_path, "script_path": script_path.resolve()}


def finalize(
    timeline_path: Path,
    asset_index: Path,
    overlay_dir: Path,
    output_video: Path,
    project_dir: Path,
    metrics_path: Path,
) -> dict:
    project_dir.mkdir(parents=True, exist_ok=True)
    if output_video.resolve().parent != OFFICIAL_OUTPUT_DIR:
        raise ValueError(f"formal video must be written to {OFFICIAL_OUTPUT_DIR}")
    stem = timeline_path.stem.replace("_时间轴", "")
    prepared = project_dir / f"{stem}_时间轴_准备后.json"
    preflight = project_dir / f"{stem}_预检报告.json"
    ledger = project_dir / f"{stem}_asset-ledger.json"
    first_review = project_dir / f"{stem}_复审报告_首次.json"
    start_stage(metrics_path, "render_review")
    _run("prepare_timeline_assets.py", ["--timeline", str(timeline_path), "--overlay-dir", str(overlay_dir), "--output", str(prepared)])
    prepared_payload = json.loads(prepared.read_text(encoding="utf-8"))
    permit = project_dir / f"{stem}_正式渲染许可.json"
    probe_report = project_dir / f"{stem}_编码探测.json"
    prepared_payload["finalize_permit_path"] = str(permit.resolve())
    write_json(prepared, prepared_payload)
    write_json(permit, {
        "source": "fast_pipeline finalize",
        "profile": "final",
        "timeline_sha256": _sha256(prepared),
        "output_video_path": str(output_video.resolve()),
    })
    _run("preflight.py", ["--timeline", str(prepared), "--asset-index", str(asset_index), "--report", str(preflight)])
    if float(prepared_payload.get("duration_seconds", 0)) >= 90 or len(prepared_payload.get("shots", [])) > 12:
        _run("render_segmented_timeline.py", [
            "--timeline", str(prepared), "--output", str(output_video),
            "--segment-dir", str(project_dir / "render_segments"),
            "--encoder", "auto", "--probe-report", str(probe_report), "--finalize-permit", str(permit),
        ])
    else:
        _run("render_continuous_timeline.py", ["--timeline", str(prepared), "--profile", "final", "--encoder", "auto", "--probe-report", str(probe_report), "--finalize-permit", str(permit), "--output", str(output_video)])
    _run("export_asset_ledger.py", ["--timeline", str(prepared), "--output", str(ledger)])
    review_arguments = ["--video", str(output_video), "--timeline", str(prepared), "--report", str(first_review)]
    if prepared_payload.get("reference_audio_path"):
        review_arguments.extend(["--reference-audio", str(prepared_payload["reference_audio_path"])])
    if prepared_payload.get("audio_path"):
        review_arguments.extend(["--source-audio", str(prepared_payload["audio_path"])])
    _run("review_render.py", review_arguments, {0, 2})
    validate_first_review(first_review)
    end_stage(metrics_path, "render_review")
    return {
        "prepared_timeline": prepared,
        "preflight_report": preflight,
        "asset_ledger": ledger,
        "first_review": first_review,
        "finalize_permit": permit,
        "encoder_probe_report": probe_report,
        "contact_sheet": first_review.with_suffix(".jpg"),
    }


def approve(
    video: Path,
    timeline: Path,
    contact_sheet: Path,
    review_notes: Path,
    approval_path: Path,
    final_report: Path,
    metrics_path: Path | None = None,
    reference_audio: Path | None = None,
    source_audio: Path | None = None,
) -> dict:
    arguments = [
        "--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet),
        "--review-notes", str(review_notes), "--output", str(approval_path),
    ]
    _run("make_visual_approval.py", arguments)
    review_arguments = [
        "--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet),
        "--visual-approval", str(approval_path), "--report", str(final_report),
    ]
    payload = json.loads(timeline.read_text(encoding="utf-8"))
    resolved_reference = reference_audio or (Path(payload["reference_audio_path"]) if payload.get("reference_audio_path") else None)
    resolved_source = source_audio or (Path(payload["audio_path"]) if payload.get("audio_path") else None)
    if resolved_reference:
        review_arguments.extend(["--reference-audio", str(resolved_reference)])
    if resolved_source:
        review_arguments.extend(["--source-audio", str(resolved_source)])
    _run("review_render.py", review_arguments)
    return {"approval": approval_path, "final_report": final_report}


def deliver(
    video: Path,
    timeline: Path,
    preflight: Path,
    ledger: Path,
    final_review: Path,
    status: Path,
    gate_report: Path,
    metrics_path: Path,
) -> dict:
    """Open the terminal state only after the fail-closed delivery gate passes."""
    require_within_budget(metrics_path, "deliver")
    result = _run("delivery_gate.py", [
        "--video", str(video),
        "--timeline", str(timeline),
        "--preflight", str(preflight),
        "--ledger", str(ledger),
        "--final-review", str(final_review),
        "--status", str(status),
        "--output", str(gate_report),
    ])
    payload = json.loads(result.stdout)
    if payload.get("terminal_allowed") is not True:
        raise RuntimeError("delivery gate returned without terminal permission")
    commit_ledger(ledger, timeline.parent)
    complete_run(metrics_path)
    return payload


def research(
    index_dir: Path,
    fact_cache: Path,
    queries: list[str],
    top_k: int,
    clip_duration: float,
    max_fact_age_days: int | None,
    device: str,
    categories: list[str] | None = None,
    delivery_root: Path | None = None,
    current_project: Path | None = None,
    metrics_path: Path | None = None,
    allow_network: bool = False,
    rejected_asset_ids: set[str] | None = None,
    cached_visual_candidates: dict | None = None,
) -> dict:
    """Run local visual retrieval and local fact-card retrieval concurrently."""
    if metrics_path:
        start_stage(metrics_path, "assets")
        start_stage(metrics_path, "news")
    with ThreadPoolExecutor(max_workers=2) as pool:
        semantic_future = None if cached_visual_candidates is not None else pool.submit(search_many, index_dir, queries, top_k, clip_duration, device=device, categories=categories, allow_network=allow_network)
        facts_future = pool.submit(search_cards, load_cache(fact_cache), queries, max_fact_age_days)
        try:
            visual_candidates = copy.deepcopy(cached_visual_candidates) if cached_visual_candidates is not None else semantic_future.result()
            for item in visual_candidates.get("queries", []):
                item["eligible_candidates"] = filter_candidates(
                    item.get("candidates", []),
                    index_path=MATERIAL_INDEX,
                    usage_path=MATERIAL_USAGE,
                    deliveries_root=delivery_root or MATERIAL_DELIVERIES_ROOT,
                    current_project=current_project,
                    rejected_asset_ids=rejected_asset_ids,
                )
            if metrics_path:
                end_stage(metrics_path, "assets")
        except Exception:
            if metrics_path:
                end_stage(metrics_path, "assets", note="failed")
            raise
        try:
            facts = facts_future.result()
            if metrics_path:
                end_stage(metrics_path, "news")
        except Exception:
            if metrics_path:
                end_stage(metrics_path, "news", note="failed")
            raise
        eligible = [
            {
                **query_result,
                "candidates": query_result.get("eligible_candidates", []),
            }
            for query_result in visual_candidates.get("queries", [])
        ]
        return {
            "source": "fast_pipeline research",
            "queries": queries,
            "visual_candidates": visual_candidates,
            "eligible_visual_candidates": {"model_id": visual_candidates.get("model_id"), "queries": eligible},
            "fact_cards": facts,
            "fact_cache": str(fact_cache),
            "search_execution": "cache" if cached_visual_candidates is not None else "model",
        }


def _research_session_path(project: Path) -> Path:
    return project / f"{date.today().isoformat()}_文档_语义检索会话.json"


def _research_key(index_dir: Path, queries: list[str] | None = None, categories: list[str] | None = None) -> dict:
    return {
        "index_dir": str(index_dir.resolve()),
        "manifest_sha256": _sha256(index_dir / "manifest.json"),
    }


def _merge_visual_candidates(previous: dict | None, appended: dict | None) -> dict:
    merged = copy.deepcopy(previous or {})
    merged.setdefault("queries", [])
    seen = {(item.get("query"), item.get("category")) for item in merged["queries"]}
    for item in (appended or {}).get("queries", []):
        key = (item.get("query"), item.get("category"))
        if key not in seen:
            merged["queries"].append(copy.deepcopy(item))
            seen.add(key)
    if not merged.get("model_id"):
        merged["model_id"] = (appended or {}).get("model_id")
    return merged


def load_research_session(project: Path, index_dir: Path) -> dict | None:
    state_path = _research_session_path(project)
    if not state_path.exists():
        return None
    state = json.loads(state_path.read_text(encoding="utf-8"))
    if state.get("version") == 2:
        return state
    # Migrate the former single-query session without discarding its completed results.
    payload = json.loads(Path(state["output"]).read_text(encoding="utf-8"))
    visual_candidates = payload.get("visual_candidates", {})
    searched_queries = state.get("key", {}).get("queries") or [
        item.get("query") for item in visual_candidates.get("queries", []) if item.get("query")
    ]
    return {"version": 2, "key": _research_key(index_dir), "visual_candidates": visual_candidates, "searched_queries": searched_queries}


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--script", required=True)
    init.add_argument("--duration", type=float, required=True)
    init.add_argument("--title", required=True)
    init.add_argument("--output-dir", required=True)
    init.add_argument("--structure-template")
    finish = sub.add_parser("finalize")
    finish.add_argument("--timeline", required=True)
    finish.add_argument("--asset-index", required=True)
    finish.add_argument("--overlay-dir", required=True)
    finish.add_argument("--output-video", required=True)
    finish.add_argument("--project-dir", required=True)
    finish.add_argument("--metrics", required=True)
    approval = sub.add_parser("approve")
    approval.add_argument("--video", required=True)
    approval.add_argument("--timeline", required=True)
    approval.add_argument("--contact-sheet", required=True)
    approval.add_argument("--review-notes", required=True)
    approval.add_argument("--approval", required=True)
    approval.add_argument("--final-report", required=True)
    approval.add_argument("--metrics", required=True)
    approval.add_argument("--reference-audio")
    approval.add_argument("--source-audio")
    delivery = sub.add_parser("deliver")
    delivery.add_argument("--video", required=True)
    delivery.add_argument("--timeline", required=True)
    delivery.add_argument("--preflight", required=True)
    delivery.add_argument("--ledger", required=True)
    delivery.add_argument("--final-review", required=True)
    delivery.add_argument("--status", required=True)
    delivery.add_argument("--gate-report", required=True)
    delivery.add_argument("--metrics", required=True)
    semantic = sub.add_parser("search")
    semantic.add_argument("--index-dir", required=True)
    semantic.add_argument("--query", action="append", required=True)
    semantic.add_argument("--top-k", type=int, default=12)
    semantic.add_argument("--clip-duration", type=float, default=5.0)
    semantic.add_argument("--device", default="auto")
    semantic.add_argument("--category", action="append", default=[])
    semantic.add_argument("--allow-network", action="store_true")
    semantic.add_argument("--output")
    research_parser = sub.add_parser("research")
    research_parser.add_argument("--index-dir", required=True)
    research_parser.add_argument("--fact-cache", required=True)
    research_parser.add_argument("--query", action="append", required=True)
    research_parser.add_argument("--top-k", type=int, default=12)
    research_parser.add_argument("--clip-duration", type=float, default=5.0)
    research_parser.add_argument("--max-fact-age-days", type=int)
    research_parser.add_argument("--device", default="auto")
    research_parser.add_argument("--category", action="append", default=[])
    research_parser.add_argument("--delivery-root")
    research_parser.add_argument("--current-project", required=True)
    research_parser.add_argument("--metrics")
    research_parser.add_argument("--allow-network", action="store_true")
    research_parser.add_argument("--reject-asset-id", action="append", default=[])
    research_parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "init":
        result = initialize(Path(args.script), args.duration, args.title, Path(args.output_dir), Path(args.structure_template) if args.structure_template else None)
    elif args.command == "finalize":
        result = finalize(Path(args.timeline), Path(args.asset_index), Path(args.overlay_dir), Path(args.output_video), Path(args.project_dir), Path(args.metrics))
    elif args.command == "approve":
        result = approve(Path(args.video), Path(args.timeline), Path(args.contact_sheet), Path(args.review_notes), Path(args.approval), Path(args.final_report), Path(args.metrics), Path(args.reference_audio) if args.reference_audio else None, Path(args.source_audio) if args.source_audio else None)
    elif args.command == "deliver":
        result = deliver(
            Path(args.video), Path(args.timeline), Path(args.preflight), Path(args.ledger),
            Path(args.final_review), Path(args.status), Path(args.gate_report), Path(args.metrics),
        )
    elif args.command == "search":
        result = search_many(Path(args.index_dir), args.query, args.top_k, args.clip_duration, device=args.device, categories=args.category or None, allow_network=args.allow_network)
        if args.output:
            write_json(Path(args.output), result)
    else:
        project = Path(args.current_project)
        output = Path(args.output)
        session = load_research_session(project, Path(args.index_dir))
        existing = session.get("visual_candidates", {}) if session else {}
        searched = set(session.get("searched_queries", [])) if session else set()
        missing_queries = [query for query in args.query if query not in searched]
        result = research(
            Path(args.index_dir), Path(args.fact_cache), missing_queries or args.query, args.top_k,
            args.clip_duration, args.max_fact_age_days, args.device, args.category or None,
            Path(args.delivery_root) if args.delivery_root else None,
            project, Path(args.metrics) if args.metrics else None, args.allow_network,
            set(args.reject_asset_id), existing if not missing_queries and session else None,
        )
        if session and missing_queries:
            result["visual_candidates"] = _merge_visual_candidates(existing, result["visual_candidates"])
            result["eligible_visual_candidates"]["queries"] = [
                {**item, "candidates": item.get("eligible_candidates", item.get("candidates", []))}
                for item in result["visual_candidates"].get("queries", [])
            ]
            result["search_execution"] = "append"
        write_json(output, result)
        state_path = _research_session_path(project)
        write_json(state_path, {
            "version": 2,
            "key": _research_key(Path(args.index_dir)),
            "visual_candidates": result["visual_candidates"],
            "searched_queries": list(dict.fromkeys([*(session or {}).get("searched_queries", []), *args.query])),
        })
    if getattr(args, "output", None):
        print(json.dumps({"output": str(Path(args.output).resolve()), "search_execution": result.get("search_execution"), "query_count": len(result.get("queries", []))}, ensure_ascii=False))
    else:
        print(json.dumps(_json_ready(result), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
