#!/usr/bin/env python3
"""Single entrypoint for the four-stage curve-video workflow."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timezone
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

from runtime_paths import MATERIAL_LIBRARY_SCRIPTS, OFFICIAL_OUTPUT_DIR

if not (MATERIAL_LIBRARY_SCRIPTS / "material_library.py").is_file():
    raise RuntimeError("material library scripts are unavailable; set CURVE_MATERIAL_LIBRARY_SCRIPTS")
if str(MATERIAL_LIBRARY_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(MATERIAL_LIBRARY_SCRIPTS))

from material_library import DELIVERIES_ROOT as MATERIAL_DELIVERIES_ROOT, INDEX as MATERIAL_INDEX, USAGE as MATERIAL_USAGE, candidate_preview_key, commit_ledger, filter_candidate_groups, prepare_candidate_previews
from build_timeline_from_script import build_production_timeline
from news_fact_cards import load_cache, search_cards
from speed_common import find_chinese_font, resolve_duration, write_json
from workflow_metrics import complete_run, end_stage, require_within_budget, start_run, start_stage
from visual_semantic_index import search_many


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_CANDIDATE_LIMIT = 4


def _safe_stem(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*]+', "", value).strip().replace(" ", "")
    value = re.sub(r"^\d{4}-\d{2}-\d{2}_[^_]+_", "", value)
    if not value:
        raise ValueError("script filename becomes empty after sanitization")
    return value


def _json_ready(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {key: _json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_ready(item) for item in value]
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_candidate_contact_sheet(query_results: list[dict], output_dir: Path) -> Path:
    """Render every unique candidate's A/M/B evidence into one review image."""
    records, seen = [], set()
    for query_result in query_results:
        for candidate in query_result.get("eligible_candidates", []):
            key = candidate.get("asset_id") or candidate.get("id") or candidate.get("path")
            frames = {item.get("label"): Path(str(item.get("path", ""))) for item in candidate.get("review_frames", [])}
            if key in seen or any(label not in frames or not frames[label].is_file() for label in "AMB"):
                continue
            seen.add(key)
            records.append((str(query_result.get("query", "")), candidate, frames))
    signature = hashlib.sha256(json.dumps([
        [query, candidate.get("asset_id") or candidate.get("id"), [[label, frames[label].stat().st_size, frames[label].stat().st_mtime_ns] for label in "AMB"]]
        for query, candidate, frames in records
    ], ensure_ascii=False).encode("utf-8")).hexdigest()[:16]
    output = Path(output_dir) / f"候选批量联系表_{signature}.jpg"
    if output.is_file():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    cell_w, cell_h, label_h = 320, 180, 42
    canvas = Image.new("RGB", (cell_w * 3, max(1, len(records)) * (cell_h + label_h)), "#111827")
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype(find_chinese_font(False), 18)
    if not records:
        draw.text((24, 24), "无合格候选", font=font, fill="white")
    for row, (query, candidate, frames) in enumerate(records):
        top = row * (cell_h + label_h)
        label = f"{candidate.get('asset_id') or candidate.get('id')}  {query}"
        draw.text((10, top + 9), label[:58], font=font, fill="#F2C86B")
        for column, frame_label in enumerate("AMB"):
            image = Image.open(frames[frame_label]).convert("RGB")
            canvas.paste(ImageOps.fit(image, (cell_w, cell_h), Image.Resampling.LANCZOS), (column * cell_w, top + label_h))
            draw.text((column * cell_w + 8, top + label_h + 6), frame_label, font=font, fill="white", stroke_width=2, stroke_fill="black")
    canvas.save(output, quality=90, optimize=True)
    return output


def _run(script: str, arguments: list[str], allowed_codes: set[int] | None = None) -> subprocess.CompletedProcess:
    command = [sys.executable, str(SCRIPT_DIR / script), *arguments]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode not in (allowed_codes or {0}):
        raise RuntimeError(f"{' '.join(command)}\n{result.stdout}\n{result.stderr}")
    return result


def validate_first_review(report_path: Path) -> None:
    report = json.loads(report_path.read_text(encoding="utf-8"))
    expected_prefixes = ("visual approval missing", "visual checks missing")
    unexpected = [error for error in report.get("errors", []) if not str(error).startswith(expected_prefixes)]
    if unexpected:
        raise RuntimeError("first review contains non-approval errors: " + "; ".join(unexpected))


def renderer_script(timeline: dict) -> str:
    return "render_segmented_timeline.py" if float(timeline.get("duration_seconds", 0)) >= 90.0 or len(timeline.get("shots", [])) > 12 else "render_continuous_timeline.py"


def close_status(status_path: Path, state: str, reason: str, correction_exhausted: bool = False) -> dict:
    if state not in {"cancelled", "blocked_external"}:
        raise ValueError("state must be cancelled or blocked_external")
    if not reason.strip():
        raise ValueError("terminal status requires a reason")
    if state == "blocked_external" and not correction_exhausted:
        raise ValueError("blocked_external requires an exhausted correction attempt")
    payload = json.loads(status_path.read_text(encoding="utf-8"))
    if payload.get("state") != "in_progress":
        raise ValueError("only in_progress can transition to a terminal state")
    payload.update({
        "state": state,
        "terminal_allowed": False,
        "current_stage": state,
        "terminal_reason": reason.strip(),
        "correction_exhausted": bool(correction_exhausted),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    })
    write_json(status_path, payload)
    return payload


def update_progress(status_path: Path, stage: str, duration: float | None = None, **details) -> dict:
    payload = json.loads(status_path.read_text(encoding="utf-8"))
    if payload.get("state") != "in_progress":
        raise ValueError("only in_progress can receive checkpoint updates")
    if duration is not None and abs(float(payload.get("target_duration_seconds", -1)) - float(duration)) > 0.001:
        raise ValueError("status duration does not match the current timeline")
    payload.update({
        "terminal_allowed": False,
        "current_stage": stage,
        "last_checkpoint_at": datetime.now(timezone.utc).isoformat(),
        **_json_ready(details),
    })
    write_json(status_path, payload)
    return payload


def complete_status(status_path: Path, gate_report: Path, gate: dict) -> dict:
    payload = json.loads(status_path.read_text(encoding="utf-8"))
    if payload.get("state") != "in_progress":
        raise ValueError("only in_progress can transition to complete")
    if gate.get("terminal_allowed") is not True:
        raise ValueError("delivery gate has not authorized completion")
    payload.update({
        "state": "complete",
        "terminal_allowed": True,
        "current_stage": "delivery_gate_passed",
        "gate_report": str(gate_report.resolve()),
        "gate_sha256": gate.get("sha256", {}),
        "gate_errors": [],
        "updated_at": datetime.now(timezone.utc).isoformat(),
    })
    write_json(status_path, payload)
    return payload


def initialize(
    script_path: Path,
    output_dir: Path,
    duration: float | None = None,
    audio_path: Path | None = None,
    date_text: str | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    if not script_path.is_file() or not script_path.read_text(encoding="utf-8").strip():
        raise ValueError("script is missing or empty")
    duration = resolve_duration(duration, audio_path)
    stamp = date_text or date.today().isoformat()
    stem = _safe_stem(script_path.stem)
    metrics_path = output_dir / f"{stamp}_文档_{stem}_端到端耗时.json"
    status_path = output_dir / f"{stamp}_文档_{stem}_执行状态.json"
    start_run(metrics_path, duration)
    write_json(status_path, {
        "state": "in_progress", "terminal_allowed": False,
        "current_stage": "initialized_waiting_for_semantic_timeline",
        "script_path": str(script_path.resolve()), "target_duration_seconds": float(duration),
        "timing_audio_path": str(audio_path.resolve()) if audio_path else None,
    })
    return {"status_path": status_path, "metrics_path": metrics_path, "script_path": script_path.resolve()}


def finalize(
    timeline_path: Path,
    asset_index: Path,
    overlay_dir: Path,
    output_video: Path,
    project_dir: Path,
    metrics_path: Path,
    status_path: Path,
) -> dict:
    if output_video.resolve().parent != OFFICIAL_OUTPUT_DIR:
        raise ValueError(f"formal video must be written to {OFFICIAL_OUTPUT_DIR}")
    source_timeline = json.loads(timeline_path.read_text(encoding="utf-8"))
    update_progress(status_path, "finalize_started", source_timeline.get("duration_seconds"), timeline=timeline_path)
    project_dir.mkdir(parents=True, exist_ok=True)
    stem = timeline_path.stem.replace("_时间轴", "")
    prepared = project_dir / f"{stem}_时间轴_准备后.json"
    preflight = project_dir / f"{stem}_预检报告.json"
    ledger = project_dir / f"{stem}_asset-ledger.json"
    first_review = project_dir / f"{stem}_复审报告_首次.json"
    start_stage(metrics_path, "render_review")
    _run("prepare_timeline_assets.py", ["--timeline", str(timeline_path), "--overlay-dir", str(overlay_dir), "--output", str(prepared)])
    prepared_payload = json.loads(prepared.read_text(encoding="utf-8"))
    update_progress(status_path, "timeline_assets_prepared", prepared_payload.get("duration_seconds"), prepared_timeline=prepared)
    permit = project_dir / f"{stem}_正式渲染许可.json"
    probe_report = project_dir / f"{stem}_编码探测.json"
    prepared_payload["finalize_permit_path"] = str(permit.resolve())
    write_json(prepared, prepared_payload)
    write_json(permit, {
        "source": "fast_pipeline finalize",
        "profile": "final",
        "timeline_sha256": _sha256(prepared),
        "output_video_path": str(output_video.resolve()),
    })
    _run("preflight.py", ["--timeline", str(prepared), "--asset-index", str(asset_index), "--report", str(preflight)])
    update_progress(status_path, "preflight_passed", preflight_report=preflight)
    if renderer_script(prepared_payload) == "render_segmented_timeline.py":
        _run("render_segmented_timeline.py", [
            "--timeline", str(prepared), "--output", str(output_video),
            "--segment-dir", str(project_dir / "render_segments"),
            "--encoder", "auto", "--probe-report", str(probe_report), "--finalize-permit", str(permit),
        ])
    else:
        _run("render_continuous_timeline.py", ["--timeline", str(prepared), "--profile", "final", "--encoder", "auto", "--probe-report", str(probe_report), "--finalize-permit", str(permit), "--output", str(output_video)])
    update_progress(status_path, "formal_render_complete", output_video=output_video, encoder_probe_report=probe_report)
    _run("export_asset_ledger.py", ["--timeline", str(prepared), "--output", str(ledger)])
    _run("review_render.py", ["--video", str(output_video), "--timeline", str(prepared), "--report", str(first_review)], {0, 2})
    validate_first_review(first_review)
    _run("make_review_notes_template.py", [
        "--timeline", str(prepared), "--contact-sheet", str(first_review.with_suffix(".jpg")),
        "--output", str(project_dir / f"{stem}_目检记录模板.json"),
    ])
    end_stage(metrics_path, "render_review")
    update_progress(status_path, "first_review_ready", first_review=first_review, contact_sheet=first_review.with_suffix(".jpg"), review_notes_template=project_dir / f"{stem}_目检记录模板.json")
    return {
        "prepared_timeline": prepared,
        "preflight_report": preflight,
        "asset_ledger": ledger,
        "first_review": first_review,
        "finalize_permit": permit,
        "encoder_probe_report": probe_report,
        "contact_sheet": first_review.with_suffix(".jpg"),
        "review_notes_template": project_dir / f"{stem}_目检记录模板.json",
    }


def approve(
    video: Path,
    timeline: Path,
    preflight: Path,
    ledger: Path,
    contact_sheet: Path,
    review_notes: Path,
    approval_path: Path,
    final_report: Path,
    gate_report: Path,
    status_path: Path,
    metrics_path: Path,
) -> dict:
    payload = json.loads(timeline.read_text(encoding="utf-8"))
    update_progress(status_path, "approval_started", payload.get("duration_seconds"), timeline=timeline)
    arguments = [
        "--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet),
        "--review-notes", str(review_notes), "--output", str(approval_path),
    ]
    _run("make_visual_approval.py", arguments)
    review_arguments = [
        "--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet),
        "--visual-approval", str(approval_path), "--report", str(final_report),
    ]
    _run("review_render.py", review_arguments)
    update_progress(status_path, "final_review_passed", visual_approval=approval_path, final_review=final_report)
    gate = deliver(video, timeline, preflight, ledger, final_report, status_path, gate_report, metrics_path)
    return {
        "approval": approval_path,
        "final_report": final_report,
        "gate_report": gate_report,
        "terminal_allowed": gate["terminal_allowed"],
        "sha256": gate.get("sha256", {}),
    }


def deliver(
    video: Path,
    timeline: Path,
    preflight: Path,
    ledger: Path,
    final_review: Path,
    status: Path,
    gate_report: Path,
    metrics_path: Path,
) -> dict:
    """Open the terminal state only after the fail-closed delivery gate passes."""
    require_within_budget(metrics_path, "deliver")
    result = _run("delivery_gate.py", [
        "--video", str(video),
        "--timeline", str(timeline),
        "--preflight", str(preflight),
        "--ledger", str(ledger),
        "--final-review", str(final_review),
        "--output", str(gate_report),
    ])
    payload = json.loads(result.stdout)
    if payload.get("terminal_allowed") is not True:
        raise RuntimeError("delivery gate returned without terminal permission")
    commit_ledger(ledger, timeline.parent)
    complete_run(metrics_path)
    complete_status(status, gate_report, payload)
    return payload


def research(
    index_dir: Path,
    fact_cache: Path,
    queries: list[str],
    top_k: int,
    clip_duration: float,
    max_fact_age_days: int | None,
    device: str,
    categories: list[str] | None = None,
    delivery_root: Path | None = None,
    current_project: Path | None = None,
    metrics_path: Path | None = None,
    allow_network: bool = False,
    rejected_asset_ids: set[str] | None = None,
    review_dir: Path | None = None,
    required_candidates: int = 0,
) -> dict:
    """Run local visual retrieval and local fact-card retrieval concurrently."""
    if metrics_path:
        start_stage(metrics_path, "assets")
    with ThreadPoolExecutor(max_workers=2) as pool:
        semantic_future = pool.submit(search_many, index_dir, queries, top_k, clip_duration, device=device, categories=categories, allow_network=allow_network)
        facts_future = pool.submit(search_cards, load_cache(fact_cache), queries, max_fact_age_days)
        try:
            visual_candidates = semantic_future.result()
            query_results = visual_candidates.get("queries", [])
            candidate_groups = [item.get("candidates", []) for item in query_results]
            filter_options = {
                "index_path": MATERIAL_INDEX,
                "usage_path": MATERIAL_USAGE,
                "deliveries_root": delivery_root or MATERIAL_DELIVERIES_ROOT,
                "current_project": current_project,
                "rejected_asset_ids": rejected_asset_ids,
                "min_duration": clip_duration,
            }
            eligible_groups = filter_candidate_groups(candidate_groups, **filter_options)
            lookback_hours = 168
            unique_count = len({candidate.get("asset_id") or candidate.get("id") for group in eligible_groups for candidate in group})
            if required_candidates and unique_count < required_candidates:
                filter_options["lookback_hours"] = 0
                eligible_groups = filter_candidate_groups(candidate_groups, **filter_options)
                lookback_hours = 0
            for item, candidates in zip(query_results, eligible_groups):
                item["eligible_candidates"] = candidates
            if review_dir is not None:
                all_candidates = [candidate for item in visual_candidates.get("queries", []) for candidate in item.get("eligible_candidates", [])]
                prepared = prepare_candidate_previews(all_candidates, review_dir)
                prepared_by_key = {
                    candidate_preview_key(item): {
                        key: item[key] for key in ("prepared_visual", "preview_cache_hit", "review_clip_path", "review_frames")
                    }
                    for item in prepared
                }
                for item in visual_candidates.get("queries", []):
                    item["eligible_candidates"] = [
                        {**candidate, **prepared_by_key[preview_key]}
                        for candidate in item.get("eligible_candidates", [])
                        if (preview_key := candidate_preview_key(candidate)) in prepared_by_key
                    ]
                candidate_contact_sheet = make_candidate_contact_sheet(visual_candidates.get("queries", []), review_dir)
            else:
                candidate_contact_sheet = None
            if metrics_path:
                end_stage(metrics_path, "assets")
        except Exception:
            if metrics_path:
                end_stage(metrics_path, "assets", note="failed")
            raise
        try:
            facts = facts_future.result()
        except Exception:
            raise
        eligible = [
            {
                **query_result,
                "candidates": query_result.get("eligible_candidates", []),
            }
            for query_result in visual_candidates.get("queries", [])
        ]
        return {
            "source": "fast_pipeline research",
            "queries": queries,
            "visual_candidates": visual_candidates,
            "eligible_visual_candidates": {"model_id": visual_candidates.get("model_id"), "queries": eligible},
            "fact_cards": facts,
            "fact_cache": str(fact_cache),
            "search_execution": "shared_query_cache_or_model",
            "candidate_contact_sheet": str(candidate_contact_sheet.resolve()) if candidate_contact_sheet else None,
            "candidate_contact_sheet_sha256": _sha256(candidate_contact_sheet) if candidate_contact_sheet else None,
            "dedupe_audit": {
                "lookback_hours": lookback_hours,
                "checked_at": datetime.now(timezone.utc).isoformat(),
                "user_authorized_exception": lookback_hours == 0,
                "exception_reason": "用户已授权1QuXian连续制作，不因七日去重停下询问" if lookback_hours == 0 else None,
            },
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--script", required=True)
    timing = init.add_mutually_exclusive_group(required=True)
    timing.add_argument("--duration", type=float)
    timing.add_argument("--audio")
    init.add_argument("--output-dir", required=True)
    finish = sub.add_parser("finalize")
    finish.add_argument("--timeline", required=True)
    finish.add_argument("--asset-index", required=True)
    finish.add_argument("--overlay-dir", required=True)
    finish.add_argument("--output-video", required=True)
    finish.add_argument("--project-dir", required=True)
    finish.add_argument("--metrics", required=True)
    finish.add_argument("--status", required=True)
    timeline_parser = sub.add_parser("timeline")
    timeline_parser.add_argument("--script", required=True)
    timeline_parser.add_argument("--audio", required=True)
    timeline_parser.add_argument("--research", required=True)
    timeline_parser.add_argument("--page-dir", required=True)
    timeline_parser.add_argument("--project-dir", required=True)
    timeline_parser.add_argument("--overlays")
    timeline_parser.add_argument("--output", required=True)
    approval = sub.add_parser("approve")
    approval.add_argument("--video", required=True)
    approval.add_argument("--timeline", required=True)
    approval.add_argument("--preflight", required=True)
    approval.add_argument("--ledger", required=True)
    approval.add_argument("--contact-sheet", required=True)
    approval.add_argument("--review-notes", required=True)
    approval.add_argument("--approval", required=True)
    approval.add_argument("--final-report", required=True)
    approval.add_argument("--gate-report", required=True)
    approval.add_argument("--metrics", required=True)
    approval.add_argument("--status", required=True)
    status = sub.add_parser("status")
    status.add_argument("--status", required=True)
    status.add_argument("--state", required=True, choices=("cancelled", "blocked_external"))
    status.add_argument("--reason", required=True)
    status.add_argument("--correction-exhausted", action="store_true")
    research_parser = sub.add_parser("research")
    research_parser.add_argument("--index-dir", required=True)
    research_parser.add_argument("--fact-cache", required=True)
    research_parser.add_argument("--query", action="append", required=True)
    research_parser.add_argument("--top-k", type=int, default=DEFAULT_CANDIDATE_LIMIT)
    research_parser.add_argument("--clip-duration", type=float, default=5.0)
    research_parser.add_argument("--max-fact-age-days", type=int)
    research_parser.add_argument("--device", default="auto")
    research_parser.add_argument("--category", action="append", default=[])
    research_parser.add_argument("--delivery-root")
    research_parser.add_argument("--current-project", required=True)
    research_parser.add_argument("--review-dir")
    research_parser.add_argument("--metrics")
    research_parser.add_argument("--allow-network", action="store_true")
    research_parser.add_argument("--reject-asset-id", action="append", default=[])
    research_parser.add_argument("--required-candidates", type=int, default=0)
    research_parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "init":
        result = initialize(Path(args.script), Path(args.output_dir), args.duration, Path(args.audio) if args.audio else None)
    elif args.command == "finalize":
        result = finalize(Path(args.timeline), Path(args.asset_index), Path(args.overlay_dir), Path(args.output_video), Path(args.project_dir), Path(args.metrics), Path(args.status))
    elif args.command == "timeline":
        timeline = build_production_timeline(
            Path(args.script), Path(args.audio), Path(args.research), Path(args.page_dir),
            Path(args.project_dir), Path(args.overlays) if args.overlays else None,
        )
        output = Path(args.output)
        write_json(output, timeline)
        result = {"output": output.resolve(), "shots": len(timeline["shots"]), "overlays": len(timeline["overlays"])}
    elif args.command == "approve":
        result = approve(
            Path(args.video), Path(args.timeline), Path(args.preflight), Path(args.ledger),
            Path(args.contact_sheet), Path(args.review_notes), Path(args.approval), Path(args.final_report),
            Path(args.gate_report), Path(args.status), Path(args.metrics),
        )
    elif args.command == "status":
        result = close_status(Path(args.status), args.state, args.reason, args.correction_exhausted)
    elif args.command == "research":
        project = Path(args.current_project)
        output = Path(args.output)
        result = research(
            Path(args.index_dir), Path(args.fact_cache), args.query, args.top_k,
            args.clip_duration, args.max_fact_age_days, args.device, args.category or None,
            Path(args.delivery_root) if args.delivery_root else None,
            project, Path(args.metrics) if args.metrics else None, args.allow_network,
            set(args.reject_asset_id), Path(args.review_dir) if args.review_dir else project / "候选预览",
            args.required_candidates,
        )
        write_json(output, result)
    if args.command == "research":
        print(json.dumps({"output": str(Path(args.output).resolve()), "search_execution": result.get("search_execution"), "query_count": len(result.get("queries", []))}, ensure_ascii=False))
    else:
        print(json.dumps(_json_ready(result), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
