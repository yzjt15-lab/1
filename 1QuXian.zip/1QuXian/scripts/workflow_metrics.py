#!/usr/bin/env python3
"""Track end-to-end infoflow production time against stage budgets."""
from __future__ import annotations

import argparse
import time
from pathlib import Path

from speed_common import load_json, write_json


DEFAULT_BUDGETS = {
    "semantic_index": 60.0,
    "news": 120.0,
    "assets": 180.0,
    "timeline": 120.0,
    "render_review": 600.0,
}
DEFAULT_DELIVERY_DEADLINE_SECONDS = 1_200.0
DEFAULT_RENDER_START_DEADLINE_SECONDS = 600.0


def _production_elapsed(state: dict, timestamp: float) -> float:
    waiting = float(state.get("waiting_for_user_seconds", 0.0))
    if state.get("user_wait_started_at_epoch") is not None:
        waiting += timestamp - float(state["user_wait_started_at_epoch"])
    return max(0.0, timestamp - float(state["started_at_epoch"]) - waiting)


def _alert(state: dict, timestamp: float, stage: str, reason: str) -> None:
    completed = [
        (name, item) for name, item in state.get("stages", {}).items()
        if item.get("ended_at_epoch") is not None
    ]
    checkpoint = max(completed, key=lambda pair: pair[1]["ended_at_epoch"])[0] if completed else "initialized"
    state["service_alert"] = {
        "stage": stage,
        "reason": reason,
        "last_completed_checkpoint": checkpoint,
        "unique_blocking_point": reason,
        "next_action": "report_progress_and_continue",
        "formal_render_allowed": True,
        "production_elapsed_seconds": round(_production_elapsed(state, timestamp), 3),
        "checked_at_epoch": timestamp,
    }


def require_within_budget(path: Path, stage: str, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    timestamp = time.time() if now is None else now
    elapsed = _production_elapsed(state, timestamp)
    delivery_deadline = float(state.get("delivery_deadline_seconds", DEFAULT_DELIVERY_DEADLINE_SECONDS))
    render_start_deadline = float(state.get("render_start_deadline_seconds", DEFAULT_RENDER_START_DEADLINE_SECONDS))
    reason = None
    if elapsed >= delivery_deadline:
        reason = f"20-minute delivery service target exceeded before {stage}"
    elif stage == "render_review" and elapsed >= render_start_deadline:
        reason = "10-minute render-start service target missed"
    if reason:
        _alert(state, timestamp, stage, reason)
        write_json(path, state)
    return state


def start_run(path: Path, title: str, target_duration: float, now: float | None = None, budgets: dict | None = None) -> dict:
    timestamp = time.time() if now is None else now
    state = {
        "version": 1,
        "title": title,
        "target_duration_seconds": float(target_duration),
        "started_at_epoch": timestamp,
        "budgets_seconds": {**DEFAULT_BUDGETS, **(budgets or {})},
        "delivery_deadline_seconds": DEFAULT_DELIVERY_DEADLINE_SECONDS,
        "render_start_deadline_seconds": DEFAULT_RENDER_START_DEADLINE_SECONDS,
        "stages": {},
        "waiting_for_user_seconds": 0.0,
        "user_wait_started_at_epoch": None,
    }
    write_json(path, state)
    return state


def start_stage(path: Path, stage: str, now: float | None = None) -> dict:
    timestamp = time.time() if now is None else now
    state = require_within_budget(path, stage, timestamp)
    state.setdefault("stages", {})[stage] = {"started_at_epoch": timestamp}
    write_json(path, state)
    return state


def end_stage(path: Path, stage: str, now: float | None = None, note: str | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    item = state.setdefault("stages", {}).get(stage)
    if not item or "started_at_epoch" not in item:
        raise ValueError(f"stage not started: {stage}")
    timestamp = time.time() if now is None else now
    item["ended_at_epoch"] = timestamp
    item["elapsed_seconds"] = round(timestamp - float(item["started_at_epoch"]), 3)
    if note:
        item["note"] = note
    write_json(path, state)
    return state


def complete_run(path: Path, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    state["completed_at_epoch"] = time.time() if now is None else now
    state["completed"] = True
    write_json(path, state)
    return state


def start_user_wait(path: Path, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    if state.get("user_wait_started_at_epoch") is not None:
        raise ValueError("user wait already started")
    state["user_wait_started_at_epoch"] = time.time() if now is None else now
    write_json(path, state)
    return state


def end_user_wait(path: Path, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    started = state.get("user_wait_started_at_epoch")
    if started is None:
        raise ValueError("user wait not started")
    timestamp = time.time() if now is None else now
    state["waiting_for_user_seconds"] = round(float(state.get("waiting_for_user_seconds", 0.0)) + timestamp - float(started), 3)
    state["user_wait_started_at_epoch"] = None
    write_json(path, state)
    return state


def build_report(path: Path, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    timestamp = float(state.get("completed_at_epoch") or (time.time() if now is None else now))
    budgets = state.get("budgets_seconds", DEFAULT_BUDGETS)
    stages = {}
    for name, item in state.get("stages", {}).items():
        elapsed = item.get("elapsed_seconds")
        if elapsed is None:
            elapsed = round(timestamp - float(item["started_at_epoch"]), 3)
        budget = float(budgets.get(name, 0.0))
        stages[name] = {
            **item,
            "elapsed_seconds": elapsed,
            "budget_seconds": budget,
            "over_budget": bool(budget and elapsed > budget),
        }
    total = round(timestamp - float(state["started_at_epoch"]), 3)
    waiting = float(state.get("waiting_for_user_seconds", 0.0))
    if state.get("user_wait_started_at_epoch") is not None:
        waiting += timestamp - float(state["user_wait_started_at_epoch"])
    return {**state, "stages": stages, "total_elapsed_seconds": total, "waiting_for_user_seconds": round(waiting, 3), "production_elapsed_seconds": round(_production_elapsed(state, timestamp), 3)}


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    start = sub.add_parser("start")
    start.add_argument("--state", required=True)
    start.add_argument("--title", required=True)
    start.add_argument("--duration", type=float, required=True)
    stage_start = sub.add_parser("stage-start")
    stage_start.add_argument("--state", required=True)
    stage_start.add_argument("--stage", required=True, choices=sorted(DEFAULT_BUDGETS))
    stage_end = sub.add_parser("stage-end")
    stage_end.add_argument("--state", required=True)
    stage_end.add_argument("--stage", required=True, choices=sorted(DEFAULT_BUDGETS))
    stage_end.add_argument("--note")
    report = sub.add_parser("report")
    report.add_argument("--state", required=True)
    report.add_argument("--output")
    complete = sub.add_parser("complete")
    complete.add_argument("--state", required=True)
    wait_start = sub.add_parser("wait-start")
    wait_start.add_argument("--state", required=True)
    wait_end = sub.add_parser("wait-end")
    wait_end.add_argument("--state", required=True)
    budget = sub.add_parser("budget-check")
    budget.add_argument("--state", required=True)
    budget.add_argument("--stage", required=True)
    args = parser.parse_args()
    state_path = Path(args.state)
    if args.command == "start":
        result = start_run(state_path, args.title, args.duration)
    elif args.command == "stage-start":
        result = start_stage(state_path, args.stage)
    elif args.command == "stage-end":
        result = end_stage(state_path, args.stage, note=args.note)
    elif args.command == "complete":
        result = complete_run(state_path)
    elif args.command == "wait-start":
        result = start_user_wait(state_path)
    elif args.command == "wait-end":
        result = end_user_wait(state_path)
    elif args.command == "budget-check":
        result = require_within_budget(state_path, args.stage)
    else:
        result = build_report(state_path)
        if args.output:
            write_json(Path(args.output), result)
    print(args.output if getattr(args, "output", None) else state_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
