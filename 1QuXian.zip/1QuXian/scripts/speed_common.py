#!/usr/bin/env python3
"""Shared cache and toolchain helpers for the infoflow workflow."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

DEFAULT_EXCLUDED_DIRS = {
    ".cache", ".git", ".npm-cache", "cache", "code cache", "gpucache",
    "node_modules", "temp", "tmp", "frames", "frame", "render", "renders",
    "proxy", "proxies", "__pycache__", "hf-cache", "mpl", ".worktrees",
    ".pytest-tmp", ".venv", "venv", "site-packages", "test-results",
    "playwright-report", "coverage",
}


def find_ffmpeg(explicit: str | None = None) -> str:
    configured = explicit or os.environ.get("CURVE_FFMPEG") or os.environ.get("CODEX_FFMPEG")
    found = shutil.which(configured or "ffmpeg")
    if found:
        return found
    if configured and Path(configured).expanduser().is_file():
        return str(Path(configured).expanduser().resolve())
    raise FileNotFoundError("ffmpeg not found; pass --ffmpeg or set CURVE_FFMPEG")


def resolve_duration(duration: float | None = None, audio_path: Path | None = None) -> float:
    if (duration is None) == (audio_path is None):
        raise ValueError("provide exactly one of duration or audio")
    if duration is not None:
        if duration <= 0:
            raise ValueError("duration must be > 0")
        return float(duration)
    audio_path = Path(audio_path)
    if not audio_path.is_file():
        raise FileNotFoundError(audio_path)
    ffmpeg = Path(find_ffmpeg())
    ffprobe = ffmpeg.with_name("ffprobe.exe" if ffmpeg.suffix.lower() == ".exe" else "ffprobe")
    probe = str(ffprobe) if ffprobe.is_file() else (shutil.which("ffprobe") or "")
    if not probe:
        raise FileNotFoundError("ffprobe not found")
    result = subprocess.run(
        [probe, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path)],
        capture_output=True, text=True, encoding="utf-8", errors="replace", check=True,
    )
    value = float(result.stdout.strip())
    if value <= 0:
        raise ValueError("audio duration must be > 0")
    return value


def find_chinese_font(bold: bool = False) -> str:
    variable = "CURVE_FONT_BOLD" if bold else "CURVE_FONT_REGULAR"
    configured = os.environ.get(variable)
    if configured:
        path = Path(configured).expanduser()
        if path.is_file():
            return str(path.resolve())
        raise FileNotFoundError(f"configured Chinese font not found; set {variable} to a font file")
    windows = Path(os.environ["WINDIR"]) / "Fonts" if os.environ.get("WINDIR") else None
    candidates = [
        *(([windows / "msyhbd.ttc", windows / "msyh.ttc"] if bold else [windows / "msyh.ttc", windows / "simhei.ttf"]) if windows else []),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc" if bold else "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
        Path("/System/Library/Fonts/PingFang.ttc"),
    ]
    for path in candidates:
        if path.is_file():
            return str(path.resolve())
    raise FileNotFoundError(f"Chinese font not found; set {variable} to a font file")


def stable_json(data: object) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def content_key(data: object, length: int = 16) -> str:
    return hashlib.sha256(stable_json(data).encode("utf-8")).hexdigest()[:length]


def file_signature(path: Path) -> dict:
    stat = path.stat()
    return {"path": str(path.resolve()), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns}


def quick_hash(path: Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    size = path.stat().st_size
    with path.open("rb") as handle:
        digest.update(handle.read(block_size))
        if size > block_size:
            handle.seek(max(0, size - block_size))
            digest.update(handle.read(block_size))
    digest.update(str(size).encode("ascii"))
    return digest.hexdigest()


def load_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
