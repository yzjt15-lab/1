#!/usr/bin/env python3
"""Render five independent black-gold market chart layouts."""
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from speed_common import find_chinese_font

CHART_KINDS = {"relative_return", "futures_position", "dual_axis_trend", "kline_wave", "kline_fibonacci"}
GOLD, BLUE, CYAN, GREEN, RED, WHITE = (242, 190, 82, 255), (72, 145, 255, 255), (52, 220, 244, 255), (49, 205, 116, 255), (246, 66, 66, 255), (240, 243, 248, 255)


def font(size: int, bold: bool = False):
    return ImageFont.truetype(find_chinese_font(bold), size)


def safe_name(value: str) -> str:
    return re.sub(r"[^0-9A-Za-z_-]+", "_", value).strip("_") or "chart"


def numeric(values) -> list[float]:
    try:
        result = [float(value) for value in values]
    except (TypeError, ValueError) as exc:
        raise ValueError("chart data must be a non-empty numeric array") from exc
    if not result:
        raise ValueError("chart data must be a non-empty numeric array")
    return result


def _range(values: list[float]) -> tuple[float, float]:
    low, high = min(values), max(values)
    pad = (high - low or max(abs(high), 1)) * .08
    return low - pad, high + pad


def _xy(values, box, limits=None):
    left, top, right, bottom = box
    low, high = limits or _range(values)
    span = high - low or 1
    return [(round(left + i * (right - left) / max(1, len(values) - 1)), round(bottom - (v - low) / span * (bottom - top))) for i, v in enumerate(values)]


def _fmt(value: float, percent=False) -> str:
    if percent:
        return f"{value:.0f}%"
    return f"{value:,.0f}" if abs(value) >= 100 else f"{value:.1f}".rstrip("0").rstrip(".")


def _grid(draw, box, limits, right_limits=None, percent=False):
    left, top, right, bottom = box
    axis = font(20)
    for index in range(6):
        y = round(top + index * (bottom - top) / 5)
        draw.line((left, y, right, y), fill=(140, 155, 175, 90), width=1)
        value = limits[1] - index * (limits[1] - limits[0]) / 5
        label = _fmt(value, percent)
        bounds = draw.textbbox((0, 0), label, font=axis)
        draw.text((left - bounds[2] - 16, y - 12), label, font=axis, fill=WHITE)
        if right_limits:
            rvalue = right_limits[1] - index * (right_limits[1] - right_limits[0]) / 5
            draw.text((right + 14, y - 12), _fmt(rvalue), font=axis, fill=CYAN)
    draw.line((left, top, left, bottom), fill=WHITE, width=2)
    draw.line((left, bottom, right, bottom), fill=WHITE, width=2)
    if right_limits:
        draw.line((right, top, right, bottom), fill=WHITE, width=2)


def _labels(draw, labels, box):
    if not labels:
        return
    f = font(20)
    for i, label in enumerate(labels):
        if i % max(1, math.ceil(len(labels) / 7)):
            continue
        x = round(box[0] + i * (box[2] - box[0]) / max(1, len(labels) - 1))
        draw.text((x - 28, box[3] + 14), str(label), font=f, fill=WHITE)


def _base(config, size):
    width, height = size
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    panel = (int(width * .12), int(height * .125), int(width * .88), int(height * .84))
    draw.rounded_rectangle(panel, radius=20, fill=(3, 18, 35, 232), outline=GOLD, width=2)
    title = str(config["title"])
    title_font = font(width // 35, True)
    bounds = draw.textbbox((0, 0), title, font=title_font)
    tx = (width - bounds[2]) // 2
    draw.text((tx, panel[1] + 24), title, font=title_font, fill=GOLD)
    cy = panel[1] + 57
    draw.line((panel[0] + 70, cy, tx - 30, cy), fill=(216, 166, 65, 150), width=2)
    draw.line((tx + bounds[2] + 30, cy, panel[2] - 70, cy), fill=(216, 166, 65, 150), width=2)
    return image, draw, panel


def _series(config):
    data = config.get("series")
    if not isinstance(data, list) or not data:
        raise ValueError("chart requires non-empty series")
    return [(str(item.get("label", f"序列{i + 1}")), numeric(item.get("values"))) for i, item in enumerate(data)]


def _line_chart(draw, config, panel, kind):
    series = _series(config)
    box = (panel[0] + 120, panel[1] + 175, panel[2] - (250 if kind == "relative_return" else 105), panel[3] - 82)
    palette = [GOLD, BLUE, CYAN, GREEN]
    if kind == "dual_axis_trend":
        if len(series) != 2:
            raise ValueError("dual_axis_trend requires exactly two series")
        limits, right_limits = _range(series[0][1]), _range(series[1][1])
        _grid(draw, box, limits, right_limits)
        palette = [GOLD, CYAN]
        for i, (_, values) in enumerate(series):
            draw.line(_xy(values, box, limits if i == 0 else right_limits), fill=palette[i], width=4, joint="curve")
        draw.text((box[0] - 70, box[1] - 42), str(config.get("left_axis_label", series[0][0])), font=font(20, True), fill=GOLD)
        draw.text((box[2] - 80, box[1] - 42), str(config.get("right_axis_label", series[1][0])), font=font(20, True), fill=CYAN)
    else:
        values = [v for _, line in series for v in line]
        limits = _range(values)
        if limits[0] < 0 < limits[1]:
            limits = (min(limits[0], -abs(limits[1])), max(limits[1], abs(limits[0])))
        _grid(draw, box, limits, percent=True)
        zero = _xy([0], box, limits)[0][1]
        draw.line((box[0], zero, box[2], zero), fill=(230, 235, 240, 190), width=2)
        for i, (_, line) in enumerate(series):
            draw.line(_xy(line, box, limits), fill=palette[i % len(palette)], width=4, joint="curve")
    _labels(draw, config.get("labels"), box)
    if kind == "relative_return":
        for i, (label, _) in enumerate(series):
            x, legend_y = box[2] + 42, box[1] + 270 + i * 54
            draw.line((x, legend_y, x + 44, legend_y), fill=palette[i], width=5)
            draw.text((x + 58, legend_y - 15), label, font=font(21), fill=WHITE)
    else:
        for i, (label, _) in enumerate(series):
            x, legend_y = panel[0] + 460 + i * 250, panel[1] + 128
            draw.line((x, legend_y, x + 44, legend_y), fill=palette[i], width=5)
            draw.text((x + 58, legend_y - 15), label, font=font(21), fill=WHITE)
    for item in config.get("annotations", []):
        text = str(item.get("text", ""))
        if text:
            draw.rounded_rectangle((panel[2] - 390, panel[1] + 130, panel[2] - 80, panel[1] + 190), radius=8, fill=(5, 14, 25, 240), outline=GOLD, width=2)
            draw.text((panel[2] - 360, panel[1] + 144), text, font=font(23, True), fill=GOLD)


def _positions(draw, config, panel):
    series = _series(config)
    panel_width, panel_height = panel[2] - panel[0], panel[3] - panel[1]
    box = (panel[0] + int(panel_width * .10), panel[1] + int(panel_height * .24), panel[2] - int(panel_width * .05), panel[3] - int(panel_height * .12))
    maximum = max(abs(v) for _, values in series for v in values) or 1
    limits = (0, maximum * 1.15)
    _grid(draw, box, limits)
    count = max(len(values) for _, values in series)
    group = (box[2] - box[0]) / count
    bar_width = group * .22
    palette = [BLUE, GOLD]
    for si, (label, values) in enumerate(series):
        for i, value in enumerate(values):
            x1 = box[0] + i * group + group * (.25 + si * .30)
            y = _xy([value], box, limits)[0][1]
            draw.rectangle((x1, min(y, box[3]), x1 + bar_width, max(y, box[3])), fill=palette[si % 2])
            text = _fmt(value)
            bounds = draw.textbbox((0, 0), text, font=font(18, True))
            draw.text((x1 + (bar_width - bounds[2]) / 2, y - 28), text, font=font(18, True), fill=palette[si % 2])
        lx = panel[0] + 500 + si * 180
        draw.rectangle((lx, panel[1] + 120, lx + 25, panel[1] + 145), fill=palette[si % 2])
        draw.text((lx + 38, panel[1] + 116), label, font=font(21), fill=WHITE)
    labels = config.get("labels") or [str(i + 1) for i in range(count)]
    for i, label in enumerate(labels):
        x = box[0] + i * group + group / 2
        draw.text((x - 20, box[3] + 16), str(label), font=font(22, True), fill=WHITE)
    draw.text((box[0] - 70, box[1] - 42), str(config.get("left_axis_label", "持仓（手）")), font=font(20), fill=WHITE)
    annotations = config.get("annotations") or []
    if annotations:
        text = str(annotations[0].get("text", ""))
        draw.rounded_rectangle((panel[2] - 350, panel[1] + 115, panel[2] - 70, panel[1] + 175), radius=9, fill=(8, 22, 35, 245), outline=GOLD, width=2)
        draw.text((panel[2] - 325, panel[1] + 130), text, font=font(21, True), fill=GOLD)


def _kline(draw, config, panel, fibonacci=False):
    rows = config.get("ohlc")
    if not isinstance(rows, list) or not rows:
        raise ValueError("K-line charts require non-empty ohlc rows")
    box = (panel[0] + (240 if fibonacci else 50), panel[1] + 140, panel[2] - 70, panel[3] - 70)
    lows, highs = numeric([r["low"] for r in rows]), numeric([r["high"] for r in rows])
    limits = _range(lows + highs)
    _grid(draw, box, limits)
    step, span = (box[2] - box[0]) / len(rows), limits[1] - limits[0]
    y = lambda value: round(box[3] - (value - limits[0]) / span * (box[3] - box[1]))
    for i, row in enumerate(rows):
        opening, high, low, closing = (float(row[key]) for key in ("open", "high", "low", "close"))
        x, color = round(box[0] + step * (i + .5)), RED if closing >= opening else GREEN
        draw.line((x, y(high), x, y(low)), fill=color, width=2)
        draw.rectangle((x - max(2, int(step * .25)), min(y(opening), y(closing)), x + max(2, int(step * .25)), max(y(opening), y(closing)) + 2), fill=color)
    _labels(draw, config.get("labels"), box)
    if fibonacci:
        high, low = max(highs), min(lows)
        for ratio, color in zip((0, .236, .382, .5, .618, .786, 1), (WHITE, RED, (255, 139, 40, 255), GOLD, (255, 215, 45, 255), (130, 210, 65, 255), WHITE)):
            level = high - (high - low) * ratio
            yy = y(level)
            draw.line((box[0], yy, box[2], yy), fill=color, width=2)
            draw.text((panel[0] + 32, yy - 14), f"{ratio:.3f}  {_fmt(level)}", font=font(18, True), fill=color)
    else:
        wave = config.get("wave_points") or list(range(0, len(rows), max(1, len(rows) // 8)))
        pts = [(round(box[0] + step * (i + .5)), y(float(rows[i]["high"] if n % 2 else rows[i]["low"]))) for n, i in enumerate(wave)]
        if len(pts) > 1:
            draw.line(pts, fill=(255, 220, 105, 255), width=3)
            for n, (x, yy) in enumerate(pts):
                draw.text((x - 8, yy - 32), str(n + 1), font=font(20, True), fill=GOLD)
        for ref in config.get("reference_lines", []):
            yy = y(float(ref["value"]))
            draw.line((box[0], yy, box[2], yy), fill=GOLD, width=2)
            draw.text((box[2] - 170, yy - 28), str(ref.get("label", ref["value"])), font=font(19, True), fill=GOLD)


def _moving_average(values, window):
    return [sum(values[max(0, i - window + 1):i + 1]) / min(window, i + 1) for i in range(len(values))]


def _kline_wave(draw, config, panel):
    rows = config.get("ohlc")
    if not isinstance(rows, list) or not rows:
        raise ValueError("K-line charts require non-empty ohlc rows")
    price_box = (panel[0] + 32, panel[1] + 132, panel[2] - 58, panel[3] - 150)
    volume_box = (price_box[0], panel[3] - 125, price_box[2], panel[3] - 42)
    lows, highs, closes = numeric([r["low"] for r in rows]), numeric([r["high"] for r in rows]), numeric([r["close"] for r in rows])
    limits = _range(lows + highs)
    _grid(draw, price_box, limits)
    step, span = (price_box[2] - price_box[0]) / len(rows), limits[1] - limits[0]
    y = lambda value: round(price_box[3] - (value - limits[0]) / span * (price_box[3] - price_box[1]))
    volumes = [float(r.get("volume", abs(float(r["close"]) - float(r["open"])) * 100 + 100)) for r in rows]
    vmax = max(volumes) or 1
    for i, row in enumerate(rows):
        opening, high, low, closing = (float(row[key]) for key in ("open", "high", "low", "close"))
        x, color = round(price_box[0] + step * (i + .5)), RED if closing >= opening else GREEN
        half = max(2, int(step * .25))
        draw.line((x, y(high), x, y(low)), fill=color, width=2)
        draw.rectangle((x - half, min(y(opening), y(closing)), x + half, max(y(opening), y(closing)) + 2), fill=color)
        vy = round(volume_box[3] - volumes[i] / vmax * (volume_box[3] - volume_box[1]))
        draw.rectangle((x - half, vy, x + half, volume_box[3]), fill=color)
    for window, color in zip((5, 10, 20, 60), (GOLD, BLUE, (193, 89, 235, 255), GREEN)):
        draw.line(_xy(_moving_average(closes, window), price_box, limits), fill=color, width=2)
    wave = config.get("wave_points") or list(range(0, len(rows), max(1, len(rows) // 8)))
    pts = [(round(price_box[0] + step * (i + .5)), y(float(rows[i]["high"] if n % 2 else rows[i]["low"]))) for n, i in enumerate(wave)]
    if len(pts) > 1:
        draw.line(pts, fill=(255, 224, 112, 255), width=3)
        labels = config.get("wave_labels") or [str(i + 1) for i in range(len(pts))]
        for label, (x, yy) in zip(labels, pts):
            draw.text((x - 8, yy - 32), str(label), font=font(20, True), fill=GOLD)
    for ref in config.get("reference_lines", []):
        yy = y(float(ref["value"])); draw.line((price_box[0], yy, price_box[2], yy), fill=GOLD, width=2)
        label = str(ref.get("label", ref["value"]))
        label_x = price_box[0] + 18 if yy < panel[1] + 230 else price_box[2] - 230
        draw.text((label_x, yy - 28), label, font=font(19, True), fill=GOLD)
    for index, item in enumerate(config.get("annotations", [])[:3]):
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        top = panel[1] + 112 + index * 54
        bounds = draw.textbbox((0, 0), text, font=font(20, True))
        left = panel[2] - bounds[2] - 92
        draw.rounded_rectangle((left, top, panel[2] - 42, top + 44), radius=8, fill=(5, 17, 31, 238), outline=GOLD, width=2)
        draw.text((left + 18, top + 8), text, font=font(20, True), fill=GOLD)
    draw.text((price_box[0], volume_box[1] - 26), "成交量", font=font(17), fill=WHITE)
    _labels(draw, config.get("labels"), volume_box)


def _kline_fibonacci(draw, config, panel):
    rows = config.get("ohlc")
    if not isinstance(rows, list) or not rows:
        raise ValueError("K-line charts require non-empty ohlc rows")
    box = (panel[0] + 250, panel[1] + 135, panel[2] - 68, panel[3] - 65)
    lows, highs = numeric([r["low"] for r in rows]), numeric([r["high"] for r in rows])
    limits = _range(lows + highs); _grid(draw, box, limits)
    step, span = (box[2] - box[0]) / len(rows), limits[1] - limits[0]
    y = lambda value: round(box[3] - (value - limits[0]) / span * (box[3] - box[1]))
    for i, row in enumerate(rows):
        opening, high, low, closing = (float(row[key]) for key in ("open", "high", "low", "close"))
        x, color = round(box[0] + step * (i + .5)), RED if closing >= opening else GREEN
        half = max(2, int(step * .25)); draw.line((x, y(high), x, y(low)), fill=color, width=2)
        draw.rectangle((x - half, min(y(opening), y(closing)), x + half, max(y(opening), y(closing)) + 2), fill=color)
    high, low = max(highs), min(lows)
    ratios = ((0, WHITE), (.236, RED), (.382, (255, 139, 40, 255)), (.5, GOLD), (.618, (255, 215, 45, 255)), (.786, (130, 210, 65, 255)), (1, WHITE))
    for ratio, color in ratios:
        level = high - (high - low) * ratio; yy = y(level)
        if ratio == .618:
            draw.rectangle((box[0], yy - 14, box[2], yy + 14), fill=(232, 190, 82, 45))
        draw.line((box[0], yy, box[2], yy), fill=color, width=2)
        draw.text((panel[0] + 32, yy - 14), f"{ratio:.3f}  {_fmt(level)}", font=font(18, True), fill=color)
    draw.rounded_rectangle((box[2] - 300, y(high - (high - low) * .618) + 30, box[2] - 35, y(high - (high - low) * .618) + 86), radius=8, fill=(6, 19, 34, 245), outline=GOLD, width=2)
    draw.text((box[2] - 272, y(high - (high - low) * .618) + 43), "0.618 关键支撑", font=font(21, True), fill=GOLD)
    _labels(draw, config.get("labels"), box)


def render(config: dict, output_dir: Path, size=(1920, 1080)) -> Path:
    kind = config.get("chart_kind")
    if kind not in CHART_KINDS:
        raise ValueError(f"chart_kind must be one of {sorted(CHART_KINDS)}")
    if not all(str(config.get(key, "")).strip() for key in ("title", "data_metric", "data_interval")):
        raise ValueError("title, data_metric and data_interval are required")
    image, draw, panel = _base(config, size)
    if kind == "futures_position":
        _positions(draw, config, panel)
    elif kind in {"relative_return", "dual_axis_trend"}:
        _line_chart(draw, config, panel, kind)
    elif kind == "kline_wave":
        _kline_wave(draw, config, panel)
    else:
        _kline_fibonacci(draw, config, panel)
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"{safe_name(str(config.get('id') or kind))}.png"
    image.save(output)
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    args = parser.parse_args()
    print(render(json.loads(Path(args.config).read_text(encoding="utf-8-sig")), Path(args.output_dir), (args.width, args.height)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
