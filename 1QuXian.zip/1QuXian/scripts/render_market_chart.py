#!/usr/bin/env python3
"""Render six independent black-gold market chart layouts."""
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from page_reference_contract import PAGE_SIZE, approved_reference_path
from speed_common import find_chinese_font

CHART_KINDS = {"relative_return", "futures_position", "grouped_comparison", "dual_axis_trend", "kline_wave", "kline_fibonacci"}
GOLD, BLUE, CYAN, GREEN, RED, WHITE = (242, 190, 82, 255), (72, 145, 255, 255), (52, 220, 244, 255), (49, 205, 116, 255), (246, 66, 66, 255), (240, 243, 248, 255)
DEFAULT_TITLES = {
    "relative_return": "主要指数相对涨跌",
    "futures_position": "股指期货会员持仓",
    "grouped_comparison": "指数与成交额相对变化",
    "dual_axis_trend": "估值与盈利趋势",
    "kline_wave": "上证指数波浪结构",
    "kline_fibonacci": "斐波那契回撤区间",
}


def font(size: int, bold: bool = False):
    return ImageFont.truetype(find_chinese_font(bold), size)


def _fit_font(draw, text: str, current, max_width: int, minimum: int = 12):
    while current.size > minimum and draw.textbbox((0, 0), text, font=current)[2] > max_width:
        current = current.font_variant(size=current.size - 1)
    if draw.textbbox((0, 0), text, font=current)[2] > max_width:
        raise ValueError(f"text exceeds its safe area: {text}")
    return current


def safe_name(value: str) -> str:
    return re.sub(r"[^\w-]+", "_", value).strip("_") or "chart"


def numeric(values) -> list[float]:
    try:
        result = [float(value) for value in values]
    except (TypeError, ValueError) as exc:
        raise ValueError("chart data must be a non-empty numeric array") from exc
    if not result:
        raise ValueError("chart data must be a non-empty numeric array")
    if not all(math.isfinite(value) for value in result):
        raise ValueError("chart data values must be finite")
    return result


def _range(values: list[float]) -> tuple[float, float]:
    low, high = min(values), max(values)
    pad = (high - low or max(abs(high), 1)) * .08
    return low - pad, high + pad


def _checked_limits(config, key: str, values: list[float]) -> tuple[float, float]:
    raw = config.get(key)
    if raw is None:
        return _range(values)
    if not isinstance(raw, (list, tuple)) or len(raw) != 2:
        raise ValueError(f"{key} must contain two numeric bounds")
    try:
        low, high = map(float, raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{key} must contain two numeric bounds") from exc
    if not all(math.isfinite(value) for value in (low, high)) or low >= high:
        raise ValueError(f"{key} must be finite and increasing")
    if min(values) < low or max(values) > high:
        raise ValueError(f"{key} must include every plotted value")
    return low, high


def _xy(values, box, limits=None):
    left, top, right, bottom = box
    low, high = limits or _range(values)
    span = high - low or 1
    return [(round(left + i * (right - left) / max(1, len(values) - 1)), round(bottom - (v - low) / span * (bottom - top))) for i, v in enumerate(values)]


def _fmt(value: float, percent=False) -> str:
    if percent:
        return f"{value:.0f}%"
    return f"{value:,.0f}" if abs(value) >= 100 else f"{value:.1f}".rstrip("0").rstrip(".")


def _grid(draw, box, limits, right_limits=None, percent=False, safe=None, tick_count=6, dashed=False):
    left, top, right, bottom = box
    safe_left, safe_right = safe or (0, PAGE_SIZE[0])
    for index in range(tick_count):
        y = round(top + index * (bottom - top) / (tick_count - 1))
        if dashed:
            for x in range(left, right, 14):
                draw.line((x, y, min(x + 7, right), y), fill=(140, 155, 175, 120), width=2)
        else:
            draw.line((left, y, right, y), fill=(140, 155, 175, 90), width=1)
        value = limits[1] - index * (limits[1] - limits[0]) / (tick_count - 1)
        label = _fmt(value, percent)
        axis = _fit_font(draw, label, font(20), left - safe_left - 16, minimum=8)
        bounds = draw.textbbox((0, 0), label, font=axis)
        draw.text((left - bounds[2] - 16, y - 12), label, font=axis, fill=WHITE)
        if right_limits:
            rvalue = right_limits[1] - index * (right_limits[1] - right_limits[0]) / (tick_count - 1)
            right_label = f"{rvalue:.2f}" if max(abs(right_limits[0]), abs(right_limits[1])) <= 10 else _fmt(rvalue)
            right_axis = _fit_font(draw, right_label, font(20), safe_right - right - 14, minimum=8)
            draw.text((right + 14, y - 12), right_label, font=right_axis, fill=CYAN)
    draw.line((left, top, left, bottom), fill=WHITE, width=2)
    draw.line((left, bottom, right, bottom), fill=WHITE, width=2)
    if right_limits:
        draw.line((right, top, right, bottom), fill=WHITE, width=2)


def _labels(draw, labels, box, safe=None):
    if not labels:
        return
    nonempty = sum(bool(str(label).strip()) for label in labels)
    base_font = font(13 if nonempty > 8 else 20)
    safe_left, safe_right = safe or (0, PAGE_SIZE[0])
    entries = [(round(box[0] + i * (box[2] - box[0]) / max(1, len(labels) - 1)), str(label)) for i, label in enumerate(labels) if str(label).strip()]
    for index, (x, label) in enumerate(entries):
        if len(entries) == 1:
            max_width = box[2] - box[0]
        else:
            distances = []
            if index:
                distances.append(x - entries[index - 1][0])
            if index + 1 < len(entries):
                distances.append(entries[index + 1][0] - x)
            max_width = min(distances) - 8
        max_width = min(max_width, 2 * min(x - safe_left, safe_right - x) - 8)
        label_font = _fit_font(draw, label, base_font, max(1, int(max_width)), minimum=9)
        bounds = draw.textbbox((0, 0), label, font=label_font)
        draw.text((x - bounds[2] / 2, box[3] + 14), label, font=label_font, fill=WHITE)


def _base(config, size):
    width, height = size
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    panel = (int(width * .04), int(height * .04), int(width * .96), int(height * .96))
    draw.rounded_rectangle(panel, radius=20, fill=(3, 18, 35, 232), outline=GOLD, width=2)
    return image, draw, panel


def _header(draw, panel, title: str):
    title_font = _fit_font(draw, title, font(44, True), int((panel[2] - panel[0]) * .48), minimum=9)
    bounds = draw.textbbox((0, 0), title, font=title_font)
    center = (panel[0] + panel[2]) / 2
    y = panel[1] + 22
    draw.text((center - bounds[2] / 2, y), title, font=title_font, fill=GOLD)
    line_y = y + max(34, bounds[3] - bounds[1]) / 2 + 7
    gap = bounds[2] / 2 + 28
    for start, end in ((panel[0] + 70, center - gap), (center + gap, panel[2] - 70)):
        if end <= start:
            continue
        draw.line((start, line_y, end, line_y), fill=GOLD, width=2)
        diamond_x = end if end < center else start
        draw.polygon(((diamond_x, line_y - 7), (diamond_x + 7, line_y), (diamond_x, line_y + 7), (diamond_x - 7, line_y)), outline=GOLD)


def _series(config):
    data = config.get("series")
    if not isinstance(data, list) or not data:
        raise ValueError("chart requires non-empty series")
    result = []
    for item in data:
        if not isinstance(item, dict) or not str(item.get("label", "")).strip():
            raise ValueError("every series requires a non-empty label")
        result.append((str(item["label"]).strip(), numeric(item.get("values"))))
    if len({len(values) for _, values in result}) != 1:
        raise ValueError("all series must have the same number of values")
    return result


def _checked_labels(config, count: int, required: bool = False):
    labels = config.get("labels")
    if labels is None:
        if required:
            raise ValueError("labels are required for this chart")
        return []
    if not isinstance(labels, list) or len(labels) != count:
        raise ValueError("labels must match the number of values")
    if required and any(not str(label).strip() for label in labels):
        raise ValueError("labels must be non-empty for this chart")
    return labels


def _line_chart(draw, config, panel, kind):
    series = _series(config)
    count = len(series[0][1])
    labels = _checked_labels(config, count)
    box = (panel[0] + 120, panel[1] + 175, panel[2] - (250 if kind == "relative_return" else 105), panel[3] - 82)
    palette = [GOLD, BLUE, CYAN, GREEN]
    if kind == "dual_axis_trend":
        if len(series) != 2:
            raise ValueError("dual_axis_trend requires exactly two series")
        if count < 3:
            raise ValueError("dual_axis_trend requires at least three shared points")
        limits = _checked_limits(config, "left_limits", series[0][1])
        right_limits = _checked_limits(config, "right_limits", series[1][1])
        _grid(draw, box, limits, right_limits, safe=(panel[0] + 16, panel[2] - 16), tick_count=7)
        palette = [GOLD, CYAN]
        for i, (_, values) in enumerate(series):
            points = _xy(values, box, limits if i == 0 else right_limits)
            draw.line(points, fill=palette[i], width=4, joint="curve")
        left_title = str(config.get("left_axis_label", series[0][0])); right_title = str(config.get("right_axis_label", series[1][0]))
        left_font = _fit_font(draw, left_title, font(18, True), int((box[2] - box[0]) * .34))
        right_font = _fit_font(draw, right_title, font(18, True), int((box[2] - box[0]) * .34))
        rb = draw.textbbox((0, 0), right_title, font=right_font)
        draw.text((panel[0] + 16, box[1] - 27), left_title, font=left_font, fill=GOLD)
        draw.text((box[2] - rb[2], box[1] - 27), right_title, font=right_font, fill=CYAN)
    else:
        if not 1 <= len(series) <= len(palette):
            raise ValueError("relative_return supports one to four series")
        if count < 2:
            raise ValueError("relative_return requires at least two shared points")
        values = [v for _, line in series for v in line]
        limits = _checked_limits(config, "y_limits", values + [0])
        if limits[0] < 0 < limits[1]:
            limits = (min(limits[0], -abs(limits[1])), max(limits[1], abs(limits[0])))
        _grid(draw, box, limits, percent=True, safe=(panel[0] + 16, panel[2] - 16), tick_count=7)
        zero = _xy([0], box, limits)[0][1]
        draw.line((box[0], zero, box[2], zero), fill=(230, 235, 240, 190), width=2)
        for i, (_, line) in enumerate(series):
            draw.line(_xy(line, box, limits), fill=palette[i % len(palette)], width=4, joint="curve")
    _labels(draw, labels, box, safe=(panel[0] + 16, panel[2] - 16))
    if kind == "relative_return":
        for i, (label, _) in enumerate(series):
            x, legend_y = box[2] + 42, box[1] + 270 + i * 54
            draw.line((x, legend_y, x + 44, legend_y), fill=palette[i], width=5)
            legend_font = _fit_font(draw, label, font(21), panel[2] - x - 76)
            draw.text((x + 58, legend_y - 15), label, font=legend_font, fill=WHITE)
        x, y = _xy([series[0][1][-1]], box, limits)[0]
        x = box[2]
        draw.ellipse((x - 8, y - 8, x + 8, y + 8), fill=GOLD, outline=WHITE, width=2)
        endpoint_label = str(config.get("endpoint_label") or f"{series[0][1][-1]:g}%")
        endpoint_font = _fit_font(draw, endpoint_label, font(28, True), panel[2] - x - 36)
        draw.text((x + 18, y - 22), endpoint_label, font=endpoint_font, fill=GOLD)
        interval = str(config.get("data_interval", "")); interval_font = _fit_font(draw, interval, font(20), panel[2] - panel[0] - 80)
        bounds = draw.textbbox((0, 0), interval, font=interval_font)
        draw.text(((panel[0] + panel[2] - bounds[2]) / 2, panel[3] - 38), interval, font=interval_font, fill=WHITE)
    else:
        legend_xs = [round(box[0] + (box[2] - box[0]) * ratio) for ratio in (.44, .76)]
        for i, (label, _) in enumerate(series):
            x, legend_y = legend_xs[i], panel[1] + 128
            draw.line((x, legend_y, x + 44, legend_y), fill=palette[i], width=5)
            right_edge = legend_xs[i + 1] if i + 1 < len(legend_xs) else panel[2]
            legend_font = _fit_font(draw, label, font(21), right_edge - x - 76)
            draw.text((x + 58, legend_y - 15), label, font=legend_font, fill=WHITE)
    annotations = config.get("annotations", [])
    if not isinstance(annotations, list) or len(annotations) > 1:
        raise ValueError(f"{kind} supports at most one annotation")
    for item in annotations:
        text = str(item.get("text", ""))
        if text:
            note_top = box[1] + 75 if kind == "dual_axis_trend" else panel[1] + 130
            if kind == "dual_axis_trend":
                series_index = item.get("series_index", 1)
                if isinstance(series_index, bool) or not isinstance(series_index, int) or series_index not in (0, 1):
                    raise ValueError("dual_axis_trend annotation series_index must be 0 or 1")
                values = series[series_index][1]
                index = item.get("index", len(values) // 2)
                if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < len(values):
                    raise ValueError("dual_axis_trend annotation index must select an existing point")
                px, py = _xy(values, box, limits if series_index == 0 else right_limits)[index]
                note_left = min(max(px - 120, panel[0] + 16), panel[2] - 256)
                note_right = note_left + 240
                if note_top <= py <= note_top + 60:
                    note_top = py - 90 if py - 90 >= box[1] + 8 else py + 30
            else:
                note_left, note_right = panel[2] - 390, panel[2] - 80
            note_font = _fit_font(draw, text, font(23, True), int(note_right - note_left - 32))
            draw.rounded_rectangle((note_left, note_top, note_right, note_top + 60), radius=8, fill=(5, 14, 25, 240), outline=GOLD, width=2)
            tb = draw.textbbox((0,0), text, font=note_font)
            draw.text(((note_left+note_right-tb[2])/2, note_top + 14), text, font=note_font, fill=GOLD)
            if kind == "dual_axis_trend":
                if config.get("annotation_connector", True):
                    anchor_y = note_top if py < note_top else note_top + 60 if py > note_top + 60 else py
                    draw.line((px, anchor_y, px, py), fill=GOLD, width=2)
                    draw.ellipse((px-11, py-11, px+11, py+11), fill=(255,255,255,210), outline=GOLD, width=4)


def _positions(draw, config, panel, kind):
    series = _series(config)
    labels = _checked_labels(config, len(series[0][1]), required=True)
    if len(series) != 2:
        raise ValueError(f"{kind} requires exactly two comparison series")
    count = len(series[0][1])
    if kind == "grouped_comparison" and config.get("prediction_bounds") is not None:
        bounds = numeric(config["prediction_bounds"])
        if len(bounds) != 2 or bounds[0] > bounds[1]:
            raise ValueError("prediction_bounds must contain an increasing lower and upper bound")
        if config.get("source_state") != "user_authorized_prediction" or not config.get("prediction_basis"):
            raise ValueError("prediction_bounds require source_state=user_authorized_prediction and prediction_basis")
        if any(value < bounds[0] or value > bounds[1] for _, values in series for value in values):
            raise ValueError("predicted grouped_comparison values must stay inside prediction_bounds")
    maximum = 4 if kind == "futures_position" else 6
    if count > maximum:
        raise ValueError(f"{kind} supports at most {maximum} categories")
    panel_width, panel_height = panel[2] - panel[0], panel[3] - panel[1]
    if kind == "futures_position":
        box = (panel[0] + int(panel_width * .14), panel[1] + int(panel_height * .25), panel[2] - int(panel_width * .05), panel[3] - int(panel_height * .13))
    else:
        box = (panel[0] + int(panel_width * .08), panel[1] + int(panel_height * .24), panel[2] - int(panel_width * .05), panel[3] - int(panel_height * .20))
    all_values = [value for _, values in series for value in values]
    if config.get("y_limits") is not None:
        limits = _checked_limits(config, "y_limits", all_values + [0])
    elif min(all_values) >= 0:
        limits = (0, max(all_values) * 1.15 or 1)
    elif max(all_values) <= 0:
        limits = (min(all_values) * 1.15, 0)
    else:
        limits = _range(all_values)
    _grid(draw, box, limits, safe=(panel[0] + 16, panel[2] - 16), dashed=kind == "grouped_comparison")
    group = (box[2] - box[0]) / count
    bar_width = group * .25
    zero_y = _xy([0], box, limits)[0][1]
    palette = [BLUE, GOLD] if kind == "futures_position" else [GOLD, BLUE]
    for si, (label, values) in enumerate(series):
        for i, value in enumerate(values):
            x1 = box[0] + i * group + group * (.20 + si * .34)
            y = _xy([value], box, limits)[0][1]
            draw.rectangle((x1, min(y, zero_y), x1 + bar_width, max(y, zero_y)), fill=palette[si])
            text = _fmt(value)
            value_font = _fit_font(draw, text, font(18, True), max(30, int(group * .28)))
            bounds = draw.textbbox((0, 0), text, font=value_font)
            text_height = bounds[3] - bounds[1]
            text_y = max(box[1] + 4, y - text_height - 8) if value >= 0 else min(box[3] - text_height - 4, y + 8)
            draw.text((x1 + (bar_width - bounds[2]) / 2, text_y), text, font=value_font, fill=palette[si])
        legend_ratio = (.38, .52) if kind == "futures_position" else (.39, .57)
        lx = panel[0] + int(panel_width * legend_ratio[si])
        draw.rectangle((lx, panel[1] + 120, lx + 25, panel[1] + 145), fill=palette[si])
        legend_font = _fit_font(draw, label, font(21), 100 if si == 0 else 70)
        draw.text((lx + 38, panel[1] + 116), label, font=legend_font, fill=WHITE)
    for i, label in enumerate(labels):
        x = box[0] + i * group + group / 2
        label = str(label)
        label_font = _fit_font(draw, label, font(22, True), int(group * .75))
        bounds = draw.textbbox((0, 0), label, font=label_font)
        draw.text((x - bounds[2] / 2, box[3] + 16), label, font=label_font, fill=WHITE)
    axis_label = str(config.get("left_axis_label") or config["data_metric"])
    axis_font = _fit_font(draw, axis_label, font(20), 300)
    draw.text((panel[0] + 16, box[1] - 42), axis_label, font=axis_font, fill=GOLD if kind == "grouped_comparison" else WHITE)
    annotations = config.get("annotations") or []
    if not isinstance(annotations, list) or len(annotations) > 1:
        raise ValueError(f"{kind} supports at most one annotation")
    if annotations:
        text = str(annotations[0].get("text", ""))
        note_height = max(48, int(panel_height * .075))
        if kind == "futures_position":
            note_width = min(300, int(panel_width * .32))
            note = (panel[2] - note_width - 64, panel[1] + 112, panel[2] - 64, panel[1] + 112 + note_height)
        else:
            note_width = min(760, int(panel_width * .72))
            center = (panel[0] + panel[2]) // 2
            note = (center - note_width // 2, panel[3] - note_height - 14, center + note_width // 2, panel[3] - 14)
        note_font = _fit_font(draw, text, font(25, True), note_width - 40)
        bounds = draw.textbbox((0, 0), text, font=note_font)
        draw.rounded_rectangle(note, radius=9, fill=(8, 22, 35, 245), outline=GOLD, width=2)
        draw.text(((note[0] + note[2] - bounds[2]) / 2, note[1] + (note_height - (bounds[3] - bounds[1])) / 2 - bounds[1]), text, font=note_font, fill=GOLD)


def _price_data(config):
    points = config.get("price_points")
    if not isinstance(points, list) or len(points) < 2:
        raise ValueError("K-line charts require at least two price_points from the script")
    if all(isinstance(item, dict) for item in points):
        values = numeric([item.get("value") for item in points])
        labels = config.get("labels") or [str(item.get("label", "")) for item in points]
    else:
        values = numeric(points)
        labels = config.get("labels") or []
    if labels and len(labels) != len(values):
        raise ValueError("labels must match price_points")
    return values, labels


def _candle_ohlc(values, index):
    closing = values[index]
    opening = values[index - 1] if index else closing - (values[1] - closing) * .45
    span = max(values) - min(values) or max(abs(closing), 1)
    wick = max(span * .009, abs(closing - opening) * .28)
    high = max(opening, closing) + wick * (1 + index % 3 * .16)
    low = min(opening, closing) - wick * (1 + (index + 1) % 3 * .16)
    return opening, high, low, closing


def _draw_price_bars(draw, values, box, limits):
    if len(values) > max(2, int((box[2] - box[0]) / 4)):
        raise ValueError("price_points exceed chart pixel capacity")
    step, span = (box[2] - box[0]) / len(values), limits[1] - limits[0]
    y = lambda value: round(box[3] - (value - limits[0]) / span * (box[3] - box[1]))
    points = []
    for i in range(len(values)):
        opening, high, low, closing = _candle_ohlc(values, i)
        x, color = round(box[0] + step * (i + .5)), RED if closing >= opening else GREEN
        half = max(2, min(14, int(step * .25)))
        draw.line((x, y(min(high, limits[1])), x, y(max(low, limits[0]))), fill=color, width=2)
        draw.rectangle((x - half, min(y(opening), y(closing)), x + half, max(y(opening), y(closing)) + 2), fill=color)
        points.append((x, y(closing)))
    return points, step, y


def _moving_average(values, period):
    if isinstance(period, bool) or not isinstance(period, int) or period < 2:
        raise ValueError("ma_periods must contain integers >= 2")
    return [sum(values[max(0, index - period + 1):index + 1]) / min(index + 1, period) for index in range(len(values))]


def _kline_wave(draw, config, panel):
    values, labels = _price_data(config)
    volumes = config.get("volume_values")
    price_box = (panel[0] + 120, panel[1] + 132, panel[2] - 58, panel[3] - (150 if volumes is not None else 70))
    volume_box = (price_box[0], panel[3] - 125, price_box[2], panel[3] - 42)
    references = [float(item["value"]) for item in config.get("reference_lines", [])]
    limits = _checked_limits(config, "y_limits", values + references)
    for index in range(9):
        yy = round(price_box[1] + index * (price_box[3]-price_box[1])/8)
        value = limits[1] - index*(limits[1]-limits[0])/8
        draw.line((price_box[0], yy, price_box[2], yy), fill=(140,155,175,80), width=1)
        tick = _fmt(value)
        tick_font = _fit_font(draw, tick, font(15), panel[2] - price_box[2] - 12, minimum=9)
        draw.text((price_box[2] + 8, yy - 10), tick, font=tick_font, fill=WHITE)
    draw.line((price_box[2],price_box[1],price_box[2],price_box[3]), fill=WHITE, width=2)
    price_points, step, y = _draw_price_bars(draw, values, price_box, limits)
    ma_periods = config.get("ma_periods") or []
    if not isinstance(ma_periods, list) or len(ma_periods) > 5:
        raise ValueError("ma_periods must contain at most five periods")
    ma_colors = (GOLD, BLUE, (196, 77, 232, 255), GREEN, (255, 150, 0, 255))
    for index, period in enumerate(ma_periods):
        draw.line(_xy(_moving_average(values, period), price_box, limits), fill=ma_colors[index], width=2)
    metric = str(config["data_metric"])
    metric_font = _fit_font(draw, metric, font(16), price_box[2] - price_box[0])
    draw.text((price_box[0], panel[1] + 92), metric, font=metric_font, fill=WHITE)
    legend_x = price_box[0] + draw.textbbox((0, 0), metric, font=metric_font)[2] + 22
    for index, period in enumerate(ma_periods):
        text = f"MA{period}: {_moving_average(values, period)[-1]:.0f}"
        label_font = _fit_font(draw, text, font(14, True), max(1, price_box[2] - legend_x), minimum=9)
        draw.text((legend_x, panel[1] + 94), text, font=label_font, fill=ma_colors[index])
        legend_x += draw.textbbox((0, 0), text, font=label_font)[2] + 18
    wave = config.get("wave_points")
    if wave is not None:
        if not isinstance(wave, list) or len(wave) < 2 or any(not isinstance(index, int) or index < 0 or index >= len(values) for index in wave):
            raise ValueError("wave_points must contain at least two valid price_points indices")
        if any(left >= right for left, right in zip(wave, wave[1:])):
            raise ValueError("wave_points must be strictly increasing")
        wave_labels = config.get("wave_labels") or [str(i + 1) for i in range(len(wave))]
        if not isinstance(wave_labels, list) or len(wave_labels) != len(wave):
            raise ValueError("wave_labels must match wave_points")
        pts = [price_points[i] for i in wave]
        draw.line(pts, fill=(255, 224, 112, 255), width=3)
        for index, (label, (x, yy)) in enumerate(zip(wave_labels, pts)):
            label = str(label)
            distances = []
            if index:
                distances.append(x - pts[index - 1][0])
            if index + 1 < len(pts):
                distances.append(pts[index + 1][0] - x)
            neighbor_width = min(distances) - 8 if distances else price_box[2] - price_box[0]
            boundary_width = 2 * min(x - panel[0] - 16, panel[2] - 16 - x) - 8
            wave_font = _fit_font(draw, label, font(20, True), max(1, int(min(neighbor_width, boundary_width))), minimum=9)
            bounds = draw.textbbox((0, 0), label, font=wave_font)
            draw.text((x - bounds[2] / 2, yy - 32), label, font=wave_font, fill=GOLD)
    for ref in config.get("reference_lines", []):
        yy = y(float(ref["value"])); draw.line((price_box[0], yy, price_box[2], yy), fill=GOLD, width=2)
        label = str(ref.get("label", ref["value"]))
        label_font = _fit_font(draw, label, font(19, True), 220)
        label_bounds = draw.textbbox((0, 0), label, font=label_font)
        label_y = max(price_box[1] + 8, min(yy - 38, price_box[3] - 34))
        draw.text((price_box[2] - label_bounds[2] - 12, label_y), label, font=label_font, fill=GOLD)
    annotations = config.get("annotations", [])
    if not isinstance(annotations, list) or len(annotations) > 3:
        raise ValueError("kline_wave supports at most three annotations")
    for index, item in enumerate(annotations):
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        top = panel[1] + 112 + index * 54
        note_font = _fit_font(draw, text, font(20, True), min(360, price_box[2] - price_box[0] - 40))
        bounds = draw.textbbox((0, 0), text, font=note_font)
        right = price_box[2] - 20
        left = right - bounds[2] - 36
        draw.rounded_rectangle((left, top, right, top + 44), radius=8, fill=(5, 17, 31, 238), outline=GOLD, width=2)
        draw.text((left + 18, top + 8), text, font=note_font, fill=GOLD)
    if volumes is not None:
        volume_label = str(config.get("volume_label") or "量能")
        volume_font = _fit_font(draw, volume_label, font(17), price_box[2] - price_box[0])
        draw.text((price_box[0], volume_box[1] - 26), volume_label, font=volume_font, fill=WHITE)
        volumes = numeric(volumes)
        if len(volumes) != len(values):
            raise ValueError("volume_values must match price_points")
        vmax = max(abs(value) for value in volumes) or 1
        for i, value in enumerate(volumes):
            x = round(price_box[0] + step * (i + .5)); half = max(2, min(14, int(step * .25)))
            vy = round(volume_box[3] - abs(value) / vmax * (volume_box[3] - volume_box[1]))
            color = RED if values[i] >= (values[i - 1] if i else values[i]) else GREEN
            draw.rectangle((x - half, vy, x + half, volume_box[3]), fill=color)
    _labels(draw, labels, volume_box if volumes is not None else price_box, safe=(panel[0] + 16, panel[2] - 16))


def _kline_fibonacci(draw, config, panel):
    values, labels = _price_data(config)
    box = (panel[0] + 250, panel[1] + 135, panel[2] - 68, panel[3] - 65)
    if "fib_high" not in config or "fib_low" not in config:
        raise ValueError("kline_fibonacci requires explicit fib_high and fib_low")
    high, low = float(config["fib_high"]), float(config["fib_low"])
    if not math.isfinite(high) or not math.isfinite(low) or high <= low:
        raise ValueError("fib_high must be greater than fib_low")
    raw_levels = config.get("fib_levels") or {}
    if not isinstance(raw_levels, dict):
        raise ValueError("fib_levels must be an object")
    try:
        fixed_levels = {float(k): float(v) for k, v in raw_levels.items()}
    except (TypeError, ValueError) as exc:
        raise ValueError("fib_levels keys and values must be numeric") from exc
    allowed_ratios = {0.0, .236, .382, .5, .618, .786, 1.0}
    if set(fixed_levels) - allowed_ratios:
        raise ValueError("fib_levels contains an unsupported ratio")
    if not all(math.isfinite(value) for value in fixed_levels.values()):
        raise ValueError("fib_levels values must be finite")
    tolerance = max(.01, (high - low) * .001)
    for ratio, level in fixed_levels.items():
        expected = high - (high - low) * ratio
        if abs(level - expected) > tolerance:
            raise ValueError("fib_levels must agree with fib_high and fib_low")
    limits = _checked_limits(config, "y_limits", values + [high, low] + list(fixed_levels.values()))
    left, top, right, bottom = box
    for index in range(7):
        yy = round(top + index * (bottom-top)/6); value = limits[1] - index*(limits[1]-limits[0])/6
        draw.line((left, yy, right, yy), fill=(140,155,175,70), width=1)
        tick = _fmt(value)
        tick_font = _fit_font(draw, tick, font(17), panel[2] - right - 18)
        draw.text((right + 12, yy - 11), tick, font=tick_font, fill=WHITE)
    draw.line((left,top,left,bottom,right,bottom,right,top), fill=WHITE, width=2)
    price_points, step, y = _draw_price_bars(draw, values, box, limits)
    ratios = ((0, WHITE), (.236, RED), (.382, (255, 139, 40, 255)), (.5, GOLD), (.618, (255, 215, 45, 255)), (.786, (130, 210, 65, 255)), (1, WHITE))
    level_positions = [y(fixed_levels.get(ratio, high - (high - low) * ratio)) for ratio, _ in ratios]
    minimum_spacing = max(4, round((box[3] - box[1]) * .025))
    if any(abs(first - second) < minimum_spacing for first, second in zip(level_positions, level_positions[1:])):
        raise ValueError("y_limits compress Fibonacci levels below readable spacing")
    for ratio, color in ratios:
        level = fixed_levels.get(ratio, high - (high - low) * ratio); yy = y(level)
        if ratio == .618:
            draw.rectangle((box[0], yy - 14, box[2], yy + 14), fill=(232, 190, 82, 45))
        draw.line((box[0], yy, box[2], yy), fill=color, width=2)
        prefix = "0 (高点)" if ratio == 0 else "1 (低点)" if ratio == 1 else f"{ratio:.3f}"
        draw.text((panel[0] + 32, yy - 14), f"{prefix}  {level:.2f}", font=font(18, True), fill=color)
    low_index, high_index = config.get("fib_low_index"), config.get("fib_high_index")
    if low_index is not None or high_index is not None:
        if any(isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < len(values) for index in (low_index, high_index)):
            raise ValueError("fib_low_index and fib_high_index must select existing price_points")
        if low_index == high_index:
            raise ValueError("fib_low_index and fib_high_index must be different")
        draw.line((price_points[low_index][0], y(low), price_points[high_index][0], y(high)), fill=WHITE, width=2)
    annotations = config.get("annotations", [])
    if not isinstance(annotations, list) or len(annotations) > 1:
        raise ValueError("kline_fibonacci supports at most one annotation")
    if annotations and str(annotations[0].get("text", "")).strip():
        text = str(annotations[0]["text"]).strip()
        support_y = y(fixed_levels.get(.618, high-(high-low)*.618))
        below = support_y + 86 <= panel[3] - 16
        note_top = support_y + 30 if below else max(panel[1] + 16, support_y - 86)
        note = (box[2] - 300, note_top, box[2] - 35, note_top + 56)
        note_font = _fit_font(draw, text, font(21, True), 225)
        bounds = draw.textbbox((0, 0), text, font=note_font)
        draw.rounded_rectangle(note, radius=8, fill=(6, 19, 34, 245), outline=GOLD, width=2)
        draw.text(((note[0] + note[2] - bounds[2]) / 2, note_top + 13), text, font=note_font, fill=GOLD)
        arrow_x = box[2]-165
        arrow_start = note_top if below else note_top + 56
        draw.line((arrow_x, arrow_start, arrow_x, support_y + (5 if below else -5)), fill=GOLD, width=5)
        direction = 1 if below else -1
        draw.polygon(((arrow_x, support_y), (arrow_x - 12, support_y + 16 * direction), (arrow_x + 12, support_y + 16 * direction)), fill=GOLD)
    _labels(draw, labels, box, safe=(panel[0] + 16, panel[2] - 16))


def render(config: dict, output_dir: Path, size=PAGE_SIZE) -> Path:
    kind = config.get("chart_kind")
    if kind not in CHART_KINDS:
        raise ValueError(f"chart_kind must be one of {sorted(CHART_KINDS)}")
    approved_reference_path(kind, config.get("reference_template"), config.get("reference_template_path"))
    if not all(str(config.get(key, "")).strip() for key in ("data_metric", "data_interval")):
        raise ValueError("data_metric and data_interval are required")
    image, draw, panel = _base(config, size)
    _header(draw, panel, str(config.get("title") or DEFAULT_TITLES[kind]))
    if kind in {"futures_position", "grouped_comparison"}:
        _positions(draw, config, panel, kind)
    elif kind in {"relative_return", "dual_axis_trend"}:
        _line_chart(draw, config, panel, kind)
    elif kind == "kline_wave":
        _kline_wave(draw, config, panel)
    else:
        _kline_fibonacci(draw, config, panel)
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"{safe_name(str(config.get('id') or kind))}.png"
    image.save(output)
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--width", type=int, default=1080)
    parser.add_argument("--height", type=int, default=830)
    args = parser.parse_args()
    print(render(json.loads(Path(args.config).read_text(encoding="utf-8-sig")), Path(args.output_dir), (args.width, args.height)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
