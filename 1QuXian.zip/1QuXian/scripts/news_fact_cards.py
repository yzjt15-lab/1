#!/usr/bin/env python3
"""Maintain a local cache of evidence-backed news fact cards."""
from __future__ import annotations

import argparse
from datetime import date
from fnmatch import fnmatchcase
from pathlib import Path
from urllib.parse import urlparse

from speed_common import load_json, write_json


REQUIRED = ("id", "source_text", "published_at", "keywords", "claims")
DEFAULT_TRUSTED_SOURCES = Path(__file__).resolve().parents[1] / "assets" / "templates" / "trusted-news-sources.json"


def empty_cache() -> dict:
    return {"version": 1, "kind": "news-fact-card-cache", "cards": []}


def load_cache(path: Path) -> dict:
    raw = load_json(path, empty_cache())
    return raw if isinstance(raw, dict) else empty_cache()


def load_trusted_domains(path: Path | None) -> list[str]:
    if path is None:
        return []
    raw = load_json(path, {})
    return [str(domain).casefold() for source in raw.get("sources", []) for domain in source.get("domains", [])]


def is_trusted_url(url: str, trusted_domains: list[str]) -> bool:
    host = (urlparse(url).hostname or "").casefold()
    return any(
        fnmatchcase(host, pattern) if "*" in pattern else host == pattern or host.endswith("." + pattern)
        for pattern in trusted_domains
    )


def validate_card(
    card: dict,
    max_age_days: int | None = None,
    trusted_domains: list[str] | None = None,
) -> list[str]:
    errors = []
    for key in REQUIRED:
        if not card.get(key):
            errors.append(f"missing {key}")
    if card.get("source_url") and urlparse(str(card["source_url"])).scheme not in {"http", "https"}:
        errors.append("source_url must be http(s)")
    elif card.get("source_url") and trusted_domains and not is_trusted_url(str(card["source_url"]), trusted_domains):
        errors.append("source_url domain is not in trusted sources")
    if card.get("published_at"):
        try:
            age = (date.today() - date.fromisoformat(str(card["published_at"]))).days
            if max_age_days is not None and age > max_age_days:
                errors.append(f"stale by {age - max_age_days} days")
        except ValueError:
            errors.append("published_at must use YYYY-MM-DD")
    return errors


def validate_cache(
    cache: dict,
    max_age_days: int | None = None,
    trusted_domains: list[str] | None = None,
) -> list[str]:
    errors = []
    seen = set()
    for index, card in enumerate(cache.get("cards", []), start=1):
        identifier = card.get("id")
        if identifier in seen:
            errors.append(f"card {index}: duplicate id {identifier}")
        seen.add(identifier)
        errors.extend(f"card {identifier or index}: {error}" for error in validate_card(card, max_age_days, trusted_domains))
    return errors


def add_card(cache: dict, card: dict, trusted_domains: list[str] | None = None) -> dict:
    errors = validate_card(card, trusted_domains=trusted_domains)
    if errors:
        raise ValueError("; ".join(errors))
    cards = [item for item in cache.get("cards", []) if item.get("id") != card["id"]]
    cards.append(card)
    cache["cards"] = sorted(cards, key=lambda item: (item["published_at"], item["id"]), reverse=True)
    return cache


def search_cards(
    cache: dict,
    keywords: list[str],
    max_age_days: int | None = None,
    trusted_domains: list[str] | None = None,
) -> list[dict]:
    wanted = [word.casefold() for word in keywords if word.strip()]
    ranked = []
    for card in cache.get("cards", []):
        if validate_card(card, max_age_days, trusted_domains):
            continue
        haystack = " ".join([card["source_text"], *card["keywords"], *card["claims"]]).casefold()
        score = sum(word in haystack for word in wanted)
        if score:
            ranked.append((score, card["published_at"], card))
    ranked.sort(key=lambda row: (-row[0], row[1]), reverse=False)
    return [row[2] for row in ranked]


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--cache", required=True)
    add = sub.add_parser("add")
    add.add_argument("--cache", required=True)
    add.add_argument("--id", required=True)
    add.add_argument("--source-text", required=True)
    add.add_argument("--published-at", required=True)
    add.add_argument("--source-url")
    add.add_argument("--publisher")
    add.add_argument("--keyword", action="append", required=True)
    add.add_argument("--claim", action="append", required=True)
    add.add_argument("--screenshot-path")
    add.add_argument("--trusted-sources", default=str(DEFAULT_TRUSTED_SOURCES))
    check = sub.add_parser("validate")
    check.add_argument("--cache", required=True)
    check.add_argument("--max-age-days", type=int)
    check.add_argument("--trusted-sources", default=str(DEFAULT_TRUSTED_SOURCES))
    search = sub.add_parser("search")
    search.add_argument("--cache", required=True)
    search.add_argument("--keyword", action="append", required=True)
    search.add_argument("--max-age-days", type=int)
    search.add_argument("--trusted-sources", default=str(DEFAULT_TRUSTED_SOURCES))
    search.add_argument("--output")
    args = parser.parse_args()
    path = Path(args.cache)
    if args.command == "init":
        if not path.exists():
            write_json(path, empty_cache())
        print(path)
        return 0
    cache = load_cache(path)
    if args.command == "add":
        card = {"id": args.id, "source_text": args.source_text, "published_at": args.published_at, "source_url": args.source_url,
                "publisher": args.publisher, "keywords": args.keyword, "claims": args.claim}
        if args.screenshot_path:
            card["screenshot_path"] = args.screenshot_path
        write_json(path, add_card(cache, card, load_trusted_domains(Path(args.trusted_sources))))
        print(path)
        return 0
    if args.command == "validate":
        errors = validate_cache(cache, args.max_age_days, load_trusted_domains(Path(args.trusted_sources)))
        write_json(path.with_suffix(path.suffix + ".validation.json"), {"errors": errors, "card_count": len(cache.get("cards", []))})
        if errors:
            print("\n".join(errors))
            return 2
        print(path)
        return 0
    result = {
        "keywords": args.keyword,
        "cards": search_cards(cache, args.keyword, args.max_age_days, load_trusted_domains(Path(args.trusted_sources))),
    }
    if args.output:
        write_json(Path(args.output), result)
    else:
        import json
        print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
