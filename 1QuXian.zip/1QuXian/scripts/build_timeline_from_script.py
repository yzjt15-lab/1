#!/usr/bin/env python3
"""Build a final asset-bound timeline from copy, audio, and one research result."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from pathlib import Path

from page_reference_contract import PAGE_REFERENCE_FILENAMES
from render_overlay_templates import render_hook_frames
from speed_common import resolve_duration, write_json


BREAK_RE = re.compile(r"(?<=[。！？!?；;])\s*|\n+")
CLAUSE_RE = re.compile(r"[，,。！？!?；;：:]\s*")


def semantic_split(script: str) -> list[str]:
    return [part.strip() for part in BREAK_RE.split(script.strip()) if part.strip()]


def _weight(text: str) -> int:
    return max(1, len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text)))


def _group_script(script: str, count: int) -> list[str]:
    parts = semantic_split(script)
    if not parts:
        raise ValueError("script is empty")
    while len(parts) < count:
        index = max(range(len(parts)), key=lambda i: len(parts[i]))
        text = parts[index]
        middle = max(1, len(text) // 2)
        parts[index:index + 1] = [text[:middle].strip(), text[middle:].strip()]
    return ["".join(parts[round(index * len(parts) / count):round((index + 1) * len(parts) / count)]) for index in range(count)]


def _chapter_durations(texts: list[str], total: float) -> list[float]:
    if total < len(texts) * 2:
        raise ValueError("audio is too short for the research query count")
    weights = [_weight(text) for text in texts]
    remaining = total - len(texts) * 2
    values = [2 + remaining * weight / sum(weights) for weight in weights]
    values[-1] += total - sum(values)
    return values


def _hook_lines(script: str) -> list[str]:
    clauses = [part.strip() for part in CLAUSE_RE.split(script) if part.strip()]
    return [(part[:18] if len(part) > 18 else part) for part in clauses[:3]]


def _candidate_id(candidate: dict) -> str:
    return str(candidate.get("asset_id") or candidate.get("id") or "")


def build_production_timeline(
    script_path: Path,
    audio_path: Path,
    research_path: Path,
    page_dir: Path,
    project_dir: Path,
    overlays_path: Path | None = None,
) -> dict:
    script = script_path.read_text(encoding="utf-8").strip()
    duration = resolve_duration(None, audio_path)
    if duration < 4:
        raise ValueError("audio must be at least 4 seconds")
    research = json.loads(research_path.read_text(encoding="utf-8-sig"))
    query_results = [item for item in research.get("eligible_visual_candidates", {}).get("queries", []) if item.get("candidates")]
    if not query_results:
        raise ValueError("research result has no query groups")
    chapter_count = min(len(query_results), max(1, math.floor(duration / 2)))
    query_results = query_results[:chapter_count]
    texts = _group_script(script, chapter_count)
    chapter_durations = _chapter_durations(texts, duration)

    chapters, shots, assets = [], [], []
    used, global_candidates, global_ids = set(), [], set()
    for query_result in query_results:
        for candidate in query_result.get("candidates", []):
            asset_id = _candidate_id(candidate)
            if asset_id and asset_id not in global_ids:
                global_ids.add(asset_id)
                global_candidates.append(candidate)

    cursor, shot_number = 0.0, 0
    audit = research.get("dedupe_audit") or {}
    for chapter_index, (text, chapter_duration, query_result) in enumerate(zip(texts, chapter_durations, query_results), 1):
        chapter_start = round(cursor, 6)
        chapter_end = duration if chapter_index == chapter_count else round(cursor + chapter_duration, 6)
        chapter_id = f"c{chapter_index:02d}"
        chapters.append({"id": chapter_id, "start": chapter_start, "end": chapter_end, "thesis": text})
        shot_count = math.ceil((chapter_end - chapter_start) / 5)
        shot_duration = (chapter_end - chapter_start) / shot_count
        local_candidates = query_result.get("candidates", [])
        for local_index in range(shot_count):
            candidate = next((item for item in local_candidates if _candidate_id(item) not in used), None)
            candidate = candidate or next((item for item in global_candidates if _candidate_id(item) not in used), None)
            if candidate is None:
                raise ValueError(f"not enough unique reviewed candidates; need at least {shot_number + 1}")
            asset_id = _candidate_id(candidate)
            used.add(asset_id)
            shot_number += 1
            start = chapter_start + local_index * shot_duration
            end = chapter_end if local_index == shot_count - 1 else chapter_start + (local_index + 1) * shot_duration
            source_in = float(candidate.get("source_in", 0))
            reviewed_out = float(candidate.get("source_out", source_in + 5))
            source_out = source_in + (end - start)
            if source_out > reviewed_out + 0.001:
                raise ValueError(f"candidate {asset_id} reviewed range is shorter than the shot")
            semantic_fields = {key: candidate.get(key) for key in ("subject", "action", "location", "equipment", "keywords")}
            shots.append({
                "id": f"s{shot_number:02d}", "asset_id": asset_id, "chapter_id": chapter_id,
                "start": round(start, 6), "end": round(end, 6),
                "source_in": round(source_in, 6), "source_out": round(source_out, 6),
                "script_range": {"start": chapter_start, "end": chapter_end},
                "timing_audio_range": {"start": round(start, 6), "end": round(end, 6)},
                "information_task": "broll", "selection_mode": "semantic_index",
                "candidate_asset_ids": [asset_id],
                "selection_reason": f"批量联系表A/M/B显示{candidate.get('subject')}与本章语义直接对应。",
                "keyword": str(query_result.get("query") or text)[:40],
                "subject": candidate.get("subject"), "action": candidate.get("action"),
                "result": "承接本章市场判断", "semantic_fields": semantic_fields,
            })
            eligible = candidate.get("seven_day_eligible") is True
            assets.append({
                "id": asset_id, "local_path": candidate.get("path"),
                "sha256": candidate.get("sha256"), "quick_hash": candidate.get("quick_hash"),
                "watermark_free": candidate.get("watermark_free") is True,
                "embedded_subtitles_free": candidate.get("embedded_subtitles_free") is True,
                "platform_overlay_free": candidate.get("platform_overlay_free") is True,
                "cleanliness_checked_at": candidate.get("cleanliness_checked_at") or audit.get("checked_at"),
                "cleanliness_evidence": candidate.get("cleanliness_evidence") or "批量联系表A/M/B已复核",
                "seven_day_eligible": eligible, "dedupe_clear": eligible,
                "dedupe_checked_at": audit.get("checked_at"),
            })
        cursor = chapter_end

    hook_config = {
        "id": "hook-01", "type": "hook", "role": "hook",
        "chinese_text": "\n".join(_hook_lines(script)),
        "reference_template": PAGE_REFERENCE_FILENAMES["hook"],
        "hook_text_colors": {"thesis": {"color": "#F2C86B", "opacity": 1.0}, "judgment": {"color": "#F8F9FB", "opacity": 0.95}, "evidence": {"color": "#C6CCD3", "opacity": 0.8}},
        "hook_contrast": {"thesis": {"background_luminance": 0.02, "contrast_ratio": 12.8}, "judgment": {"background_luminance": 0.02, "contrast_ratio": 18.0}, "evidence": {"background_luminance": 0.02, "contrast_ratio": 11.9}},
    }
    stable, pattern = render_hook_frames(hook_config, page_dir)
    overlays = [{
        **hook_config, "start": 0.0, "end": 4.0, "chapter_id": "c01",
        "background_shot_id": "s01", "image_path": str(stable.resolve()), "frame_pattern": pattern,
    }]
    if overlays_path:
        payload = json.loads(overlays_path.read_text(encoding="utf-8-sig"))
        overlays.extend(payload.get("overlays", []) if isinstance(payload, dict) else payload)

    return {
        "script_path": str(script_path.resolve()), "project_path": str(project_dir.resolve()),
        "duration_seconds": float(duration), "audio_delivery_mode": "silent",
        "timing_audio_path": str(audio_path.resolve()),
        "timing_audio_segments": [{"start": item["start"], "end": item["end"], "text": item["thesis"]} for item in chapters],
        "selection_manifest_path": str(research_path.resolve()),
        "selection_manifest_sha256": hashlib.sha256(research_path.read_bytes()).hexdigest(),
        "dedupe_audit": audit, "candidate_contact_sheet": research.get("candidate_contact_sheet"),
        "chapters": chapters, "assets": assets, "shots": shots, "overlays": overlays,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--script", required=True)
    parser.add_argument("--audio", required=True)
    parser.add_argument("--research", required=True)
    parser.add_argument("--page-dir", required=True)
    parser.add_argument("--project-dir", required=True)
    parser.add_argument("--overlays")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    timeline = build_production_timeline(
        Path(args.script), Path(args.audio), Path(args.research), Path(args.page_dir),
        Path(args.project_dir), Path(args.overlays) if args.overlays else None,
    )
    write_json(Path(args.output), timeline)
    print(json.dumps({"output": str(Path(args.output).resolve()), "shots": len(timeline["shots"]), "overlays": len(timeline["overlays"])}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
