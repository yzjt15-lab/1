#!/usr/bin/env python3
"""Create an exact-duration semantic timeline skeleton from Chinese copy."""
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

from speed_common import write_json


BREAK_RE = re.compile(r"(?<=[。！？!?；;])\s*|\n+")


def semantic_split(script: str) -> list[str]:
    return [part.strip() for part in BREAK_RE.split(script.strip()) if part.strip()]


def _weight(text: str) -> int:
    chars = len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text))
    numbers = len(re.findall(r"\d+(?:\.\d+)?%?", text))
    return max(1, chars + numbers * 2)


def _split_longest(parts: list[str]) -> None:
    index = max(range(len(parts)), key=lambda i: len(parts[i]))
    text = parts[index]
    middle = max(1, len(text) // 2)
    parts[index:index + 1] = [text[:middle].strip(), text[middle:].strip()]


def _fit_parts(parts: list[str], count: int) -> list[str]:
    fitted = list(parts)
    while len(fitted) < count:
        _split_longest(fitted)
    while len(fitted) > count:
        index = min(range(len(fitted) - 1), key=lambda i: len(fitted[i]) + len(fitted[i + 1]))
        fitted[index:index + 2] = [fitted[index] + fitted[index + 1]]
    return fitted


def _allocate(weights: list[int], total: float, maximum: float = 5.0) -> list[float]:
    remaining = set(range(len(weights)))
    values = [0.0] * len(weights)
    remaining_total = total
    while remaining:
        weight_total = sum(weights[index] for index in remaining)
        capped = [index for index in remaining if remaining_total * weights[index] / weight_total > maximum]
        if not capped:
            for index in remaining:
                values[index] = remaining_total * weights[index] / weight_total
            break
        for index in capped:
            values[index] = maximum
            remaining_total -= maximum
            remaining.remove(index)
    return values


def build_timeline(title: str, script: str, duration: float, script_path: str, structure_template: dict | None = None) -> dict:
    if duration <= 0:
        raise ValueError("duration must be > 0")
    parts = semantic_split(script)
    if not parts:
        raise ValueError("script is empty")
    slots = None
    if structure_template:
        minimum, maximum = structure_template.get("allowed_duration_range", [duration, duration])
        if not float(minimum) <= duration <= float(maximum):
            raise ValueError(f"duration {duration} outside structure template range {minimum}-{maximum}")
        slots = structure_template.get("slots", [])
        if not slots:
            raise ValueError("structure template has no slots")
        parts = _fit_parts(parts, len(slots))
        base_duration = float(structure_template.get("base_duration_seconds") or sum(float(slot["duration"]) for slot in slots))
        durations = [float(slot["duration"]) * duration / base_duration for slot in slots]
        durations[-1] += duration - sum(durations)
        if any(value > 5.0 + 0.001 for value in durations):
            raise ValueError("structure template creates a shot longer than 5 seconds")
    else:
        minimum_count = math.ceil(duration / 5.0)
        while len(parts) < minimum_count:
            _split_longest(parts)
        durations = _allocate([_weight(part) for part in parts], float(duration))
    shots = []
    cursor = 0.0
    for index, (text, shot_duration) in enumerate(zip(parts, durations), start=1):
        end = float(duration) if index == len(parts) else round(cursor + shot_duration, 3)
        keyword = "".join(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]+", text))[:12] or "待提取"
        shot = {
            "id": f"s{index:02d}", "start": round(cursor, 3), "end": end,
            "chapter_id": f"c{index:02d}",
            "script": text, "keyword": keyword, "subject": keyword,
            "action": "待语义确认", "result": "待语义确认", "asset_id": f"pending-s{index:02d}",
            "news_id": None, "overlay_id": None, "visual": "待匹配真实视频",
        }
        if slots:
            shot["slot_role"] = slots[index - 1].get("role")
            shot["overlay_hint"] = slots[index - 1].get("overlay_hint")
        shots.append(shot)
        cursor = end
    chapters = [
        {
            "id": shot["chapter_id"], "start": shot["start"], "end": shot["end"], "thesis": shot["script"],
            "information_plan": [{"id": f"evidence-{shot['chapter_id']}", "task": "broll", "reason": "初始化后必须按文案补全信息任务或保留为纯实拍过渡", "script_range": {"start": shot["start"], "end": shot["end"]}}],
        }
        for shot in shots
    ]
    chart_inventory = [
        {"chart_kind": kind, "status": "pending"}
        for kind in ("relative_return", "futures_position", "dual_axis_trend", "kline_wave", "kline_fibonacci")
    ]
    return {
        "title": title, "script_path": script_path, "duration_seconds": float(duration),
        "audio_delivery_mode": "pending_confirmation", "audio_path": None, "chapters": chapters, "shots": shots, "assets": [],
        "news": [], "overlays": [], "chart_inventory": chart_inventory,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--script", required=True)
    parser.add_argument("--duration", type=float, required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--structure-template")
    args = parser.parse_args()
    script_path = Path(args.script)
    template = json.loads(Path(args.structure_template).read_text(encoding="utf-8")) if args.structure_template else None
    timeline = build_timeline(args.title, script_path.read_text(encoding="utf-8"), args.duration, str(script_path.resolve()), template)
    write_json(Path(args.output), timeline)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
