#!/usr/bin/env python3
"""Create or reuse a content-addressed 720p editing proxy."""
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from speed_common import content_key, file_signature, find_ffmpeg


def prepare_proxy(source: Path, cache_dir: Path, ffmpeg: str | None = None) -> Path:
    params = {"width": 1280, "height": 720, "fps": 30, "codec": "libx264", "preset": "ultrafast", "crf": 28}
    key = content_key({"source": file_signature(source), "params": params}, 20)
    output = cache_dir / f"proxy_{key}.mp4"
    if output.exists():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    command = [find_ffmpeg(ffmpeg), "-y", "-i", str(source), "-map", "0:v:0", "-an", "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2", "-r", "30", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-pix_fmt", "yuv420p", str(output)]
    subprocess.run(command, check=True)
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--ffmpeg")
    args = parser.parse_args()
    print(prepare_proxy(Path(args.source), Path(args.cache_dir), args.ffmpeg))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

