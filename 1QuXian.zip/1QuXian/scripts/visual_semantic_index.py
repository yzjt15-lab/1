#!/usr/bin/env python3
"""Build and query an incremental Chinese video-frame semantic index."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import subprocess
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path

import numpy as np

from speed_common import content_key, find_ffmpeg, load_json
from workflow_metrics import end_stage, start_stage

SEMANTIC_INDEX_API_VERSION = 1


DEFAULT_MODEL_ID = "OFA-Sys/chinese-clip-vit-base-patch16"
MAX_UNINDEXED_INCREMENTAL_ASSETS = 12
SEARCH_TEXT_RE = re.compile(r"[A-Za-z0-9]+|[\u4e00-\u9fff]{2,}")
GENERIC_SEARCH_TERMS = {"市场", "财经", "金融", "视频", "素材", "画面", "数据", "科技", "行业", "公司"}


def normalized_category(value: object) -> str:
    text = str(value or "").strip().casefold()
    head, separator, tail = text.partition(". ")
    return tail if separator and head.isdigit() else text


def metadata_text(asset: dict) -> str:
    """Keep filename and library labels available to ranking without inventing tags."""
    values = [
        asset.get("path", ""), asset.get("primary_category", ""), asset.get("source_description", ""),
        asset.get("subject", ""), asset.get("action", ""), asset.get("location", ""), asset.get("equipment", ""),
    ]
    values.extend(asset.get("keywords") or [])
    return " ".join(str(value) for value in values if value)


def lexical_terms(value: str) -> set[str]:
    terms: set[str] = set()
    for token in SEARCH_TEXT_RE.findall(str(value).casefold()):
        if token.isascii():
            if len(token) >= 2:
                terms.add(token)
        else:
            terms.update(token[index:index + 2] for index in range(len(token) - 1))
    return terms - GENERIC_SEARCH_TERMS


def metadata_score(query: str, row: dict) -> float:
    wanted = lexical_terms(query)
    if not wanted:
        return 0.0
    available = lexical_terms(str(row.get("metadata_text") or row.get("path", "")))
    return round(len(wanted & available) / len(wanted), 6)


def sample_times(duration: float, interval: float = 3.0, max_samples: int = 24) -> list[float]:
    if duration <= 0 or interval <= 0 or max_samples <= 0:
        return []
    count = min(max_samples, max(1, math.ceil(duration / interval)))
    width = duration / count
    return [round((index + 0.5) * width, 3) for index in range(count)]


def can_reuse(previous: dict | None, asset: dict, model_id: str) -> bool:
    if not previous:
        return False
    return (
        str(previous.get("path", "")).casefold() == str(asset.get("path", "")).casefold()
        and previous.get("size") == asset.get("size")
        and previous.get("mtime_ns") == asset.get("mtime_ns")
        and previous.get("model_id") == model_id
    )


def failures_for_asset(failures: list[dict], path: str) -> list[dict]:
    wanted = str(path).casefold()
    return [item for item in failures if str(item.get("path", "")).casefold() == wanted]


def refresh_provenance(row: dict, asset: dict) -> dict:
    refreshed = dict(row)
    for key in ("source_type", "source_url", "publisher", "source_description", "primary_category", "quick_hash", "library_asset_id"):
        refreshed[key] = asset.get(key)
    refreshed["provenance_complete"] = _provenance_complete(asset)
    refreshed["metadata_text"] = metadata_text(asset)
    return refreshed


def _provenance_complete(asset: dict) -> bool:
    if asset.get("source_type") == "local_library":
        return all(asset.get(key) for key in ("library_asset_id", "quick_hash", "primary_category"))
    return all(asset.get(key) for key in ("source_url", "publisher", "source_description"))


def clip_range(timestamp: float, duration: float, clip_duration: float = 5.0) -> tuple[float, float]:
    if duration <= 0:
        return 0.0, 0.0
    length = min(float(clip_duration), float(duration))
    start = max(0.0, min(float(timestamp) - length / 2, float(duration) - length))
    return round(start, 3), round(start + length, 3)


def _normalized(vector: np.ndarray) -> np.ndarray:
    vector = np.asarray(vector, dtype=np.float32)
    norm = float(np.linalg.norm(vector))
    return vector if norm == 0 else vector / norm


def rank_embeddings(
    matrix: np.ndarray,
    query: np.ndarray,
    rows: list[dict],
    top_k: int = 8,
    clip_duration: float = 5.0,
    provenance_only: bool = False,
    allowed_categories: set[str] | None = None,
    query_text: str = "",
) -> list[dict]:
    if matrix.ndim != 2 or len(rows) != matrix.shape[0]:
        raise ValueError("embedding matrix and metadata row count differ")
    if not len(rows):
        return []
    scores = matrix @ _normalized(query)
    lexical = np.asarray([metadata_score(query_text, row) for row in rows], dtype=np.float32)
    combined = scores + 0.25 * lexical
    order = np.argsort(-combined)
    results = []
    seen_assets = set()
    for index in order:
        row = rows[int(index)]
        if allowed_categories and normalized_category(row.get("primary_category")) not in allowed_categories:
            continue
        if float(row.get("duration", 0)) + 0.001 < clip_duration:
            continue
        if provenance_only and not row.get("provenance_complete"):
            continue
        identity = row.get("asset_id") or row.get("path")
        if identity in seen_assets:
            continue
        seen_assets.add(identity)
        start, end = clip_range(float(row["timestamp"]), float(row["duration"]), clip_duration)
        results.append({**row, "source_in": start, "source_out": end, "score": round(float(combined[index]), 6), "visual_score": round(float(scores[index]), 6), "metadata_score": round(float(lexical[index]), 6), "needs_visual_review": bool(query_text and lexical[index] < 0.5)})
        if len(results) >= top_k:
            break
    return results


def _atomic_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def _atomic_npy(path: Path, matrix: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    with temporary.open("wb") as handle:
        np.save(handle, matrix)
    os.replace(temporary, path)


@contextmanager
def _cache_write_lock(cache_path: Path):
    lock_path = cache_path.with_suffix(cache_path.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def extract_thumbnail(video_path: Path, timestamp: float, destination: Path) -> Path:
    if destination.exists():
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [find_ffmpeg(), "-y", "-ss", f"{timestamp:.3f}", "-i", str(video_path), "-frames:v", "1", "-vf", "scale=384:-2", str(destination)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if result.returncode or not destination.exists():
        raise RuntimeError(result.stderr.strip()[-500:] or "no decodable frame")
    return destination


def _feature_tensor(value):
    return value.pooler_output if hasattr(value, "pooler_output") else value


class ChineseClipEmbedder:
    def __init__(self, model_id: str = DEFAULT_MODEL_ID, device: str = "auto", allow_network: bool = False):
        import torch
        from transformers import AutoProcessor, ChineseCLIPModel

        self.torch = torch
        self.device = "cuda" if device == "auto" and torch.cuda.is_available() else ("cpu" if device == "auto" else device)
        try:
            self.processor = AutoProcessor.from_pretrained(model_id, local_files_only=not allow_network)
            self.model = ChineseCLIPModel.from_pretrained(model_id, local_files_only=not allow_network).eval().to(self.device)
        except OSError as exc:
            raise RuntimeError("Chinese-CLIP is not cached locally; rerun explicitly with --allow-network") from exc
        self.model_id = model_id

    def encode_images(self, paths: list[Path], batch_size: int = 32) -> np.ndarray:
        from PIL import Image

        chunks = []
        for start in range(0, len(paths), batch_size):
            images = []
            for path in paths[start:start + batch_size]:
                with Image.open(path) as image:
                    images.append(image.convert("RGB").copy())
            inputs = self.processor(images=images, return_tensors="pt")
            inputs = {key: value.to(self.device) for key, value in inputs.items()}
            with self.torch.inference_mode():
                features = _feature_tensor(self.model.get_image_features(**inputs))
                features = features / features.norm(p=2, dim=-1, keepdim=True)
            chunks.append(features.detach().cpu().float().numpy())
        return np.concatenate(chunks, axis=0) if chunks else np.empty((0, 0), dtype=np.float32)

    def encode_text(self, text: str) -> np.ndarray:
        return self.encode_texts([text])[0]

    def encode_texts(self, texts: list[str]) -> np.ndarray:
        inputs = self.processor(text=texts, padding=True, return_tensors="pt")
        inputs = {key: value.to(self.device) for key, value in inputs.items()}
        with self.torch.inference_mode():
            features = _feature_tensor(self.model.get_text_features(**inputs))
            features = features / features.norm(p=2, dim=-1, keepdim=True)
        return features.detach().cpu().float().numpy()


def _build_index(
    asset_index_path: Path,
    output_dir: Path,
    model_id: str = DEFAULT_MODEL_ID,
    interval: float = 3.0,
    max_samples: int = 24,
    batch_size: int = 32,
    limit: int | None = None,
    selected_paths: set[str] | None = None,
    device: str = "auto",
    workers: int = 6,
    allow_network: bool = False,
    full_rebuild: bool = False,
) -> dict:
    started = time.perf_counter()
    source = load_json(asset_index_path, None)
    if source is None:
        raise FileNotFoundError(f"asset index not found: {asset_index_path}")
    assets = [item for item in source.get("assets", []) if item.get("probe_ok") and item.get("duration")]
    if limit is not None:
        assets = assets[:limit]

    manifest_path = output_dir / "manifest.json"
    matrix_path = output_dir / "embeddings.npy"
    old = load_json(manifest_path, {})
    old_matrix = np.load(matrix_path) if matrix_path.exists() and old.get("model_id") == model_id else None
    old_assets = {str(Path(item["path"]).resolve()).casefold(): item for item in old.get("assets", [])}
    old_exclusions = {
        str(Path(item["path"]).resolve()).casefold(): item
        for item in old.get("excluded_assets", [])
        if item.get("path")
    }
    old_rows = old.get("rows", [])
    selected_keys = None
    if selected_paths:
        selected_keys = {str(Path(value).resolve()).casefold() for value in selected_paths}
        indexed_keys = {str(Path(item["path"]).resolve()).casefold() for item in assets}
        missing = selected_keys - indexed_keys
        if missing:
            raise ValueError("selected incremental paths are missing from the asset index: " + ", ".join(sorted(missing)))
    source_keys = {str(Path(item["path"]).resolve()).casefold() for item in assets}
    unindexed_keys = source_keys - set(old_assets)
    if len(unindexed_keys) > MAX_UNINDEXED_INCREMENTAL_ASSETS and not full_rebuild:
        raise RuntimeError(f"{len(unindexed_keys)} assets are unindexed; pass --full-rebuild instead of starting an unbounded rebuild")
    if not old_assets and not full_rebuild:
        raise RuntimeError("semantic index is missing; run one explicit maintenance build with --full-rebuild")
    if selected_keys is not None:
        missing_base = unindexed_keys - selected_keys
        if missing_base and not full_rebuild:
            raise RuntimeError("semantic index is incomplete outside --path; restore it or run an explicit --full-rebuild")

    rows: list[dict] = []
    vectors: list[np.ndarray] = []
    asset_records: list[dict] = []
    new_jobs: list[tuple[int, Path]] = []
    extraction_jobs: list[tuple[int, Path, float, Path]] = []
    excluded_assets: list[dict] = []
    extraction_failures: list[dict] = []
    reused_assets = 0

    for position, asset in enumerate(assets, start=1):
        path = Path(asset["path"])
        path_key = str(path.resolve()).casefold()
        previous = old_assets.get(path_key)
        preserve_untargeted = selected_keys is not None and path_key not in selected_keys
        if preserve_untargeted and previous is None:
            continue
        record = {
            "path": str(path), "size": asset.get("size"), "mtime_ns": asset.get("mtime_ns"),
            "model_id": model_id, "row_indices": [],
        }
        previous_exclusion = old_exclusions.get(path_key)
        previous_failures = failures_for_asset(old.get("failures", []), str(path))
        was_excluded = bool(previous_exclusion or previous_failures)
        retry_selected = selected_keys is not None and path_key in selected_keys and was_excluded
        if not full_rebuild and (preserve_untargeted or (can_reuse(previous, asset, model_id) and not retry_selected)) and old_matrix is not None:
            if was_excluded:
                excluded_assets.append({
                    "asset_id": asset.get("id"), "path": str(path),
                    "size": asset.get("size"), "mtime_ns": asset.get("mtime_ns"), "model_id": model_id,
                    "reason": (previous_exclusion or {}).get("reason") or "thumbnail_extraction_failed",
                    "failures": (previous_exclusion or {}).get("failures") or previous_failures,
                })
                reused_assets += 1
                asset_records.append(record)
                continue
            for old_index in previous.get("row_indices", []):
                if 0 <= old_index < len(old_rows) and old_index < old_matrix.shape[0]:
                    record["row_indices"].append(len(rows))
                    rows.append(refresh_provenance(old_rows[old_index], asset))
                    vectors.append(old_matrix[old_index])
            reused_assets += 1
            asset_records.append(record)
            continue

        signature = asset.get("quick_hash") or content_key({"path": str(path), "size": asset.get("size"), "mtime_ns": asset.get("mtime_ns")})
        for timestamp in sample_times(float(asset["duration"]), interval, max_samples):
            thumbnail = output_dir / "thumbnails" / signature[:16] / f"{round(timestamp * 1000):010d}.jpg"
            row = {
                "asset_id": asset.get("id"),
                "path": str(path),
                "timestamp": timestamp,
                "duration": float(asset["duration"]),
                "thumbnail": str(thumbnail),
                "source_url": asset.get("source_url"),
                "publisher": asset.get("publisher"),
                "source_description": asset.get("source_description"),
                "source_type": asset.get("source_type"),
                "primary_category": asset.get("primary_category"),
                "quick_hash": asset.get("quick_hash"),
                "library_asset_id": asset.get("library_asset_id"),
                "provenance_complete": _provenance_complete(asset),
                "metadata_text": metadata_text(asset),
            }
            record["row_indices"].append(len(rows))
            rows.append(row)
            extraction_jobs.append((len(rows) - 1, path, timestamp, thumbnail))
            vectors.append(np.asarray([], dtype=np.float32))
        asset_records.append(record)
        if position % 100 == 0 or position == len(assets):
            print(f"[plan] {position}/{len(assets)} assets, {len(rows)} frames", flush=True)

    def run_extraction(job):
        row_index, path, timestamp, thumbnail = job
        try:
            extract_thumbnail(path, timestamp, thumbnail)
            return row_index, thumbnail, None
        except Exception as error:
            return row_index, thumbnail, {"path": str(path), "timestamp": timestamp, "error": str(error)}

    if extraction_jobs:
        with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
            for completed, (row_index, thumbnail, failure) in enumerate(pool.map(run_extraction, extraction_jobs), start=1):
                if failure:
                    extraction_failures.append(failure)
                else:
                    new_jobs.append((row_index, thumbnail))
                if completed % 500 == 0 or completed == len(extraction_jobs):
                    print(f"[extract] {completed}/{len(extraction_jobs)} frames, {len(extraction_failures)} failures", flush=True)

    failures_by_path: dict[str, list[dict]] = {}
    for failure in extraction_failures:
        failures_by_path.setdefault(str(Path(failure["path"]).resolve()).casefold(), []).append(failure)
    if failures_by_path:
        failed_indices = {
            index
            for record in asset_records
            if str(Path(record["path"]).resolve()).casefold() in failures_by_path
            for index in record["row_indices"]
        }
        new_jobs = [job for job in new_jobs if job[0] not in failed_indices]
        assets_by_path = {str(Path(item["path"]).resolve()).casefold(): item for item in assets}
        for record in asset_records:
            path_key = str(Path(record["path"]).resolve()).casefold()
            if path_key not in failures_by_path:
                continue
            asset = assets_by_path[path_key]
            record["row_indices"] = []
            excluded_assets.append({
                "asset_id": asset.get("id"), "path": record["path"],
                "size": record.get("size"), "mtime_ns": record.get("mtime_ns"), "model_id": model_id,
                "reason": "thumbnail_extraction_failed", "failures": failures_by_path[path_key],
            })

    if new_jobs:
        embedder = ChineseClipEmbedder(model_id, device, allow_network)
        for start in range(0, len(new_jobs), 256):
            jobs = new_jobs[start:start + 256]
            encoded = embedder.encode_images([path for _, path in jobs], batch_size)
            for (row_index, _), vector in zip(jobs, encoded):
                vectors[row_index] = vector
            print(f"[embed] {min(start + len(jobs), len(new_jobs))}/{len(new_jobs)} frames", flush=True)

    valid_indices = [index for index, vector in enumerate(vectors) if vector.size]
    rows = [rows[index] for index in valid_indices]
    matrix = np.stack([vectors[index] for index in valid_indices]).astype(np.float32) if valid_indices else np.empty((0, 0), dtype=np.float32)
    remap = {old_index: new_index for new_index, old_index in enumerate(valid_indices)}
    for record in asset_records:
        record["row_indices"] = [remap[index] for index in record["row_indices"] if index in remap]

    elapsed = round(time.perf_counter() - started, 3)
    manifest = {
        "version": 1,
        "model_id": model_id,
        "asset_index_path": str(asset_index_path.resolve()),
        "interval_seconds": interval,
        "max_samples_per_asset": max_samples,
        "asset_count": len(asset_records),
        "frame_count": len(rows),
        "reused_asset_count": reused_assets,
        "new_or_changed_asset_count": len(asset_records) - reused_assets,
        "failure_count": 0,
        "excluded_asset_count": len(excluded_assets),
        "build_elapsed_seconds": elapsed,
        "assets": asset_records,
        "rows": rows,
        "failures": [],
        "excluded_assets": excluded_assets,
    }
    _atomic_npy(matrix_path, matrix)
    _atomic_json(manifest_path, manifest)
    return manifest


def build_index(
    asset_index_path: Path,
    output_dir: Path,
    model_id: str = DEFAULT_MODEL_ID,
    interval: float = 3.0,
    max_samples: int = 24,
    batch_size: int = 32,
    limit: int | None = None,
    selected_paths: set[str] | None = None,
    device: str = "auto",
    workers: int = 6,
    allow_network: bool = False,
    metrics_path: Path | None = None,
    full_rebuild: bool = False,
) -> dict:
    if full_rebuild and metrics_path:
        raise ValueError("--full-rebuild is maintenance-only and cannot use a production metrics file")
    if metrics_path:
        start_stage(metrics_path, "semantic_index")
    try:
        result = _build_index(
            asset_index_path, output_dir, model_id, interval, max_samples, batch_size,
            limit, selected_paths, device, workers, allow_network, full_rebuild,
        )
    except Exception:
        if metrics_path:
            end_stage(metrics_path, "semantic_index", note="failed")
        raise
    if metrics_path:
        end_stage(metrics_path, "semantic_index")
    return result


def sync_metadata(asset_index_path: Path, output_dir: Path) -> dict:
    manifest_path = output_dir / "manifest.json"
    manifest = load_json(manifest_path, None)
    source = load_json(asset_index_path, None)
    if manifest is None or source is None:
        raise FileNotFoundError("semantic manifest and material index are required")
    assets = {str(Path(item["path"]).resolve()).casefold(): item for item in source.get("assets", [])}
    indexed = set()
    for row in manifest.get("rows", []):
        key = str(Path(row["path"]).resolve()).casefold()
        if key in assets:
            row.update(refresh_provenance(row, assets[key]))
            indexed.add(key)
    for excluded in manifest.get("excluded_assets", []):
        key = str(Path(excluded["path"]).resolve()).casefold()
        if key in assets:
            excluded["asset_id"] = assets[key].get("id")
            excluded["size"] = assets[key].get("size")
            excluded["mtime_ns"] = assets[key].get("mtime_ns")
            indexed.add(key)
    manifest["asset_index_path"] = str(asset_index_path.resolve())
    manifest["metadata_synced_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    manifest["unindexed_asset_count"] = len(set(assets) - indexed)
    _atomic_json(manifest_path, manifest)
    return {"indexed_asset_count": len(indexed), "unindexed_asset_count": manifest["unindexed_asset_count"]}


def _query_cache_key(query: str, top_k: int, clip_duration: float, category: str | None) -> str:
    return json.dumps({"query": query, "top_k": top_k, "clip_duration": clip_duration, "category": category, "ranker": 4}, ensure_ascii=False, sort_keys=True)


def _load_query_cache(cache_path: Path, manifest_path: Path, model_id: str) -> dict:
    manifest_sha256 = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    try:
        payload = load_json(cache_path, {})
    except (OSError, TypeError, ValueError):
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    if payload.get("manifest_sha256") != manifest_sha256 or payload.get("model_id") != model_id:
        return {"version": 2, "manifest_sha256": manifest_sha256, "model_id": model_id, "entries": {}}
    return payload if isinstance(payload.get("entries"), dict) else {"version": 2, "manifest_sha256": manifest_sha256, "model_id": model_id, "entries": {}}


def search_index(
    index_dir: Path,
    query: str,
    top_k: int = 8,
    clip_duration: float = 5.0,
    model_id: str | None = None,
    device: str = "auto",
) -> dict:
    result = search_many(index_dir, [query], top_k, clip_duration, model_id, device)
    return {"query": query, "model_id": result["model_id"], "candidates": result["queries"][0]["candidates"]}


def search_many(
    index_dir: Path,
    queries: list[str],
    top_k: int = 8,
    clip_duration: float = 5.0,
    model_id: str | None = None,
    device: str = "auto",
    embedder=None,
    categories: list[str] | None = None,
    allow_network: bool = False,
) -> dict:
    manifest = load_json(index_dir / "manifest.json", None)
    if manifest is None:
        raise FileNotFoundError(f"semantic manifest not found: {index_dir}")
    active_model = model_id or manifest["model_id"]
    if active_model != manifest["model_id"]:
        raise ValueError("query model differs from index model")
    if categories and len(categories) not in (1, len(queries)):
        raise ValueError("category count must be one or match query count")
    cache_path = index_dir / "query-cache.json"
    cache = _load_query_cache(cache_path, index_dir / "manifest.json", active_model) if embedder is None else None
    results: list[dict | None] = [None] * len(queries)
    missing: list[tuple[int, str, str | None]] = []
    for position, query in enumerate(queries):
        category = categories[0] if categories and len(categories) == 1 else (categories[position] if categories else None)
        key = _query_cache_key(query, top_k, clip_duration, category)
        cached = cache["entries"].get(key) if cache else None
        if cached:
            results[position] = cached
        else:
            missing.append((position, query, category))
    if missing:
        matrix = np.load(index_dir / "embeddings.npy")
        active_embedder = embedder or ChineseClipEmbedder(active_model, device, allow_network)
        query_vectors = active_embedder.encode_texts([query for _, query, _ in missing])
        updates = {}
        for (position, query, category), query_vector in zip(missing, query_vectors):
            allowed = {normalized_category(category)} if category else None
            candidates = rank_embeddings(matrix, query_vector, manifest["rows"], top_k, clip_duration, allowed_categories=allowed, query_text=query)
            eligible_candidates = rank_embeddings(
                matrix, query_vector, manifest["rows"], top_k, clip_duration, provenance_only=True, allowed_categories=allowed, query_text=query,
            )
            result = {"query": query, "category": category, "candidates": candidates, "eligible_candidates": eligible_candidates}
            results[position] = result
            if cache is not None:
                updates[_query_cache_key(query, top_k, clip_duration, category)] = result
        if cache is not None and updates:
            with _cache_write_lock(cache_path):
                latest = _load_query_cache(cache_path, index_dir / "manifest.json", active_model)
                latest["entries"].update(updates)
                _atomic_json(cache_path, latest)
    return {"model_id": active_model, "queries": results}


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build")
    build.add_argument("--asset-index", required=True)
    build.add_argument("--output-dir", required=True)
    build.add_argument("--model-id", default=DEFAULT_MODEL_ID)
    build.add_argument("--interval", type=float, default=3.0)
    build.add_argument("--max-samples", type=int, default=24)
    build.add_argument("--batch-size", type=int, default=32)
    build.add_argument("--limit", type=int)
    build.add_argument("--path", action="append", default=[])
    build.add_argument("--device", default="auto")
    build.add_argument("--workers", type=int, default=6)
    build.add_argument("--allow-network", action="store_true")
    build.add_argument("--metrics")
    build.add_argument("--full-rebuild", action="store_true")
    sync = sub.add_parser("sync-metadata")
    sync.add_argument("--asset-index", required=True)
    sync.add_argument("--output-dir", required=True)
    search = sub.add_parser("search")
    search.add_argument("--index-dir", required=True)
    search.add_argument("--query", action="append", required=True)
    search.add_argument("--top-k", type=int, default=8)
    search.add_argument("--clip-duration", type=float, default=5.0)
    search.add_argument("--model-id")
    search.add_argument("--device", default="auto")
    search.add_argument("--category", action="append", default=[])
    search.add_argument("--allow-network", action="store_true")
    search.add_argument("--output")
    stats = sub.add_parser("stats")
    stats.add_argument("--index-dir", required=True)
    args = parser.parse_args()

    if args.command == "build":
        if not Path(args.asset_index).is_file():
            parser.error(f"asset index not found: {args.asset_index}")
        result = build_index(
            Path(args.asset_index), Path(args.output_dir), args.model_id, args.interval,
            args.max_samples, args.batch_size, args.limit, set(args.path) or None, args.device, args.workers, args.allow_network,
            Path(args.metrics) if args.metrics else None, args.full_rebuild,
        )
    elif args.command == "sync-metadata":
        result = sync_metadata(Path(args.asset_index), Path(args.output_dir))
    elif args.command == "search":
        result = search_many(Path(args.index_dir), args.query, args.top_k, args.clip_duration, args.model_id, args.device, categories=args.category or None, allow_network=args.allow_network)
        if args.output:
            _atomic_json(Path(args.output), result)
    else:
        result = load_json(Path(args.index_dir) / "manifest.json", None)
        if result is None:
            raise FileNotFoundError("semantic manifest not found")
        result = {key: result.get(key) for key in (
            "model_id", "asset_count", "frame_count", "reused_asset_count",
            "new_or_changed_asset_count", "failure_count", "excluded_asset_count", "build_elapsed_seconds",
        )}
    print(json.dumps(result if args.command != "build" else {
        key: result.get(key) for key in (
            "model_id", "asset_count", "frame_count", "reused_asset_count",
            "new_or_changed_asset_count", "failure_count", "excluded_asset_count", "build_elapsed_seconds",
        )
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
