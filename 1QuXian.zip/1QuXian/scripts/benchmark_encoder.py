#!/usr/bin/env python3
"""Detect and benchmark encoders, persisting only verified hardware choices."""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

from speed_common import find_ffmpeg, write_json


HARDWARE_ORDER = ("h264_nvenc", "h264_qsv", "h264_amf")


def parse_encoders(output: str) -> set[str]:
    names = {match.group(1) for line in output.splitlines() if (match := re.match(r"\s*[A-Z\.]{6}\s+(\S+)", line))}
    return {name for name in names if name != "="}


def choose_encoder(available: set[str], validation: dict) -> str:
    for encoder in HARDWARE_ORDER:
        result = validation.get(encoder, {})
        if encoder in available and result.get("ok") and result.get("quality_approved"):
            return encoder
    return "libx264"


def verified_encoder(profile: dict, gpu: str, driver: str, ffmpeg_version: str) -> str:
    if not profile.get("quality_approved"):
        return "libx264"
    if profile.get("gpu") != gpu or profile.get("driver") != driver or profile.get("ffmpeg") != ffmpeg_version:
        return "libx264"
    return profile.get("encoder", "libx264")


def machine_signature(ffmpeg: str) -> tuple[str, str, str]:
    gpu = driver = ""
    nvidia_smi = shutil.which("nvidia-smi")
    if nvidia_smi:
        result = subprocess.run([nvidia_smi, "--query-gpu=name,driver_version", "--format=csv,noheader"], capture_output=True, text=True, encoding="utf-8", errors="replace")
        if result.returncode == 0 and "," in result.stdout:
            gpu, driver = [part.strip() for part in result.stdout.splitlines()[0].split(",", 1)]
    version = subprocess.run([ffmpeg, "-version"], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.splitlines()[0]
    ffmpeg_version = version.replace("ffmpeg version ", "").split(" Copyright", 1)[0].strip()
    return gpu, driver, ffmpeg_version


def benchmark(ffmpeg: str, encoders: list[str], seconds: float = 3.0, approved_encoders: set[str] | None = None) -> dict:
    approved_encoders = approved_encoders or set()
    results = {}
    with tempfile.TemporaryDirectory() as tmp:
        for encoder in encoders:
            output = Path(tmp) / f"{encoder}.mp4"
            command = [ffmpeg, "-y", "-f", "lavfi", "-i", f"testsrc2=size=1280x720:rate=30:duration={seconds}", "-an", "-c:v", encoder]
            command += ["-preset", "veryfast", "-crf", "19"] if encoder == "libx264" else []
            command += ["-pix_fmt", "yuv420p", str(output)]
            started = time.perf_counter()
            result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
            elapsed = time.perf_counter() - started
            results[encoder] = {"ok": result.returncode == 0 and output.exists(), "seconds": round(elapsed, 3), "quality_approved": encoder == "libx264" or encoder in approved_encoders}
    return results


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ffmpeg")
    parser.add_argument("--output", required=True)
    parser.add_argument("--seconds", type=float, default=3.0)
    parser.add_argument("--approve-encoder", action="append", default=[], choices=HARDWARE_ORDER)
    args = parser.parse_args()
    ffmpeg = find_ffmpeg(args.ffmpeg)
    listing = subprocess.run([ffmpeg, "-hide_banner", "-encoders"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    available = parse_encoders(listing.stdout + listing.stderr)
    candidates = [encoder for encoder in ("libx264",) + HARDWARE_ORDER if encoder in available]
    results = benchmark(ffmpeg, candidates, args.seconds, set(args.approve_encoder))
    payload = {"ffmpeg": ffmpeg, "available": sorted(available), "results": results, "preferred": choose_encoder(available, results)}
    write_json(Path(args.output), payload)
    print(json.dumps(payload, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
