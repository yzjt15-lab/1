#!/usr/bin/env python3
"""Render only the uncertain motion window, hard-limited to two seconds."""
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from speed_common import find_ffmpeg


def preview_duration(requested: float) -> float:
    if requested <= 0:
        raise ValueError("duration must be > 0")
    return min(2.0, float(requested))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--start", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=2.0)
    parser.add_argument("--overlay")
    parser.add_argument("--ffmpeg")
    args = parser.parse_args()
    ffmpeg = find_ffmpeg(args.ffmpeg)
    duration = preview_duration(args.duration)
    command = [ffmpeg, "-y", "-ss", str(args.start), "-t", str(duration), "-i", args.source]
    if args.overlay:
        command += ["-loop", "1", "-i", args.overlay, "-filter_complex", "[0:v]scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720[base];[1:v]scale=1280:720[ov];[base][ov]overlay=0:0[out]", "-map", "[out]"]
    else:
        command += ["-vf", "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720"]
    command += ["-an", "-r", "30", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-pix_fmt", "yuv420p", str(Path(args.output))]
    subprocess.run(command, check=True)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

