#!/usr/bin/env python3
"""Render the persistent disclaimer layer for the vertical output."""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from speed_common import content_key, find_chinese_font


def _font(size: int, bold: bool = False):
    return ImageFont.truetype(find_chinese_font(bold), size)


def render_chrome(config: dict, output_dir: Path, size=(1080, 1920)) -> Path:
    signature = content_key({"template_version": 4, "size": size, "config": config}, 20)
    output = Path(output_dir) / f"chrome_{signature}.png"
    if output.exists():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = size
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    disclaimer = str(config.get("disclaimer", "内容仅为个人观点，不构成投资建议"))
    scale = width / 1080
    font_size = max(1, round(24 * scale))
    disclaimer_font = _font(font_size)
    bounds = draw.textbbox((0, 0), disclaimer, font=disclaimer_font)
    text_width, text_height = bounds[2] - bounds[0], bounds[3] - bounds[1]
    draw.text(
        (width - text_width - round(38 * scale) - font_size, round(604 * height / 1920) - text_height - round(8 * scale) - bounds[1]),
        disclaimer,
        font=disclaimer_font,
        fill=(216, 216, 216, 184),
        stroke_width=max(1, round(scale)),
        stroke_fill=(0, 0, 0, 115),
    )
    image.save(output)
    return output
