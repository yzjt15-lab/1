#!/usr/bin/env python3
"""Render the fixed black-gold title/footer chrome used by every video."""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from speed_common import content_key


def _font(size: int, bold: bool = False):
    for path in ([Path(r"C:\Windows\Fonts\msyhbd.ttc"), Path(r"C:\Windows\Fonts\msyh.ttc")] if bold else [Path(r"C:\Windows\Fonts\msyh.ttc"), Path(r"C:\Windows\Fonts\simhei.ttf")]):
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def render_chrome(config: dict, output_dir: Path, size=(1920, 1080)) -> Path:
    signature = content_key({"template_version": 2, "size": size, "config": config}, 20)
    output = Path(output_dir) / f"chrome_{signature}.png"
    if output.exists():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = size
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    title = str(config.get("title", ""))
    top_height, bottom_height = int(height * .082), int(height * .105)
    gold = (242, 200, 107, 255)
    draw.rectangle((0, 0, width, top_height), fill=(2, 3, 5, 250))
    draw.rectangle((0, top_height - 3, width, top_height), fill=gold)
    draw.rectangle((0, height - bottom_height, width, height), fill=(2, 3, 5, 250))
    draw.rectangle((0, height - bottom_height, width, height - bottom_height + 3), fill=gold)
    draw.text((int(width * .022), int(top_height * .14)), title, font=_font(max(26, width // 46), True), fill=gold)
    disclaimer = str(config.get("disclaimer", "内容仅代表个人观点，不作为投资建议"))
    disclaimer_font = _font(max(20, width // 75))
    bounds = draw.textbbox((0, 0), disclaimer, font=disclaimer_font)
    draw.text((width - bounds[2] - int(width * .022), int(top_height * .23)), disclaimer, font=disclaimer_font, fill=(242, 244, 247, 245))
    image.save(output)
    return output
