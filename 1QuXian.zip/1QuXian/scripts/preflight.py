#!/usr/bin/env python3
"""Unified preflight for timeline logic, provenance, and selected files."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import subprocess
import sys
from pathlib import Path

from runtime_paths import MATERIAL_LIBRARY_SCRIPTS

if not (MATERIAL_LIBRARY_SCRIPTS / "material_library.py").is_file():
    raise RuntimeError("material library scripts are unavailable; set CURVE_MATERIAL_LIBRARY_SCRIPTS")
if str(MATERIAL_LIBRARY_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(MATERIAL_LIBRARY_SCRIPTS))

from material_library import DELIVERIES_ROOT as DEFAULT_HISTORY_ROOT, full_hash, identities, recent_material_identities
from speed_common import find_ffmpeg, quick_hash, write_json
from validate_timeline import validate

SOURCE_ID_RE = re.compile(r"(?:pexels|mixkit)[_-](\d+)", re.IGNORECASE)


def derived_source_id(path: Path, digest: str | None) -> str:
    """Use the publisher's ID when present; never trust a timeline-supplied identity."""
    match = SOURCE_ID_RE.search(path.name)
    return f"publisher:{match.group(1)}" if match else f"file:{digest or path.resolve().casefold()}"


def has_pillarbox(path: Path, source_in: float, source_out: float) -> bool:
    """Detect a vertically framed picture embedded in a horizontal container."""
    from PIL import Image, ImageStat
    timestamp = max(source_in, (source_in + source_out) / 2)
    command = [find_ffmpeg(), "-v", "error", "-ss", f"{timestamp:.3f}", "-i", str(path), "-frames:v", "1", "-vf", "scale=160:90", "-f", "image2pipe", "-vcodec", "png", "-"]
    result = subprocess.run(command, capture_output=True, check=False)
    if result.returncode or not result.stdout:
        raise RuntimeError("unable to decode selected frame")
    image = Image.open(io.BytesIO(result.stdout)).convert("RGB")
    side = image.width * 3 // 10
    def nearly_black(region) -> bool:
        stat = ImageStat.Stat(region)
        return max(stat.mean) < 8 and max(stat.var) < 20
    return nearly_black(image.crop((0, 0, side, image.height))) and nearly_black(image.crop((image.width - side, 0, image.width, image.height)))


def _candidate_binding_errors(candidates: list[dict], assets: list[dict], shots: list[dict], require_files: bool) -> list[str]:
    by_id: dict[str, list[dict]] = {}
    for item in candidates:
        by_id.setdefault(str(item.get("asset_id")), []).append(item)
    assets_by_id = {str(item.get("id")): item for item in assets if item.get("id")}
    errors: list[str] = []
    for asset_id, asset in assets_by_id.items():
        records = by_id.get(asset_id, [])
        if not records:
            errors.append(f"selection manifest missing selected candidate: {asset_id}")
            continue
        asset_path = Path(str(asset.get("local_path", ""))).resolve()
        asset_hashes = {str(asset[key]) for key in ("sha256", "quick_hash") if asset.get(key)}
        bound = []
        for item in records:
            candidate_path = item.get("local_path") or item.get("path")
            candidate_hashes = {str(item[key]) for key in ("sha256", "quick_hash") if item.get(key)}
            if candidate_path and Path(str(candidate_path)).resolve() == asset_path and asset_hashes & candidate_hashes:
                bound.append(item)
        if not bound:
            errors.append(f"selection manifest path/hash does not bind timeline asset: {asset_id}")
            continue
        complete = [item for item in bound if (item.get("frame_evidence") or item.get("thumbnail")) and isinstance(item.get("source_in"), (int, float)) and isinstance(item.get("source_out"), (int, float)) and item["source_out"] > item["source_in"]]
        if not complete:
            errors.append(f"selection manifest candidate lacks frame evidence or reviewed source range: {asset_id}")
            continue
        if require_files:
            evidence = complete[0].get("frame_evidence") or complete[0].get("thumbnail")
            if not Path(str(evidence)).is_file():
                errors.append(f"selection manifest frame evidence missing file: {asset_id}")
        for shot in (item for item in shots if str(item.get("asset_id")) == asset_id):
            source_in, source_out = shot.get("source_in"), shot.get("source_out")
            if not isinstance(source_in, (int, float)) or not isinstance(source_out, (int, float)) or not any(abs(float(item["source_in"]) - float(source_in)) <= 0.001 and abs(float(item["source_out"]) - float(source_out)) <= 0.001 for item in complete):
                errors.append(f"selection manifest reviewed range does not bind shot {shot.get('id', '?')}")
    return errors


def validate_selection_manifest(payload: dict, assets: list[dict], shots: list[dict], require_files: bool = False) -> list[str]:
    """Accept research output or an explicit, asset-bound continuation authorization."""
    source = payload.get("source")
    if source == "fast_pipeline research":
        queries = payload.get("eligible_visual_candidates", {}).get("queries", [])
        candidates = [item for query in queries if isinstance(query, dict) for item in query.get("candidates", []) if isinstance(item, dict)]
        return _candidate_binding_errors(candidates, assets, shots, require_files)
    if source != "user-authorized library selection":
        return ["selection manifest must originate from fast_pipeline research or explicit user-authorized library selection"]
    authorization = payload.get("user_authorization")
    selected = payload.get("selected_assets")
    candidates = payload.get("candidates")
    if not isinstance(authorization, str) or not authorization.strip():
        return ["manual selection manifest requires user_authorization"]
    if not isinstance(selected, list) or not selected or not all(isinstance(item, str) and item for item in selected):
        return ["manual selection manifest requires non-empty selected_assets"]
    selected_asset_ids = {str(item.get("id")) for item in assets if item.get("id")}
    if set(selected) != selected_asset_ids:
        return ["manual selection manifest selected_assets must exactly match timeline assets"]
    if not isinstance(candidates, list):
        return ["manual selection manifest requires candidate records"]
    return _candidate_binding_errors([item for item in candidates if isinstance(item, dict)], assets, shots, require_files)


def run_preflight(timeline: dict, require_files: bool = True, asset_index: dict | None = None, history_root: Path | None = None) -> list[str]:
    errors = list(validate(timeline))
    if require_files and asset_index is None:
        errors.append("asset_index is required for formal preflight")
    if timeline.get("reference_audio_path") and require_files and not Path(timeline["reference_audio_path"]).is_file():
        errors.append(f"reference audio missing file {timeline['reference_audio_path']}")
    selection_manifest_path = timeline.get("selection_manifest_path")
    selection_manifest_sha256 = timeline.get("selection_manifest_sha256")
    if not selection_manifest_path:
        errors.append("selection_manifest_path is required")
    elif not selection_manifest_sha256:
        errors.append("selection_manifest_sha256 is required")
    else:
        manifest = Path(selection_manifest_path)
        if not manifest.exists():
            errors.append(f"selection manifest missing file {selection_manifest_path}")
        elif hashlib.sha256(manifest.read_bytes()).hexdigest() != selection_manifest_sha256:
            errors.append("selection manifest sha256 mismatch")
        else:
            try:
                payload = json.loads(manifest.read_text(encoding="utf-8"))
                errors.extend(validate_selection_manifest(payload, timeline.get("assets", []), timeline.get("shots", []), require_files))
            except json.JSONDecodeError:
                errors.append("selection manifest is not valid json")
    chrome_path = timeline.get("chrome_path")
    if not chrome_path:
        errors.append("chrome_path is required")
    elif require_files and not Path(chrome_path).exists():
        errors.append(f"chrome_path missing file {chrome_path}")
    indexed = {item.get("path", "").casefold(): item for item in (asset_index or {}).get("assets", [])}
    assets_by_id = {item.get("id"): item for item in timeline.get("assets", [])}
    seen_hashes: dict[str, str] = {}
    seen_sources: dict[str, str] = {}
    recent = recent_material_identities(deliveries_root=history_root) if history_root else set()
    for shot in timeline.get("shots", []):
        values = (shot.get("keyword"), shot.get("subject"), shot.get("action"), shot.get("result"), shot.get("asset_id"))
        if any(not value or str(value).startswith("pending-") or "待语义确认" in str(value) or str(value) == "待提取" for value in values):
            errors.append(f"shot {shot.get('id', '?')}: unconfirmed semantic or asset field")
        asset = assets_by_id.get(shot.get("asset_id"), {})
        local = asset.get("local_path")
        metadata = indexed.get(str(Path(local).resolve()).casefold()) if local else None
        source_in = float(shot.get("source_in", 0))
        selected_end = source_in + float(shot.get("end", 0)) - float(shot.get("start", 0))
        if source_in < 0:
            errors.append(f"shot {shot.get('id', '?')}: source_in must be >= 0")
        if shot.get("source_out") is not None and abs(float(shot["source_out"]) - selected_end) > 0.001:
            errors.append(f"shot {shot.get('id', '?')}: source_out differs from renderer selected range")
        if shot.get("source_out") is None:
            errors.append(f"shot {shot.get('id', '?')}: source_out is required before render")
        elif float(shot["source_out"]) <= source_in:
            errors.append(f"shot {shot.get('id', '?')}: source_out must be greater than source_in")
        if metadata and metadata.get("duration") is not None and selected_end > float(metadata["duration"]) + 0.001:
            errors.append(f"shot {shot.get('id', '?')}: selected range exceeds source duration")
        digest = asset.get("sha256") or asset.get("quick_hash")
        if local and require_files and Path(local).is_file():
            source_id = derived_source_id(Path(local), digest)
            if asset.get("source_id") not in (None, source_id):
                errors.append(f"asset {shot.get('asset_id')}: source_id must match file-derived identity")
            if source_id in seen_sources:
                errors.append(f"duplicate source: {shot.get('asset_id')} matches {seen_sources[source_id]}")
            else:
                seen_sources[source_id] = shot.get("asset_id")
            try:
                if has_pillarbox(Path(local), source_in, selected_end):
                    errors.append(f"asset {shot.get('asset_id')}: selected frame is pillarboxed or vertically embedded")
            except RuntimeError as exc:
                errors.append(f"asset {shot.get('asset_id')}: effective-frame check failed: {exc}")
        if identities({**asset, "asset_id": shot.get("asset_id"), "path": local or ""}) & recent:
            errors.append(f"asset {shot.get('asset_id')}: material identity was used within seven days")
        if digest:
            if digest in seen_hashes:
                errors.append(f"duplicate content: {shot.get('asset_id')} matches {seen_hashes[digest]}")
            else:
                seen_hashes[digest] = shot.get("asset_id")
    for asset in timeline.get("assets", []):
        local = asset.get("local_path")
        if not local:
            continue
        path = Path(local)
        if require_files and not path.exists():
            errors.append(f"asset {asset.get('id', '?')}: missing local file {local}")
        metadata = indexed.get(str(path.resolve()).casefold())
        if require_files and path.is_file():
            if not metadata:
                errors.append(f"asset {asset.get('id', '?')}: file is not present in the supplied material-library index")
            else:
                actual_quick_hash = quick_hash(path)
                if str(metadata.get("id")) != str(asset.get("id")):
                    errors.append(f"asset {asset.get('id', '?')}: id does not match material-library index")
                if metadata.get("quick_hash") != actual_quick_hash or (asset.get("quick_hash") and asset.get("quick_hash") != actual_quick_hash):
                    errors.append(f"asset {asset.get('id', '?')}: quick hash does not match indexed file")
                if asset.get("sha256") and full_hash(path) != asset["sha256"]:
                    errors.append(f"asset {asset.get('id', '?')}: sha256 does not match local file")
                for field in ("subject", "action", "location", "equipment", "keywords", "frame_evidence", "cleanliness_evidence"):
                    if not metadata.get(field):
                        errors.append(f"asset {asset.get('id', '?')}: material-library index missing {field}")
                if any(metadata.get(field) is not True for field in ("watermark_free", "embedded_subtitles_free", "platform_overlay_free")):
                    errors.append(f"asset {asset.get('id', '?')}: material-library cleanliness gate is not clear")
        if metadata and asset.get("source_out") is not None and metadata.get("duration") is not None:
            if float(asset["source_out"]) > float(metadata["duration"]):
                errors.append(f"asset {asset.get('id', '?')}: source_out exceeds duration")
    seen_overlay_hashes: dict[str, str] = {}
    for overlay in timeline.get("overlays", []):
        image_path = overlay.get("image_path")
        frame_pattern = overlay.get("frame_pattern")
        if not image_path and not frame_pattern:
            errors.append(f"overlay {overlay.get('id', '?')}: image_path is required")
        elif image_path and require_files and not Path(image_path).exists():
            errors.append(f"overlay {overlay.get('id', '?')}: missing image {image_path}")
        elif image_path and Path(image_path).is_file():
            digest = hashlib.sha256(Path(image_path).read_bytes()).hexdigest()
            if digest in seen_overlay_hashes:
                errors.append(f"overlay {overlay.get('id', '?')}: duplicate information image matches {seen_overlay_hashes[digest]}")
            else:
                seen_overlay_hashes[digest] = overlay.get("id", "?")
    return sorted(set(errors))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--asset-index", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--skip-file-check", action="store_true")
    parser.add_argument("--history-root", default=str(DEFAULT_HISTORY_ROOT))
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8"))
    asset_index_path = Path(args.asset_index)
    index = json.loads(asset_index_path.read_text(encoding="utf-8-sig"))
    errors = run_preflight(timeline, not args.skip_file_check, index, Path(args.history_root))
    timeline_path = Path(args.timeline)
    report = {"timeline": str(timeline_path.resolve()), "timeline_sha256": hashlib.sha256(timeline_path.read_bytes()).hexdigest(), "asset_index": str(asset_index_path.resolve()), "asset_index_sha256": hashlib.sha256(asset_index_path.read_bytes()).hexdigest(), "ok": not errors, "errors": errors}
    write_json(Path(args.report), report)
    print(json.dumps(report, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
