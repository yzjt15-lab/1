#!/usr/bin/env python3
"""Unified preflight for timeline logic, provenance, and selected files."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from speed_common import write_json
from validate_timeline import validate

DEFAULT_HISTORY_ROOT = Path(r"C:\Users\28723\Documents\Codex")


def delivered_asset_hashes(root: Path, now: datetime | None = None) -> set[str]:
    cutoff = (now or datetime.now(timezone.utc)) - timedelta(hours=168)
    ledgers: dict[str, set[str]] = {}
    for path in root.rglob("*asset-ledger.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                continue
            ledgers[hashlib.sha256(path.read_bytes()).hexdigest()] = {str(item.get("sha256") or item.get("quick_hash")) for item in payload.get("assets", []) if item.get("sha256") or item.get("quick_hash")}
        except (OSError, json.JSONDecodeError):
            continue
    delivered: set[str] = set()
    for path in root.rglob("*.json"):
        if "门禁" not in path.name and "gate" not in path.name.casefold():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            checked = datetime.fromisoformat(str(payload.get("checked_at", "")).replace("Z", "+00:00"))
            if payload.get("terminal_allowed") is True and checked.tzinfo and checked >= cutoff:
                delivered.update(ledgers.get(str(payload.get("sha256", {}).get("ledger")), set()))
        except (OSError, json.JSONDecodeError, ValueError):
            continue
    return delivered


def run_preflight(timeline: dict, require_files: bool = True, asset_index: dict | None = None, history_root: Path | None = None) -> list[str]:
    errors = list(validate(timeline))
    if timeline.get("reference_audio_path") and require_files and not Path(timeline["reference_audio_path"]).is_file():
        errors.append(f"reference audio missing file {timeline['reference_audio_path']}")
    selection_manifest_path = timeline.get("selection_manifest_path")
    selection_manifest_sha256 = timeline.get("selection_manifest_sha256")
    if not selection_manifest_path:
        errors.append("selection_manifest_path is required")
    elif not selection_manifest_sha256:
        errors.append("selection_manifest_sha256 is required")
    else:
        manifest = Path(selection_manifest_path)
        if not manifest.exists():
            errors.append(f"selection manifest missing file {selection_manifest_path}")
        elif hashlib.sha256(manifest.read_bytes()).hexdigest() != selection_manifest_sha256:
            errors.append("selection manifest sha256 mismatch")
        else:
            try:
                payload = json.loads(manifest.read_text(encoding="utf-8"))
                source = payload.get("source")
                manual_authorization = payload.get("user_authorization")
                if source != "fast_pipeline research" and not (
                    source == "user-authorized library selection"
                    and isinstance(manual_authorization, str)
                    and manual_authorization.strip()
                    and isinstance(payload.get("selected_assets"), list)
                    and payload["selected_assets"]
                ):
                    errors.append("selection manifest must originate from fast_pipeline research or explicit user-authorized library selection")
            except json.JSONDecodeError:
                errors.append("selection manifest is not valid json")
    chrome_path = timeline.get("chrome_path")
    if not chrome_path:
        errors.append("chrome_path is required")
    elif require_files and not Path(chrome_path).exists():
        errors.append(f"chrome_path missing file {chrome_path}")
    indexed = {item.get("path", "").casefold(): item for item in (asset_index or {}).get("assets", [])}
    assets_by_id = {item.get("id"): item for item in timeline.get("assets", [])}
    seen_hashes: dict[str, str] = {}
    historical_hashes = delivered_asset_hashes(history_root) if history_root else set()
    for shot in timeline.get("shots", []):
        values = (shot.get("keyword"), shot.get("subject"), shot.get("action"), shot.get("result"), shot.get("asset_id"))
        if any(not value or str(value).startswith("pending-") or "待语义确认" in str(value) or str(value) == "待提取" for value in values):
            errors.append(f"shot {shot.get('id', '?')}: unconfirmed semantic or asset field")
        asset = assets_by_id.get(shot.get("asset_id"), {})
        local = asset.get("local_path")
        metadata = indexed.get(str(Path(local).resolve()).casefold()) if local else None
        source_in = float(shot.get("source_in", 0))
        selected_end = source_in + float(shot.get("end", 0)) - float(shot.get("start", 0))
        if source_in < 0:
            errors.append(f"shot {shot.get('id', '?')}: source_in must be >= 0")
        if shot.get("source_out") is not None and abs(float(shot["source_out"]) - selected_end) > 0.001:
            errors.append(f"shot {shot.get('id', '?')}: source_out differs from renderer selected range")
        if metadata and metadata.get("duration") is not None and selected_end > float(metadata["duration"]) + 0.001:
            errors.append(f"shot {shot.get('id', '?')}: selected range exceeds source duration")
        digest = asset.get("sha256") or asset.get("quick_hash")
        if digest:
            if digest in historical_hashes:
                errors.append(f"asset {shot.get('asset_id')}: source hash was used by a delivered video within seven days")
            if digest in seen_hashes:
                errors.append(f"duplicate content: {shot.get('asset_id')} matches {seen_hashes[digest]}")
            else:
                seen_hashes[digest] = shot.get("asset_id")
    for asset in timeline.get("assets", []):
        local = asset.get("local_path")
        if not local:
            continue
        path = Path(local)
        if require_files and not path.exists():
            errors.append(f"asset {asset.get('id', '?')}: missing local file {local}")
        metadata = indexed.get(str(path.resolve()).casefold())
        if metadata and asset.get("source_out") is not None and metadata.get("duration") is not None:
            if float(asset["source_out"]) > float(metadata["duration"]):
                errors.append(f"asset {asset.get('id', '?')}: source_out exceeds duration")
    seen_overlay_hashes: dict[str, str] = {}
    for overlay in timeline.get("overlays", []):
        image_path = overlay.get("image_path")
        frame_pattern = overlay.get("frame_pattern")
        if not image_path and not frame_pattern:
            errors.append(f"overlay {overlay.get('id', '?')}: image_path is required")
        elif image_path and require_files and not Path(image_path).exists():
            errors.append(f"overlay {overlay.get('id', '?')}: missing image {image_path}")
        elif image_path and Path(image_path).is_file():
            digest = hashlib.sha256(Path(image_path).read_bytes()).hexdigest()
            if digest in seen_overlay_hashes:
                errors.append(f"overlay {overlay.get('id', '?')}: duplicate information image matches {seen_overlay_hashes[digest]}")
            else:
                seen_overlay_hashes[digest] = overlay.get("id", "?")
    return sorted(set(errors))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--asset-index")
    parser.add_argument("--report", required=True)
    parser.add_argument("--skip-file-check", action="store_true")
    parser.add_argument("--history-root", default=str(DEFAULT_HISTORY_ROOT))
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8"))
    index = json.loads(Path(args.asset_index).read_text(encoding="utf-8")) if args.asset_index else None
    errors = run_preflight(timeline, not args.skip_file_check, index, Path(args.history_root))
    timeline_path = Path(args.timeline)
    report = {"timeline": str(timeline_path.resolve()), "timeline_sha256": hashlib.sha256(timeline_path.read_bytes()).hexdigest(), "ok": not errors, "errors": errors}
    write_json(Path(args.report), report)
    print(json.dumps(report, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
