#!/usr/bin/env python3
"""Validate the non-negotiable editorial contract before rendering."""
import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from page_reference_contract import PAGE_REFERENCE_FILENAMES

ENGLISH = re.compile(r"[A-Za-z]")
HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")
SEMANTIC_KEYS = ("subject", "action", "location", "equipment", "keywords")
INFORMATION_TASKS = {"fact", "news", "data", "number", "comparison", "causal", "broll"}
CHART_INFORMATION_TASKS = {"fact", "data", "number", "comparison", "causal"}
OVERLAY_TYPES = {"hook", "news", "chart"}
CHART_KINDS = {
    "relative_return", "futures_position", "grouped_comparison", "dual_axis_trend", "kline_wave", "kline_fibonacci",
    "contract_comparison", "hedge_mechanism", "financial_loop", "three_stage_trend",
}
HOOK_LINES = ("thesis", "judgment", "evidence")
ALLOWED_LATIN = ("ETF", "A股", "B浪", "C浪", "c浪", "K线")
def semantic_value(value) -> str:
    if isinstance(value, list):
        return " ".join(str(item).strip() for item in value if str(item).strip())
    return str(value or "").strip()


def validate(data: dict) -> list[str]:
    errors: list[str] = []
    assets = {item.get("id"): item for item in data.get("assets", [])}
    shots = data.get("shots", [])
    overlays = sorted(data.get("overlays", []), key=lambda item: item.get("start", 0))
    used: set[str] = set()
    shot_ids = {shot.get("id") for shot in shots}
    chapters = data.get("chapters")
    chapter_by_id: dict[str, dict] = {}

    if not isinstance(chapters, list) or not chapters:
        errors.append("chapters are required")
        chapters = []
    previous_chapter_end = None
    for chapter in chapters:
        cid = chapter.get("id")
        start, end = chapter.get("start"), chapter.get("end")
        if not isinstance(cid, str) or not cid.strip() or cid in chapter_by_id:
            errors.append("chapter requires a unique non-empty id")
            continue
        chapter_by_id[cid] = chapter
        if not isinstance(start, (int, float)) or not isinstance(end, (int, float)) or end <= start:
            errors.append(f"chapter {cid}: requires numeric start/end with end > start")
        elif previous_chapter_end is not None and start < previous_chapter_end - 0.001:
            errors.append(f"chapter {cid}: overlaps previous chapter")
        else:
            previous_chapter_end = end
        if not isinstance(chapter.get("thesis"), str) or not chapter["thesis"].strip():
            errors.append(f"chapter {cid}: thesis is required")

    if not data.get("script_path"):
        errors.append("script_path is required")
    audit = data.get("dedupe_audit")
    authorized_exception = isinstance(audit, dict) and audit.get("lookback_hours") == 0 and audit.get("user_authorized_exception") is True and isinstance(audit.get("exception_reason"), str) and audit["exception_reason"].strip()
    if not isinstance(audit, dict) or not audit.get("checked_at") or (audit.get("lookback_hours") != 168 and not authorized_exception):
        errors.append("seven-day dedupe audit with 168-hour lookback is required unless an explicit user-authorized single-project exception is recorded")
    else:
        try:
            checked_at = datetime.fromisoformat(str(audit["checked_at"]).replace("Z", "+00:00"))
            if checked_at.tzinfo is None or abs((datetime.now(timezone.utc) - checked_at).total_seconds()) > 86400:
                errors.append("seven-day dedupe audit must be timezone-aware and less than 24 hours old")
        except ValueError:
            errors.append("seven-day dedupe audit checked_at is invalid")
    target_duration = data.get("duration_seconds")
    if not isinstance(target_duration, (int, float)) or target_duration <= 0:
        errors.append("duration_seconds must be >0")
    elif shots:
        if abs(float(shots[0].get("start", -1))) > 0.001:
            errors.append("timeline must start at 0.0")
        if not isinstance(shots[-1].get("end"), (int, float)) or abs(float(shots[-1]["end"]) - float(target_duration)) > 0.001:
            errors.append("timeline must end at duration_seconds")

    timing_audio_path = data.get("timing_audio_path")
    audio_delivery_mode = data.get("audio_delivery_mode")
    if audio_delivery_mode != "silent":
        errors.append("audio_delivery_mode must be silent")
    if data.get("audio_path"):
        errors.append("silent curve video must not include audio_path")
    if any(data.get(key) is not None for key in ("reference_audio_path", "reference_audio_segments")):
        errors.append("legacy reference_audio fields are not allowed; use timing_audio fields")
    if timing_audio_path:
        segments = data.get("timing_audio_segments")
        if not isinstance(segments, list) or not segments:
            errors.append("timing_audio_segments are required when timing_audio_path is set")

    for previous, current in zip(shots, shots[1:]):
        if not isinstance(previous.get("end"), (int, float)) or not isinstance(current.get("start"), (int, float)) or abs(float(previous["end"]) - float(current["start"])) > 0.001:
            errors.append(f"timeline must be contiguous between {previous.get('id', '?')} and {current.get('id', '?')}")

    for shot in shots:
        sid, asset_id = shot.get("id", "?"), shot.get("asset_id")
        if not all(shot.get(key) for key in ("keyword", "subject", "action", "result", "asset_id")):
            errors.append(f"shot {sid}: missing keyword mapping")
        if shot.get("selection_mode") != "semantic_index":
            errors.append(f"shot {sid}: selection_mode must be semantic_index")
        semantic_fields = shot.get("semantic_fields")
        if not isinstance(semantic_fields, dict) or not all(semantic_value(semantic_fields.get(key)) for key in SEMANTIC_KEYS):
            errors.append(f"shot {sid}: semantic_fields must include subject/action/location/equipment/keywords")
        if shot.get("information_task") not in INFORMATION_TASKS:
            errors.append(f"shot {sid}: information_task must be one of {sorted(INFORMATION_TASKS)}")
        if timing_audio_path:
            audio_range = shot.get("timing_audio_range")
            if not isinstance(audio_range, dict) or not isinstance(audio_range.get("start"), (int, float)) or not isinstance(audio_range.get("end"), (int, float)) or audio_range["end"] <= audio_range["start"]:
                errors.append(f"shot {sid}: timing_audio_range is required")
        script_range = shot.get("script_range")
        if not isinstance(script_range, dict) or not isinstance(script_range.get("start"), (int, float)) or not isinstance(script_range.get("end"), (int, float)) or script_range["end"] <= script_range["start"]:
            errors.append(f"shot {sid}: script_range requires numeric start/end with end > start")
        if not isinstance(shot.get("selection_reason"), str) or not shot["selection_reason"].strip():
            errors.append(f"shot {sid}: selection_reason is required")
        chapter = chapter_by_id.get(shot.get("chapter_id"))
        if not chapter:
            errors.append(f"shot {sid}: chapter_id must reference a planned chapter")
        elif isinstance(script_range, dict) and isinstance(script_range.get("start"), (int, float)) and isinstance(script_range.get("end"), (int, float)):
            if script_range["start"] < chapter.get("start", float("inf")) - 0.001 or script_range["end"] > chapter.get("end", float("-inf")) + 0.001:
                errors.append(f"shot {sid}: script_range must stay within chapter")
        candidates = shot.get("candidate_asset_ids")
        if not isinstance(candidates, list) or asset_id not in candidates:
            errors.append(f"shot {sid}: selected asset must appear in candidate_asset_ids")
        if not isinstance(shot.get("start"), (int, float)) or not isinstance(shot.get("end"), (int, float)):
            errors.append(f"shot {sid}: invalid timing")
        elif shot["end"] <= shot["start"] or shot["end"] - shot["start"] > 5.001:
            errors.append(f"shot {sid}: duration must be >0 and <=5.0 seconds")
        elif shot.get("information_task") == "broll" and shot["end"] - shot["start"] < 2.0:
            errors.append(f"shot {sid}: broll duration must be 2.0-5.0 seconds")
        if asset_id in used:
            errors.append(f"duplicate asset: {asset_id}")
        used.add(asset_id)
        asset = assets.get(asset_id)
        if not asset or not asset.get("local_path"):
            errors.append(f"shot {sid}: asset local file missing")
        elif not asset.get("sha256") and not asset.get("quick_hash"):
            errors.append(f"shot {sid}: asset hash missing")
        elif asset.get("replacement") and not asset.get("replacement_reason"):
            errors.append(f"asset {asset_id}: replacement reason missing")
        if asset:
            cleanliness = ("watermark_free", "embedded_subtitles_free", "platform_overlay_free")
            if any(asset.get(key) is not True for key in cleanliness) or not isinstance(asset.get("cleanliness_checked_at"), str) or not asset["cleanliness_checked_at"].strip() or not isinstance(asset.get("cleanliness_evidence"), str) or not asset["cleanliness_evidence"].strip():
                errors.append(f"asset {asset_id}: visual cleanliness gate is not clear")
            if not authorized_exception and (asset.get("seven_day_eligible") is not True or asset.get("dedupe_clear") is not True or not asset.get("dedupe_checked_at")):
                errors.append(f"asset {asset_id}: seven-day dedupe status is not clear")

    missing_chapters = set(chapter_by_id) - {shot.get("chapter_id") for shot in shots}
    if missing_chapters:
        errors.append("chapters without any covering shot: " + ", ".join(sorted(missing_chapters)))

    previous_end = None
    information_texts: set[str] = set()
    chart_keys: set[tuple[str, str]] = set()
    hooks = [item for item in overlays if item.get("role") == "hook"]
    if len(hooks) != 1:
        errors.append("timeline must contain exactly one hook overlay")
    for overlay in overlays:
        oid = overlay.get("id", "?")
        overlay_type = overlay.get("type")
        if overlay_type not in OVERLAY_TYPES:
            errors.append(f"overlay {oid}: invalid type")
        reference_key = "hook" if overlay.get("role") == "hook" else ("news" if overlay_type == "news" else overlay.get("chart_kind"))
        expected_reference = PAGE_REFERENCE_FILENAMES.get(reference_key)
        if expected_reference and overlay.get("reference_template") != expected_reference:
            errors.append(f"overlay {oid}: reference_template must be {expected_reference}")
        if overlay.get("background_shot_id") not in shot_ids:
            errors.append(f"overlay {oid}: real-video background missing")
        overlay_chapter = chapter_by_id.get(overlay.get("chapter_id"))
        if not overlay_chapter:
            errors.append(f"overlay {oid}: chapter_id must reference a chapter")
        if overlay.get("role") != "hook":
            represented_task = overlay.get("information_task") if overlay_type == "chart" else overlay_type
            if represented_task not in INFORMATION_TASKS - {"broll"}:
                errors.append(f"overlay {oid}: information_task must describe the page directly")
            script_range = overlay.get("script_range")
            if not isinstance(script_range, dict) or not isinstance(script_range.get("start"), (int, float)) or not isinstance(script_range.get("end"), (int, float)) or script_range["end"] <= script_range["start"]:
                errors.append(f"overlay {oid}: script_range requires numeric start/end with end > start")
            elif overlay_chapter and (script_range["start"] < overlay_chapter.get("start", float("inf")) - 0.001 or script_range["end"] > overlay_chapter.get("end", float("-inf")) + 0.001):
                errors.append(f"overlay {oid}: script_range must stay within chapter")
        start, end = overlay.get("start"), overlay.get("end")
        expected_duration = 4.5 if overlay_type == "chart" else 4.0
        if not isinstance(start, (int, float)) or not isinstance(end, (int, float)) or abs((end - start) - expected_duration) > 0.001:
            errors.append(f"overlay {oid}: duration must equal {expected_duration:.1f} seconds")
        if previous_end is not None and isinstance(start, (int, float)) and start < previous_end - 0.001:
            errors.append(f"overlapping overlay: {oid}")
        previous_end = end
        text = overlay.get("chinese_text", "")
        latin_check = str(text)
        for token in ALLOWED_LATIN:
            latin_check = latin_check.replace(token, "")
        if not text or ENGLISH.search(latin_check):
            errors.append(f"overlay {oid}: text must be simplified Chinese without English")
        if not Path(str(overlay.get("image_path", ""))).is_file():
            errors.append(f"overlay {oid}: existing image_path is required")
        if overlay_type == "news" and not str(overlay.get("screenshot_path", "")).strip():
            errors.append(f"overlay {oid}: screenshot_path is required for direct news display")
        if timing_audio_path and overlay.get("role") != "hook":
            audio_range = overlay.get("timing_audio_range")
            if not isinstance(audio_range, dict) or not isinstance(audio_range.get("start"), (int, float)) or not isinstance(audio_range.get("end"), (int, float)) or audio_range["end"] <= audio_range["start"]:
                errors.append(f"overlay {oid}: timing_audio_range is required")
            if not str(overlay.get("timing_audio_text", "")).strip() or overlay.get("audio_semantic_match") is not True:
                errors.append(f"overlay {oid}: timing audio semantic lock is incomplete")
        normalized_text = re.sub(r"\s+", "", str(text))
        if normalized_text in information_texts:
            errors.append(f"overlay {oid}: duplicate information content")
        information_texts.add(normalized_text)
        if overlay_type == "chart":
            required = ("chart_kind", "data_chain_id", "data_interval", "data_metric", "source_state", "source_excerpt")
            if overlay.get("information_task") not in CHART_INFORMATION_TASKS:
                errors.append(f"overlay {oid}: chart information_task must be one of {sorted(CHART_INFORMATION_TASKS)}")
            if overlay.get("chart_kind") not in CHART_KINDS:
                errors.append(f"overlay {oid}: invalid chart_kind")
            if any(not str(overlay.get(key, "")).strip() for key in required):
                errors.append(f"overlay {oid}: chart requires {', '.join(required)}")
            if overlay.get("source_state") == "user_authorized_prediction":
                basis = overlay.get("prediction_basis")
                if not isinstance(basis, list) or not basis or any(not str(item).strip() for item in basis):
                    errors.append(f"overlay {oid}: predicted page requires non-empty prediction_basis[]")
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(overlay.get("prediction_corpus_date", ""))):
                    errors.append(f"overlay {oid}: predicted page requires prediction_corpus_date YYYY-MM-DD")
            if overlay_chapter and str(overlay.get("source_excerpt", "")).strip() not in str(overlay_chapter.get("thesis", "")):
                errors.append(f"overlay {oid}: source_excerpt must appear in chapter thesis")
            chart_key = (str(overlay.get("chart_kind", "")), str(overlay.get("data_chain_id", "")))
            if all(chart_key) and chart_key in chart_keys:
                errors.append(f"overlay {oid}: duplicate chart_kind + data_chain_id")
            chart_keys.add(chart_key)
        if overlay.get("role") == "hook":
            if start != 0 or end != 4:
                errors.append(f"overlay {oid}: hook must cover 0.0-4.0 seconds")
            if not overlay.get("frame_pattern"):
                errors.append(f"overlay {oid}: dynamic hook frame_pattern is required")
            colors = overlay.get("hook_text_colors")
            if overlay.get("hook_color_fallback") == "white":
                if not isinstance(colors, dict) or any(colors.get(line, {}).get("color", "").upper() != "#FFFFFF" for line in HOOK_LINES):
                    errors.append(f"overlay {oid}: white fallback must set every hook line to #FFFFFF")
                contrast = overlay.get("hook_contrast")
                if not isinstance(contrast, dict) or any(not isinstance(contrast.get(line), dict) or not isinstance(contrast[line].get("contrast_ratio"), (int, float)) or contrast[line]["contrast_ratio"] < 4.5 for line in HOOK_LINES):
                    errors.append(f"overlay {oid}: white fallback still requires measured contrast >=4.5 for every line")
                continue
            contrast = overlay.get("hook_contrast")
            if not isinstance(colors, dict) or not isinstance(contrast, dict):
                errors.append(f"overlay {oid}: hook_text_colors and hook_contrast are required")
                continue
            selected, opacities = [], []
            for line in HOOK_LINES:
                color = colors.get(line, {})
                check = contrast.get(line, {})
                if not isinstance(color, dict) or not HEX_COLOR.fullmatch(str(color.get("color", ""))):
                    errors.append(f"overlay {oid}: hook_text_colors.{line}.color must be #RRGGBB")
                    continue
                selected.append(color["color"].upper())
                opacity = color.get("opacity")
                if not isinstance(opacity, (int, float)) or not 0 < opacity <= 1:
                    errors.append(f"overlay {oid}: hook_text_colors.{line}.opacity must be in (0,1]")
                else:
                    opacities.append(float(opacity))
                if not isinstance(check, dict) or not isinstance(check.get("background_luminance"), (int, float)) or not 0 <= check["background_luminance"] <= 1:
                    errors.append(f"overlay {oid}: hook_contrast.{line}.background_luminance must be in [0,1]")
                if not isinstance(check, dict) or not isinstance(check.get("contrast_ratio"), (int, float)) or check["contrast_ratio"] < 4.5:
                    errors.append(f"overlay {oid}: hook_contrast.{line}.contrast_ratio must be >=4.5")
            if len(selected) == len(HOOK_LINES) and len(set(selected)) != len(HOOK_LINES):
                errors.append(f"overlay {oid}: hook text colors must differ by line")
            if len(opacities) == len(HOOK_LINES) and not (opacities[0] > opacities[1] > opacities[2]):
                errors.append(f"overlay {oid}: hook text opacity must descend thesis>judgment>data")

    if data.get("news"):
        errors.append("news pages must use overlays[] as the single registry")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()
    errors = validate(json.loads(Path(args.timeline).read_text(encoding="utf-8")))
    report = {"timeline": args.timeline, "errors": errors, "ok": not errors}
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
