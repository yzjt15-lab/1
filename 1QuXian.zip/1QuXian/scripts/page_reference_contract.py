"""Single source of truth and fail-closed checks for approved curve pages."""
import hashlib
import json
from pathlib import Path

from PIL import Image

SKILL_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PAGES = SKILL_ROOT / "assets" / "approved-pages"
MANIFEST_PATH = SKILL_ROOT / "references" / "曲线页面固定标准.json"
PAGE_SIZE = (1080, 830)
CHART_TYPES = {"relative_return", "futures_position", "grouped_comparison", "dual_axis_trend", "kline_wave", "kline_fibonacci"}
STRUCTURE_TYPES = {"contract_comparison", "hedge_mechanism", "financial_loop", "three_stage_trend"}
PAGE_TYPES = {"hook", "news"} | CHART_TYPES | STRUCTURE_TYPES
COMPOSITION_MODE = "native_1080x830_relayout_no_source_scaling_or_cropping"


def _read_manifest(manifest_path: Path = MANIFEST_PATH) -> dict:
    return json.loads(manifest_path.read_text(encoding="utf-8"))


def _manifest_filenames(manifest_path: Path = MANIFEST_PATH) -> dict[str, str]:
    try:
        templates = _read_manifest(manifest_path).get("templates", {})
    except (OSError, json.JSONDecodeError):
        return {}
    return {
        page_type: Path(str(item.get("file", ""))).name
        for page_type, item in templates.items()
        if page_type in PAGE_TYPES and Path(str(item.get("file", ""))).name
    }


PAGE_REFERENCE_FILENAMES = _manifest_filenames()


def verify_page_reference_assets(manifest_path: Path = MANIFEST_PATH, page_types: set[str] | None = None) -> list[str]:
    try:
        payload = _read_manifest(manifest_path)
    except (OSError, json.JSONDecodeError) as exc:
        return [f"curve page manifest unavailable: {exc}"]
    errors = []
    if payload.get("schema_version") != 5 or payload.get("central_window") != {"width": 1080, "height": 830, "top": 604}:
        errors.append("curve page manifest must declare the current 1080x830 central window at y=604")
    if payload.get("composition_mode") != COMPOSITION_MODE:
        errors.append("curve pages must use the native 1080x830 relayout without scaling or cropping source templates")
    templates = payload.get("templates", {})
    if set(templates) != PAGE_TYPES:
        errors.append("curve page manifest must map exactly hook, news, six chart types, and four structure types")
    selected = PAGE_TYPES if page_types is None else set(page_types)
    unknown = selected - PAGE_TYPES
    if unknown:
        errors.append("unsupported curve page types: " + ", ".join(sorted(unknown)))
    if page_types is None:
        expected_files = {Path(str(item.get("file", ""))).name for item in templates.values()}
        actual_files = {path.name for path in REFERENCE_PAGES.glob("*") if path.is_file() and path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}}
        if actual_files != expected_files:
            errors.append("assets/approved-pages must contain exactly the twelve manifest-bound images")
    for page_type in selected & PAGE_TYPES:
        item = templates.get(page_type, {})
        relative = Path(str(item.get("file", "")))
        path = SKILL_ROOT / relative
        if relative.parent.as_posix() != "assets/approved-pages" or not relative.name or not path.is_file():
            errors.append(f"curve page {page_type}: missing approved file")
            continue
        if hashlib.sha256(path.read_bytes()).hexdigest() != item.get("sha256"):
            errors.append(f"curve page {page_type}: sha256 mismatch")
            continue
        with Image.open(path) as image:
            if image.size != PAGE_SIZE or item.get("width") != 1080 or item.get("height") != 830 or item.get("role") != "central_clear_window":
                errors.append(f"curve page {page_type}: must be a 1080x830 central_clear_window")
            elif image.mode != "RGBA" or image.getchannel("A").getextrema() != (0, 255):
                errors.append(f"curve page {page_type}: must be RGBA with a real transparent channel")
    return errors


def approved_reference_path(page_type: str, reference_template=None, reference_template_path=None) -> Path:
    errors = verify_page_reference_assets(page_types={page_type})
    if errors:
        raise ValueError("; ".join(errors))
    expected = PAGE_REFERENCE_FILENAMES.get(page_type)
    if not expected:
        raise ValueError(f"unsupported curve page type: {page_type}")
    if reference_template is not None and Path(str(reference_template)) != Path(expected):
        raise ValueError(f"reference_template must be {expected}")
    path = (REFERENCE_PAGES / expected).resolve()
    if reference_template_path is not None and Path(str(reference_template_path)).resolve() != path:
        raise ValueError(f"reference_template_path must be {path}")
    return path
