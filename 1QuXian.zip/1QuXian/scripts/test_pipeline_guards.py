#!/usr/bin/env python3
"""Regression checks for the timeline gates that previously allowed bad renders."""
from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

from preflight import run_preflight
from fast_pipeline import renderer_script
from render_continuous_timeline import build_ffmpeg_command
from render_market_chart import render as render_market_chart
from review_render import duration_matches
from render_segmented_timeline import split_timeline
from validate_timeline import validate


def timeline(duration: float = 8.5) -> dict:
    assets = []
    shots = []
    for index in range(2):
        asset_id = f"a{index}"
        assets.append({
            "id": asset_id, "local_path": f"asset-{index}.mp4", "sha256": str(index) * 64,
            "status": "unused", "use_count": 0, "seven_day_eligible": True, "dedupe_clear": True,
            "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
            "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
            "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
        })
        start = 0.0 if index == 0 else 4.0
        end = 4.0 if index == 0 else duration
        shots.append({
            "id": f"s{index}", "start": start, "end": end,
            "source_in": 0.0, "source_out": end - start, "keyword": "行情",
            "subject": "市场", "action": "变化", "result": "形成信号",
            "asset_id": asset_id, "selection_mode": "semantic_index",
            "script_semantics": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "semantic_fields": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "theme_mapping": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "information_task": "data",
            "script_range": {"start": start, "end": end},
            "chapter_id": "c01",
            "selection_reason": "主体、动作、地点、设备与当前文案匹配",
            "candidate_asset_ids": [asset_id, f"candidate-{index}"],
        })
    return {
        "title": "测试", "script_path": "script.md", "main_thesis": "市场信号",
        "duration_seconds": duration, "assets": assets, "shots": shots,
        "chapters": [{
            "id": "c01", "start": 0.0, "end": duration, "thesis": "市场信号",
            "information_plan": [{
                "id": "evidence-c01-data", "task": "data", "claim": "资金正在进场",
                "script_range": {"start": 0.0, "end": duration},
            }],
        }],
        "dedupe_audit": {"lookback_hours": 168, "checked_at": datetime.now(timezone.utc).isoformat()},
        "chart_inventory": [
            {"chart_kind": "relative_return", "status": "generated", "overlay_ids": ["info"]},
            {"chart_kind": "futures_position", "status": "skipped", "skip_reason": "文案无持仓数据"},
            {"chart_kind": "dual_axis_trend", "status": "skipped", "skip_reason": "文案无双轴数据"},
            {"chart_kind": "kline_wave", "status": "skipped", "skip_reason": "文案无波浪结构"},
            {"chart_kind": "kline_fibonacci", "status": "skipped", "skip_reason": "文案无回撤数据"},
        ],
        "overlays": [
            {
                "id": "hook", "type": "hook", "role": "hook", "start": 0.0, "end": 4.0,
                "chapter_id": "c01", "evidence_id": "evidence-c01-data",
                "background_shot_id": "s0", "image_path": "hook.png", "frame_pattern": "hook/%04d.png",
                "chinese_text": "市场信号", "hook_color_fallback": "white",
                "hook_text_colors": {line: {"color": "#FFFFFF", "opacity": 1.0} for line in ("thesis", "judgment", "evidence")},
                "hook_contrast": {line: {"background_luminance": 0.02, "contrast_ratio": 17.5} for line in ("thesis", "judgment", "evidence")},
            },
            {
                "id": "info", "type": "chart", "information_task": "data", "start": 4.0, "end": 8.5,
                "chapter_id": "c01", "evidence_id": "evidence-c01-data",
                "background_shot_id": "s1", "image_path": "info.png", "chinese_text": "资金正在进场",
                "chart_kind": "relative_return", "data_chain_id": "chain-1",
                "data_interval": "一月至七月", "data_metric": "累计涨跌幅", "source_state": "user_copy",
            },
        ],
    }


class TimelineGuardTests(unittest.TestCase):
    def test_seamless_information_pages_are_allowed(self):
        self.assertFalse(validate(timeline()))

    def test_duplicate_information_text_is_rejected(self):
        data = timeline()
        data["overlays"][1]["chinese_text"] = data["overlays"][0]["chinese_text"]
        self.assertTrue(any("duplicate information content" in error for error in validate(data)))

    def test_hook_requires_dynamic_frame_pattern(self):
        data = timeline()
        del data["overlays"][0]["frame_pattern"]
        self.assertTrue(any("frame_pattern" in error for error in validate(data)))

    def test_missing_seven_day_audit_is_rejected(self):
        data = timeline()
        del data["dedupe_audit"]
        self.assertTrue(any("seven-day dedupe audit" in error for error in validate(data)))

    def test_unclean_asset_is_rejected(self):
        data = timeline()
        data["assets"][0]["embedded_subtitles_free"] = False
        self.assertTrue(any("visual cleanliness gate" in error for error in validate(data)))

    def test_planning_fields_are_required(self):
        for field in ("script_semantics", "semantic_fields", "theme_mapping", "information_task", "script_range", "chapter_id", "selection_reason"):
            data = timeline()
            del data["shots"][0][field]
            self.assertTrue(any(field in error for error in validate(data)), field)

    def test_semantic_mirrors_must_match_all_five_fields(self):
        data = timeline()
        data["shots"][0]["theme_mapping"]["keywords"] = "不一致关键词"
        self.assertTrue(any("semantic mirrors disagree on keywords" in error for error in validate(data)))

    def test_removed_ordinary_page_types_are_rejected(self):
        for removed in ("fact", "data", "number", "comparison", "causal"):
            data = timeline()
            data["overlays"][1]["type"] = removed
            self.assertTrue(any("invalid type" in error for error in validate(data)), removed)

    def test_preflight_propagates_invalid_overlay_type(self):
        data = timeline()
        data["overlays"][1]["type"] = "fact"
        self.assertTrue(any("invalid type" in error for error in run_preflight(data, require_files=False)))

    def test_hook_and_news_use_four_seconds(self):
        hook = timeline()
        hook["overlays"][0]["end"] = 4.5
        self.assertTrue(any("4.0 seconds" in error for error in validate(hook)))

        news = timeline(8.0)
        news["chapters"][0]["end"] = 8.0
        news["chapters"][0]["information_plan"][0].update({"task": "news", "script_range": {"start": 0.0, "end": 8.0}})
        news["shots"][1].update({"end": 8.0, "source_out": 4.0, "script_range": {"start": 4.0, "end": 8.0}})
        news["chart_inventory"][0] = {"chart_kind": "relative_return", "status": "skipped", "skip_reason": "本章是新闻证据"}
        news["overlays"][1] = {
            "id": "info", "type": "news", "start": 4.0, "end": 8.5,
            "chapter_id": "c01", "evidence_id": "evidence-c01-data",
            "background_shot_id": "s1", "image_path": "info.png", "chinese_text": "新闻证据",
        }
        self.assertTrue(any("4.0 seconds" in error for error in validate(news)))

    def test_chart_page_uses_existing_information_task_and_4_5_seconds(self):
        data = timeline()
        data["overlays"][1].update({
            "type": "chart", "information_task": "data", "end": 8.5,
            "chart_kind": "relative_return", "data_chain_id": "chain-1",
            "data_interval": "一月至七月", "data_metric": "累计涨跌幅",
            "source_state": "user_copy",
        })
        self.assertFalse(validate(data))

    def test_chart_page_rejects_four_second_duration(self):
        data = timeline(8.0)
        data["chapters"][0]["end"] = 8.0
        data["chapters"][0]["information_plan"][0]["script_range"]["end"] = 8.0
        data["shots"][1]["end"] = 8.0
        data["shots"][1]["source_out"] = 4.0
        data["shots"][1]["script_range"]["end"] = 8.0
        data["overlays"][1]["end"] = 8.0
        data["overlays"][1].update({
            "type": "chart", "information_task": "data",
            "chart_kind": "relative_return", "data_chain_id": "chain-1",
            "data_interval": "一月至七月", "data_metric": "累计涨跌幅",
            "source_state": "user_copy",
        })
        self.assertTrue(any("4.5 seconds" in error for error in validate(data)))

    def test_market_chart_renderer_creates_png(self):
        config = {
            "id": "chart-test", "chart_kind": "relative_return", "title": "指数表现",
            "data_interval": "一月至七月", "data_metric": "累计涨跌幅",
            "series": [{"label": "指数甲", "values": [0, 1, 0.5, 2]}],
        }
        with tempfile.TemporaryDirectory() as folder:
            output = render_market_chart(config, Path(folder), (640, 360))
            self.assertTrue(output.is_file())

    def test_white_hook_fallback_still_requires_measured_contrast(self):
        data = timeline()
        del data["overlays"][0]["hook_contrast"]
        self.assertTrue(any("white fallback" in error for error in validate(data)))

    def test_planned_information_page_requires_same_chapter_evidence(self):
        data = timeline()
        data["overlays"][1]["evidence_id"] = "not-planned"
        self.assertTrue(any("evidence_id" in error for error in validate(data)))

    def test_information_page_cannot_reference_another_chapter(self):
        data = timeline()
        data["chapters"].append({
            "id": "c02", "start": 8.0, "end": 9.0, "thesis": "第二章",
            "information_plan": [{"id": "evidence-c02", "task": "data", "claim": "第二章数据", "script_range": {"start": 8.0, "end": 9.0}}],
        })
        data["overlays"][1]["evidence_id"] = "evidence-c02"
        self.assertTrue(any("another chapter" in error for error in validate(data)))

    def test_long_broll_run_is_allowed_when_each_cut_is_2_to_5_seconds(self):
        data = timeline(12.0)
        data["shots"] = []
        data["assets"] = []
        for index in range(3):
            asset_id = f"b{index}"
            data["assets"].append({
                "id": asset_id, "local_path": f"{asset_id}.mp4", "sha256": str(index + 3) * 64,
                "status": "unused", "use_count": 0, "seven_day_eligible": True, "dedupe_clear": True,
                "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
                "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
                "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
            })
            data["shots"].append({
                "id": f"b{index}", "start": index * 4.0, "end": (index + 1) * 4.0, "source_in": 0.0, "source_out": 4.0,
                "keyword": "市场", "subject": "交易员", "action": "观察", "result": "形成信号", "asset_id": asset_id,
                "selection_mode": "semantic_index", "script_semantics": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "semantic_fields": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "theme_mapping": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "information_task": "broll", "script_range": {"start": index * 4.0, "end": (index + 1) * 4.0}, "chapter_id": "c01",
                "selection_reason": "当前章节的交易员观察行情实拍", "candidate_asset_ids": [asset_id, f"candidate-{index}"],
            })
        data["overlays"][0]["background_shot_id"] = "b0"
        data["overlays"][1]["background_shot_id"] = "b1"
        self.assertFalse(validate(data))

    def test_broll_cut_shorter_than_two_seconds_is_rejected(self):
        data = timeline()
        data["shots"][0]["information_task"] = "broll"
        data["shots"][0]["end"] = 1.5
        data["shots"][0]["source_out"] = 1.5
        data["shots"][1]["start"] = 1.5
        self.assertTrue(any("broll duration" in error for error in validate(data)))

    def test_false_global_eligibility_credential_is_rejected(self):
        data = timeline()
        asset = data["assets"][1]
        asset["seven_day_eligible"] = False
        self.assertTrue(any("seven-day dedupe status" in error for error in validate(data)))

    def test_historical_delivered_hash_is_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            ledger = root / "2026-08-06_文档_旧片_asset-ledger.json"
            ledger.write_text('{"assets":[{"sha256":"' + "0" * 64 + '"}]}', encoding="utf-8")
            import hashlib, json
            gate = {
                "terminal_allowed": True,
                "checked_at": datetime.now(timezone.utc).isoformat(),
                "sha256": {"ledger": hashlib.sha256(ledger.read_bytes()).hexdigest()},
            }
            (root / "2026-08-06_文档_旧片_交付门禁.json").write_text(json.dumps(gate), encoding="utf-8")
            errors = run_preflight(data, require_files=False, history_root=root)
        self.assertTrue(any("material identity was used" in error for error in errors))

    def test_chart_inventory_must_cover_every_kind(self):
        data = timeline()
        data["chart_inventory"].pop()
        self.assertTrue(any("cover all five" in error for error in validate(data)))

    def test_generated_inventory_entry_must_bind_matching_overlay(self):
        data = timeline()
        data["chart_inventory"][0]["overlay_ids"] = ["missing"]
        self.assertTrue(any("bind a matching chart overlay" in error for error in validate(data)))

    def test_duplicate_overlay_files_are_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            duplicate = Path(folder) / "same.png"
            duplicate.write_bytes(b"same")
            data["overlays"][0]["image_path"] = str(duplicate)
            data["overlays"][1]["image_path"] = str(duplicate)
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("duplicate information image" in error for error in errors))

    def test_continuous_renderer_rejects_long_timeline(self):
        data = timeline(120.0)
        data["shots"][-1]["end"] = 120.0
        with self.assertRaisesRegex(ValueError, "segmented"):
            build_ffmpeg_command(data, "out.mp4", ffmpeg="ffmpeg")

    def test_renderer_requests_exact_frame_count(self):
        command = build_ffmpeg_command(timeline(), "out.mp4", ffmpeg="ffmpeg")
        frames_index = command.index("-frames:v")
        self.assertEqual(command[frames_index + 1], "255")

    def test_duration_tolerance_is_one_frame(self):
        self.assertTrue(duration_matches(120.0, 120.03))
        self.assertFalse(duration_matches(120.0, 120.04))

    def test_formal_entry_selects_segmented_renderer_for_long_timeline(self):
        self.assertEqual(renderer_script(timeline(120.0)), "render_segmented_timeline.py")
        self.assertEqual(renderer_script(timeline()), "render_continuous_timeline.py")

    def test_segmenter_preserves_all_shots_without_large_segments(self):
        data = timeline(100.0)
        data["shots"] = []
        data["assets"] = []
        data["overlays"] = []
        for index in range(20):
            data["shots"].append({"id": f"s{index}", "start": index * 5.0, "end": (index + 1) * 5.0, "asset_id": f"a{index}"})
            data["assets"].append({"id": f"a{index}", "local_path": f"a{index}.mp4"})
        segments = split_timeline(data)
        self.assertEqual(sum(len(item["shots"]) for item in segments), 20)
        self.assertTrue(all(len(item["shots"]) <= 5 and item["duration_seconds"] <= 25.0 for item in segments))


if __name__ == "__main__":
    unittest.main()
