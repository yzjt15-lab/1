#!/usr/bin/env python3
"""Create or reuse a static contact sheet; motion previews stay optional."""
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from build_asset_index import ffmpeg_probe
from speed_common import content_key, file_signature, find_ffmpeg


def adaptive_interval(duration: float, cols: int, rows: int) -> float:
    return max(0.25, float(duration) / (cols * rows) * 0.98)


def make_contact_sheet(source: Path, cache_dir: Path, interval=None, cols=4, rows=3, ffmpeg: str | None = None) -> Path:
    if interval is None:
        duration = ffmpeg_probe(source, ffmpeg).get("duration")
        interval = adaptive_interval(duration, cols, rows) if duration else 5.0
    params = {"interval": interval, "cols": cols, "rows": rows, "cell_width": 320}
    key = content_key({"source": file_signature(source), "params": params}, 20)
    output = cache_dir / f"contact_{key}.jpg"
    if output.exists():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    vf = f"fps=1/{interval},scale=320:-2,tile={cols}x{rows}"
    subprocess.run([find_ffmpeg(ffmpeg), "-y", "-i", str(source), "-vf", vf, "-frames:v", "1", "-update", "1", str(output)], check=True)
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--interval", type=float)
    parser.add_argument("--ffmpeg")
    args = parser.parse_args()
    print(make_contact_sheet(Path(args.source), Path(args.cache_dir), args.interval, ffmpeg=args.ffmpeg))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
