#!/usr/bin/env python3
"""Render black-gold hook frames and wrappers for verified news screenshots."""
from __future__ import annotations

import argparse
import json
import os
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

from speed_common import content_key, find_chinese_font

GOLD, WHITE, GRAY = (242, 200, 107, 255), (248, 249, 251, 245), (198, 204, 211, 205)


def _font(size: int, bold: bool = False):
    return ImageFont.truetype(find_chinese_font(bold), size)


def _center(draw, box, text, font, fill):
    bounds = draw.textbbox((0, 0), str(text), font=font)
    draw.text(((box[0] + box[2] - bounds[2]) / 2, (box[1] + box[3] - bounds[3]) / 2), str(text), font=font, fill=fill)


def render_hook_frames(config: dict, output_dir: Path, size=(1920, 1080), fps=30, duration=4.0) -> tuple[Path, str]:
    lines = config.get("hook_lines") or str(config.get("chinese_text", "")).splitlines()
    if isinstance(lines, dict):
        lines = [lines.get(key, "") for key in ("thesis", "judgment", "evidence")]
    lines = ([str(value) for value in lines if str(value).strip()] + ["", "", ""])[:3]
    fallback = config.get("hook_color_fallback") == "white"
    colors = [WHITE] * 3 if fallback else [GOLD, WHITE, GRAY]
    signature = content_key({"template_version": 2, "size": size, "lines": lines, "colors": colors, "fps": fps, "duration": duration}, 20)
    folder = Path(output_dir) / f"hook_{signature}"
    stable = folder / "0030.png"
    total = max(31, round(fps * duration))
    if not (folder / f"{total - 1:04d}.png").exists():
        folder.mkdir(parents=True, exist_ok=True)
        width, height = size
        fonts = [_font(width // 18, True), _font(width // 21, True), _font(width // 29, True)]
        centers = [height * .34, height * .51, height * .66]
        for frame in range(31):
            image = Image.new("RGBA", size, (0, 0, 0, 0))
            ImageDraw.Draw(image, "RGBA").rectangle((0, int(height * .08), width, int(height * .895)), fill=(0, 0, 0, 205))
            for index, (line, font, color, center) in enumerate(zip(lines, fonts, colors, centers)):
                progress = min(1.0, max(0.0, (frame - index * 8) / 8))
                if not line or progress <= 0:
                    continue
                layer = Image.new("RGBA", size, (0, 0, 0, 0))
                ld = ImageDraw.Draw(layer)
                bounds = ld.textbbox((0, 0), line, font=font)
                x, y = (width - bounds[2]) // 2, round(center - (bounds[3] - bounds[1]) / 2)
                ld.text((x, y), line, font=font, fill=color)
                image.alpha_composite(layer.crop((0, 0, round(width * progress), height)), (0, 0))
            image.save(folder / f"{frame:04d}.png")
        for frame in range(31, total):
            target = folder / f"{frame:04d}.png"
            try:
                os.link(stable, target)
            except OSError:
                shutil.copyfile(stable, target)
    return stable, str((folder / "%04d.png").resolve())


def render_news_page(config: dict, screenshot_path: Path, output_dir: Path, size=(1920, 1080)) -> Path:
    screenshot_path = Path(screenshot_path)
    if not screenshot_path.exists():
        raise FileNotFoundError(screenshot_path)
    signature = content_key({"template_version": 1, "size": size, "config": config, "screenshot": str(screenshot_path.resolve()), "mtime": screenshot_path.stat().st_mtime_ns}, 20)
    output = Path(output_dir) / f"news_{signature}.png"
    if output.exists():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = size
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    panel = (int(width * .15), int(height * .13), int(width * .85), int(height * .855))
    draw.rounded_rectangle(panel, radius=14, fill=(7, 18, 33, 230), outline=GOLD, width=2)
    headline = str(config.get("headline") or config.get("title") or "市场快讯")
    draw.text((panel[0] + 44, panel[1] + 26), headline, font=_font(width // 36, True), fill=WHITE)
    date_text = str(config.get("date_text") or "")
    if date_text:
        draw.text((panel[0] + 48, panel[1] + 88), date_text, font=_font(width // 70), fill=GRAY)
    inner = (panel[0] + 38, panel[1] + 130, panel[2] - 38, panel[3] - 32)
    shot = Image.open(screenshot_path).convert("RGBA")
    shot = ImageOps.contain(shot, (inner[2] - inner[0], inner[3] - inner[1]), Image.Resampling.LANCZOS)
    x, y = (inner[0] + inner[2] - shot.width) // 2, (inner[1] + inner[3] - shot.height) // 2
    draw.rounded_rectangle((x - 3, y - 3, x + shot.width + 3, y + shot.height + 3), radius=8, fill=(238, 241, 246, 255))
    image.alpha_composite(shot, (x, y))
    image.save(output)
    return output


def render_overlay(config: dict, output_dir: Path, size=(1920, 1080)) -> Path:
    if config.get("type") == "news":
        return render_news_page(config, Path(config["screenshot_path"]), output_dir, size)
    if config.get("type") == "hook":
        return render_hook_frames(config, output_dir, size)[0]
    raise ValueError("overlay type must be hook or news")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8-sig"))
    print(render_overlay(config, Path(args.output_dir), (args.width, args.height)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
