#!/usr/bin/env python3
"""Render transparent hook frames and wrappers for verified news screenshots."""
from __future__ import annotations

import argparse
import json
import os
import shutil
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

from page_reference_contract import PAGE_SIZE, approved_reference_path
from speed_common import content_key, find_chinese_font

GOLD, WHITE, GRAY = (242, 200, 107, 255), (248, 249, 251, 245), (198, 204, 211, 205)


def _font(size: int, bold: bool = False):
    return ImageFont.truetype(find_chinese_font(bold), size)


def _fit_font(draw, text: str, size: int, max_width: int):
    current = _font(size, True)
    while current.size > 28 and draw.textbbox((0, 0), text, font=current)[2] > max_width:
        current = current.font_variant(size=current.size - 1)
    return current


def _center(draw, box, text, font, fill):
    bounds = draw.textbbox((0, 0), str(text), font=font)
    draw.text(((box[0] + box[2] - bounds[2]) / 2, (box[1] + box[3] - bounds[3]) / 2), str(text), font=font, fill=fill)


def _hook_color(config: dict, line: str, default: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    if config.get("hook_color_fallback") == "white":
        return WHITE
    spec = config.get("hook_text_colors", {}).get(line, {})
    value = str(spec.get("color", ""))
    if len(value) == 7 and value.startswith("#"):
        try:
            rgb = tuple(int(value[index:index + 2], 16) for index in (1, 3, 5))
            opacity = max(0.0, min(1.0, float(spec.get("opacity", 1.0))))
            return (*rgb, round(255 * opacity))
        except (TypeError, ValueError):
            pass
    return default


def render_hook_frames(config: dict, output_dir: Path, size=PAGE_SIZE, fps=30, duration=4.0) -> tuple[Path, str]:
    approved_reference_path("hook", config.get("reference_template"), config.get("reference_template_path"))
    lines = config.get("hook_lines") or str(config.get("chinese_text", "")).splitlines()
    if isinstance(lines, dict):
        lines = [lines.get(key, "") for key in ("thesis", "judgment", "evidence")]
    lines = ([str(value) for value in lines if str(value).strip()] + ["", "", ""])[:3]
    colors = [_hook_color(config, line, default) for line, default in zip(("thesis", "judgment", "evidence"), (GOLD, WHITE, GRAY))]
    signature = content_key({"template_version": 3, "size": size, "lines": lines, "colors": colors, "fps": fps, "duration": duration}, 20)
    folder = Path(output_dir) / f"hook_{signature}"
    stable = folder / "0030.png"
    total = max(31, round(fps * duration))
    if not (folder / f"{total - 1:04d}.png").exists():
        folder.mkdir(parents=True, exist_ok=True)
        width, height = size
        probe = ImageDraw.Draw(Image.new("RGBA", size))
        fonts = [_fit_font(probe, line, size, width - 120) for line, size in zip(lines, (104, 82, 58))]
        centers = [height * .30, height * .51, height * .70]
        for frame in range(31):
            image = Image.new("RGBA", size, (0, 0, 0, 0))
            for index, (line, font, color, center) in enumerate(zip(lines, fonts, colors, centers)):
                progress = min(1.0, max(0.0, (frame - index * 8) / 8))
                if not line or progress <= 0:
                    continue
                layer = Image.new("RGBA", size, (0, 0, 0, 0))
                ld = ImageDraw.Draw(layer)
                bounds = ld.textbbox((0, 0), line, font=font)
                x, y = (width - bounds[2]) // 2, round(center - (bounds[3] - bounds[1]) / 2)
                ld.text((x, y), line, font=font, fill=color, stroke_width=max(3, width // 480), stroke_fill=(0, 0, 0, 230))
                image.alpha_composite(layer.crop((0, 0, round(width * progress), height)), (0, 0))
            image.save(folder / f"{frame:04d}.png")
        for frame in range(31, total):
            target = folder / f"{frame:04d}.png"
            try:
                os.link(stable, target)
            except OSError:
                shutil.copyfile(stable, target)
    return stable, str((folder / "%04d.png").resolve())


def render_news_page(config: dict, screenshot_path: Path, output_dir: Path, size=PAGE_SIZE) -> Path:
    approved_reference_path("news", config.get("reference_template"), config.get("reference_template_path"))
    screenshot_path = Path(screenshot_path)
    if not screenshot_path.exists():
        raise FileNotFoundError(screenshot_path)
    signature = content_key({"template_version": 2, "size": size, "screenshot": str(screenshot_path.resolve()), "mtime": screenshot_path.stat().st_mtime_ns}, 20)
    output = Path(output_dir) / f"news_{signature}.png"
    if output.exists():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    shot = ImageOps.contain(Image.open(screenshot_path).convert("RGBA"), size, Image.Resampling.LANCZOS)
    x, y = (size[0] - shot.width) // 2, (size[1] - shot.height) // 2
    image.alpha_composite(shot, (x, y))
    image.save(output)
    return output


def render_overlay(config: dict, output_dir: Path, size=PAGE_SIZE) -> Path:
    if config.get("type") == "news":
        return render_news_page(config, Path(config["screenshot_path"]), output_dir, size)
    if config.get("type") == "hook":
        return render_hook_frames(config, output_dir, size)[0]
    raise ValueError("overlay type must be hook or news")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--width", type=int, default=1080)
    parser.add_argument("--height", type=int, default=830)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8-sig"))
    print(render_overlay(config, Path(args.output_dir), (args.width, args.height)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
