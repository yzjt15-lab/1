"""Regression: reject the two defects found in the 3965 project."""
from __future__ import annotations

import sys
import subprocess
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from preflight import derived_source_id, has_pillarbox, validate_selection_manifest  # noqa: E402


def main() -> None:
    assert derived_source_id(Path("Pexels_36435763_001.mp4"), None) == derived_source_id(Path("Pexels_36435763_002.mp4"), None)
    with tempfile.TemporaryDirectory() as directory:
        portrait_container = Path(directory) / "portrait-in-landscape.mp4"
        subprocess.run([
            "ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=black:s=1280x720:d=1",
            "-vf", "drawbox=x=460:y=0:w=360:h=720:color=red:t=fill", "-c:v", "libx264", str(portrait_container),
        ], check=True)
        assert has_pillarbox(portrait_container, 0, 0.8), "embedded portrait fixture must be rejected"
    selected = {"asset-01", "asset-02"}
    manifest = {
        "source": "user-authorized library selection", "user_authorization": "continue",
        "selected_assets": sorted(selected),
        "candidates": [{"asset_id": asset_id, "local_path": asset_id + ".mp4", "sha256": "a" * 64, "source_in": 1.0, "source_out": 5.0, "frame_evidence": asset_id + ".jpg"} for asset_id in selected],
    }
    assert not validate_selection_manifest(manifest, selected)
    manifest["candidates"][0].pop("frame_evidence")
    assert validate_selection_manifest(manifest, selected)
    manifest["candidates"][0]["frame_evidence"] = "asset-01.jpg"
    manifest["selected_assets"] = ["asset-01"]
    assert validate_selection_manifest(manifest, selected)
    print("source and effective-frame guards passed")


if __name__ == "__main__":
    main()
