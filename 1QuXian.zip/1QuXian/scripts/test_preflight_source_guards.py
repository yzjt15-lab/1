"""Regression: reject the two defects found in the 3965 project."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from preflight import derived_source_id, has_pillarbox  # noqa: E402


ROOT = Path(r"C:\Users\28723\.codex\SuCaiKu\5. 股市与市场")


def main() -> None:
    same_source = sorted(ROOT.glob("*Pexels_36435763_*.mp4"))
    assert len(same_source) >= 2
    assert derived_source_id(same_source[0], None) == derived_source_id(same_source[1], None)
    portrait_container = next(ROOT.glob("*Pexels_34975243_011.mp4"))
    assert has_pillarbox(portrait_container, 0, 2), "known embedded portrait fixture must be rejected"
    print("source and effective-frame guards passed")


if __name__ == "__main__":
    main()
