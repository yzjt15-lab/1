#!/usr/bin/env python3
"""Run technical delivery checks and emit a per-shot review report."""
import argparse
import json
import os
import re
import shutil
import subprocess
import tempfile
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from make_visual_approval import sha256
from speed_common import find_ffmpeg


REQUIRED_VISUAL_CHECKS = {"title_bar", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder"}
FRAME_TOLERANCE_SECONDS = 1 / 30 + 1e-6


def duration_matches(expected: float, actual: float) -> bool:
    return abs(float(expected) - float(actual)) <= FRAME_TOLERANCE_SECONDS


def same_path(left: str | None, right: str | None) -> bool:
    if not left or not right:
        return False
    try:
        return Path(left).resolve() == Path(right).resolve()
    except (OSError, TypeError, ValueError):
        return False


def validate_reference_audio_contract(timeline: dict, reference_audio: str | None) -> list[str]:
    errors: list[str] = []
    timeline_audio = timeline.get("reference_audio_path")
    if not reference_audio:
        if timeline_audio:
            errors.append("timeline reference_audio_path requires --reference-audio")
        return errors
    if not same_path(timeline_audio, reference_audio):
        errors.append("reference audio does not match timeline reference_audio_path")
    if not isinstance(timeline.get("reference_audio_segments"), list) or not timeline["reference_audio_segments"]:
        errors.append("reference audio segments are missing")
    return errors


def build_review_rows(shots: list[dict], approved_ids: set[str], shot_checks: dict) -> list[dict]:
    required = ("visible_subject", "visible_action", "visible_location", "visible_equipment")
    rows = []
    for shot in shots:
        shot_id = shot.get("id")
        observation = shot_checks.get(shot_id, {}) if isinstance(shot_checks, dict) else {}
        semantic_checked = (
            isinstance(observation, dict)
            and observation.get("semantic_match") is True
            and all(str(observation.get(field, "")).strip() for field in required)
        )
        rows.append({"id": shot_id, "start": shot.get("start"), "end": shot.get("end"), "keyword": shot.get("keyword"), "checked": shot_id in approved_ids, "semantic_checked": semantic_checked})
    return rows


def make_shot_contact_sheet(video: str, shots: list[dict], output: str, ffmpeg: str) -> None:
    points = []
    labels = []
    for shot in shots:
        start, end = float(shot["start"]), float(shot["end"])
        for suffix, moment in (("A", start + min(0.1, (end - start) / 4)), ("M", (start + end) / 2), ("B", end - min(0.1, (end - start) / 4))):
            points.append(moment)
            labels.append(f"{shot.get('id', '?')}-{suffix}")
    if not points:
        return
    rows = math.ceil(len(points) / 4)
    image = Image.new("RGB", (1280, rows * 180), "black")
    with tempfile.TemporaryDirectory() as directory:
        for index, moment in enumerate(points):
            frame = Path(directory) / f"{index:03d}.jpg"
            subprocess.run([ffmpeg, "-y", "-ss", f"{moment:.3f}", "-i", video, "-frames:v", "1", "-vf", "scale=320:180", str(frame)], check=True, capture_output=True)
            image.paste(Image.open(frame).convert("RGB"), ((index % 4) * 320, (index // 4) * 180))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    for index, label in enumerate(labels):
        x, y = (index % 4) * 320, (index // 4) * 180
        draw.rectangle((x, y, x + 58, y + 18), fill="black")
        draw.text((x + 4, y + 3), label, fill="white", font=font)
    image.save(output, quality=90)


def probe(path: str) -> dict:
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        cmd = [ffprobe, "-v", "error", "-show_entries", "format=duration:stream=codec_type,codec_name,duration", "-of", "json", path]
        return json.loads(subprocess.check_output(cmd, text=True, encoding="utf-8"))
    ffmpeg = os.environ.get("CODEX_FFMPEG") or shutil.which("ffmpeg") or "ffmpeg"
    result = subprocess.run([ffmpeg, "-hide_banner", "-i", path, "-frames:v", "1", "-f", "null", "NUL"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    report = result.stderr
    match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", report)
    if not match:
        raise RuntimeError(f"could not read duration from ffmpeg output for {path}")
    duration = int(match.group(1)) * 3600 + int(match.group(2)) * 60 + float(match.group(3))
    streams = [{"codec_type": "audio" if re.search(r"Audio:", line) else "video"} for line in report.splitlines() if "Stream #" in line and ("Audio:" in line or "Video:" in line)]
    return {"format": {"duration": duration}, "streams": streams}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--reference-audio")
    parser.add_argument("--source-audio")
    parser.add_argument("--report", required=True)
    parser.add_argument("--contact-sheet")
    parser.add_argument("--visual-approval")
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8"))
    approval = json.loads(Path(args.visual_approval).read_text(encoding="utf-8")) if args.visual_approval else {}
    errors: list[str] = validate_reference_audio_contract(timeline, args.reference_audio)
    try:
        video = probe(args.video)
        duration = float(video["format"]["duration"])
        if args.source_audio:
            audio = probe(args.source_audio)
            source_duration = float(audio["format"]["duration"])
        else:
            source_duration = float(timeline["duration_seconds"])
        if not duration_matches(source_duration, duration):
            errors.append("video duration differs from source audio or target duration")
        if args.source_audio and not any(item.get("codec_type") == "audio" for item in video.get("streams", [])):
            errors.append("rendered video has no audio stream")
        if not args.source_audio and any(item.get("codec_type") == "audio" for item in video.get("streams", [])):
            errors.append("rendered video unexpectedly contains audio without narration_audio")
        if args.visual_approval:
            ffmpeg = find_ffmpeg(os.environ.get("CODEX_FFMPEG"))
            decode = subprocess.run([ffmpeg, "-hide_banner", "-i", args.video, "-vf", "blackdetect=d=0.2:pix_th=0.10", "-f", "null", "NUL"], capture_output=True, text=True, encoding="utf-8", errors="replace")
            if decode.returncode != 0:
                errors.append("full decode failed: " + decode.stderr.strip()[:300])
            if "black_start:" in decode.stderr:
                errors.append("black frame interval detected")
            if any(marker in decode.stderr for marker in ("Non-monotonic DTS", "backward in time")):
                errors.append("timestamp regression detected")
    except Exception as exc:
        errors.append(f"technical review failed: {exc}")
        duration = None
        source_duration = None
    contact_sheet = args.contact_sheet or str(Path(args.report).with_suffix(".jpg"))
    try:
        if not args.contact_sheet:
            make_shot_contact_sheet(args.video, timeline.get("shots", []), contact_sheet, find_ffmpeg(os.environ.get("CODEX_FFMPEG")))
    except Exception as exc:
        errors.append(f"contact sheet failed: {exc}")
    if args.visual_approval:
        expected_hashes = {
            "video_sha256": sha256(Path(args.video)),
            "timeline_sha256": sha256(Path(args.timeline)),
            "contact_sheet_sha256": sha256(Path(contact_sheet)),
        }
        hashes = approval.get("hashes", {})
        if not isinstance(hashes, dict) or any(hashes.get(key) != value for key, value in expected_hashes.items()):
            errors.append("visual approval artifact hashes do not match")
    approved_ids = set(approval.get("approved_shot_ids", []))
    checks = approval.get("checks", {})
    rows = build_review_rows(timeline.get("shots", []), approved_ids, approval.get("shot_checks", {}))
    unchecked = [row["id"] for row in rows if not row["checked"]]
    if unchecked:
        errors.append("visual approval missing for shots: " + ", ".join(unchecked))
    if args.visual_approval:
        unreviewed = [row["id"] for row in rows if not row["semantic_checked"]]
        if unreviewed:
            errors.append("semantic visual review missing for shots: " + ", ".join(unreviewed))
    missing_checks = sorted(check for check in REQUIRED_VISUAL_CHECKS if checks.get(check) is not True)
    if missing_checks:
        errors.append("visual checks missing: " + ", ".join(missing_checks))
    report = {
        "video": args.video,
        "timeline": str(Path(args.timeline).resolve()),
        "timeline_sha256": sha256(Path(args.timeline)),
        "reference_audio": args.reference_audio,
        "source_audio": args.source_audio,
        "video_duration": duration,
        "audio_duration": source_duration if args.source_audio else None,
        "target_duration": float(timeline["duration_seconds"]),
        "shots": rows,
        "contact_sheet": contact_sheet,
        "contact_sheet_sha256": sha256(Path(contact_sheet)) if Path(contact_sheet).is_file() else None,
        "visual_approval": args.visual_approval,
        "visual_approval_sha256": sha256(Path(args.visual_approval)) if args.visual_approval and Path(args.visual_approval).is_file() else None,
        "semantic_reviewed_shot_ids": [row["id"] for row in rows if row["semantic_checked"]],
        "errors": errors,
        "ok": not errors,
    }
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
