#!/usr/bin/env python3
"""Run technical delivery checks and emit a per-shot review report."""
import argparse
import json
import re
import shutil
import subprocess
import math
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from make_visual_approval import sha256
from speed_common import find_ffmpeg


REQUIRED_VISUAL_CHECKS = {"vertical_layout", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder"}
# Segmented concat can discard one boundary frame; accept at most two 30fps frames.
FRAME_TOLERANCE_SECONDS = 2 / 30 + 1e-6


def duration_matches(expected: float, actual: float) -> bool:
    return abs(float(expected) - float(actual)) <= FRAME_TOLERANCE_SECONDS


def build_review_rows(shots: list[dict], approved_ids: set[str], shot_checks: dict) -> list[dict]:
    required = ("visible_subject", "visible_action", "visible_location", "visible_equipment")
    rows = []
    for shot in shots:
        shot_id = shot.get("id")
        observation = shot_checks.get(shot_id, {}) if isinstance(shot_checks, dict) else {}
        semantic_checked = (
            isinstance(observation, dict)
            and observation.get("semantic_match") is True
            and all(str(observation.get(field, "")).strip() for field in required)
        )
        rows.append({"id": shot_id, "start": shot.get("start"), "end": shot.get("end"), "keyword": shot.get("keyword"), "checked": shot_id in approved_ids, "semantic_checked": semantic_checked})
    return rows


def make_shot_contact_sheet(video: str, shots: list[dict], output: str, ffmpeg: str) -> None:
    if not shots:
        return
    batches = [shots] if len(shots) <= 12 else [shots[index:index + 16] for index in range(0, len(shots), 16)]
    columns, cell_width = (4, 320) if len(batches) == 1 else (8, 180)
    rendered = []
    with tempfile.TemporaryDirectory() as directory:
        for batch_index, batch in enumerate(batches):
            points, labels = [], []
            for shot in batch:
                start, end = float(shot["start"]), float(shot["end"])
                for suffix, moment in (("A", start + min(0.1, (end - start) / 4)), ("M", (start + end) / 2), ("B", end - min(0.1, (end - start) / 4))):
                    points.append(moment)
                    labels.append(f"{shot.get('id', '?')}-{suffix}")
            frame_numbers = [max(0, round(moment * 30)) for moment in points]
            selection = "+".join(f"eq(n\\,{number})" for number in frame_numbers)
            rows = math.ceil(len(frame_numbers) / columns)
            part = Path(output) if len(batches) == 1 else Path(directory) / f"part-{batch_index:02d}.jpg"
            vf = f"select='{selection}',scale={cell_width}:-2,tile={columns}x{rows}"
            subprocess.run([ffmpeg, "-y", "-i", video, "-vf", vf, "-frames:v", "1", "-update", "1", str(part)], check=True, capture_output=True)
            image = Image.open(part).convert("RGB")
            draw = ImageDraw.Draw(image)
            cell_height = image.height // rows
            font = ImageFont.load_default()
            for index, label in enumerate(labels):
                x, y = (index % columns) * cell_width, (index // columns) * cell_height
                draw.rectangle((x, y, x + 58, y + 18), fill="black")
                draw.text((x + 4, y + 3), label, fill="white", font=font)
            rendered.append(image)
        if len(rendered) == 1:
            rendered[0].save(output, quality=90)
        else:
            sheet = Image.new("RGB", (max(image.width for image in rendered), sum(image.height for image in rendered)), "black")
            y = 0
            for image in rendered:
                sheet.paste(image, (0, y))
                y += image.height
            sheet.save(output, quality=90)


def probe(path: str) -> dict:
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        cmd = [ffprobe, "-v", "error", "-show_entries", "format=duration:stream=codec_type,codec_name,duration,width,height,r_frame_rate,pix_fmt,sample_aspect_ratio", "-of", "json", path]
        return json.loads(subprocess.check_output(cmd, text=True, encoding="utf-8"))
    ffmpeg = find_ffmpeg()
    result = subprocess.run([ffmpeg, "-hide_banner", "-i", path, "-frames:v", "1", "-f", "null", "NUL"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    report = result.stderr
    match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", report)
    if not match:
        raise RuntimeError(f"could not read duration from ffmpeg output for {path}")
    duration = int(match.group(1)) * 3600 + int(match.group(2)) * 60 + float(match.group(3))
    streams = [{"codec_type": "audio" if re.search(r"Audio:", line) else "video"} for line in report.splitlines() if "Stream #" in line and ("Audio:" in line or "Video:" in line)]
    return {"format": {"duration": duration}, "streams": streams}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--contact-sheet")
    parser.add_argument("--visual-approval")
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8"))
    approval = json.loads(Path(args.visual_approval).read_text(encoding="utf-8")) if args.visual_approval else {}
    errors: list[str] = []
    try:
        video = probe(args.video)
        duration = float(video["format"]["duration"])
        video_stream = next((item for item in video.get("streams", []) if item.get("codec_type") == "video"), {})
        if (video_stream.get("width"), video_stream.get("height")) != (1080, 1920):
            errors.append("rendered video must be 1080x1920")
        if video_stream.get("r_frame_rate") != "30/1" or video_stream.get("pix_fmt") != "yuv420p":
            errors.append("rendered video must be 30 fps yuv420p")
        if video_stream.get("sample_aspect_ratio") != "1:1":
            errors.append("rendered video must use square pixels")
        if not duration_matches(float(timeline["duration_seconds"]), duration):
            errors.append("video duration differs from target duration")
        if any(item.get("codec_type") == "audio" for item in video.get("streams", [])):
            errors.append("rendered curve video unexpectedly contains an audio stream")
        if args.visual_approval:
            ffmpeg = find_ffmpeg()
            decode = subprocess.run([ffmpeg, "-hide_banner", "-i", args.video, "-vf", "blackdetect=d=0.2:pix_th=0.10", "-f", "null", "NUL"], capture_output=True, text=True, encoding="utf-8", errors="replace")
            if decode.returncode != 0:
                errors.append("full decode failed: " + decode.stderr.strip()[:300])
            if "black_start:" in decode.stderr:
                errors.append("black frame interval detected")
            if any(marker in decode.stderr for marker in ("Non-monotonic DTS", "backward in time")):
                errors.append("timestamp regression detected")
    except Exception as exc:
        errors.append(f"technical review failed: {exc}")
        duration = None
    contact_sheet = args.contact_sheet or str(Path(args.report).with_suffix(".jpg"))
    try:
        if not args.contact_sheet:
            make_shot_contact_sheet(args.video, timeline.get("shots", []), contact_sheet, find_ffmpeg())
    except Exception as exc:
        errors.append(f"contact sheet failed: {exc}")
    if args.visual_approval:
        expected_hashes = {
            "video_sha256": sha256(Path(args.video)),
            "timeline_sha256": sha256(Path(args.timeline)),
            "contact_sheet_sha256": sha256(Path(contact_sheet)),
        }
        hashes = approval.get("hashes", {})
        if not isinstance(hashes, dict) or any(hashes.get(key) != value for key, value in expected_hashes.items()):
            errors.append("visual approval artifact hashes do not match")
    approved_ids = set(approval.get("approved_shot_ids", []))
    checks = approval.get("checks", {})
    rows = build_review_rows(timeline.get("shots", []), approved_ids, approval.get("shot_checks", {}))
    unchecked = [row["id"] for row in rows if not row["checked"]]
    if unchecked:
        errors.append("visual approval missing for shots: " + ", ".join(unchecked))
    if args.visual_approval:
        unreviewed = [row["id"] for row in rows if not row["semantic_checked"]]
        if unreviewed:
            errors.append("semantic visual review missing for shots: " + ", ".join(unreviewed))
    missing_checks = sorted(check for check in REQUIRED_VISUAL_CHECKS if checks.get(check) is not True)
    if missing_checks:
        errors.append("visual checks missing: " + ", ".join(missing_checks))
    report = {
        "video": args.video,
        "timeline": str(Path(args.timeline).resolve()),
        "timeline_sha256": sha256(Path(args.timeline)),
        "video_duration": duration,
        "target_duration": float(timeline["duration_seconds"]),
        "shots": rows,
        "contact_sheet": contact_sheet,
        "contact_sheet_sha256": sha256(Path(contact_sheet)) if Path(contact_sheet).is_file() else None,
        "visual_approval": args.visual_approval,
        "visual_approval_sha256": sha256(Path(args.visual_approval)) if args.visual_approval and Path(args.visual_approval).is_file() else None,
        "semantic_reviewed_shot_ids": [row["id"] for row in rows if row["semantic_checked"]],
        "errors": errors,
        "ok": not errors,
    }
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
