#!/usr/bin/env python3
"""Normalize existing asset ledgers into a provenance-only reusable pack."""
from __future__ import annotations

import argparse
from pathlib import Path
from urllib.parse import urlparse

from speed_common import load_json, write_json


def publisher_for_url(url: str) -> str | None:
    host = (urlparse(url).hostname or "").casefold()
    if host == "svs.gsfc.nasa.gov":
        return "NASA Scientific Visualization Studio"
    if host == "images-assets.nasa.gov":
        return "NASA Image and Video Library"
    return None


def ledger_items(path: Path) -> list[dict]:
    raw = load_json(path, {})
    return raw if isinstance(raw, list) else raw.get("assets", [])


def normalize_item(item: dict, require_exists: bool = True) -> dict | None:
    local = item.get("local_path") or item.get("path")
    source_url = item.get("source_url") or item.get("url")
    if not local or not source_url:
        return None
    local_path = Path(local).resolve()
    if require_exists and not local_path.is_file():
        return None
    publisher = item.get("publisher") or publisher_for_url(str(source_url))
    description = item.get("source_description") or item.get("role")
    if not publisher or not description:
        return None
    result = {
        "id": item.get("id") or f"source-{local_path.stem}",
        "local_path": str(local_path),
        "source_url": str(source_url),
        "publisher": str(publisher),
        "source_description": str(description),
    }
    for key in ("license", "segments", "tags"):
        if item.get(key):
            result[key] = item[key]
    return result


def build_pack(ledgers: list[Path], require_exists: bool = True) -> dict:
    by_path: dict[str, dict] = {}
    skipped = 0
    for ledger in ledgers:
        for item in ledger_items(ledger):
            normalized = normalize_item(item, require_exists=require_exists)
            if normalized is None:
                skipped += 1
                continue
            key = normalized["local_path"].casefold()
            # Prefer a ledger that states its publisher explicitly over an inferred NASA publisher.
            existing = by_path.get(key)
            if existing is None or (item.get("publisher") and not existing.get("publisher", "").startswith("NASA ")):
                by_path[key] = normalized
    assets = sorted(by_path.values(), key=lambda value: value["local_path"].casefold())
    return {
        "version": 1,
        "kind": "curated-provenance-pack",
        "asset_count": len(assets),
        "skipped_incomplete_or_missing": skipped,
        "assets": assets,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ledger", action="append", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--allow-missing", action="store_true")
    args = parser.parse_args()
    result = build_pack([Path(value) for value in args.ledger], require_exists=not args.allow_missing)
    write_json(Path(args.output), result)
    print(Path(args.output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
