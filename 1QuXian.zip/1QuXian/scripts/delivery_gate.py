#!/usr/bin/env python3
"""Fail-closed terminal gate for the 1XinXiLiu delivery workflow."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path


REQUIRED_LEDGER_FIELDS = ("id", "local_path")
HASH_INPUTS = ("video", "timeline", "preflight", "ledger", "final_review")


def read_json(path: Path, label: str, errors: list[str]) -> dict:
    if not path.is_file():
        errors.append(f"{label} missing: {path}")
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"{label} is not valid JSON: {exc}")
        return {}
    if not isinstance(value, dict):
        errors.append(f"{label} root must be an object")
        return {}
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def same_path(left: str | Path, right: Path) -> bool:
    try:
        return Path(left).resolve() == right.resolve()
    except (OSError, TypeError, ValueError):
        return False


def validate(
    video: Path,
    timeline_path: Path,
    preflight_path: Path,
    ledger_path: Path,
    review_path: Path,
) -> tuple[list[str], dict[str, str]]:
    errors: list[str] = []
    paths = {
        "video": video,
        "timeline": timeline_path,
        "preflight": preflight_path,
        "ledger": ledger_path,
        "final_review": review_path,
    }
    if not video.is_file() or video.stat().st_size <= 0:
        errors.append(f"final video missing or empty: {video}")
    else:
        ffprobe = shutil.which("ffprobe")
        if not ffprobe:
            errors.append("ffprobe is required to verify the final MP4")
        else:
            probe = subprocess.run([ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_type", "-of", "json", str(video)], capture_output=True, text=True, encoding="utf-8", errors="replace")
            try:
                streams = json.loads(probe.stdout).get("streams", []) if probe.returncode == 0 else []
            except json.JSONDecodeError:
                streams = []
            if not streams:
                errors.append("final video is not a probeable MP4 with a video stream")

    timeline = read_json(timeline_path, "timeline", errors)
    preflight = read_json(preflight_path, "preflight", errors)
    ledger = read_json(ledger_path, "asset ledger", errors)
    review = read_json(review_path, "final review", errors)

    permit_path = timeline.get("finalize_permit_path")
    if not permit_path:
        errors.append("timeline has no finalize permit")
    else:
        permit = read_json(Path(permit_path), "finalize permit", errors)
        if permit.get("source") != "fast_pipeline finalize":
            errors.append("finalize permit has an invalid source")
        if permit.get("profile") != "final" or not same_path(permit.get("output_video_path"), video):
            errors.append("finalize permit does not authorize this final video")
        if permit.get("timeline_sha256") != sha256(timeline_path):
            errors.append("finalize permit does not match timeline")

    duration = timeline.get("duration_seconds")
    shots = timeline.get("shots")
    if not isinstance(duration, (int, float)) or duration <= 0:
        errors.append("timeline duration_seconds must be positive")
    if not isinstance(shots, list) or not shots:
        errors.append("timeline shots must be a non-empty list")
        shots = []
    timeline_shot_ids = [str(shot.get("id", "")) for shot in shots if isinstance(shot, dict)]
    if any(not item for item in timeline_shot_ids) or len(set(timeline_shot_ids)) != len(timeline_shot_ids):
        errors.append("timeline shot ids must be present and unique")
    timeline_asset_ids = [str(shot.get("asset_id", "")) for shot in shots if isinstance(shot, dict)]
    if any(not item for item in timeline_asset_ids):
        errors.append("every timeline shot must have an asset_id")
    if len(set(timeline_asset_ids)) != len(timeline_asset_ids):
        errors.append("timeline asset_id values must be unique; repeated real video is forbidden")

    if preflight.get("ok") is not True or preflight.get("errors") not in ([], None):
        errors.append("preflight did not pass cleanly")
    if not same_path(preflight.get("timeline"), timeline_path) or preflight.get("timeline_sha256") != sha256(timeline_path):
        errors.append("preflight does not belong to the current timeline")

    assets = ledger.get("assets")
    uses = ledger.get("uses")
    if not isinstance(assets, list) or not assets:
        errors.append("asset ledger assets must be a non-empty list")
        assets = []
    if not isinstance(uses, list) or not uses:
        errors.append("asset ledger uses must be a non-empty list")
        uses = []
    if not same_path(ledger.get("timeline"), timeline_path) or ledger.get("timeline_sha256") != sha256(timeline_path):
        errors.append("asset ledger does not belong to the current timeline")
    for index, asset in enumerate(assets):
        if not isinstance(asset, dict):
            errors.append(f"asset ledger item {index} must be an object")
            continue
        for field in REQUIRED_LEDGER_FIELDS:
            if not str(asset.get(field, "")).strip():
                errors.append(f"asset ledger item {index} missing {field}")
        if not asset.get("sha256") and not asset.get("quick_hash"):
            errors.append(f"asset ledger item {index} missing source file hash")
    ledger_ids = {str(asset.get("id")) for asset in assets if isinstance(asset, dict) and asset.get("id")}
    use_shots = {str(use.get("shot_id")) for use in uses if isinstance(use, dict) and use.get("shot_id")}
    use_assets = [str(use.get("asset_id")) for use in uses if isinstance(use, dict) and use.get("asset_id")]
    if set(timeline_shot_ids) != use_shots:
        errors.append("asset ledger uses do not cover every timeline shot exactly")
    if any(asset_id not in ledger_ids for asset_id in use_assets):
        errors.append("asset ledger uses reference unknown assets")
    if len(use_assets) != len(set(use_assets)):
        errors.append("asset ledger reuses a real video across shots")

    if review.get("ok") is not True or review.get("errors") not in ([], None):
        errors.append("final review did not pass cleanly")
    if not review.get("visual_approval"):
        errors.append("final review has no visual approval")
    if review.get("video") and not same_path(review["video"], video):
        errors.append("final review belongs to a different video")
    if not same_path(review.get("timeline"), timeline_path) or review.get("timeline_sha256") != sha256(timeline_path):
        errors.append("final review does not belong to the current timeline")
    approval_path = Path(str(review.get("visual_approval", "")))
    contact_sheet_path = Path(str(review.get("contact_sheet", "")))
    approval = read_json(approval_path, "visual approval", errors) if review.get("visual_approval") else {}
    if review.get("visual_approval_sha256") != (sha256(approval_path) if approval_path.is_file() else None):
        errors.append("final review visual approval hash does not match")
    if review.get("contact_sheet_sha256") != (sha256(contact_sheet_path) if contact_sheet_path.is_file() else None):
        errors.append("final review contact sheet hash does not match")
    expected_approval_hashes = {
        "video_sha256": sha256(video) if video.is_file() else None,
        "timeline_sha256": sha256(timeline_path) if timeline_path.is_file() else None,
        "contact_sheet_sha256": sha256(contact_sheet_path) if contact_sheet_path.is_file() else None,
    }
    approval_hashes = approval.get("hashes", {})
    if not isinstance(approval_hashes, dict) or any(approval_hashes.get(key) != value for key, value in expected_approval_hashes.items()):
        errors.append("visual approval is not bound to the current video, timeline, and contact sheet")
    review_shots = review.get("shots")
    if not isinstance(review_shots, list) or not review_shots or any(not isinstance(item, dict) or item.get("checked") is not True for item in review_shots):
        errors.append("final review has unchecked shots")
    elif any(item.get("semantic_checked") is not True for item in review_shots):
        errors.append("final review has shots without semantic visual observations")
    if isinstance(duration, (int, float)):
        for field in ("video_duration", "target_duration"):
            measured = review.get(field)
            if not isinstance(measured, (int, float)) or abs(float(measured) - float(duration)) > 0.2:
                errors.append(f"final review {field} does not match timeline duration")

    hashes = {name: sha256(path) for name, path in paths.items() if path.is_file()}
    return errors, hashes


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run(args: argparse.Namespace) -> int:
    video = Path(args.video)
    timeline = Path(args.timeline)
    preflight = Path(args.preflight)
    ledger = Path(args.ledger)
    final_review = Path(args.final_review)
    errors, hashes = validate(video, timeline, preflight, ledger, final_review)
    passed = not errors and set(hashes) == set(HASH_INPUTS)
    if not passed and not errors:
        errors.append("one or more delivery artifacts could not be hashed")
    checked_at = datetime.now(timezone.utc).isoformat()
    report = {
        "ok": passed,
        "terminal_allowed": passed,
        "checked_at": checked_at,
        "sha256": hashes,
        "errors": errors,
        "rule": "Only exit code 0 with terminal_allowed=true permits final delivery.",
    }
    write_json(Path(args.output), report)
    if args.status:
        write_json(Path(args.status), {
            "state": "complete" if passed else "in_progress",
            "terminal_allowed": passed,
            "current_stage": "delivery_gate_passed" if passed else "delivery_gate_failed_continue_work",
            "gate_report": str(Path(args.output).resolve()),
            "gate_sha256": hashes,
            "gate_errors": errors,
            "updated_at": checked_at,
        })
    print(json.dumps(report, ensure_ascii=False))
    return 0 if passed else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Fail-closed terminal delivery gate")
    parser.add_argument("--video", required=True)
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--preflight", required=True)
    parser.add_argument("--ledger", required=True)
    parser.add_argument("--final-review", required=True)
    parser.add_argument("--status")
    parser.add_argument("--output", required=True)
    return run(parser.parse_args())


if __name__ == "__main__":
    raise SystemExit(main())
