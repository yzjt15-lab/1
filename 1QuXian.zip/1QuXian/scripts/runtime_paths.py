"""Portable defaults for local curve-video runtime paths."""
from __future__ import annotations

import os
from pathlib import Path


def env_path(name: str, default: Path) -> Path:
    return Path(os.environ.get(name, str(default))).expanduser().resolve()


OFFICIAL_OUTPUT_DIR = env_path("CURVE_VIDEO_OUTPUT_DIR", Path.home() / "Videos" / "Codex")
MATERIAL_LIBRARY_SCRIPTS = env_path("CURVE_MATERIAL_LIBRARY_SCRIPTS", Path(__file__).resolve().parents[2] / "1SuCaiKu" / "scripts")
