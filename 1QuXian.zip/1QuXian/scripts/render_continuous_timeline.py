#!/usr/bin/env python3
"""Render a declarative timeline in one FFmpeg process."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
import time
from pathlib import Path

from benchmark_encoder import machine_signature, parse_encoders, verified_encoder
from speed_common import find_ffmpeg, write_json


PROFILES = {
    "preview": {"size": (1280, 720), "preset": "ultrafast", "crf": "28"},
    "final": {"size": (1920, 1080), "preset": "veryfast", "crf": "19"},
}
OFFICIAL_OUTPUT_DIR = Path(r"C:\Users\28723\Videos\Codex").resolve()


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def select_encoder_with_probe(initial_encoder: str, probe) -> str:
    if probe(initial_encoder):
        return initial_encoder
    if initial_encoder == "h264_nvenc" and probe("libx264"):
        return "libx264"
    raise RuntimeError(f"encoder probe failed for {initial_encoder}" + (" and libx264" if initial_encoder == "h264_nvenc" else ""))


def choose_initial_encoder(requested: str, ffmpeg: str, profile_path: Path) -> str:
    if requested != "auto":
        return requested
    profile = json.loads(profile_path.read_text(encoding="utf-8")) if profile_path.exists() else {}
    encoder = verified_encoder(profile, *machine_signature(ffmpeg))
    listing = subprocess.run([ffmpeg, "-hide_banner", "-encoders"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    return encoder if encoder in parse_encoders(listing.stdout + listing.stderr) else "libx264"


def probe_timeline(timeline: dict, seconds: float = 3.0) -> dict:
    limit = min(seconds, float(timeline["duration_seconds"]))
    shots = [{**shot, "end": min(float(shot["end"]), limit)} for shot in timeline["shots"] if float(shot["start"]) < limit]
    overlays = [{**item, "end": min(float(item["end"]), limit)} for item in timeline.get("overlays", []) if float(item["start"]) < limit]
    return {**timeline, "duration_seconds": limit, "shots": shots, "overlays": overlays}


def _decode_ok(ffmpeg: str, path: Path) -> bool:
    return path.is_file() and path.stat().st_size > 0 and subprocess.run(
        [ffmpeg, "-v", "error", "-i", str(path), "-f", "null", "NUL"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    ).returncode == 0


def audio_codec_args(audio_path: str, ffmpeg: str) -> list[str]:
    ffprobe = str(Path(ffmpeg).with_name("ffprobe.exe"))
    if not Path(ffprobe).is_file():
        ffprobe = "ffprobe"
    probe = subprocess.run(
        [ffprobe, "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_name", "-of", "default=nw=1:nk=1", audio_path],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    codec = probe.stdout.strip().casefold() if probe.returncode == 0 else ""
    return ["-c:a", "copy"] if codec in {"aac", "mp3", "ac3", "eac3", "alac"} else ["-c:a", "aac", "-b:a", "192k"]


def run_encoder_probe(timeline: dict, ffmpeg: str, encoder: str, attempts: list[dict]) -> bool:
    started = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="curve-encoder-probe-") as folder:
        output = Path(folder) / "probe.mp4"
        result = subprocess.run(build_ffmpeg_command(probe_timeline(timeline), str(output), "final", ffmpeg, encoder), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        ok = result.returncode == 0 and _decode_ok(ffmpeg, output)
    attempts.append({"encoder": encoder, "ok": ok, "elapsed_seconds": round(time.perf_counter() - started, 3)})
    return ok


def enforce_render_policy(timeline: dict, output: Path, profile: str, permit_path: str | None) -> None:
    official_output = output.resolve().parent == OFFICIAL_OUTPUT_DIR
    if not permit_path:
        if profile != "preview":
            raise ValueError("direct formal render requires a fast_pipeline finalize permit")
        if official_output:
            raise ValueError("preview output cannot be written to the official video directory")
        return
    if profile != "final" or not official_output:
        raise ValueError("finalize permit only authorizes final rendering into the official video directory")
    permit = Path(permit_path)
    if not permit.is_file():
        raise ValueError("finalize permit file is missing")
    payload = json.loads(permit.read_text(encoding="utf-8"))
    if payload.get("source") != "fast_pipeline finalize":
        raise ValueError("finalize permit has an invalid source")
    if payload.get("profile") != "final" or Path(payload.get("output_video_path", "")).resolve() != output.resolve():
        raise ValueError("finalize permit does not authorize this output")
    if payload.get("timeline_sha256") != _sha256(Path(timeline["_timeline_path"])):
        raise ValueError("finalize permit does not match the prepared timeline")


def build_ffmpeg_command(timeline: dict, output: str, profile="final", ffmpeg: str | None = None, encoder="libx264") -> list[str]:
    if profile == "preview" and float(timeline.get("duration_seconds", 0)) > 2.0:
        raise ValueError("full timeline previews are forbidden; use render_motion_preview.py")
    settings = PROFILES[profile]
    width, height = settings["size"]
    assets = {item["id"]: item for item in timeline.get("assets", [])}
    command = [find_ffmpeg(ffmpeg) if ffmpeg != "ffmpeg" else "ffmpeg", "-y"]
    shots = timeline.get("shots", [])
    if float(timeline.get("duration_seconds", 0)) >= 90.0 or len(shots) > 12:
        raise ValueError("timeline requires segmented rendering: continuous mode is limited to <90 seconds and <=12 shots")
    for shot in shots:
        asset = assets[shot["asset_id"]]
        command += ["-stream_loop", "-1", "-ss", str(shot.get("source_in", 0)), "-t", str(round(shot["end"] - shot["start"], 3)), "-i", asset["local_path"]]
    overlays = [item for item in timeline.get("overlays", []) if item.get("image_path") or item.get("frame_pattern")]
    if timeline.get("chrome_path"):
        overlays.append({"id": "persistent-chrome", "start": 0.0, "end": timeline["duration_seconds"], "image_path": timeline["chrome_path"]})
    for overlay in overlays:
        if overlay.get("frame_pattern"):
            # A hook uses a real per-frame reveal rather than a static PNG fade.
            command += ["-framerate", "30", "-start_number", "0", "-i", overlay["frame_pattern"]]
        else:
            command += ["-loop", "1", "-i", overlay["image_path"]]
    audio_index = None
    if timeline.get("audio_path"):
        audio_index = len(shots) + len(overlays)
        if timeline.get("audio_source_in") is not None:
            command += ["-ss", str(timeline["audio_source_in"]), "-t", str(timeline["duration_seconds"])]
        command += ["-i", timeline["audio_path"]]
    filters = []
    labels = []
    for index, shot in enumerate(shots):
        label = f"v{index}"
        shot_duration = round(float(shot["end"]) - float(shot["start"]), 3)
        filters.append(f"[{index}:v]scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps=30,setsar=1,setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration=0.25,trim=duration={shot_duration},setpts=PTS-STARTPTS[{label}]")
        labels.append(f"[{label}]")
    filters.append("".join(labels) + f"concat=n={len(labels)}:v=1:a=0[base]")
    current = "base"
    for offset, overlay in enumerate(overlays):
        input_index = len(shots) + offset
        output_label = f"ov{offset}"
        filters.append(f"[{input_index}:v]scale={width}:{height},format=rgba[img{offset}]")
        filters.append(f"[{current}][img{offset}]overlay=0:0:enable='between(t,{overlay['start']},{overlay['end']})'[{output_label}]")
        current = output_label
    command += ["-filter_complex", ";".join(filters), "-map", f"[{current}]", "-vsync", "cfr", "-r", "30", "-c:v", encoder]
    if encoder == "libx264":
        command += ["-preset", settings["preset"], "-crf", settings["crf"]]
    elif encoder == "h264_nvenc":
        command += ["-preset", "p4", "-tune", "hq", "-rc", "vbr", "-cq", "23" if profile == "final" else "28", "-b:v", "0"]
    command += ["-pix_fmt", "yuv420p", "-movflags", "+faststart", "-frames:v", str(round(float(timeline["duration_seconds"]) * 30))]
    if audio_index is None:
        command += ["-an"]
    else:
        command += ["-map", f"{audio_index}:a:0", *audio_codec_args(timeline["audio_path"], command[0])]
    command += [output]
    return command


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--profile", choices=PROFILES, default="final")
    parser.add_argument("--ffmpeg")
    parser.add_argument("--encoder", choices=("auto", "libx264", "h264_nvenc"), default="auto")
    parser.add_argument("--encoder-profile", default=str(Path(__file__).resolve().parents[1] / "assets" / "templates" / "verified-encoder.json"))
    parser.add_argument("--probe-report")
    parser.add_argument("--finalize-permit")
    parser.add_argument("--print-command", action="store_true")
    args = parser.parse_args()
    timeline_path = Path(args.timeline)
    timeline = json.loads(timeline_path.read_text(encoding="utf-8"))
    timeline["_timeline_path"] = str(timeline_path.resolve())
    enforce_render_policy(timeline, Path(args.output), args.profile, args.finalize_permit)
    ffmpeg = find_ffmpeg(args.ffmpeg)
    attempts: list[dict] = []
    initial = choose_initial_encoder(args.encoder, ffmpeg, Path(args.encoder_profile))
    try:
        encoder = select_encoder_with_probe(initial, lambda item: run_encoder_probe(timeline, ffmpeg, item, attempts))
    finally:
        if args.probe_report:
            write_json(Path(args.probe_report), {"initial_encoder": initial, "attempts": attempts, "selected_encoder": locals().get("encoder")})
    command = build_ffmpeg_command(timeline, args.output, args.profile, ffmpeg, encoder)
    if args.print_command:
        print(json.dumps(command, ensure_ascii=False))
        return 0
    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError:
        if encoder != "h264_nvenc":
            raise
        encoder = select_encoder_with_probe("libx264", lambda item: run_encoder_probe(timeline, ffmpeg, item, attempts))
        if args.probe_report:
            write_json(Path(args.probe_report), {"initial_encoder": initial, "attempts": attempts, "selected_encoder": encoder, "fallback_after_render_failure": True})
        subprocess.run(build_ffmpeg_command(timeline, args.output, args.profile, ffmpeg, encoder), check=True)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
