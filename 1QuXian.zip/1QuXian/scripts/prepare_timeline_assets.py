#!/usr/bin/env python3
"""Generate persistent chrome, charts, and verified news overlays."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from render_video_chrome import render_chrome
from render_market_chart import render as render_market_chart
from render_overlay_templates import render_hook_frames, render_news_page
from speed_common import write_json

HOOK_LINES = ("thesis", "judgment", "evidence")


def _hook_colors_are_valid(overlay: dict) -> bool:
    colors, contrast = overlay.get("hook_text_colors"), overlay.get("hook_contrast")
    if not isinstance(colors, dict) or not isinstance(contrast, dict):
        return False
    entries = [colors.get(line) for line in HOOK_LINES]
    checks = [contrast.get(line) for line in HOOK_LINES]
    if not all(isinstance(item, dict) and isinstance(item.get("color"), str) and isinstance(item.get("opacity"), (int, float)) for item in entries):
        return False
    if len({item["color"].upper() for item in entries}) != len(HOOK_LINES):
        return False
    if not (entries[0]["opacity"] > entries[1]["opacity"] > entries[2]["opacity"]):
        return False
    return all(isinstance(item, dict) and isinstance(item.get("contrast_ratio"), (int, float)) and item["contrast_ratio"] >= 4.5 for item in checks)


def _apply_white_hook_fallback(overlay: dict) -> None:
    if overlay.get("role") != "hook" or _hook_colors_are_valid(overlay):
        return
    overlay["hook_color_fallback"] = "white"
    overlay["hook_text_colors"] = {line: {"color": "#FFFFFF", "opacity": 1.0} for line in HOOK_LINES}
    overlay["hook_contrast"] = {}
    overlay["hook_color_fallback_reason"] = "missing_or_invalid_color_contract"


def prepare(timeline: dict, overlay_dir: Path, size=(1920, 1080)) -> dict:
    prepared = json.loads(json.dumps(timeline, ensure_ascii=False))
    chrome = render_chrome({"title": prepared["title"], "disclaimer": "内容仅代表个人观点，不作为投资建议"}, overlay_dir, size)
    prepared["chrome_path"] = str(chrome.resolve())
    overlays = prepared.setdefault("overlays", [])
    for overlay in overlays:
        _apply_white_hook_fallback(overlay)
        if overlay.get("role") == "hook":
            image_path, frame_pattern = render_hook_frames(overlay, overlay_dir, size)
            overlay["image_path"] = str(image_path.resolve())
            overlay["frame_pattern"] = frame_pattern
        if overlay.get("type") == "news" and (overlay.get("screenshot_path") or overlay.get("image_path")):
            screenshot_path = Path(overlay.get("screenshot_path") or overlay["image_path"])
            overlay["screenshot_path"] = str(screenshot_path)
            overlay["image_path"] = str(render_news_page(overlay, screenshot_path, overlay_dir, size).resolve())
        if overlay.get("type") == "chart" and overlay.get("chart_config_path"):
            config_path = Path(overlay["chart_config_path"])
            config = json.loads(config_path.read_text(encoding="utf-8-sig"))
            chart_path = render_market_chart(config, overlay_dir, size)
            overlay["image_path"] = str(chart_path.resolve())
    existing_news = {item.get("news_id") for item in overlays if item.get("news_id")}
    shot_ids = {shot.get("id") for shot in prepared.get("shots", [])}
    for news in prepared.get("news", []):
        news_id = news.get("id")
        if news_id in existing_news:
            continue
        required = ("screenshot_path", "headline", "start", "end", "background_shot_id")
        if not all(news.get(key) is not None for key in required):
            raise ValueError(f"news {news_id or '?'} missing screenshot/timing/background fields")
        if news["background_shot_id"] not in shot_ids:
            raise ValueError(f"news {news_id or '?'} background shot missing")
        news_page = render_news_page(news, Path(news["screenshot_path"]), overlay_dir, size)
        overlays.append({
            "id": f"overlay-{news_id}", "type": "news", "news_id": news_id,
            "chapter_id": news.get("chapter_id"), "evidence_id": news.get("evidence_id"),
            "start": news["start"], "end": news["end"],
            "chinese_text": news["headline"], "background_shot_id": news["background_shot_id"],
            "image_path": str(news_page.resolve()), "screenshot_path": news["screenshot_path"],
        })
    return prepared


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--overlay-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8-sig"))
    prepared = prepare(timeline, Path(args.overlay_dir))
    write_json(Path(args.output), prepared)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
