#!/usr/bin/env python3
"""Prepare the persistent disclaimer and verify timeline-bound information pages."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from render_video_chrome import render_chrome
from speed_common import write_json
from page_reference_contract import PAGE_REFERENCE_FILENAMES, REFERENCE_PAGES, verify_page_reference_assets


def prepare(timeline: dict, overlay_dir: Path) -> dict:
    prepared = json.loads(json.dumps(timeline, ensure_ascii=False))
    if prepared.get("news"):
        raise ValueError("register each news page only in overlays[]")
    overlays = prepared.setdefault("overlays", [])
    reference_types = {
        "hook" if overlay.get("role") == "hook" else ("news" if overlay.get("type") == "news" else overlay.get("chart_kind"))
        for overlay in overlays
    } - {None}
    reference_errors = verify_page_reference_assets(page_types=reference_types)
    if reference_errors:
        raise ValueError("; ".join(reference_errors))
    chrome = render_chrome({"disclaimer": "内容仅为个人观点，不构成投资建议"}, overlay_dir)
    prepared["chrome_path"] = str(chrome.resolve())
    for overlay in overlays:
        reference_key = "hook" if overlay.get("role") == "hook" else ("news" if overlay.get("type") == "news" else overlay.get("chart_kind"))
        expected_reference = PAGE_REFERENCE_FILENAMES.get(reference_key)
        if not expected_reference:
            raise ValueError(f"overlay {overlay.get('id', '?')}: page type must be hook, news, or an approved chart_kind")
        if overlay.get("reference_template") != expected_reference:
            raise ValueError(f"overlay {overlay.get('id', '?')}: reference_template must be {expected_reference}")
        reference_path = REFERENCE_PAGES / expected_reference
        if not reference_path.is_file():
            raise FileNotFoundError(reference_path)
        overlay["reference_template_path"] = str(reference_path.resolve())
        image_path = Path(str(overlay.get("image_path", "")))
        if not image_path.is_file():
            raise ValueError(f"overlay {overlay.get('id', '?')}: existing image_path is required")
        overlay["image_path"] = str(image_path.resolve())
        if overlay.get("role") == "hook":
            pattern = overlay.get("frame_pattern")
            try:
                first, complete = Path(pattern % 0), Path(pattern % 30)
            except (TypeError, ValueError):
                raise ValueError(f"overlay {overlay.get('id', '?')}: hook frame_pattern is required") from None
            if not first.is_file() or not complete.is_file():
                raise ValueError(f"overlay {overlay.get('id', '?')}: hook frames 0000 and 0030 are required")
    return prepared


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--overlay-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8-sig"))
    prepared = prepare(timeline, Path(args.overlay_dir))
    write_json(Path(args.output), prepared)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
