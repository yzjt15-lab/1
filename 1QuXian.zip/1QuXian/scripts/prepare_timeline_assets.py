#!/usr/bin/env python3
"""Generate persistent chrome, charts, and verified news overlays."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from render_video_chrome import render_chrome
from render_market_chart import render as render_market_chart
from render_overlay_templates import render_hook_frames, render_news_page
from speed_common import write_json

HOOK_LINES = ("thesis", "judgment", "evidence")


def _hook_colors_are_valid(overlay: dict) -> bool:
    colors, contrast = overlay.get("hook_text_colors"), overlay.get("hook_contrast")
    if not isinstance(colors, dict) or not isinstance(contrast, dict):
        return False
    entries = [colors.get(line) for line in HOOK_LINES]
    checks = [contrast.get(line) for line in HOOK_LINES]
    if not all(isinstance(item, dict) and isinstance(item.get("color"), str) and isinstance(item.get("opacity"), (int, float)) for item in entries):
        return False
    if len({item["color"].upper() for item in entries}) != len(HOOK_LINES):
        return False
    if not (entries[0]["opacity"] > entries[1]["opacity"] > entries[2]["opacity"]):
        return False
    return all(isinstance(item, dict) and isinstance(item.get("contrast_ratio"), (int, float)) and item["contrast_ratio"] >= 4.5 for item in checks)


def _apply_white_hook_fallback(overlay: dict) -> None:
    if overlay.get("role") != "hook" or _hook_colors_are_valid(overlay):
        return
    overlay["hook_color_fallback"] = "white"
    overlay["hook_text_colors"] = {line: {"color": "#FFFFFF", "opacity": 1.0} for line in HOOK_LINES}
    overlay["hook_contrast"] = {line: {"background_luminance": 0.032, "contrast_ratio": 12.8} for line in HOOK_LINES}
    overlay["hook_color_fallback_reason"] = "missing_or_invalid_color_contract"


def prepare(timeline: dict, overlay_dir: Path, size=(1920, 1080)) -> dict:
    prepared = json.loads(json.dumps(timeline, ensure_ascii=False))
    if prepared.get("news"):
        raise ValueError("legacy news[] is not allowed; register each news page only in overlays[]")
    chrome = render_chrome({"title": prepared["title"], "disclaimer": "内容仅代表个人观点，不作为投资建议"}, overlay_dir, size)
    prepared["chrome_path"] = str(chrome.resolve())
    overlays = prepared.setdefault("overlays", [])
    for overlay in overlays:
        _apply_white_hook_fallback(overlay)
        if overlay.get("role") == "hook":
            image_path, frame_pattern = render_hook_frames(overlay, overlay_dir, size)
            overlay["image_path"] = str(image_path.resolve())
            overlay["frame_pattern"] = frame_pattern
        if overlay.get("type") == "news" and (overlay.get("screenshot_path") or overlay.get("image_path")):
            screenshot_path = Path(overlay.get("screenshot_path") or overlay["image_path"])
            overlay["screenshot_path"] = str(screenshot_path)
            overlay["image_path"] = str(render_news_page(overlay, screenshot_path, overlay_dir, size).resolve())
        if overlay.get("type") == "chart" and overlay.get("chart_config_path"):
            config_path = Path(overlay["chart_config_path"])
            config = json.loads(config_path.read_text(encoding="utf-8-sig"))
            chart_path = render_market_chart(config, overlay_dir, size)
            overlay["image_path"] = str(chart_path.resolve())
    return prepared


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--overlay-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8-sig"))
    prepared = prepare(timeline, Path(args.overlay_dir))
    write_json(Path(args.output), prepared)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
