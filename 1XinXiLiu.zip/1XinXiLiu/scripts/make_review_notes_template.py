#!/usr/bin/env python3
"""Create the exact per-shot visual-review record before human inspection."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from speed_common import write_json


def build_template(timeline: Path, contact_sheet: Path) -> dict:
    data = json.loads(timeline.read_text(encoding="utf-8"))
    shots = {}
    for shot in data.get("shots", []):
        shot_id = str(shot.get("id", "")).strip()
        if not shot_id:
            raise ValueError("timeline shot id is required")
        shots[shot_id] = {
            "evidence_frames": [f"{shot_id}-A", f"{shot_id}-M", f"{shot_id}-B"],
            "visible_subject": "",
            "visible_action": "",
            "visible_location": "",
            "visible_equipment": "",
            "semantic_match": False,
        }
    return {
        "schema_version": 1,
        "timeline": str(timeline.resolve()),
        "contact_sheet": str(contact_sheet.resolve()),
        "contact_sheet_sha256": hashlib.sha256(contact_sheet.read_bytes()).hexdigest(),
        "checks": {
            "vertical_layout": False,
            "disclaimer": False,
            "no_subtitles": False,
            "keyword_match": False,
            "no_black_or_placeholder": False,
        },
        "shots": shots,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--contact-sheet", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    timeline, sheet = Path(args.timeline), Path(args.contact_sheet)
    if not sheet.is_file():
        raise SystemExit("contact sheet is missing")
    write_json(Path(args.output), build_template(timeline, sheet))
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
