#!/usr/bin/env python3
"""Render only the uncertain motion window, hard-limited to two seconds."""
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory

from render_overlay_templates import render_overlay
from speed_common import find_ffmpeg


def preview_duration(requested: float) -> float:
    if requested <= 0:
        raise ValueError("duration must be > 0")
    return min(2.0, float(requested))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--start", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=2.0)
    parser.add_argument("--overlay")
    parser.add_argument("--ffmpeg")
    args = parser.parse_args()
    ffmpeg = find_ffmpeg(args.ffmpeg)
    duration = preview_duration(args.duration)
    command = [ffmpeg, "-y", "-ss", str(args.start), "-t", str(duration), "-i", args.source]
    filters = ["[0:v]split=2[bgsrc][centersrc]", "[bgsrc]scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,boxblur=20:10[blurred]", "[centersrc]scale=720:554:force_original_aspect_ratio=increase,crop=720:554[center]"]
    current = "center"
    if args.overlay:
        command += ["-loop", "1", "-i", args.overlay]
        filters += [
            "[1:v]scale=720:554,format=rgba[ov]",
            "[center][ov]overlay=0:0[content]",
        ]
        current = "content"
    with TemporaryDirectory(prefix="infoflow-motion-preview-") as directory:
        chrome = render_overlay({"type": "chrome", "disclaimer": "内容仅为个人观点，不构成投资建议"}, Path(directory), size=(720, 1280))
        chrome_index = 2 if args.overlay else 1
        command += ["-loop", "1", "-i", str(chrome)]
        filters += [f"[blurred][{current}]overlay=0:403[vertical]", f"[vertical][{chrome_index}:v]overlay=0:0[composed]", "[composed]setsar=1[out]"]
        command += ["-filter_complex", ";".join(filters), "-map", "[out]"]
        command += ["-an", "-t", str(duration), "-r", "30", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-pix_fmt", "yuv420p", str(Path(args.output))]
        subprocess.run(command, check=True)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
