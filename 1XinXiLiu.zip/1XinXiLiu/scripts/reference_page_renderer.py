#!/usr/bin/env python3
"""Reference-bound 1080x830 page renderer and canonical sample builder."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps


SKILL_ROOT = Path(__file__).resolve().parent.parent
APPROVED_DIR = SKILL_ROOT / "assets" / "approved-pages"
COMPONENT_DIR = SKILL_ROOT / "assets" / "components"
MANIFEST_PATH = SKILL_ROOT / "references" / "七类信息页固定标准.json"
PAGE_SIZE = (1080, 830)
GOLD = (243, 194, 96, 255)
PALE_GOLD = (255, 226, 162, 255)
WHITE = (247, 250, 255, 255)
MUTED = (199, 207, 220, 235)
NAVY = (5, 24, 48, 222)
BLUE = (87, 157, 255, 255)
GREEN = (111, 195, 83, 255)
RED = (255, 78, 78, 255)


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    path = Path(r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc")
    if not path.is_file():
        path = Path(r"C:\Windows\Fonts\simhei.ttf")
    return ImageFont.truetype(str(path), size, index=0)


def _serif_font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(r"C:\Windows\Fonts\simsun.ttc", size, index=0)


def _named_font(filename: str, size: int, fallback_bold: bool = True) -> ImageFont.FreeTypeFont:
    path = Path(r"C:\Windows\Fonts") / filename
    return ImageFont.truetype(str(path), size, index=0) if path.is_file() else _font(size, fallback_bold)


def _fit(source: Image.Image, size: tuple[int, int]) -> Image.Image:
    ratio = max(size[0] / source.width, size[1] / source.height)
    resized = source.resize((round(source.width * ratio), round(source.height * ratio)), Image.Resampling.LANCZOS)
    left, top = (resized.width - size[0]) // 2, (resized.height - size[1]) // 2
    return resized.crop((left, top, left + size[0], top + size[1]))


def _canvas(size: tuple[int, int]) -> Image.Image:
    return Image.new("RGBA", size, (0, 0, 0, 0))


def fit_screenshot(path: Path, size=PAGE_SIZE) -> Image.Image:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    shot = ImageOps.contain(Image.open(path).convert("RGBA"), size, Image.Resampling.LANCZOS)
    image.alpha_composite(shot, ((size[0] - shot.width) // 2, (size[1] - shot.height) // 2))
    return image


def _center(draw: ImageDraw.ImageDraw, text: str, y: int, font: ImageFont.FreeTypeFont, fill=WHITE, x0=0, x1=1080) -> None:
    text = str(text)
    available = max(1, x1 - x0 - 24)
    while font.size > 14 and draw.textbbox((0, 0), text, font=font)[2] > available:
        font = font.font_variant(size=font.size - 1)
    box = draw.textbbox((0, 0), text, font=font)
    if box[2] > available:
        raise ValueError(f"text exceeds its safe area: {text}")
    draw.text(((x0 + x1 - (box[2] - box[0])) / 2, y), text, font=font, fill=fill)


def _draw_fit(draw: ImageDraw.ImageDraw, text: str, xy: tuple[int, int], font: ImageFont.FreeTypeFont, fill, max_width: int) -> None:
    text = str(text)
    while font.size > 14 and draw.textbbox((0, 0), text, font=font)[2] > max_width:
        font = font.font_variant(size=font.size - 1)
    if draw.textbbox((0, 0), text, font=font)[2] > max_width:
        raise ValueError(f"text exceeds its safe area: {text}")
    draw.text(xy, text, font=font, fill=fill)


def _draw_gold_text(image: Image.Image, text: str, xy: tuple[int, int], font: ImageFont.FreeTypeFont, max_width: int, glow: int = 0, embolden: int = 0) -> None:
    text = str(text)
    probe = ImageDraw.Draw(image)
    while font.size > 14 and probe.textbbox((0, 0), text, font=font)[2] > max_width:
        font = font.font_variant(size=font.size - 1)
    if probe.textbbox((0, 0), text, font=font)[2] > max_width:
        raise ValueError(f"text exceeds its safe area: {text}")
    x, y = xy
    mask = Image.new("L", image.size, 0)
    ImageDraw.Draw(mask).text((x, y), text, font=font, fill=255, stroke_width=embolden, stroke_fill=255)
    bbox = mask.getbbox()
    if bbox is None:
        return
    if glow:
        glow_layer = Image.new("RGBA", image.size, (238, 168, 62, 0))
        glow_layer.putalpha(mask.filter(ImageFilter.GaussianBlur(glow)).point(lambda value: value // 8))
        image.alpha_composite(glow_layer)
    ImageDraw.Draw(image, "RGBA").text((x, y), text, font=font, fill=(130, 78, 17, 255), stroke_width=embolden + 1, stroke_fill=(79, 43, 6, 255))
    gradient = Image.new("RGBA", image.size, (0, 0, 0, 0))
    gradient_draw = ImageDraw.Draw(gradient)
    colors = ((255, 247, 209), (236, 190, 104), (255, 226, 157), (194, 126, 39))
    height = max(1, bbox[3] - bbox[1])
    for row in range(height):
        position = row / max(1, height - 1) * (len(colors) - 1)
        index = min(len(colors) - 2, int(position))
        blend = position - index
        color = tuple(round(colors[index][channel] * (1 - blend) + colors[index + 1][channel] * blend) for channel in range(3))
        gradient_draw.line((bbox[0], bbox[1] + row, bbox[2], bbox[1] + row), fill=(*color, 255))
    gradient.putalpha(mask)
    image.alpha_composite(gradient)


def _panel(draw: ImageDraw.ImageDraw, box=(58, 48, 1022, 782), radius=28) -> None:
    draw.rounded_rectangle(box, radius, fill=NAVY, outline=GOLD, width=2)


def _luxury_panel(image: Image.Image, box=(20, 22, 1060, 808), radius=18, top_color=(5, 27, 55), bottom_color=(8, 35, 66)) -> None:
    glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow, "RGBA").rounded_rectangle(box, radius, outline=(246, 190, 80, 150), width=8)
    glow = glow.filter(ImageFilter.GaussianBlur(14))
    glow_alpha = glow.getchannel("A")
    glow_alpha.paste(0, (0, 0, 20, image.height)); glow_alpha.paste(0, (1060, 0, image.width, image.height))
    glow.putalpha(glow_alpha)
    image.alpha_composite(glow)
    mask = Image.new("L", image.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle(box, radius, fill=255)
    panel = Image.new("RGBA", image.size, (0, 0, 0, 0))
    panel_draw = ImageDraw.Draw(panel, "RGBA")
    top, bottom = box[1], box[3]
    for y in range(top, bottom + 1):
        ratio = (y - top) / max(1, bottom - top)
        color = tuple(round(top_color[channel] * (1 - ratio) + bottom_color[channel] * ratio) for channel in range(3)) + (246,)
        panel_draw.line((box[0], y, box[2], y), fill=color)
    panel.putalpha(mask)
    image.alpha_composite(panel)
    draw = ImageDraw.Draw(image, "RGBA")
    draw.rounded_rectangle(box, radius, outline=(248, 197, 93, 235), width=3)
    draw.rounded_rectangle((box[0] + 8, box[1] + 8, box[2] - 8, box[3] - 8), max(4, radius - 6), outline=(255, 226, 162, 35), width=1)


def _glowing_circle(image: Image.Image, box: tuple[int, int, int, int], outline=GOLD, fill=(7, 29, 57, 245), width=4) -> None:
    glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow, "RGBA").ellipse(box, outline=outline, width=10)
    image.alpha_composite(glow.filter(ImageFilter.GaussianBlur(16)))
    ImageDraw.Draw(image, "RGBA").ellipse(box, fill=fill, outline=outline, width=width)


def _finance_icon(kind: str, size: int) -> Image.Image:
    """Draw one deterministic, supersampled icon in the renderer's gold style."""
    if kind not in {"institution", "rise_curve", "rise_zigzag", "decline_zigzag", "causal_group", "causal_curve", "causal_zigzag"}:
        raise ValueError(f"unsupported finance icon: {kind}")
    scale = 4
    side = size * scale
    mask = Image.new("L", (side, side), 0)
    draw = ImageDraw.Draw(mask)
    px = lambda value: round(value * side / 100)
    if kind == "causal_group":
        sides = Image.new("L", (side, side), 0)
        side_draw = ImageDraw.Draw(sides)
        for center_x in (24, 76):
            side_draw.ellipse((px(center_x-9), px(24), px(center_x+9), px(42)), fill=255)
            side_draw.rectangle((px(center_x-5), px(40), px(center_x+5), px(50)), fill=255)
            side_draw.rounded_rectangle((px(center_x-18), px(47), px(center_x+18), px(81)), radius=px(12), fill=255)
            side_draw.polygon(((px(center_x-9), px(48)), (px(center_x), px(61)), (px(center_x+9), px(48))), fill=0)
        center = Image.new("L", (side, side), 0)
        center_draw = ImageDraw.Draw(center)
        center_draw.ellipse((px(39), px(12), px(61), px(36)), fill=255)
        center_draw.rectangle((px(44), px(33), px(56), px(48)), fill=255)
        center_draw.rounded_rectangle((px(25), px(44), px(75), px(92)), radius=px(16), fill=255)
        center_draw.polygon(((px(34), px(45)), (px(50), px(63)), (px(66), px(45)), (px(58), px(43)), (px(50), px(53)), (px(42), px(43))), fill=0)
        center_draw.polygon(((px(47), px(56)), (px(53), px(56)), (px(56), px(80)), (px(50), px(88)), (px(44), px(80))), fill=0)
        mask = ImageChops.lighter(ImageChops.subtract(sides, center.filter(ImageFilter.MaxFilter(17))), center)
    elif kind == "causal_curve":
        for left, height in ((18, 28), (39, 45), (60, 65)):
            draw.rounded_rectangle((px(left), px(87-height), px(left+14), px(87)), radius=px(2), fill=255)
        points = []
        for step in range(41):
            t = step / 40
            x = (10 * (1-t)**3 + 3*36 * (1-t)**2*t + 3*62 * (1-t)*t*t + 90*t**3)
            y = (61 * (1-t)**3 + 3*55 * (1-t)**2*t + 3*40 * (1-t)*t*t + 13*t**3)
            points.append((px(x), px(y)))
        draw.line(points, fill=255, width=px(6), joint="curve")
        draw.polygon(((px(90), px(13)), (px(72), px(15)), (px(86), px(31))), fill=255)
    elif kind == "causal_zigzag":
        for left, height in ((12, 25), (31, 38), (50, 50), (69, 68)):
            draw.rounded_rectangle((px(left), px(88-height), px(left+12), px(88)), radius=px(2), fill=255)
        font = ImageFont.truetype(r"C:\Windows\Fonts\segmdl2.ttf", px(88))
        glyph = "\ueafc"  # Segoe MDL2 Market: consistent native rising-arrow geometry.
        box = draw.textbbox((0, 0), glyph, font=font)
        draw.text(((side - (box[2] - box[0])) / 2 - box[0], (side - (box[3] - box[1])) / 2 - box[1] - px(7)), glyph, font=font, fill=255)
    elif kind == "institution":
        for center_x, center_y, radius in ((23, 40, 9), (50, 32, 12), (77, 40, 9)):
            draw.ellipse((px(center_x-radius), px(center_y-radius), px(center_x+radius), px(center_y+radius)), fill=255)
        draw.polygon(tuple((px(x), px(y)) for x, y in ((7, 62), (17, 54), (23, 60), (29, 54), (39, 62), (36, 84), (10, 80))), fill=255)
        draw.polygon(tuple((px(x), px(y)) for x, y in ((61, 62), (71, 54), (77, 60), (83, 54), (93, 62), (90, 80), (64, 84))), fill=255)
        draw.polygon(tuple((px(x), px(y)) for x, y in ((27, 61), (41, 51), (50, 59), (59, 51), (73, 61), (69, 93), (31, 93))), fill=255)
        draw.line((px(37), px(62), px(34), px(88)), fill=0, width=px(3))
        draw.line((px(63), px(62), px(66), px(88)), fill=0, width=px(3))
        draw.line((px(41), px(53), px(50), px(62), px(59), px(53)), fill=0, width=px(3))
        draw.polygon(tuple((px(x), px(y)) for x, y in ((47, 61), (53, 61), (56, 82), (50, 90), (44, 82))), fill=0)
    else:
        descending = kind == "decline_zigzag"
        heights = (34, 52, 70) if kind == "rise_curve" else ((26, 39, 52, 68) if not descending else (68, 52, 39, 26))
        for index, height in enumerate(heights):
            left = (19 + index * 25) if kind == "rise_curve" else (8 + index * 19)
            draw.rectangle((px(left), px(88-height), px(left+13), px(88)), fill=255)
        if kind == "rise_curve":
            points = ((9, 62), (28, 54), (46, 43), (63, 28), (88, 10))
        elif kind == "rise_zigzag":
            points = ((8, 62), (29, 42), (47, 52), (66, 29), (89, 10))
        else:
            points = ((8, 25), (29, 43), (47, 35), (66, 58), (89, 78))
        points = tuple((px(x), px(y)) for x, y in points)
        draw.line(points, fill=255, width=px(6), joint="curve")
        tip_x, tip_y = points[-1]
        arrow = ((tip_x, tip_y), (px(69), px(16)), (px(84), px(32))) if not descending else ((tip_x, tip_y), (px(70), px(73)), (px(84), px(58)))
        draw.polygon(arrow, fill=255)
    glow = Image.new("RGBA", (side, side), (235, 157, 43, 0))
    glow.putalpha(mask.filter(ImageFilter.GaussianBlur(px(4))).point(lambda value: value * 2 // 5))
    icon = glow
    outline = Image.new("RGBA", (side, side), (111, 63, 8, 0))
    outline.putalpha(mask.filter(ImageFilter.MaxFilter(13)))
    icon.alpha_composite(outline)
    gradient = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    gradient_draw = ImageDraw.Draw(gradient)
    for y in range(side):
        ratio = y / max(1, side - 1)
        stops = ((255, 250, 218), (255, 227, 157), (240, 184, 91), (193, 123, 33))
        position = ratio * (len(stops) - 1)
        index = min(len(stops) - 2, int(position))
        blend = position - index
        color = tuple(round(stops[index][channel] * (1 - blend) + stops[index + 1][channel] * blend) for channel in range(3))
        gradient_draw.line((0, y, side, y), fill=(*color, 255))
    gradient.putalpha(mask)
    icon.alpha_composite(gradient)
    return icon.resize((size, size), Image.Resampling.LANCZOS)


def _metallic_text(image: Image.Image, text: str, y: int, font: ImageFont.FreeTypeFont, colors: tuple[tuple[int, int, int], ...]) -> None:
    mask = Image.new("L", image.size, 0)
    draw = ImageDraw.Draw(mask)
    while font.size > 20 and draw.textbbox((0, 0), text, font=font, stroke_width=2)[2] > 980:
        font = font.font_variant(size=font.size - 1)
    box = draw.textbbox((0, 0), text, font=font, stroke_width=2)
    x = (image.width - (box[2] - box[0])) // 2
    draw.text((x, y), text, font=font, fill=255, stroke_width=2, stroke_fill=255)
    glow = Image.new("RGBA", image.size, (*colors[-1], 0))
    glow.putalpha(mask.filter(ImageFilter.GaussianBlur(18)).point(lambda value: value * 2 // 5))
    image.alpha_composite(glow)
    gradient = Image.new("RGBA", image.size, (0, 0, 0, 0))
    gradient_draw = ImageDraw.Draw(gradient)
    stops = len(colors) - 1
    for row in range(max(1, box[3] - box[1] + 8)):
        position = row / max(1, box[3] - box[1] + 7) * stops
        index = min(stops - 1, int(position))
        blend = position - index
        color = tuple(round(colors[index][channel] * (1 - blend) + colors[index + 1][channel] * blend) for channel in range(3))
        gradient_draw.line((0, min(image.height - 1, y + row), image.width, min(image.height - 1, y + row)), fill=(*color, 255))
    gradient.putalpha(mask)
    image.alpha_composite(gradient)


def _hook(image: Image.Image, config: dict) -> None:
    image.alpha_composite(Image.new("RGBA", image.size, (0, 0, 0, 148)))
    lines = [config.get("thesis") or config.get("chinese_text", ""), config.get("judgment", "3960 是关键压力位"), config.get("evidence", "资金结构仍偏多")]
    styles = (
        ((255, 247, 204), (224, 170, 74), (255, 235, 164)),
        ((255, 255, 255), (190, 194, 203), (255, 255, 255)),
        ((247, 248, 250), (137, 141, 150), (232, 234, 238)),
    )
    for text, y, font, colors in zip(lines, (155, 350, 535), (_serif_font(94), _serif_font(78), _serif_font(58)), styles):
        _metallic_text(image, str(text), y, font, colors)


def _fact(image: Image.Image, config: dict) -> None:
    _luxury_panel(image, (20, 31, 1060, 798), 18, (0, 14, 29), (0, 10, 22))
    ambient = Image.new("RGBA", image.size, (0, 0, 0, 0))
    ambient_draw = ImageDraw.Draw(ambient, "RGBA")
    ambient_draw.ellipse((70, -80, 1010, 690), fill=(0, 66, 130, 58))
    ambient_draw.line((420, 32, 660, 32), fill=(255, 213, 132, 210), width=5)
    ambient_draw.line((410, 796, 670, 796), fill=(255, 186, 75, 175), width=5)
    ambient = ambient.filter(ImageFilter.GaussianBlur(38))
    panel_mask = Image.new("L", image.size, 0)
    ImageDraw.Draw(panel_mask).rounded_rectangle((20, 31, 1060, 798), 18, fill=255)
    image.alpha_composite(Image.composite(ambient, Image.new("RGBA", image.size, (0, 0, 0, 0)), panel_mask))
    draw = ImageDraw.Draw(image, "RGBA")
    for x0, x1 in ((80, 360), (760, 1000)):
        draw.line((x0, 115, x1, 115), fill=(243, 194, 96, 125), width=2)
    for x in (358, 742):
        draw.polygon(((x, 106), (x + 9, 115), (x, 124), (x - 9, 115)), outline=GOLD, width=2)
    blocks = list(config.get("content_blocks") or ["多头席位继续增加", "空头席位出现回落"])
    details = config.get("details") or [["多头席位数  4,126", "多头持仓量  1,671,862", "多头占比  56.3%"], ["空头席位数  3,207", "空头持仓量  1,295,784", "空头占比  43.7%"]]
    changes = config.get("changes") or [["+68", "+42,317", "+2.6%"], ["-54", "-38,652", "-2.6%"]]
    for i, x in enumerate((41, 551)):
        card = (x, 180, x + 489, 601)
        draw.rounded_rectangle(card, 18, fill=(1, 14, 31, 212), outline=(190, 126, 56, 225), width=2)
        _glowing_circle(image, (x + 18, 210, x + 128, 320), outline=(250, 198, 101, 255), fill=(0, 13, 28, 245), width=2)
        image.alpha_composite(_finance_icon("rise_zigzag" if i == 0 else "decline_zigzag", 78), (x + 34, 226))
        draw = ImageDraw.Draw(image, "RGBA")
        heading = str(blocks[min(i, len(blocks)-1)])
        _draw_gold_text(image, heading, (x + 146, 241), _font(32, True), 330)
        draw = ImageDraw.Draw(image, "RGBA")
        for row, text in enumerate(details[min(i, len(details)-1)]):
            y = 354 + row * 84
            label, separator, value = str(text).partition("  ")
            if not separator:
                label, value = str(text), ""
            draw.ellipse((x + 25, y + 13, x + 37, y + 25), outline=GOLD, width=2)
            draw.ellipse((x + 29, y + 17, x + 33, y + 21), fill=PALE_GOLD)
            _draw_fit(draw, label, (x + 48, y), _font(23), WHITE, 152)
            value_x = x + (177 if i == 0 else 195)
            _draw_gold_text(image, value, (value_x, y - 4), _font(29, True), 120)
            draw = ImageDraw.Draw(image, "RGBA")
            delta = str(changes[min(i, len(changes)-1)][row])
            draw.text((x + 333, y + 2), "较上日", font=_font(20), fill=WHITE)
            delta_font = _font(23, True)
            delta_width = draw.textbbox((0, 0), delta, font=delta_font)[2]
            draw.text((x + 485 - delta_width, y), delta, font=delta_font, fill=RED if i == 0 else GREEN)
            if row < 2:
                for dot_x in range(x + 24, x + 466, 6):
                    draw.point((dot_x, y + 59), fill=(243, 194, 96, 105))
    conclusion = config.get("conclusion", "资金结构仍然偏多")
    draw.rounded_rectangle((184, 629, 896, 760), 18, fill=(3, 18, 37, 238), outline=GOLD, width=2)
    draw.polygon(((247, 657), (283, 644), (319, 657), (313, 711), (283, 737), (253, 711)), outline=PALE_GOLD, width=5)
    draw.line((265, 685, 279, 700, 301, 674), fill=PALE_GOLD, width=6)
    conclusion_text = str(conclusion)
    conclusion_font = _font(53, True)
    while conclusion_font.size > 30 and draw.textbbox((0, 0), conclusion_text, font=conclusion_font)[2] > 510:
        conclusion_font = conclusion_font.font_variant(size=conclusion_font.size - 1)
    _draw_gold_text(image, conclusion_text, (374, 661), conclusion_font, 510, glow=3)
    glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow, "RGBA").line((390, 756, 690, 756), fill=(255, 196, 86, 210), width=5)
    image.alpha_composite(glow.filter(ImageFilter.GaussianBlur(10)))


def _data(image: Image.Image, config: dict) -> None:
    left_series = config.get("left_series")
    right_series = config.get("right_series")
    if not isinstance(left_series, list) or not isinstance(right_series, list) or len(left_series) < 2 or len(right_series) < 2:
        raise ValueError("data requires left_series and right_series with at least two real values")
    if len(left_series) != len(right_series):
        raise ValueError("data left_series and right_series must have the same length")
    try:
        left_series = [float(value) for value in left_series]
        right_series = [float(value) for value in right_series]
    except (TypeError, ValueError) as error:
        raise ValueError("data series values must be numeric") from error
    _luxury_panel(image, (20, 55, 1060, 775), 16, (1, 16, 37), (0, 4, 22))
    draw = ImageDraw.Draw(image, "RGBA")
    draw.text((60, 176), str(config.get("data_interval", "7月1日—8月12日")), font=_font(22, True), fill=PALE_GOLD)
    draw.text((60, 222), str(config.get("left_axis_label", "指数")), font=_font(20), fill=PALE_GOLD)
    right_label = str(config.get("right_axis_label", "净多头（手）"))
    right_font = _font(20); right_box = draw.textbbox((0, 0), right_label, font=right_font)
    draw.text((1024 - right_box[2], 222), right_label, font=right_font, fill=BLUE)
    blocks = list(config.get("content_blocks") or ["指数", "净多头"])
    draw.line((375, 174, 420, 174), fill=GOLD, width=6)
    _draw_fit(draw, str(blocks[0]), (435, 155), _font(26), WHITE, 120)
    draw.line((557, 174, 602, 174), fill=BLUE, width=6)
    _draw_fit(draw, str(blocks[min(1, len(blocks) - 1)]), (617, 155), _font(26), WHITE, 145)
    left, top, right, bottom = 134, 273, 939, 689
    left_ticks = [4100, 4000, 3900, 3800, 3700, 3600, 3500, 3400]
    right_ticks = [120000, 90000, 60000, 30000, 0, -30000, -60000, -90000]
    for i, (left_value, right_value) in enumerate(zip(left_ticks, right_ticks)):
        y = top + i * (bottom - top) / 7
        draw.line((left, y, right, y), fill=(255, 255, 255, 55), width=1)
        draw.text((58, y - 13), f"{left_value:,}", font=_font(18), fill=WHITE)
        draw.text((right + 12, y - 13), f"{right_value:,}", font=_font(18), fill=BLUE)
    draw.line((left, top, left, bottom, right, bottom), fill=WHITE, width=2); draw.line((right, top, right, bottom), fill=WHITE, width=2)
    left_points = [(left + index * (right - left) / (len(left_series) - 1), bottom - (value - 3400) / 700 * (bottom - top)) for index, value in enumerate(left_series)]
    right_points = [(left + index * (right - left) / (len(right_series) - 1), bottom - (value + 90000) / 210000 * (bottom - top)) for index, value in enumerate(right_series)]
    draw.line(left_points, fill=GOLD, width=4, joint="curve")
    draw.line(right_points, fill=BLUE, width=4, joint="curve")
    pressure_y = top + (4100 - 3960) / 700 * (bottom - top)
    for x in range(left, right, 14):
        draw.line((x, pressure_y, min(x + 7, right), pressure_y), fill=GOLD, width=3)
    draw.rounded_rectangle((699, pressure_y - 27, 830, pressure_y + 20), 8, fill=(70, 46, 8, 235), outline=GOLD)
    _draw_fit(draw, str(config.get("marker", "3960 压力位")), (711, pressure_y - 20), _font(20), PALE_GOLD, 110)
    for y in range(top, bottom, 12):
        draw.line(((left + right) // 2, y, (left + right) // 2, min(y + 6, bottom)), fill=(255, 255, 255, 75), width=1)
    draw.text((318, bottom + 16), "7月", font=_font(24, True), fill=WHITE); draw.text((716, bottom + 16), "8月", font=_font(24, True), fill=WHITE)


def _number(image: Image.Image, config: dict) -> None:
    _luxury_panel(image, (20, 28, 1060, 801), 20, (3, 8, 15), (4, 10, 19))
    draw = ImageDraw.Draw(image, "RGBA")
    texture = Image.new("RGBA", image.size, (0, 0, 0, 0))
    texture_draw = ImageDraw.Draw(texture, "RGBA")
    for offset in range(-830, 1080, 7):
        texture_draw.line((offset, 800, offset + 773, 27), fill=(255, 255, 255, 7), width=1)
    texture_mask = Image.new("L", image.size, 0)
    ImageDraw.Draw(texture_mask).rounded_rectangle((20, 28, 1060, 801), 20, fill=255)
    texture.putalpha(ImageChops.multiply(texture.getchannel("A"), texture_mask))
    image.alpha_composite(texture)
    draw = ImageDraw.Draw(image, "RGBA")
    value = str(config.get("primary_value", "3960"))
    value_font = _named_font("arialbd.ttf", 388)
    while value_font.size > 80 and draw.textbbox((0, 0), value, font=value_font)[2] > 900:
        value_font = value_font.font_variant(size=value_font.size - 1)
    value_box = draw.textbbox((0, 0), value, font=value_font)
    value_x = (1080 - (value_box[2] - value_box[0])) // 2
    _draw_gold_text(image, value, (value_x, 142), value_font, 920, glow=5)
    unit = str(config.get("unit", "点"))
    unit_font = _named_font("Dengb.ttf", 64)
    unit_box = draw.textbbox((0, 0), unit, font=unit_font)
    _draw_gold_text(image, unit, ((1080 - (unit_box[2] - unit_box[0])) // 2, 514), unit_font, 180, glow=2)
    draw = ImageDraw.Draw(image, "RGBA")
    draw.line((126, 640, 954, 640), fill=(243, 194, 96, 145), width=2)
    draw.polygon(((540, 630), (550, 640), (540, 650), (530, 640)), fill=GOLD)
    _center(draw, str(config.get("conclusion", "突破后观察成交量确认")), 681, _named_font("Dengb.ttf", 52), WHITE, 80, 1000)


def _causal(image: Image.Image, config: dict) -> None:
    _luxury_panel(image, (20, 29, 1060, 800), 22, (0, 16, 32), (1, 13, 27))
    ambient = Image.new("RGBA", image.size, (0, 0, 0, 0))
    ImageDraw.Draw(ambient, "RGBA").ellipse((80, -40, 1000, 690), fill=(0, 68, 132, 50))
    ambient = ambient.filter(ImageFilter.GaussianBlur(45))
    mask = Image.new("L", image.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((20, 29, 1060, 800), 22, fill=255)
    image.alpha_composite(Image.composite(ambient, Image.new("RGBA", image.size, (0, 0, 0, 0)), mask))
    draw = ImageDraw.Draw(image, "RGBA")
    draw.line((260, 207, 820, 207), fill=(243, 194, 96, 130), width=2)
    draw.polygon(((540, 194), (553, 207), (540, 220), (527, 207)), fill=PALE_GOLD)
    blocks = list(config.get("content_blocks") or ["机构增多", "净多头上升", "指数挑战3960"])
    centers = (190, 540, 890)
    for i, x in enumerate(centers):
        _glowing_circle(image, (x - 102, 263, x + 102, 477), outline=(250, 198, 89, 255), fill=(0, 15, 31, 246), width=3)
        icon_kind = ("causal_group", "causal_curve", "causal_zigzag")[i]
        image.alpha_composite(_finance_icon(icon_kind, 158), (x - 79, 291))
        draw = ImageDraw.Draw(image, "RGBA")
        _center(draw, str(blocks[min(i, len(blocks)-1)]), 505, _font(34, True), WHITE, x - 155, x + 155)
        if i < 2:
            x0, x1 = x + 118, centers[i + 1] - 118
            arrow = ((x0, 356), (x1 - 27, 356), (x1 - 27, 342), (x1, 370), (x1 - 27, 398), (x1 - 27, 384), (x0, 384))
            draw.polygon(tuple((px, py + 4) for px, py in arrow), fill=(92, 48, 5, 210))
            draw.polygon(arrow, fill=(231, 160, 43, 255))
            draw.polygon(((x0, 356), (x1 - 27, 356), (x1 - 27, 342), (x1, 370), (x1 - 27, 370), (x0, 370)), fill=(255, 225, 142, 255))
    draw.line((150, 594, 930, 594), fill=(243, 194, 96, 145), width=2)
    draw.polygon(((540, 584), (550, 594), (540, 604), (530, 594)), fill=GOLD)
    draw = ImageDraw.Draw(image, "RGBA")
    conclusion = str(config.get("conclusion", "持仓变化强化上行动能"))
    conclusion_font = _serif_font(57)
    conclusion_box = draw.textbbox((0, 0), conclusion, font=conclusion_font)
    _draw_gold_text(image, conclusion, ((1080 - (conclusion_box[2] - conclusion_box[0])) // 2, 646), conclusion_font, 760, glow=2, embolden=1)


def _comparison(image: Image.Image, config: dict) -> None:
    _luxury_panel(image, (20, 104, 1060, 726), 20, (5, 16, 32), (7, 22, 43))
    draw = ImageDraw.Draw(image, "RGBA")
    draw.rectangle((28, 190, 540, 598), fill=(4, 22, 48, 234)); draw.rectangle((540, 190, 1052, 598), fill=(14, 15, 18, 240))
    draw.line((540, 190, 540, 598), fill=GOLD, width=2)
    for x in range(70, 500, 43):
        height = 50 + ((x * 7) % 125); draw.rectangle((x, 410-height, x+19, 410), fill=(93, 139, 210, 45))
    draw.line(((70, 430), (205, 330), (315, 360), (495, 220)), fill=(128, 174, 236, 45), width=36)
    for x in range(585, 1020, 43):
        height = 50 + ((x * 5) % 125); draw.rectangle((x, 410-height, x+19, 410), fill=(190, 195, 202, 38))
    draw.line(((585, 235), (710, 355), (815, 325), (1010, 445)), fill=(190, 195, 202, 38), width=36)
    left_visual = config.get("left_visual_path")
    right_visual = config.get("right_visual_path")
    if bool(left_visual) != bool(right_visual):
        raise ValueError("comparison requires both left_visual_path and right_visual_path")
    if left_visual and right_visual:
        for path, center_x in ((Path(left_visual), 315), (Path(right_visual), 765)):
            if not path.is_file():
                raise FileNotFoundError(path)
            visual = ImageOps.contain(Image.open(path).convert("RGBA"), (310, 220), Image.Resampling.LANCZOS)
            image.alpha_composite(visual, (center_x - visual.width // 2, 205))
    elif config.get("visual_theme") == "bull_bear":
        bull = COMPONENT_DIR / "2026-08-24_图片_多头金牛组件.png"
        bear = COMPONENT_DIR / "2026-08-24_图片_空头银熊组件.png"
        if not bull.is_file() or not bear.is_file():
            raise FileNotFoundError("bull/bear components are required only for visual_theme=bull_bear")
        for path, size, position in ((bull, (290, 238), (165, 200)), (bear, (296, 238), (625, 205))):
            visual = Image.open(path).convert("RGBA").resize(size, Image.Resampling.LANCZOS)
            fade = Image.new("L", size, 0)
            ImageDraw.Draw(fade).rounded_rectangle((12, 12, size[0] - 12, size[1] - 12), 18, fill=255)
            visual.putalpha(fade.filter(ImageFilter.GaussianBlur(14)))
            image.alpha_composite(visual, position)
    else:
        glow = Image.new("RGBA", image.size, (0, 0, 0, 0)); glow_draw = ImageDraw.Draw(glow, "RGBA")
        glow_draw.ellipse((185, 205, 445, 405), fill=(84, 150, 255, 70)); glow_draw.ellipse((635, 205, 895, 405), fill=(220, 225, 235, 55))
        image.alpha_composite(glow.filter(ImageFilter.GaussianBlur(30)))
        draw = ImageDraw.Draw(image, "RGBA")
        for center_x, outline, inner in ((315, PALE_GOLD, (16, 57, 112, 245)), (765, (214, 218, 226, 255), (42, 43, 47, 245))):
            draw.ellipse((center_x - 103, 215, center_x + 103, 401), fill=inner, outline=outline, width=5)
            draw.polygon(((center_x, 246), (center_x + 70, 308), (center_x, 370), (center_x - 70, 308)), outline=outline)
            draw.ellipse((center_x - 31, 279, center_x + 31, 341), outline=outline, width=5)
    draw = ImageDraw.Draw(image, "RGBA")
    _center(draw, str(config.get("left_label", "多头")), 405, _font(48, True), WHITE, 28, 540)
    _center(draw, str(config.get("left_value", "+1.8万手")), 475, _font(68, True), PALE_GOLD, 28, 540)
    _center(draw, str(config.get("right_label", "空头")), 405, _font(48, True), WHITE, 540, 1052)
    _center(draw, str(config.get("right_value", "-0.6万手")), 475, _font(68, True), GREEN, 540, 1052)
    _glowing_circle(image, (474, 335, 606, 467), outline=PALE_GOLD, fill=(6, 27, 52, 255), width=4)
    draw = ImageDraw.Draw(image, "RGBA"); draw.ellipse((485, 346, 595, 456), outline=GOLD, width=4); _center(draw, "VS", 367, _font(46, True), PALE_GOLD, 478, 602)
    draw.line((28, 598, 1052, 598), fill=GOLD, width=3)
    draw.polygon(((28, 598), (116, 598), (95, 611), (28, 611)), fill=(255, 222, 142, 255))
    draw.polygon(((1052, 598), (964, 598), (985, 611), (1052, 611)), fill=(255, 222, 142, 255))
    draw.polygon(((60, 610), (1020, 610), (1052, 638), (1020, 716), (60, 716), (28, 688), (28, 638)), fill=(5, 24, 55, 250), outline=GOLD)
    draw.line(((65, 617), (1015, 617), (1044, 642), (1016, 707), (65, 707), (36, 684), (36, 642), (65, 617)), fill=(255, 224, 151, 235), width=2)
    conclusion = str(config.get("conclusion", "多头占优"))
    conclusion_font = _font(82, True)
    conclusion_box = draw.textbbox((0, 0), conclusion, font=conclusion_font)
    _draw_gold_text(image, conclusion, ((1080 - (conclusion_box[2] - conclusion_box[0])) // 2, 616), conclusion_font, 800, glow=3)


RENDERERS = {"hook": _hook, "fact": _fact, "data": _data, "number": _number, "causal": _causal, "comparison": _comparison}
PAGE_BOUNDS = {
    "fact": (22, 31, 1058, 799),
    "data": (22, 54, 1058, 776),
    "number": (22, 28, 1058, 801),
    "causal": (22, 29, 1058, 800),
    "comparison": (22, 104, 1058, 726),
}


def render_page(config: dict, size=PAGE_SIZE, background_path: Path | None = None) -> Image.Image:
    kind = config.get("type")
    if kind not in RENDERERS:
        raise ValueError(f"unsupported reference page type: {kind}")
    if background_path is not None:
        raise ValueError("reference/sample images cannot be used as page backgrounds")
    image = _canvas(size)
    RENDERERS[kind](image, config)
    if kind in PAGE_BOUNDS:
        left, top, right, bottom = PAGE_BOUNDS[kind]
        alpha = image.getchannel("A")
        alpha.paste(0, (0, 0, left, image.height)); alpha.paste(0, (right, 0, image.width, image.height))
        alpha.paste(0, (0, 0, image.width, top)); alpha.paste(0, (0, bottom, image.width, image.height))
        image.putalpha(alpha)
    return image


SAMPLES = {
    "hook": {"type": "hook", "thesis": "机构继续加多", "judgment": "3960 是关键压力位", "evidence": "资金结构仍偏多"},
    "news": {"type": "news"},
    "fact": {"type": "fact", "content_blocks": ["多头席位继续增加", "空头席位出现回落"], "details": [["多头席位数  4,126", "多头持仓量  1,671,862", "多头占比  56.3%"], ["空头席位数  3,207", "空头持仓量  1,295,784", "空头占比  43.7%"]], "changes": [["+68", "+42,317", "+2.6%"], ["-54", "-38,652", "-2.6%"]], "conclusion": "资金结构仍然偏多"},
    "data": {"type": "data", "content_blocks": ["指数", "净多头"], "left_series": [3550, 3540, 3560, 3550, 3570, 3580, 3620, 3600, 3620, 3640, 3650, 3630, 3645, 3635, 3615, 3600, 3630, 3660, 3680, 3705, 3700, 3720, 3740, 3770, 3785, 3750, 3720, 3710, 3740, 3720, 3760, 3800, 3830, 3865, 3850, 3840, 3860, 3890, 3910, 3880, 3860, 3900, 3940, 3975, 3955, 3990, 3970, 4000, 3980, 4020, 3990], "right_series": [-55000, -52000, -57000, -50000, -55000, -60000, -52000, -58000, -60000, -62000, -57000, -65000, -70000, -66000, -59000, -51000, -54000, -49000, -52000, -46000, -42000, -30000, -33000, -25000, -20000, -15000, -10000, -8000, -3000, 5000, 10000, 25000, 35000, 42000, 38000, 45000, 50000, 55000, 30000, 40000, 35000, 50000, 60000, 70000, 65000, 75000, 70000, 80000, 76000, 82000, 78000]},
    "number": {"type": "number", "primary_value": "3960", "unit": "点", "conclusion": "突破后观察成交量确认"},
    "causal": {"type": "causal", "content_blocks": ["机构增多", "净多头上升", "指数挑战3960"], "conclusion": "持仓变化强化上行动能"},
    "comparison": {"type": "comparison", "left_label": "多头", "left_value": "+1.8万手", "right_label": "空头", "right_value": "-0.6万手", "conclusion": "多头占优"},
}
PAGE_LABELS = {"hook": "钩子页", "fact": "事实页", "news": "新闻页", "data": "数据页", "number": "数字页", "causal": "因果页", "comparison": "对比页"}


def _vertical_sample(center: Image.Image) -> Image.Image:
    full = _fit(center.convert("RGB"), (1080, 1920)).filter(ImageFilter.GaussianBlur(30)).convert("RGBA")
    full.alpha_composite(Image.new("RGBA", full.size, (0, 0, 0, 75)))
    full.alpha_composite(center.convert("RGBA"), (0, 604))
    draw = ImageDraw.Draw(full, "RGBA"); text = "内容仅为个人观点，不构成投资建议"; font = _font(24)
    box = draw.textbbox((0, 0), text, font=font)
    draw.text((1080 - 62 - (box[2] - box[0]), 604 - 8 - (box[3] - box[1])), text, font=font, fill=WHITE)
    return full


def build_reference_set(reference_dir: Path, manifest_path: Path, news_screenshot_path: Path, samples_dir: Path | None = None, contact_sheet: Path | None = None) -> dict:
    templates = {}
    rendered_samples = []
    reference_dir.mkdir(parents=True, exist_ok=True)
    if not Path(news_screenshot_path).is_file():
        raise FileNotFoundError(news_screenshot_path)
    if samples_dir:
        samples_dir.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for kind, item in manifest["templates"].items():
        output = SKILL_ROOT / item["file"]
        page = fit_screenshot(news_screenshot_path) if kind == "news" else render_page(SAMPLES[kind])
        page.save(output)
        if page.size != PAGE_SIZE:
            raise ValueError(f"approved page must be 1080x830: {output}")
        templates[kind] = {"file": output.relative_to(SKILL_ROOT).as_posix(), "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "width": 1080, "height": 830, "role": "central_clear_window"}
        if samples_dir:
            sample = samples_dir / f"2026-08-24_图片_{PAGE_LABELS[kind]}竖版样图.png"
            vertical = _vertical_sample(page); vertical.save(sample); rendered_samples.append(vertical.resize((270, 480), Image.Resampling.LANCZOS))
    payload = {"schema_version": 2, "central_window": {"width": 1080, "height": 830, "top": 604}, "templates": templates}
    manifest_path.parent.mkdir(parents=True, exist_ok=True); manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if contact_sheet and rendered_samples:
        sheet = Image.new("RGB", (1080, 960), (12, 16, 24))
        for index, sample in enumerate(rendered_samples):
            sheet.paste(sample.convert("RGB"), ((index % 4) * 270, (index // 4) * 480))
        contact_sheet.parent.mkdir(parents=True, exist_ok=True); sheet.save(contact_sheet, quality=94)
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-reference-set", action="store_true")
    parser.add_argument("--news-screenshot", required=True)
    parser.add_argument("--samples-dir")
    parser.add_argument("--contact-sheet")
    args = parser.parse_args()
    if not args.build_reference_set:
        parser.error("--build-reference-set is required")
    payload = build_reference_set(APPROVED_DIR, MANIFEST_PATH, Path(args.news_screenshot), Path(args.samples_dir) if args.samples_dir else None, Path(args.contact_sheet) if args.contact_sheet else None)
    assert set(payload["templates"]) == {"hook", "fact", "news", "data", "number", "causal", "comparison"}
    print(MANIFEST_PATH)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
