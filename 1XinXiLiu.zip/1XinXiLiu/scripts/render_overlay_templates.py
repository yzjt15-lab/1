#!/usr/bin/env python3
"""Render the single dark-blue/gold information-page system used by this skill."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from speed_common import content_key


FONT_CANDIDATES = (Path(r"C:\Windows\Fonts\msyhbd.ttc"), Path(r"C:\Windows\Fonts\msyh.ttc"), Path(r"C:\Windows\Fonts\simhei.ttf"))
GOLD, GOLD_LIGHT, NAVY, NAVY_2, WHITE, GREEN, RED = (232, 190, 82, 245), (255, 222, 151, 255), (7, 24, 48, 224), (17, 45, 83, 220), (247, 250, 255, 255), (125, 209, 144, 255), (255, 108, 100, 255)
BULL_BEAR_ASSET = Path(__file__).resolve().parent.parent / "assets" / "bull-bear.png"


def _font(size: int, bold: bool = False):
    for path in FONT_CANDIDATES:
        if path.exists():
            return ImageFont.truetype(str(path), size, index=0)
    return ImageFont.load_default()


def _center(draw, box, text, font, fill=WHITE):
    left, top, right, bottom = box
    text = str(text)
    bounds = draw.textbbox((0, 0), text, font=font)
    draw.text(((left + right - bounds[2]) / 2, (top + bottom - bounds[3]) / 2), text, font=font, fill=fill)


def _text(draw, xy, text, font, fill=WHITE):
    draw.text(xy, str(text), font=font, fill=fill)


def _panel(draw, box, radius=28, fill=NAVY):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=GOLD, width=2)


def _title(draw, box, text):
    _center(draw, box, text, _font(54, True), GOLD_LIGHT)
    y = box[3] - 10
    draw.line((box[0] + 120, y, box[2] - 120, y), fill=(232, 190, 82, 150), width=2)


def _trend(draw, box, color=GOLD):
    left, top, right, bottom = box
    points = [(left, bottom - 16), (left + (right-left)*.18, bottom-44), (left + (right-left)*.36, bottom-31), (left + (right-left)*.56, bottom-76), (left + (right-left)*.75, bottom-64), (right-16, top+22)]
    draw.line(points, fill=color, width=8, joint="curve")
    x, y = points[-1]
    draw.polygon([(x, y), (x-24, y+8), (x-7, y+26)], fill=color)


def _bars(draw, box, color=GOLD, falling=False):
    left, top, right, bottom = box
    heights = [0.34, 0.50, 0.67, 0.90]
    if falling:
        heights.reverse()
    gap = (right-left) / 10
    bar_w = gap * 1.45
    for index, ratio in enumerate(heights):
        x = left + gap + index * gap * 2.1
        draw.rectangle((x, bottom-(bottom-top)*ratio, x+bar_w, bottom), fill=color)
    draw.line((left, bottom, right, bottom), fill=(255,255,255,120), width=2)
    if falling:
        draw.line((left+20, top+18, right-12, bottom-28), fill=color, width=8)
        draw.polygon([(right-12,bottom-28),(right-36,bottom-38),(right-24,bottom-54)], fill=color)
    else:
        draw.line((left+20, bottom-50, right-12, top+18), fill=color, width=8)
        draw.polygon([(right-12,top+18),(right-36,top+28),(right-24,top+44)], fill=color)


def _people_icon(draw, cx, cy, color=GOLD_LIGHT):
    for dx, scale in ((-50,.78),(0,1.0),(50,.78)):
        r = int(22*scale)
        draw.ellipse((cx+dx-r,cy-65-r,cx+dx+r,cy-65+r),fill=color)
        draw.rounded_rectangle((cx+dx-int(29*scale),cy-36,cx+dx+int(29*scale),cy+42),radius=15,fill=color)


def _bull_icon(draw, cx, cy, color=GOLD_LIGHT):
    draw.ellipse((cx-105,cy-50,cx+55,cy+55),fill=color)
    draw.ellipse((cx+30,cy-75,cx+115,cy+15),fill=color)
    draw.polygon([(cx+65,cy-70),(cx+110,cy-125),(cx+94,cy-55)],fill=color)
    draw.polygon([(cx+30,cy-65),(cx-5,cy-120),(cx+50,cy-45)],fill=color)
    for x in (cx-72,cx-18,cx+43,cx+82):
        draw.rectangle((x,cy+35,x+18,cy+110),fill=color)
    draw.line((cx-100,cy-20,cx-145,cy-55),fill=color,width=12)


def _bear_icon(draw, cx, cy, color=(205,210,218,255)):
    draw.ellipse((cx-90,cy-65,cx+65,cy+80),fill=color)
    draw.ellipse((cx+25,cy-105,cx+105,cy-20),fill=color)
    draw.ellipse((cx+30,cy-120,cx+58,cy-92),fill=color)
    draw.ellipse((cx+70,cy-118,cx+98,cy-90),fill=color)
    for x in (cx-60,cx-5,cx+40,cx+72):
        draw.rectangle((x,cy+50,x+20,cy+115),fill=color)


def _metric_card(draw, box, title, value, detail="", accent=GOLD):
    _panel(draw, box, 18, (10, 34, 68, 238))
    left, top, right, bottom = box
    _center(draw, (left, top+18, right, top+75), title, _font(32, True), accent)
    _bars(draw, (left+65, top+105, right-65, top+255), accent, falling=accent == GREEN)
    _center(draw, (left, top+255, right, bottom-74), value, _font(56, True), accent)
    _center(draw, (left+24, bottom-66, right-24, bottom-20), detail, _font(22), WHITE)


def _blocks(config):
    blocks = config.get("content_blocks") or config.get("items") or []
    return [str(x if isinstance(x, str) else f"{x.get('label', '')} {x.get('value', '')}").strip() for x in blocks if str(x).strip()]


def _render_hook(draw, config, size):
    width, height = size
    # No card: this is intentionally typography-only over the darkened real video.
    thesis = config.get("thesis") or config.get("page_title") or config.get("title", "")
    judgment = config.get("judgment") or config.get("chinese_text", "")
    evidence = config.get("evidence") or config.get("primary_value", "")
    _center(draw, (70, 205, width-70, 505), thesis, _font(176, True), GOLD_LIGHT)
    _center(draw, (80, 500, width-80, 675), judgment, _font(116, True), WHITE)
    _center(draw, (120, 690, width-120, 805), evidence, _font(66, True), (210, 215, 225, 235))


def _render_data(draw, config, size):
    width, height = size
    panel = (245, 150, width-245, 875)
    _panel(draw, panel, 30)
    _title(draw, (panel[0], panel[1]+18, panel[2], panel[1]+132), config.get("page_title") or config.get("title", ""))
    blocks = _blocks(config) or ["核心指标", "结构变化", "结论"]
    cols = 3
    gap, card_w = 24, (panel[2]-panel[0]-80-48)//cols
    for index in range(cols):
        left = panel[0]+40+index*(card_w+gap)
        label = blocks[index] if index < len(blocks) else "指标"
        detail = config.get("details", ["较前日改善"] * 3)
        _metric_card(draw, (left, panel[1]+155, left+card_w, panel[3]-125), label, config.get("values", ["—", "—", "—"])[index] if isinstance(config.get("values"), list) and index < len(config["values"]) else "重点", detail[index] if isinstance(detail, list) and index < len(detail) else "较前日改善", GREEN if index == 1 else GOLD_LIGHT)
    conclusion = config.get("conclusion") or config.get("chinese_text", "")
    _panel(draw, (panel[0]+250, panel[3]-105, panel[2]-250, panel[3]-28), 16, (11, 36, 70, 240))
    _center(draw, (panel[0]+270, panel[3]-97, panel[2]-270, panel[3]-36), conclusion, _font(34, True), GOLD_LIGHT)


def _render_number(draw, config, size):
    width, height = size
    panel = (365, 185, width-365, 855)
    _panel(draw, panel, 30)
    _title(draw, (panel[0], panel[1]+20, panel[2], panel[1]+120), config.get("page_title") or config.get("title", ""))
    _center(draw, (panel[0]+40, panel[1]+135, panel[2]-40, panel[1]+230), config.get("label", "关键数字"), _font(42, True), GOLD_LIGHT)
    _center(draw, (panel[0]+20, panel[1]+205, panel[2]-20, panel[3]-190), config.get("primary_value") or config.get("number", ""), _font(275, True), GOLD_LIGHT)
    _center(draw, (panel[0]+40, panel[3]-210, panel[2]-40, panel[3]-145), config.get("unit", ""), _font(48, True), GOLD_LIGHT)
    draw.line((panel[0]+170, panel[3]-128, panel[2]-170, panel[3]-128), fill=(232, 190, 82, 170), width=2)
    _center(draw, (panel[0]+90, panel[3]-110, panel[2]-90, panel[3]-35), config.get("conclusion") or config.get("chinese_text", ""), _font(34, True), WHITE)


def _render_comparison(draw, config, size):
    width, height = size
    panel = (305, 150, width-305, 880)
    _panel(draw, panel, 30)
    _title(draw, (panel[0], panel[1]+16, panel[2], panel[1]+118), config.get("page_title") or config.get("title", ""))
    middle = width//2
    draw.rectangle((panel[0]+2,panel[1]+125,middle,panel[3]-120),fill=(15,48,91,115))
    draw.rectangle((middle,panel[1]+125,panel[2]-2,panel[3]-120),fill=(14,16,22,145))
    draw.line((middle, panel[1]+125, middle, panel[3]-120), fill=(255,255,255,150), width=2)
    draw.ellipse((middle-65, 440, middle+65, 570), fill=(8, 24, 47, 255), outline=GOLD, width=3)
    _center(draw, (middle-65, 440, middle+65, 570), "VS", _font(40, True), GOLD_LIGHT)
    for side, title_key, value_key, x0, x1, accent in (("left", "left_title", "left_value", panel[0]+35, middle-75, GOLD_LIGHT), ("right", "right_title", "right_value", middle+75, panel[2]-35, GREEN)):
        title = config.get(title_key) or config.get(side, "")
        value = config.get(value_key) or "—"
        _center(draw, (x0, 505, x1, 585), title, _font(62, True), WHITE)
        _center(draw, (x0, 585, x1, 700), value, _font(82, True), accent)
    if BULL_BEAR_ASSET.is_file():
        animals = Image.open(BULL_BEAR_ASSET).convert("RGBA").resize((900, 345))
        draw._image.alpha_composite(animals, (510, 245))
    else:
        _bull_icon(draw, 640, 375, GOLD_LIGHT)
        _bear_icon(draw, 1280, 375)
    _panel(draw, (panel[0]+90, panel[3]-110, panel[2]-90, panel[3]-28), 14, (12, 36, 70, 244))
    _center(draw, (panel[0]+110, panel[3]-102, panel[2]-110, panel[3]-35), config.get("conclusion") or config.get("chinese_text", ""), _font(44, True), GOLD_LIGHT)


def _render_causal(draw, config, size):
    width, height = size
    panel = (280, 160, width-280, 875)
    _panel(draw, panel, 30)
    _title(draw, (panel[0], panel[1]+18, panel[2], panel[1]+122), config.get("page_title") or config.get("title", ""))
    blocks = _blocks(config) or ["起因", "传导", "结果"]
    centers = (530, 960, 1390)
    for index, cx in enumerate(centers):
        draw.ellipse((cx-105, 350, cx+105, 560), fill=(10, 34, 67, 240), outline=GOLD, width=3)
        if index == 0:
            _people_icon(draw, cx, 470)
        else:
            _bars(draw, (cx-70,405,cx+70,520), GOLD_LIGHT, falling=False)
        _center(draw, (cx-170, 580, cx+170, 660), blocks[index] if index < len(blocks) else "环节", _font(34, True), WHITE)
        if index < 2:
            draw.polygon([(cx+155, 450), (cx+290, 450), (cx+290, 420), (cx+365, 485), (cx+290, 550), (cx+290, 520), (cx+155, 520)], fill=GOLD)
    _center(draw, (panel[0]+120, panel[3]-120, panel[2]-120, panel[3]-30), config.get("conclusion") or config.get("chinese_text", ""), _font(42, True), GOLD_LIGHT)


def _render_fact(draw, config, size):
    width, height = size
    panel = (215, 155, width-215, 875)
    _panel(draw, panel, 30)
    _title(draw, (panel[0], panel[1]+20, panel[2], panel[1]+125), config.get("page_title") or config.get("title", ""))
    halves = ((panel[0]+38, width//2-20), (width//2+20, panel[2]-38))
    groups = config.get("groups") or [
        {"title": "多头席位继续增加", "metrics": ["多头席位数  4,126  +68", "多头持仓量  1,671,862  +42,317", "多头占比  56.3%  +2.6%"]},
        {"title": "空头席位出现回落", "metrics": ["空头席位数  3,207  -54", "空头持仓量  1,295,784  -38,652", "空头占比  43.7%  -2.6%"]},
    ]
    for index, (left, right) in enumerate(halves):
        top, bottom = panel[1]+145, panel[3]-145
        _panel(draw, (left, top, right, bottom), 18, (10, 34, 68, 238))
        group = groups[index] if index < len(groups) else {"title": "持仓变化", "metrics": []}
        draw.ellipse((left+25,top+26,left+120,top+121),outline=GOLD_LIGHT,width=4)
        _bars(draw,(left+45,top+48,left+100,top+101),GOLD_LIGHT if index == 0 else GREEN,falling=index==1)
        _center(draw, (left+115, top+20, right-20, top+110), group.get("title", ""), _font(38, True), GOLD_LIGHT)
        for row, metric in enumerate(group.get("metrics", [])[:3]):
            y = top+130+row*82
            draw.ellipse((left+40, y+16, left+54, y+30), fill=GOLD)
            _text(draw, (left+76, y), metric, _font(27), WHITE if index == 0 else (225,230,235,255))
            draw.line((left+38, y+58, right-38, y+58), fill=(232,190,82,70), width=1)
    _panel(draw, (panel[0]+300, panel[3]-120, panel[2]-300, panel[3]-30), 16, (11, 36, 70, 244))
    _center(draw, (panel[0]+320, panel[3]-112, panel[2]-320, panel[3]-38), config.get("conclusion") or config.get("chinese_text", ""), _font(38, True), GOLD_LIGHT)


def render_overlay(config: dict, output_dir: Path, size=(1920, 1080)) -> Path:
    kind = {"vs": "comparison"}.get(config.get("type"), config.get("type"))
    if kind not in {"chrome", "hook", "fact", "number", "comparison", "data", "causal", "news"}:
        raise ValueError("invalid overlay type")
    signature = content_key({"template_version": 7, "size": size, "config": config}, 20)
    output = Path(output_dir) / f"ov_{signature}.png"
    if output.exists():
        return output
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = size
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    if kind == "chrome":
        top_height, bottom_height = int(height*.10), int(height*.13)
        draw.rectangle((0, 0, width, top_height), fill=(3, 5, 8, 248))
        draw.rectangle((0, top_height-4, width, top_height), fill=GOLD)
        draw.rectangle((0, height-bottom_height, width, height), fill=(3, 5, 8, 248))
        draw.rectangle((0, height-bottom_height, width, height-bottom_height+4), fill=GOLD)
        _text(draw, (50, 24), config.get("title", ""), _font(48, True), GOLD_LIGHT)
        disclaimer = config.get("disclaimer", "内容仅代表个人观点，不作为投资建议")
        font = _font(29)
        bounds = draw.textbbox((0,0), disclaimer, font=font)
        _text(draw, (width-bounds[2]-50, 35), disclaimer, font, WHITE)
    elif kind == "hook": _render_hook(draw, config, size)
    elif kind == "data": _render_data(draw, config, size)
    elif kind == "number": _render_number(draw, config, size)
    elif kind == "comparison": _render_comparison(draw, config, size)
    elif kind == "causal": _render_causal(draw, config, size)
    elif kind == "fact": _render_fact(draw, config, size)
    else: raise ValueError("news overlays must use an authentic screenshot_path")
    image.save(output)
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True); parser.add_argument("--output-dir", required=True)
    parser.add_argument("--width", type=int, default=1920); parser.add_argument("--height", type=int, default=1080)
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    print(render_overlay(config, Path(args.output_dir), (args.width, args.height)))
    return 0


if __name__ == "__main__": raise SystemExit(main())
