#!/usr/bin/env python3
"""Render global chrome and reference-bound self-authored information pages."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from reference_page_renderer import PAGE_SIZE, fit_screenshot, render_page
from speed_common import content_key


def _font(size: int):
    for path in (Path(r"C:\Windows\Fonts\msyh.ttc"), Path(r"C:\Windows\Fonts\simhei.ttf")):
        if path.is_file():
            return ImageFont.truetype(str(path), size, index=0)
    return ImageFont.load_default()


def render_overlay(config: dict, output_dir: Path, size=(1920, 1080)) -> Path:
    kind = config.get("type")
    if kind == "news":
        screenshot = config.get("screenshot_path")
        if not screenshot:
            raise ValueError("news requires screenshot_path for direct display")
        output_dir.mkdir(parents=True, exist_ok=True)
        output = output_dir / f"news_{content_key({'kind': kind, 'size': size, 'screenshot': str(Path(screenshot).resolve()), 'mtime': Path(screenshot).stat().st_mtime_ns}, 20)}.png"
        if not output.exists():
            fit_screenshot(Path(screenshot), size).save(output)
        return output
    if kind not in {"chrome", "hook", "fact", "data", "number", "comparison", "causal"}:
        raise ValueError(f"unsupported overlay type: {kind}")
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_key = {'kind': kind, 'size': size, 'config': config}
    if kind == "chrome":
        cache_key["template_version"] = 5
    else:
        cache_key["template_version"] = 25
    output = output_dir / f"ov_{content_key(cache_key, 20)}.png"
    if output.exists():
        return output
    if kind != "chrome":
        image = render_page(config, PAGE_SIZE).resize(size, Image.Resampling.LANCZOS)
        image.save(output)
        return output
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    width, height = size
    text = config.get("disclaimer", "内容仅为个人观点，不构成投资建议")
    font_size = max(18, round(width * 24 / 1080))
    font = _font(font_size)
    box = draw.textbbox((0, 0), text, font=font)
    right_margin = round(width * 62 / 1080)
    draw.text((width - box[2] - right_margin, round(height * 604 / 1920) - round(height * 8 / 1920) - (box[3] - box[1])), text, font=font, fill=(247, 250, 255, 255))
    image.save(output)
    return output
