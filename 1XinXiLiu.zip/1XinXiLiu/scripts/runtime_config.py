#!/usr/bin/env python3
"""Portable runtime paths for the infoflow workflow."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path


def env_path(name: str, default: Path | None = None) -> Path | None:
    value = os.environ.get(name)
    return Path(value).expanduser().resolve() if value else (default.resolve() if default else None)


USER_ROOT = env_path("INFOFLOW_USER_ROOT", Path.home())
CONFIG_ROOT = env_path("INFOFLOW_CONFIG_ROOT", USER_ROOT / ".codex")
SKILLS_ROOT = env_path("INFOFLOW_SKILLS_ROOT", CONFIG_ROOT / "skills")
MATERIAL_LIBRARY_ROOT = env_path("INFOFLOW_MATERIAL_LIBRARY_ROOT", CONFIG_ROOT / "000SuCaiKu")
MATERIAL_LIBRARY_SCRIPTS = env_path("INFOFLOW_MATERIAL_LIBRARY_SCRIPTS", SKILLS_ROOT / "1SuCaiKu" / "scripts")
VIDEO_OUTPUT_DIR = env_path("INFOFLOW_VIDEO_OUTPUT_DIR", USER_ROOT / "Videos" / "Codex")
VISUAL_SEMANTIC_CACHE = env_path("INFOFLOW_VISUAL_SEMANTIC_CACHE", MATERIAL_LIBRARY_ROOT / ".cache" / "visual-semantic-index")
VISUAL_SEMANTIC_INDEX = env_path(
    "INFOFLOW_VISUAL_SEMANTIC_INDEX",
    SKILLS_ROOT / "1QuXian" / "scripts" / "visual_semantic_index.py",
)
FFMPEG_OVERRIDE = os.environ.get("INFOFLOW_FFMPEG")
FFPROBE_OVERRIDE = os.environ.get("INFOFLOW_FFPROBE")


def official_video_dir() -> Path:
    candidate = env_path("INFOFLOW_E2E_OUTPUT_DIR")
    temp_root = Path(tempfile.gettempdir()).resolve()
    if os.environ.get("RUN_REAL_E2E") == "1" and candidate and candidate.is_relative_to(temp_root):
        return candidate
    return VIDEO_OUTPUT_DIR
