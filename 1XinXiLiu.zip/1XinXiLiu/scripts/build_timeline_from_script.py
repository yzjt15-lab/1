#!/usr/bin/env python3
"""Create an exact-duration semantic timeline skeleton from Chinese copy."""
from __future__ import annotations

import argparse
import math
import re
from pathlib import Path

from speed_common import resolve_duration, write_json


BREAK_RE = re.compile(r"(?<=[。！？!?；;])\s*|\n+")


def semantic_split(script: str) -> list[str]:
    return [part.strip() for part in BREAK_RE.split(script.strip()) if part.strip()]


def _weight(text: str) -> int:
    chars = len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text))
    numbers = len(re.findall(r"\d+(?:\.\d+)?%?", text))
    return max(1, chars + numbers * 2)


def _split_longest(parts: list[str]) -> None:
    index = max(range(len(parts)), key=lambda i: len(parts[i]))
    text = parts[index]
    middle = max(1, len(text) // 2)
    parts[index:index + 1] = [text[:middle].strip(), text[middle:].strip()]


def _allocate(weights: list[int], total: float, maximum: float = 5.0) -> list[float]:
    remaining = set(range(len(weights)))
    values = [0.0] * len(weights)
    remaining_total = total
    while remaining:
        weight_total = sum(weights[index] for index in remaining)
        capped = [index for index in remaining if remaining_total * weights[index] / weight_total > maximum]
        if not capped:
            for index in remaining:
                values[index] = remaining_total * weights[index] / weight_total
            break
        for index in capped:
            values[index] = maximum
            remaining_total -= maximum
            remaining.remove(index)
    return values


def build_timeline(script: str, duration: float, script_path: str, audio_path: str | None = None) -> dict:
    if duration <= 0:
        raise ValueError("duration must be > 0")
    parts = semantic_split(script)
    if not parts:
        raise ValueError("script is empty")
    minimum_count = math.ceil(duration / 5.0)
    while len(parts) < minimum_count:
        _split_longest(parts)
    durations = _allocate([_weight(part) for part in parts], float(duration))
    shots = []
    cursor = 0.0
    for index, (text, shot_duration) in enumerate(zip(parts, durations), start=1):
        end = float(duration) if index == len(parts) else round(cursor + shot_duration, 3)
        keyword = "".join(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]+", text))[:12] or "待提取"
        shot = {
            "id": f"s{index:02d}", "start": round(cursor, 3), "end": end,
            "chapter_id": f"c{index:02d}",
            "script": text, "keyword": keyword, "subject": keyword,
            "action": "待语义确认", "result": "待语义确认", "asset_id": f"pending-s{index:02d}",
            "overlay_id": None, "visual": "待匹配真实视频",
        }
        shots.append(shot)
        cursor = end
    chapters = [
        {
            "id": shot["chapter_id"], "start": shot["start"], "end": shot["end"], "thesis": shot["script"],
        }
        for shot in shots
    ]
    return {"script_path": script_path, "duration_seconds": float(duration), "audio_path": audio_path, "audio_delivery_mode": "narration" if audio_path else "silent", "chapters": chapters, "shots": shots, "assets": [], "overlays": []}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--script", required=True)
    timing = parser.add_mutually_exclusive_group(required=True)
    timing.add_argument("--duration", type=float)
    timing.add_argument("--audio")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    script_path = Path(args.script)
    audio_path = Path(args.audio).resolve() if args.audio else None
    duration = resolve_duration(args.duration, audio_path)
    timeline = build_timeline(script_path.read_text(encoding="utf-8"), duration, str(script_path.resolve()), str(audio_path) if audio_path else None)
    write_json(Path(args.output), timeline)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
