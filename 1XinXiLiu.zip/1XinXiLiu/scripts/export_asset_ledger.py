#!/usr/bin/env python3
"""Export the selected asset ledger from a completed timeline."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from speed_common import write_json


def make_ledger(timeline: dict) -> dict:
    used = {shot.get("asset_id") for shot in timeline.get("shots", [])}
    known = {item.get("id") for item in timeline.get("assets", [])}
    missing = sorted(str(item) for item in used - known if item)
    if missing:
        raise ValueError("missing timeline assets: " + ", ".join(missing))
    assets = [item for item in timeline.get("assets", []) if item.get("id") in used]
    overlays = timeline.get("overlays", [])
    uses = []
    for shot in timeline.get("shots", []):
        overlay_ids = [item.get("id") for item in overlays if item.get("background_shot_id") == shot.get("id") and item.get("id")]
        uses.append({
            "shot_id": shot.get("id"), "asset_id": shot.get("asset_id"), "keyword": shot.get("keyword"),
            "source_in": shot.get("source_in", 0),
            "source_out": shot.get("source_out", float(shot.get("source_in", 0)) + float(shot.get("end", 0)) - float(shot.get("start", 0))),
            "chapter_id": shot.get("chapter_id"), "script_semantics": shot.get("script_semantics"),
            "information_task": shot.get("information_task"), "script_range": shot.get("script_range"),
            "overlay_ids": overlay_ids,
            "news_id": shot.get("news_id"),
        })
    return {"asset_count": len(assets), "assets": assets, "uses": uses, "overlays": timeline.get("overlays", [])}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8"))
    timeline_path = Path(args.timeline)
    ledger = make_ledger(timeline)
    ledger["timeline"] = str(timeline_path.resolve())
    ledger["timeline_sha256"] = hashlib.sha256(timeline_path.read_bytes()).hexdigest()
    missing = [item.get("id", "?") for item in ledger["assets"] if not item.get("local_path") or not (item.get("sha256") or item.get("quick_hash"))]
    if missing:
        raise SystemExit("incomplete local path or hash: " + ", ".join(missing))
    write_json(Path(args.output), ledger)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
