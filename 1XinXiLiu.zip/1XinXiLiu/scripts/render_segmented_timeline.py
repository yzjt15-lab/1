#!/usr/bin/env python3
"""Render long timelines sequentially in small, losslessly concatenated segments."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path

from render_continuous_timeline import OFFICIAL_OUTPUT_DIR, build_ffmpeg_command, choose_initial_encoder, run_encoder_probe, select_encoder_with_probe
from speed_common import find_ffmpeg, write_json


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _segment_fingerprint(segment: dict, encoder: str) -> str:
    """Invalidate only the segment whose timeline, sources, or overlays changed."""
    digest = hashlib.sha256()
    digest.update(json.dumps(segment, ensure_ascii=False, sort_keys=True).encode("utf-8"))
    digest.update(encoder.encode("utf-8"))
    digest.update(_sha256(Path(__file__)).encode("ascii"))
    for asset in segment.get("assets", []):
        digest.update(str(asset.get("sha256") or asset.get("quick_hash") or _sha256(Path(asset["local_path"]))).encode("ascii"))
    for overlay in segment.get("overlays", []):
        for key in ("image_path", "frame_pattern"):
            value = overlay.get(key)
            if not value:
                continue
            path = Path(value)
            if path.is_file():
                digest.update(_sha256(path).encode("ascii"))
                continue
            pattern = re.sub(r"%0?\d*d", "*", path.name)
            for frame in sorted(path.parent.glob(pattern)):
                digest.update(frame.name.encode("utf-8"))
                digest.update(_sha256(frame).encode("ascii"))
    return digest.hexdigest()


def _decode_ok(ffmpeg: str, path: Path) -> bool:
    return path.is_file() and path.stat().st_size > 0 and subprocess.run(
        [ffmpeg, "-v", "error", "-i", str(path), "-f", "null", "NUL"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    ).returncode == 0


def split_timeline(timeline: dict) -> list[dict]:
    shots = sorted(timeline.get("shots", []), key=lambda item: item["start"])
    overlays = timeline.get("overlays", [])
    assets = {item["id"]: item for item in timeline.get("assets", [])}
    segments: list[dict] = []
    offset = 0
    while offset < len(shots):
        candidates = []
        for end_index in range(offset + 1, min(offset + 5, len(shots)) + 1):
            start_time, end_time = float(shots[offset]["start"]), float(shots[end_index - 1]["end"])
            if end_time - start_time > 25.0:
                break
            if any(float(item["start"]) < end_time < float(item["end"]) for item in overlays):
                continue
            candidates.append(end_index)
        if not candidates:
            raise ValueError(f"no safe segmented rendering boundary after shot {shots[offset].get('id', '?')}")
        end_index = candidates[-1]
        selected = shots[offset:end_index]
        start_time, end_time = float(selected[0]["start"]), float(selected[-1]["end"])
        selected_ids = {item["asset_id"] for item in selected}
        local_shots = [{**item, "start": float(item["start"]) - start_time, "end": float(item["end"]) - start_time} for item in selected]
        local_overlays = [
            {**item, "start": float(item["start"]) - start_time, "end": float(item["end"]) - start_time}
            for item in overlays
            if float(item["start"]) >= start_time and float(item["end"]) <= end_time
        ]
        segment = {
            **timeline,
            "duration_seconds": end_time - start_time,
            "shots": local_shots,
            "assets": [assets[item] for item in selected_ids],
            "overlays": local_overlays,
            "audio_source_in": start_time,
            "segment_source_start": start_time,
            "segment_source_end": end_time,
        }
        segments.append(segment)
        offset = end_index
    return segments


def verify_permit(timeline_path: Path, output: Path, permit_path: Path) -> None:
    if output.resolve().parent == OFFICIAL_OUTPUT_DIR:
        raise ValueError("only fast_pipeline finalize may write to the official video directory")
    payload = json.loads(permit_path.read_text(encoding="utf-8"))
    if payload.get("source") != "fast_pipeline finalize":
        raise ValueError("segmented render requires a fast_pipeline finalize permit")
    if Path(payload.get("render_output_path", "")).resolve() != output.resolve():
        raise ValueError("finalize permit does not authorize this output")
    if payload.get("timeline_sha256") != _sha256(timeline_path):
        raise ValueError("finalize permit does not match the prepared timeline")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--segment-dir", required=True)
    parser.add_argument("--finalize-permit", required=True)
    parser.add_argument("--ffmpeg")
    parser.add_argument("--encoder", choices=("auto", "libx264", "h264_nvenc"), default="auto")
    parser.add_argument("--encoder-profile", default=str(Path(__file__).resolve().parents[1] / "assets" / "templates" / "verified-encoder.json"))
    parser.add_argument("--probe-report")
    args = parser.parse_args()

    timeline_path, output = Path(args.timeline), Path(args.output)
    verify_permit(timeline_path, output, Path(args.finalize_permit))
    timeline = json.loads(timeline_path.read_text(encoding="utf-8"))
    ffmpeg = find_ffmpeg(args.ffmpeg)
    segment_dir = Path(args.segment_dir)
    segment_dir.mkdir(parents=True, exist_ok=True)
    segments = split_timeline(timeline)
    attempts: list[dict] = []
    initial = choose_initial_encoder(args.encoder, ffmpeg, Path(args.encoder_profile))
    try:
        encoder = select_encoder_with_probe(initial, lambda item: run_encoder_probe(segments[0], ffmpeg, item, attempts))
    finally:
        if args.probe_report:
            write_json(Path(args.probe_report), {"initial_encoder": initial, "attempts": attempts, "selected_encoder": locals().get("encoder")})
    def render_batch(batch_encoder: str) -> list[Path]:
        batch_outputs = []
        for index, segment in enumerate(segments, 1):
            segment_path = segment_dir / f"segment-{index:03d}.json"
            video_path = segment_dir / f"segment-{index:03d}.mp4"
            fingerprint = _segment_fingerprint(segment, batch_encoder)
            state_path = segment_dir / f"segment-{index:03d}.state.json"
            try:
                cached = json.loads(state_path.read_text(encoding="utf-8")) if state_path.is_file() else {}
            except json.JSONDecodeError:
                cached = {}
            if cached.get("fingerprint") == fingerprint and _decode_ok(ffmpeg, video_path):
                print(f"reuse {video_path}")
                batch_outputs.append(video_path)
                continue
            write_json(segment_path, segment)
            subprocess.run(build_ffmpeg_command(segment, str(video_path), "final", ffmpeg, batch_encoder), check=True)
            if not _decode_ok(ffmpeg, video_path):
                raise RuntimeError(f"segment decode failed: {video_path}")
            write_json(state_path, {"fingerprint": fingerprint, "encoder": batch_encoder})
            batch_outputs.append(video_path)
        return batch_outputs

    try:
        outputs = render_batch(encoder)
    except (subprocess.CalledProcessError, RuntimeError):
        if encoder != "h264_nvenc":
            raise
        encoder = select_encoder_with_probe("libx264", lambda item: run_encoder_probe(segments[0], ffmpeg, item, attempts))
        if args.probe_report:
            write_json(Path(args.probe_report), {"initial_encoder": initial, "attempts": attempts, "selected_encoder": encoder, "fallback_after_render_failure": True})
        outputs = render_batch(encoder)
    concat = segment_dir / "concat.txt"
    concat.write_text("".join(f"file '{item.resolve().as_posix()}'\n" for item in outputs), encoding="utf-8")
    subprocess.run([ffmpeg, "-y", "-fflags", "+genpts", "-f", "concat", "-safe", "0", "-i", str(concat), "-c", "copy", "-avoid_negative_ts", "make_zero", "-movflags", "+faststart", str(output)], check=True)
    if not _decode_ok(ffmpeg, output):
        raise RuntimeError(f"concat decode failed: {output}")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
