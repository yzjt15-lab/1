#!/usr/bin/env python3
"""Build and query an incremental Chinese video-frame semantic index."""
from __future__ import annotations

import argparse
import json
import math
import os
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

from speed_common import content_key, load_json


DEFAULT_MODEL_ID = "OFA-Sys/chinese-clip-vit-base-patch16"


def sample_times(duration: float, interval: float = 3.0, max_samples: int = 24) -> list[float]:
    if duration <= 0 or interval <= 0 or max_samples <= 0:
        return []
    count = min(max_samples, max(1, math.ceil(duration / interval)))
    width = duration / count
    return [round((index + 0.5) * width, 3) for index in range(count)]


def can_reuse(previous: dict | None, asset: dict, model_id: str) -> bool:
    if not previous:
        return False
    return (
        str(previous.get("path", "")).casefold() == str(asset.get("path", "")).casefold()
        and previous.get("size") == asset.get("size")
        and previous.get("mtime_ns") == asset.get("mtime_ns")
        and previous.get("model_id") == model_id
    )


def failures_for_asset(failures: list[dict], path: str) -> list[dict]:
    wanted = str(path).casefold()
    return [item for item in failures if str(item.get("path", "")).casefold() == wanted]


def refresh_provenance(row: dict, asset: dict) -> dict:
    refreshed = dict(row)
    for key in ("source_url", "publisher", "source_description"):
        refreshed[key] = asset.get(key)
    refreshed["provenance_complete"] = all(asset.get(key) for key in ("source_url", "publisher", "source_description"))
    return refreshed


def clip_range(timestamp: float, duration: float, clip_duration: float = 5.0) -> tuple[float, float]:
    if duration <= 0:
        return 0.0, 0.0
    length = min(float(clip_duration), float(duration))
    start = max(0.0, min(float(timestamp) - length / 2, float(duration) - length))
    return round(start, 3), round(start + length, 3)


def _normalized(vector: np.ndarray) -> np.ndarray:
    vector = np.asarray(vector, dtype=np.float32)
    norm = float(np.linalg.norm(vector))
    return vector if norm == 0 else vector / norm


def rank_embeddings(
    matrix: np.ndarray,
    query: np.ndarray,
    rows: list[dict],
    top_k: int = 12,
    clip_duration: float = 5.0,
    provenance_only: bool = False,
) -> list[dict]:
    if matrix.ndim != 2 or len(rows) != matrix.shape[0]:
        raise ValueError("embedding matrix and metadata row count differ")
    if not len(rows):
        return []
    scores = matrix @ _normalized(query)
    order = np.argsort(-scores)
    results = []
    seen_assets = set()
    for index in order:
        row = rows[int(index)]
        if provenance_only and not row.get("provenance_complete"):
            continue
        identity = row.get("asset_id") or row.get("path")
        if identity in seen_assets:
            continue
        seen_assets.add(identity)
        start, end = clip_range(float(row["timestamp"]), float(row["duration"]), clip_duration)
        results.append({**row, "source_in": start, "source_out": end, "score": round(float(scores[index]), 6)})
        if len(results) >= top_k:
            break
    return results


def _atomic_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def _atomic_npy(path: Path, matrix: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        np.save(handle, matrix)
    os.replace(temporary, path)


def extract_thumbnail(video_path: Path, timestamp: float, destination: Path) -> Path:
    import av

    if destination.exists():
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    with av.open(str(video_path)) as container:
        stream = container.streams.video[0]
        offset = int(timestamp / float(stream.time_base))
        container.seek(max(0, offset), stream=stream, backward=True, any_frame=False)
        selected = None
        for frame in container.decode(stream):
            selected = frame
            if frame.time is None or float(frame.time) >= timestamp:
                break
        if selected is None:
            raise RuntimeError("no decodable frame")
        image = selected.to_image().convert("RGB")
        image.thumbnail((384, 384))
        image.save(destination, format="JPEG", quality=88, optimize=True)
    return destination


def _feature_tensor(value):
    return value.pooler_output if hasattr(value, "pooler_output") else value


class ChineseClipEmbedder:
    def __init__(self, model_id: str = DEFAULT_MODEL_ID, device: str = "auto"):
        import torch
        from transformers import AutoProcessor, ChineseCLIPModel

        self.torch = torch
        self.device = "cuda" if device == "auto" and torch.cuda.is_available() else ("cpu" if device == "auto" else device)
        self.processor = AutoProcessor.from_pretrained(model_id)
        self.model = ChineseCLIPModel.from_pretrained(model_id).eval().to(self.device)
        self.model_id = model_id

    def encode_images(self, paths: list[Path], batch_size: int = 32) -> np.ndarray:
        from PIL import Image

        chunks = []
        for start in range(0, len(paths), batch_size):
            images = []
            for path in paths[start:start + batch_size]:
                with Image.open(path) as image:
                    images.append(image.convert("RGB").copy())
            inputs = self.processor(images=images, return_tensors="pt")
            inputs = {key: value.to(self.device) for key, value in inputs.items()}
            with self.torch.inference_mode():
                features = _feature_tensor(self.model.get_image_features(**inputs))
                features = features / features.norm(p=2, dim=-1, keepdim=True)
            chunks.append(features.detach().cpu().float().numpy())
        return np.concatenate(chunks, axis=0) if chunks else np.empty((0, 0), dtype=np.float32)

    def encode_text(self, text: str) -> np.ndarray:
        return self.encode_texts([text])[0]

    def encode_texts(self, texts: list[str]) -> np.ndarray:
        inputs = self.processor(text=texts, padding=True, return_tensors="pt")
        inputs = {key: value.to(self.device) for key, value in inputs.items()}
        with self.torch.inference_mode():
            features = _feature_tensor(self.model.get_text_features(**inputs))
            features = features / features.norm(p=2, dim=-1, keepdim=True)
        return features.detach().cpu().float().numpy()


def build_index(
    asset_index_path: Path,
    output_dir: Path,
    model_id: str = DEFAULT_MODEL_ID,
    interval: float = 3.0,
    max_samples: int = 24,
    batch_size: int = 32,
    limit: int | None = None,
    selected_paths: set[str] | None = None,
    device: str = "auto",
    workers: int = 6,
) -> dict:
    started = time.perf_counter()
    source = load_json(asset_index_path, {"assets": []})
    assets = [item for item in source.get("assets", []) if item.get("probe_ok") and item.get("duration")]
    if selected_paths:
        wanted = {str(Path(value).resolve()).casefold() for value in selected_paths}
        assets = [item for item in assets if str(Path(item["path"]).resolve()).casefold() in wanted]
    if limit is not None:
        assets = assets[:limit]

    manifest_path = output_dir / "manifest.json"
    matrix_path = output_dir / "embeddings.npy"
    old = load_json(manifest_path, {})
    old_matrix = np.load(matrix_path) if matrix_path.exists() and old.get("model_id") == model_id else None
    old_assets = {item["path"].casefold(): item for item in old.get("assets", [])}
    old_rows = old.get("rows", [])

    rows: list[dict] = []
    vectors: list[np.ndarray] = []
    asset_records: list[dict] = []
    new_jobs: list[tuple[int, Path]] = []
    extraction_jobs: list[tuple[int, Path, float, Path]] = []
    failures: list[dict] = []
    reused_assets = 0

    for position, asset in enumerate(assets, start=1):
        path = Path(asset["path"])
        previous = old_assets.get(str(path).casefold())
        record = {
            "path": str(path), "size": asset.get("size"), "mtime_ns": asset.get("mtime_ns"),
            "model_id": model_id, "row_indices": [],
        }
        if can_reuse(previous, asset, model_id) and old_matrix is not None:
            for old_index in previous.get("row_indices", []):
                if 0 <= old_index < len(old_rows) and old_index < old_matrix.shape[0]:
                    record["row_indices"].append(len(rows))
                    rows.append(refresh_provenance(old_rows[old_index], asset))
                    vectors.append(old_matrix[old_index])
            reused_assets += 1
            failures.extend(failures_for_asset(old.get("failures", []), str(path)))
            asset_records.append(record)
            continue

        signature = asset.get("quick_hash") or content_key({"path": str(path), "size": asset.get("size"), "mtime_ns": asset.get("mtime_ns")})
        for timestamp in sample_times(float(asset["duration"]), interval, max_samples):
            thumbnail = output_dir / "thumbnails" / signature[:16] / f"{round(timestamp * 1000):010d}.jpg"
            row = {
                "asset_id": asset.get("id"),
                "path": str(path),
                "timestamp": timestamp,
                "duration": float(asset["duration"]),
                "thumbnail": str(thumbnail),
                "source_url": asset.get("source_url"),
                "publisher": asset.get("publisher"),
                "source_description": asset.get("source_description"),
                "provenance_complete": all(asset.get(key) for key in ("source_url", "publisher", "source_description")),
            }
            record["row_indices"].append(len(rows))
            rows.append(row)
            extraction_jobs.append((len(rows) - 1, path, timestamp, thumbnail))
            vectors.append(np.asarray([], dtype=np.float32))
        asset_records.append(record)
        if position % 100 == 0 or position == len(assets):
            print(f"[plan] {position}/{len(assets)} assets, {len(rows)} frames", flush=True)

    def run_extraction(job):
        row_index, path, timestamp, thumbnail = job
        try:
            extract_thumbnail(path, timestamp, thumbnail)
            return row_index, thumbnail, None
        except Exception as error:
            return row_index, thumbnail, {"path": str(path), "timestamp": timestamp, "error": str(error)}

    if extraction_jobs:
        with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
            for completed, (row_index, thumbnail, failure) in enumerate(pool.map(run_extraction, extraction_jobs), start=1):
                if failure:
                    failures.append(failure)
                else:
                    new_jobs.append((row_index, thumbnail))
                if completed % 500 == 0 or completed == len(extraction_jobs):
                    print(f"[extract] {completed}/{len(extraction_jobs)} frames, {len(failures)} failures", flush=True)

    if new_jobs:
        embedder = ChineseClipEmbedder(model_id, device)
        encoded = embedder.encode_images([path for _, path in new_jobs], batch_size)
        for (row_index, _), vector in zip(new_jobs, encoded):
            vectors[row_index] = vector

    valid_indices = [index for index, vector in enumerate(vectors) if vector.size]
    rows = [rows[index] for index in valid_indices]
    matrix = np.stack([vectors[index] for index in valid_indices]).astype(np.float32) if valid_indices else np.empty((0, 0), dtype=np.float32)
    remap = {old_index: new_index for new_index, old_index in enumerate(valid_indices)}
    for record in asset_records:
        record["row_indices"] = [remap[index] for index in record["row_indices"] if index in remap]

    elapsed = round(time.perf_counter() - started, 3)
    manifest = {
        "version": 1,
        "model_id": model_id,
        "asset_index_path": str(asset_index_path.resolve()),
        "interval_seconds": interval,
        "max_samples_per_asset": max_samples,
        "asset_count": len(assets),
        "frame_count": len(rows),
        "reused_asset_count": reused_assets,
        "new_or_changed_asset_count": len(assets) - reused_assets,
        "failure_count": len(failures),
        "build_elapsed_seconds": elapsed,
        "assets": asset_records,
        "rows": rows,
        "failures": failures,
    }
    _atomic_npy(matrix_path, matrix)
    _atomic_json(manifest_path, manifest)
    return manifest


def search_index(
    index_dir: Path,
    query: str,
    top_k: int = 12,
    clip_duration: float = 5.0,
    model_id: str | None = None,
    device: str = "auto",
) -> dict:
    result = search_many(index_dir, [query], top_k, clip_duration, model_id, device)
    return {"query": query, "model_id": result["model_id"], "candidates": result["queries"][0]["candidates"]}


def search_many(
    index_dir: Path,
    queries: list[str],
    top_k: int = 12,
    clip_duration: float = 5.0,
    model_id: str | None = None,
    device: str = "auto",
    embedder=None,
) -> dict:
    manifest = load_json(index_dir / "manifest.json", None)
    if manifest is None:
        raise FileNotFoundError(f"semantic manifest not found: {index_dir}")
    active_model = model_id or manifest["model_id"]
    if active_model != manifest["model_id"]:
        raise ValueError("query model differs from index model")
    matrix = np.load(index_dir / "embeddings.npy")
    active_embedder = embedder or ChineseClipEmbedder(active_model, device)
    query_vectors = active_embedder.encode_texts(queries)
    results = []
    for query, query_vector in zip(queries, query_vectors):
        candidates = rank_embeddings(matrix, query_vector, manifest["rows"], top_k, clip_duration)
        eligible_candidates = rank_embeddings(
            matrix, query_vector, manifest["rows"], top_k, clip_duration, provenance_only=False,
        )
        results.append({"query": query, "candidates": candidates, "eligible_candidates": eligible_candidates})
    return {"model_id": active_model, "queries": results}


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build")
    build.add_argument("--asset-index", required=True)
    build.add_argument("--output-dir", required=True)
    build.add_argument("--model-id", default=DEFAULT_MODEL_ID)
    build.add_argument("--interval", type=float, default=3.0)
    build.add_argument("--max-samples", type=int, default=24)
    build.add_argument("--batch-size", type=int, default=32)
    build.add_argument("--limit", type=int)
    build.add_argument("--path", action="append", default=[])
    build.add_argument("--device", default="auto")
    build.add_argument("--workers", type=int, default=6)
    search = sub.add_parser("search")
    search.add_argument("--index-dir", required=True)
    search.add_argument("--query", action="append", required=True)
    search.add_argument("--top-k", type=int, default=12)
    search.add_argument("--clip-duration", type=float, default=5.0)
    search.add_argument("--model-id")
    search.add_argument("--device", default="auto")
    search.add_argument("--output")
    stats = sub.add_parser("stats")
    stats.add_argument("--index-dir", required=True)
    args = parser.parse_args()

    if args.command == "build":
        result = build_index(
            Path(args.asset_index), Path(args.output_dir), args.model_id, args.interval,
            args.max_samples, args.batch_size, args.limit, set(args.path) or None, args.device, args.workers,
        )
    elif args.command == "search":
        result = search_many(Path(args.index_dir), args.query, args.top_k, args.clip_duration, args.model_id, args.device)
        if args.output:
            _atomic_json(Path(args.output), result)
    else:
        result = load_json(Path(args.index_dir) / "manifest.json", None)
        if result is None:
            raise FileNotFoundError("semantic manifest not found")
        result = {key: result.get(key) for key in (
            "model_id", "asset_count", "frame_count", "reused_asset_count",
            "new_or_changed_asset_count", "failure_count", "build_elapsed_seconds",
        )}
    print(json.dumps(result if args.command != "build" else {
        key: result.get(key) for key in (
            "model_id", "asset_count", "frame_count", "reused_asset_count",
            "new_or_changed_asset_count", "failure_count", "build_elapsed_seconds",
        )
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
