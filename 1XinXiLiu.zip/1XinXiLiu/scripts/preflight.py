#!/usr/bin/env python3
"""Unified preflight for timeline logic, provenance, and selected files."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

MATERIAL_LIBRARY_SCRIPTS = Path(r"C:\Users\28723\.codex\skills\1SuCaiKu\scripts")
if str(MATERIAL_LIBRARY_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(MATERIAL_LIBRARY_SCRIPTS))

from material_library import DELIVERIES_ROOT as DEFAULT_HISTORY_ROOT, identities, recent_material_identities
from speed_common import write_json
from validate_timeline import validate

SKILL_ROOT = Path(__file__).resolve().parent.parent
PAGE_TEMPLATE_MANIFEST = SKILL_ROOT / "references" / "七类信息页固定标准.json"


def verify_page_template_assets(manifest_path: Path = PAGE_TEMPLATE_MANIFEST) -> list[str]:
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"page template manifest unavailable: {exc}"]
    errors = []
    for page_type, item in payload.get("templates", {}).items():
        path = SKILL_ROOT / item.get("file", "")
        if not path.is_file():
            errors.append(f"page template {page_type}: missing {path}")
        elif hashlib.sha256(path.read_bytes()).hexdigest() != item.get("sha256"):
            errors.append(f"page template {page_type}: sha256 mismatch")
    if set(payload.get("templates", {})) != {"hook", "fact", "news", "data", "number", "causal", "comparison"}:
        errors.append("page template manifest must map exactly seven page types")
    return errors


def run_preflight(timeline: dict, require_files: bool = True, asset_index: dict | None = None, history_root: Path | None = None) -> list[str]:
    errors = list(validate(timeline)) + verify_page_template_assets()
    researched_assets: dict[str, dict] | None = None
    reference_audio_path = timeline.get("reference_audio_path")
    if reference_audio_path and require_files and not Path(reference_audio_path).is_file():
        errors.append(f"reference audio missing file {reference_audio_path}")
    selection_manifest_path = timeline.get("selection_manifest_path")
    selection_manifest_sha256 = timeline.get("selection_manifest_sha256")
    if not selection_manifest_path:
        errors.append("selection_manifest_path is required")
    elif not selection_manifest_sha256:
        errors.append("selection_manifest_sha256 is required")
    else:
        manifest = Path(selection_manifest_path)
        if not manifest.exists():
            errors.append(f"selection manifest missing file {selection_manifest_path}")
        elif hashlib.sha256(manifest.read_bytes()).hexdigest() != selection_manifest_sha256:
            errors.append("selection manifest sha256 mismatch")
        else:
            try:
                payload = json.loads(manifest.read_text(encoding="utf-8"))
                if payload.get("source") != "fast_pipeline research":
                    errors.append("selection manifest must originate from fast_pipeline research")
                researched_assets = {
                    str(candidate.get("asset_id")): candidate
                    for query in payload.get("eligible_visual_candidates", {}).get("queries", [])
                    for candidate in query.get("candidates", [])
                    if candidate.get("asset_id")
                }
            except json.JSONDecodeError:
                errors.append("selection manifest is not valid json")
    chrome_path = timeline.get("chrome_path")
    if not chrome_path:
        errors.append("chrome_path is required")
    elif require_files and not Path(chrome_path).exists():
        errors.append(f"chrome_path missing file {chrome_path}")
    indexed = {item.get("path", "").casefold(): item for item in (asset_index or {}).get("assets", [])}
    assets_by_id = {item.get("id"): item for item in timeline.get("assets", [])}
    recent = recent_material_identities(deliveries_root=history_root) if history_root else set()
    seen_hashes: dict[str, str] = {}
    for shot in timeline.get("shots", []):
        values = (shot.get("keyword"), shot.get("subject"), shot.get("action"), shot.get("result"), shot.get("asset_id"))
        if any(not value or str(value).startswith("pending-") or "待语义确认" in str(value) or str(value) == "待提取" for value in values):
            errors.append(f"shot {shot.get('id', '?')}: unconfirmed semantic or asset field")
        asset = assets_by_id.get(shot.get("asset_id"), {})
        candidate = (researched_assets or {}).get(str(shot.get("asset_id"))) if researched_assets is not None else None
        if researched_assets is not None and candidate is None:
            errors.append(f"shot {shot.get('id', '?')}: selected asset is absent from research candidates")
        elif candidate is not None:
            if candidate.get("seven_day_eligible") is not True:
                errors.append(f"shot {shot.get('id', '?')}: research candidate is not seven-day eligible")
            if candidate.get("sha256") != asset.get("sha256"):
                errors.append(f"shot {shot.get('id', '?')}: research candidate sha256 does not match selected asset")
        local = asset.get("local_path")
        metadata = indexed.get(str(Path(local).resolve()).casefold()) if local else None
        source_in = float(shot.get("source_in", 0))
        selected_end = source_in + float(shot.get("end", 0)) - float(shot.get("start", 0))
        if source_in < 0:
            errors.append(f"shot {shot.get('id', '?')}: source_in must be >= 0")
        if shot.get("source_out") is not None and abs(float(shot["source_out"]) - selected_end) > 0.001:
            errors.append(f"shot {shot.get('id', '?')}: source_out differs from renderer selected range")
        if metadata and metadata.get("duration") is not None and selected_end > float(metadata["duration"]) + 0.001:
            errors.append(f"shot {shot.get('id', '?')}: selected range exceeds source duration")
        digest = asset.get("sha256") or asset.get("quick_hash")
        if identities({**asset, "asset_id": shot.get("asset_id"), "path": local or ""}) & recent:
            errors.append(f"asset {shot.get('asset_id')}: material identity was used within seven days")
        if digest:
            if digest in seen_hashes:
                errors.append(f"duplicate content: {shot.get('asset_id')} matches {seen_hashes[digest]}")
            else:
                seen_hashes[digest] = shot.get("asset_id")
    for asset in timeline.get("assets", []):
        local = asset.get("local_path")
        if not local:
            continue
        path = Path(local)
        if require_files and not path.exists():
            errors.append(f"asset {asset.get('id', '?')}: missing local file {local}")
        metadata = indexed.get(str(path.resolve()).casefold())
        if metadata and asset.get("source_out") is not None and metadata.get("duration") is not None:
            if float(asset["source_out"]) > float(metadata["duration"]):
                errors.append(f"asset {asset.get('id', '?')}: source_out exceeds duration")
    for overlay in timeline.get("overlays", []):
        start, end = overlay.get("start"), overlay.get("end")
        if isinstance(start, (int, float)) and isinstance(end, (int, float)) and abs((end - start) - 4.0) > 0.001:
            errors.append(f"overlay {overlay.get('id', '?')}: duration must equal 4.0 seconds")
        image_path = overlay.get("image_path")
        if not image_path:
            errors.append(f"overlay {overlay.get('id', '?')}: image_path is required")
        elif require_files and not Path(image_path).exists():
            errors.append(f"overlay {overlay.get('id', '?')}: missing image {image_path}")
    seen_overlay_hashes: dict[str, str] = {}
    for overlay in timeline.get("overlays", []):
        image_path = overlay.get("image_path")
        if image_path and Path(image_path).is_file():
            digest = hashlib.sha256(Path(image_path).read_bytes()).hexdigest()
            if digest in seen_overlay_hashes:
                errors.append(f"overlay {overlay.get('id', '?')}: duplicate information image matches {seen_overlay_hashes[digest]}")
            else:
                seen_overlay_hashes[digest] = overlay.get("id", "?")
        if overlay.get("role") == "hook" and require_files:
            pattern = overlay.get("frame_pattern")
            try:
                first = Path(pattern % 0)
                complete = Path(pattern % 30)
            except (TypeError, ValueError):
                errors.append(f"overlay {overlay.get('id', '?')}: invalid dynamic hook frame_pattern")
            else:
                if not first.is_file() or not complete.is_file():
                    errors.append(f"overlay {overlay.get('id', '?')}: hook frames 0000 and 0030 are required")
                elif hashlib.sha256(first.read_bytes()).digest() == hashlib.sha256(complete.read_bytes()).digest():
                    errors.append(f"overlay {overlay.get('id', '?')}: hook first and complete frames must differ")
    return sorted(set(errors))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--asset-index")
    parser.add_argument("--report", required=True)
    parser.add_argument("--skip-file-check", action="store_true")
    parser.add_argument("--history-root", default=str(DEFAULT_HISTORY_ROOT))
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8"))
    index = json.loads(Path(args.asset_index).read_text(encoding="utf-8")) if args.asset_index else None
    errors = run_preflight(timeline, not args.skip_file_check, index, Path(args.history_root))
    timeline_path = Path(args.timeline)
    report = {"timeline": str(timeline_path.resolve()), "timeline_sha256": hashlib.sha256(timeline_path.read_bytes()).hexdigest(), "ok": not errors, "errors": errors}
    write_json(Path(args.report), report)
    print(json.dumps(report, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
