#!/usr/bin/env python3
"""Single entrypoint for deterministic infoflow setup, render, and approval."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from datetime import date
from pathlib import Path

MATERIAL_LIBRARY_SCRIPTS = Path(r"C:\Users\28723\.codex\skills\1SuCaiKu\scripts")
if str(MATERIAL_LIBRARY_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(MATERIAL_LIBRARY_SCRIPTS))

from material_library import DELIVERIES_ROOT as MATERIAL_DELIVERIES_ROOT, INDEX as MATERIAL_INDEX, USAGE as MATERIAL_USAGE, commit_ledger, filter_candidates
from speed_common import write_json
from workflow_metrics import complete_run, end_stage, start_run, start_stage
from visual_semantic_index import search_many


SCRIPT_DIR = Path(__file__).resolve().parent
_e2e_output = os.environ.get("INFOFLOW_E2E_OUTPUT_DIR")
_e2e_root = Path(tempfile.gettempdir()).resolve()
_e2e_path = Path(_e2e_output).resolve() if _e2e_output else None
OFFICIAL_OUTPUT_DIR = _e2e_path if os.environ.get("RUN_REAL_E2E") == "1" and _e2e_path and _e2e_path.is_relative_to(_e2e_root) else Path(r"C:\Users\28723\Videos\Codex").resolve()


def _safe_title(title: str) -> str:
    value = re.sub(r'[<>:"/\\|?*]+', "", title).strip().replace(" ", "")
    if not value:
        raise ValueError("title becomes empty after filename sanitization")
    return value


def _json_ready(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {key: _json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_ready(item) for item in value]
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _run(script: str, arguments: list[str], allowed_codes: set[int] | None = None) -> subprocess.CompletedProcess:
    command = [sys.executable, str(SCRIPT_DIR / script), *arguments]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode not in (allowed_codes or {0}):
        raise RuntimeError(f"{' '.join(command)}\n{result.stdout}\n{result.stderr}")
    return result


def validate_first_review(report_path: Path) -> None:
    report = json.loads(report_path.read_text(encoding="utf-8"))
    expected_prefixes = ("visual approval missing", "visual checks missing")
    unexpected = [error for error in report.get("errors", []) if not str(error).startswith(expected_prefixes)]
    if unexpected:
        raise RuntimeError("first review contains non-approval errors: " + "; ".join(unexpected))


def renderer_script(timeline: dict) -> str:
    if float(timeline.get("duration_seconds", 0)) >= 90.0 or len(timeline.get("shots", [])) > 12:
        return "render_segmented_timeline.py"
    return "render_continuous_timeline.py"


def initialize(
    script_path: Path,
    duration: float,
    title: str,
    output_dir: Path,
    structure_template: Path | None,
    date_text: str | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    if duration <= 0:
        raise ValueError("duration must be > 0")
    if not script_path.is_file() or not script_path.read_text(encoding="utf-8").strip():
        raise ValueError("script is missing or empty")
    if structure_template:
        raise ValueError("structure templates are applied only after semantic planning, not during init")
    stamp = date_text or date.today().isoformat()
    stem = _safe_title(title)
    metrics_path = output_dir / f"{stamp}_文档_{stem}_端到端耗时.json"
    status_path = output_dir / f"{stamp}_文档_{stem}_执行状态.json"
    start_run(metrics_path, title, duration)
    write_json(status_path, {
        "state": "in_progress",
        "terminal_allowed": False,
        "current_stage": "initialized_waiting_for_semantic_planning",
        "script_path": str(script_path.resolve()),
        "target_duration_seconds": float(duration),
        "title": title,
    })
    return {"status_path": status_path, "metrics_path": metrics_path, "script_path": script_path.resolve()}


def finalize(
    timeline_path: Path,
    asset_index: Path,
    overlay_dir: Path,
    output_video: Path,
    project_dir: Path,
    metrics_path: Path,
) -> dict:
    project_dir.mkdir(parents=True, exist_ok=True)
    if output_video.resolve().parent != OFFICIAL_OUTPUT_DIR:
        raise ValueError(f"formal video must be written to {OFFICIAL_OUTPUT_DIR}")
    stem = timeline_path.stem.replace("_时间轴", "")
    prepared = project_dir / f"{stem}_时间轴_准备后.json"
    preflight = project_dir / f"{stem}_预检报告.json"
    ledger = project_dir / f"{stem}_asset-ledger.json"
    first_review = project_dir / f"{stem}_复审报告_首次.json"
    render_output = project_dir / f"{stem}_候选成片.mp4"
    start_stage(metrics_path, "render_review")
    _run("prepare_timeline_assets.py", ["--timeline", str(timeline_path), "--overlay-dir", str(overlay_dir), "--output", str(prepared)])
    prepared_payload = json.loads(prepared.read_text(encoding="utf-8"))
    permit = project_dir / f"{stem}_正式渲染许可.json"
    probe_report = project_dir / f"{stem}_编码探测.json"
    prepared_payload["finalize_permit_path"] = str(permit.resolve())
    write_json(prepared, prepared_payload)
    write_json(permit, {
        "source": "fast_pipeline finalize",
        "profile": "final",
        "timeline_sha256": _sha256(prepared),
        "render_output_path": str(render_output.resolve()),
        "output_video_path": str(output_video.resolve()),
    })
    _run("preflight.py", ["--timeline", str(prepared), "--asset-index", str(asset_index), "--report", str(preflight)])
    renderer = renderer_script(prepared_payload)
    render_arguments = ["--timeline", str(prepared), "--encoder", "auto", "--probe-report", str(probe_report), "--finalize-permit", str(permit), "--output", str(render_output)]
    if renderer == "render_continuous_timeline.py":
        render_arguments[2:2] = ["--profile", "final"]
    else:
        render_arguments.extend(["--segment-dir", str(project_dir / "segments")])
    _run(renderer, render_arguments)
    render_output.replace(output_video)
    _run("export_asset_ledger.py", ["--timeline", str(prepared), "--output", str(ledger)])
    review_arguments = ["--video", str(output_video), "--timeline", str(prepared), "--report", str(first_review)]
    if prepared_payload.get("reference_audio_path"):
        review_arguments.extend(["--reference-audio", str(prepared_payload["reference_audio_path"])])
    if prepared_payload.get("audio_path"):
        review_arguments.extend(["--source-audio", str(prepared_payload["audio_path"])])
    _run("review_render.py", review_arguments, {0, 2})
    validate_first_review(first_review)
    end_stage(metrics_path, "render_review")
    return {
        "prepared_timeline": prepared,
        "preflight_report": preflight,
        "asset_ledger": ledger,
        "first_review": first_review,
        "finalize_permit": permit,
        "encoder_probe_report": probe_report,
        "contact_sheet": first_review.with_suffix(".jpg"),
    }


def approve(
    video: Path,
    timeline: Path,
    contact_sheet: Path,
    approval_path: Path,
    final_report: Path,
    metrics_path: Path | None = None,
    reference_audio: Path | None = None,
    source_audio: Path | None = None,
) -> dict:
    if metrics_path:
        start_stage(metrics_path, "approval_final_review")
    confirmations = [
        "title_bar", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder"
    ]
    try:
        arguments = ["--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet)]
        for item in confirmations:
            arguments.extend(["--confirm", item])
        arguments.extend(["--output", str(approval_path)])
        _run("make_visual_approval.py", arguments)
        timeline_payload = json.loads(timeline.read_text(encoding="utf-8"))
        review_arguments = [
            "--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet),
            "--visual-approval", str(approval_path), "--report", str(final_report),
        ]
        resolved_reference = reference_audio or (Path(timeline_payload["reference_audio_path"]) if timeline_payload.get("reference_audio_path") else None)
        resolved_source = source_audio or (Path(timeline_payload["audio_path"]) if timeline_payload.get("audio_path") else None)
        if resolved_reference:
            review_arguments.extend(["--reference-audio", str(resolved_reference)])
        if resolved_source:
            review_arguments.extend(["--source-audio", str(resolved_source)])
        _run("review_render.py", review_arguments)
        return {"approval": approval_path, "final_report": final_report}
    finally:
        if metrics_path:
            end_stage(metrics_path, "approval_final_review")


def deliver(
    video: Path,
    timeline: Path,
    preflight: Path,
    ledger: Path,
    final_review: Path,
    status: Path,
    gate_report: Path,
    metrics_path: Path,
) -> dict:
    """Open the terminal state only after the fail-closed delivery gate passes."""
    result = _run("delivery_gate.py", [
        "--video", str(video),
        "--timeline", str(timeline),
        "--preflight", str(preflight),
        "--ledger", str(ledger),
        "--final-review", str(final_review),
        "--status", str(status),
        "--output", str(gate_report),
    ])
    payload = json.loads(result.stdout)
    if payload.get("terminal_allowed") is not True:
        raise RuntimeError("delivery gate returned without terminal permission")
    commit_ledger(ledger, timeline.parent)
    complete_run(metrics_path)
    return payload


def research(
    index_dir: Path,
    queries: list[str],
    top_k: int,
    clip_duration: float,
    device: str,
    history_root: Path = MATERIAL_DELIVERIES_ROOT,
    current_project: Path | None = None,
) -> dict:
    """Run local visual retrieval for the user's fixed copy."""
    visual_candidates = search_many(index_dir, queries, top_k, clip_duration, device=device)
    eligible = [
        {
            **query_result,
            "candidates": filter_candidates(
                query_result.get("candidates", []),
                index_path=MATERIAL_INDEX,
                usage_path=MATERIAL_USAGE,
                deliveries_root=history_root,
                current_project=current_project,
            ),
        }
        for query_result in visual_candidates.get("queries", [])
    ]
    return {
        "source": "fast_pipeline research",
        "queries": queries,
        "visual_candidates": visual_candidates,
        "eligible_visual_candidates": {"model_id": visual_candidates.get("model_id"), "queries": eligible},
    }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--script", required=True)
    init.add_argument("--duration", type=float, required=True)
    init.add_argument("--title", required=True)
    init.add_argument("--output-dir", required=True)
    init.add_argument("--structure-template")
    finish = sub.add_parser("finalize")
    finish.add_argument("--timeline", required=True)
    finish.add_argument("--asset-index", required=True)
    finish.add_argument("--overlay-dir", required=True)
    finish.add_argument("--output-video", required=True)
    finish.add_argument("--project-dir", required=True)
    finish.add_argument("--metrics", required=True)
    approval = sub.add_parser("approve")
    approval.add_argument("--video", required=True)
    approval.add_argument("--timeline", required=True)
    approval.add_argument("--contact-sheet", required=True)
    approval.add_argument("--approval", required=True)
    approval.add_argument("--final-report", required=True)
    approval.add_argument("--metrics", required=True)
    approval.add_argument("--reference-audio")
    approval.add_argument("--source-audio")
    delivery = sub.add_parser("deliver")
    delivery.add_argument("--video", required=True)
    delivery.add_argument("--timeline", required=True)
    delivery.add_argument("--preflight", required=True)
    delivery.add_argument("--ledger", required=True)
    delivery.add_argument("--final-review", required=True)
    delivery.add_argument("--status", required=True)
    delivery.add_argument("--gate-report", required=True)
    delivery.add_argument("--metrics", required=True)
    semantic = sub.add_parser("search")
    semantic.add_argument("--index-dir", required=True)
    semantic.add_argument("--query", action="append", required=True)
    semantic.add_argument("--top-k", type=int, default=12)
    semantic.add_argument("--clip-duration", type=float, default=5.0)
    semantic.add_argument("--device", default="auto")
    semantic.add_argument("--output")
    research_parser = sub.add_parser("research")
    research_parser.add_argument("--index-dir", required=True)
    research_parser.add_argument("--query", action="append", required=True)
    research_parser.add_argument("--top-k", type=int, default=12)
    research_parser.add_argument("--clip-duration", type=float, default=5.0)
    research_parser.add_argument("--device", default="auto")
    research_parser.add_argument("--history-root", default=str(MATERIAL_DELIVERIES_ROOT))
    research_parser.add_argument("--current-project")
    research_parser.add_argument("--output")
    args = parser.parse_args()
    if args.command == "init":
        result = initialize(Path(args.script), args.duration, args.title, Path(args.output_dir), Path(args.structure_template) if args.structure_template else None)
    elif args.command == "finalize":
        result = finalize(Path(args.timeline), Path(args.asset_index), Path(args.overlay_dir), Path(args.output_video), Path(args.project_dir), Path(args.metrics))
    elif args.command == "approve":
        result = approve(
            Path(args.video), Path(args.timeline), Path(args.contact_sheet), Path(args.approval),
            Path(args.final_report), Path(args.metrics),
            Path(args.reference_audio) if args.reference_audio else None,
            Path(args.source_audio) if args.source_audio else None,
        )
    elif args.command == "deliver":
        result = deliver(
            Path(args.video), Path(args.timeline), Path(args.preflight), Path(args.ledger),
            Path(args.final_review), Path(args.status), Path(args.gate_report), Path(args.metrics),
        )
    elif args.command == "search":
        result = search_many(Path(args.index_dir), args.query, args.top_k, args.clip_duration, device=args.device)
        if args.output:
            write_json(Path(args.output), result)
    else:
        result = research(
            Path(args.index_dir), args.query, args.top_k,
            args.clip_duration, args.device, Path(args.history_root),
            Path(args.current_project) if args.current_project else None,
        )
        if args.output:
            write_json(Path(args.output), result)
    print(json.dumps(_json_ready(result), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
