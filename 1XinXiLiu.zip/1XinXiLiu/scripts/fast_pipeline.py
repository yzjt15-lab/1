#!/usr/bin/env python3
"""Single entrypoint for deterministic infoflow setup, render, and approval."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
from datetime import date, datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
from runtime_config import MATERIAL_LIBRARY_SCRIPTS, VISUAL_SEMANTIC_CACHE, VISUAL_SEMANTIC_INDEX, official_video_dir
if str(MATERIAL_LIBRARY_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(MATERIAL_LIBRARY_SCRIPTS))

from material_library import DELIVERIES_ROOT as MATERIAL_DELIVERIES_ROOT, INDEX as MATERIAL_INDEX, USAGE as MATERIAL_USAGE, candidate_preview_key, commit_ledger, filter_candidate_groups, prepare_candidate_previews
from speed_common import resolve_duration, write_json
from workflow_metrics import DEFAULT_BUDGETS, build_report, complete_run, end_stage, start_run, start_stage
SEMANTIC_INDEX_API_VERSION = 1
DEFAULT_CANDIDATE_LIMIT = 8


def _load_shared_visual_index(path: Path):
    if not path.is_file():
        raise ImportError(f"shared visual semantic index is unavailable: {path}")
    spec = importlib.util.spec_from_file_location("curve_visual_semantic_index", path)
    if not spec or not spec.loader:
        raise ImportError(f"shared visual semantic index cannot be loaded: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if getattr(module, "SEMANTIC_INDEX_API_VERSION", None) != SEMANTIC_INDEX_API_VERSION or not callable(getattr(module, "search_many", None)):
        raise ImportError(f"shared visual semantic index contract mismatch: {path}")
    return module.search_many


_semantic_index_path = Path(os.environ.get(
    "INFOFLOW_VISUAL_SEMANTIC_INDEX",
    VISUAL_SEMANTIC_INDEX,
)).resolve()
_search_many_impl = None


def search_many(*args, **kwargs):
    global _search_many_impl
    if _search_many_impl is None:
        _search_many_impl = _load_shared_visual_index(_semantic_index_path)
    return _search_many_impl(*args, **kwargs)


OFFICIAL_OUTPUT_DIR = official_video_dir()


def _safe_stem(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*]+', "", value).strip().replace(" ", "")
    value = re.sub(r"^\d{4}-\d{2}-\d{2}_[^_]+_", "", value)
    if not value:
        raise ValueError("script filename becomes empty after sanitization")
    return value


def _json_ready(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {key: _json_ready(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_ready(item) for item in value]
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class ExternalBlockError(RuntimeError):
    pass


def _run(script: str, arguments: list[str], allowed_codes: set[int] | None = None) -> subprocess.CompletedProcess:
    command = [sys.executable, str(SCRIPT_DIR / script), *arguments]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode not in (allowed_codes or {0}):
        message = f"{' '.join(command)}\n{result.stdout}\n{result.stderr}"
        error_type = ExternalBlockError if any(name in result.stderr for name in ("FileNotFoundError:", "ModuleNotFoundError:", "ImportError:")) else RuntimeError
        raise error_type(message)
    return result


def write_failure_status(status_path: Path, error: Exception, stage: str) -> None:
    message = str(error)
    external = isinstance(error, (ExternalBlockError, FileNotFoundError, ImportError, ModuleNotFoundError))
    try:
        status = json.loads(status_path.read_text(encoding="utf-8")) if status_path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        status = {}
    status.update({
        "state": "in_progress",
        "terminal_allowed": False,
        "current_stage": f"{stage}_failed",
        "blocking_domain": "external_input_or_tool" if external else stage,
        "retryable": True,
        "gate_errors": [message],
        "next_actions": ["Provide or configure the missing input/tool, then rerun this stage." if external else "Fix the reported error, then rerun this stage."],
    })
    write_json(status_path, status)


def write_success_status(status_path: Path, stage: str) -> None:
    if not status_path.is_file():
        raise FileNotFoundError(f"shared status is missing: {status_path}")
    status = json.loads(status_path.read_text(encoding="utf-8"))
    status.update({"state": "in_progress", "terminal_allowed": False, "current_stage": stage})
    for key in ("blocking_domain", "retryable", "gate_errors", "next_actions"):
        status.pop(key, None)
    write_json(status_path, status)


def close_status(status_path: Path, state: str, reason: str, correction_exhausted: bool = False) -> dict:
    if state not in {"cancelled", "blocked_external"}:
        raise ValueError("state must be cancelled or blocked_external")
    if not reason.strip():
        raise ValueError("terminal status requires a reason")
    if state == "blocked_external" and not correction_exhausted:
        raise ValueError("blocked_external requires an exhausted correction attempt")
    payload = json.loads(status_path.read_text(encoding="utf-8"))
    if payload.get("state") != "in_progress":
        raise ValueError("only in_progress can transition to a terminal state")
    payload.update({
        "state": state,
        "terminal_allowed": False,
        "current_stage": state,
        "terminal_reason": reason.strip(),
        "correction_exhausted": bool(correction_exhausted),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    })
    write_json(status_path, payload)
    return payload


def update_progress(status_path: Path, stage: str, duration: float | None = None, **details) -> dict:
    payload = json.loads(status_path.read_text(encoding="utf-8"))
    if payload.get("state") != "in_progress":
        raise ValueError("only in_progress can receive checkpoint updates")
    if duration is not None and abs(float(payload.get("target_duration_seconds", -1)) - float(duration)) > 0.001:
        raise ValueError("status duration does not match the current timeline")
    payload.update({"terminal_allowed": False, "current_stage": stage, "last_checkpoint_at": datetime.now(timezone.utc).isoformat(), **_json_ready(details)})
    write_json(status_path, payload)
    return payload


def complete_status(status_path: Path, gate_report: Path, gate: dict) -> dict:
    payload = json.loads(status_path.read_text(encoding="utf-8"))
    if payload.get("state") != "in_progress":
        raise ValueError("only in_progress can transition to complete")
    if gate.get("terminal_allowed") is not True:
        raise ValueError("delivery gate has not authorized completion")
    payload.update({
        "state": "complete", "terminal_allowed": True, "current_stage": "delivery_gate_passed",
        "gate_report": str(gate_report.resolve()), "gate_sha256": gate.get("sha256", {}),
        "gate_errors": [], "updated_at": datetime.now(timezone.utc).isoformat(),
    })
    write_json(status_path, payload)
    return payload


def validate_first_review(report_path: Path) -> None:
    report = json.loads(report_path.read_text(encoding="utf-8"))
    expected_prefixes = ("visual approval missing", "visual checks missing")
    unexpected = [error for error in report.get("errors", []) if not str(error).startswith(expected_prefixes)]
    if unexpected:
        raise RuntimeError("first review contains non-approval errors: " + "; ".join(unexpected))


def renderer_script(timeline: dict) -> str:
    if float(timeline.get("duration_seconds", 0)) >= 90.0 or len(timeline.get("shots", [])) > 12:
        return "render_segmented_timeline.py"
    return "render_continuous_timeline.py"


def omit_timed_out_news(timeline: dict, metrics_path: Path, now: float | None = None) -> tuple[dict, list[str]]:
    missing = [
        item for item in timeline.get("overlays", [])
        if item.get("type") == "news" and not Path(str(item.get("screenshot_path", ""))).is_file()
    ]
    if not missing:
        return timeline, []
    stage = build_report(metrics_path, now).get("stages", {}).get("news")
    if not stage:
        raise ValueError("news screenshot is missing; start the news timer before retrieval")
    elapsed = float(stage.get("elapsed_seconds", 0.0))
    if elapsed < DEFAULT_BUDGETS["news"]:
        raise ValueError(f"news screenshot is missing after {elapsed:.3f}s; continue retrieval until 300s or provide a valid screenshot")
    skipped = [str(item.get("id", "?")) for item in missing]
    normalized = json.loads(json.dumps(timeline, ensure_ascii=False))
    normalized["overlays"] = [item for item in normalized.get("overlays", []) if not (item.get("type") == "news" and not Path(str(item.get("screenshot_path", ""))).is_file())]
    return normalized, skipped


def initialize(
    script_path: Path,
    output_dir: Path,
    duration: float | None = None,
    audio_path: Path | None = None,
    date_text: str | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    if not script_path.is_file() or not script_path.read_text(encoding="utf-8").strip():
        raise ValueError("script is missing or empty")
    target_duration = resolve_duration(duration, audio_path)
    stamp = date_text or date.today().isoformat()
    stem = _safe_stem(script_path.stem)
    metrics_path = output_dir / f"{stamp}_文档_{stem}_端到端耗时.json"
    status_path = output_dir / f"{stamp}_文档_{stem}_执行状态.json"
    start_run(metrics_path, target_duration)
    write_json(status_path, {
        "state": "in_progress",
        "terminal_allowed": False,
        "current_stage": "initialized_waiting_for_semantic_planning",
        "script_path": str(script_path.resolve()),
        "target_duration_seconds": target_duration,
        "audio_path": str(audio_path.resolve()) if audio_path else None,
    })
    return {"status_path": status_path, "metrics_path": metrics_path, "script_path": script_path.resolve()}


def finalize(
    timeline_path: Path,
    asset_index: Path,
    overlay_dir: Path,
    output_video: Path,
    project_dir: Path,
    metrics_path: Path,
    status_path: Path,
) -> dict:
    project_dir.mkdir(parents=True, exist_ok=True)
    if output_video.resolve().parent != OFFICIAL_OUTPUT_DIR:
        raise ValueError(f"formal video must be written to {OFFICIAL_OUTPUT_DIR}")
    stem = timeline_path.stem.replace("_时间轴", "")
    prepared = project_dir / f"{stem}_时间轴_准备后.json"
    preflight = project_dir / f"{stem}_预检报告.json"
    ledger = project_dir / f"{stem}_asset-ledger.json"
    first_review = project_dir / f"{stem}_复审报告_首次.json"
    render_output = project_dir / f"{stem}_候选成片.mp4"
    source_timeline = json.loads(timeline_path.read_text(encoding="utf-8"))
    source_timeline, skipped_news = omit_timed_out_news(source_timeline, metrics_path)
    if skipped_news:
        timeline_path = project_dir / f"{stem}_时间轴_新闻超时后.json"
        write_json(timeline_path, source_timeline)
    start_stage(metrics_path, "render_review")
    _run("prepare_timeline_assets.py", ["--timeline", str(timeline_path), "--overlay-dir", str(overlay_dir), "--output", str(prepared)])
    prepared_payload = json.loads(prepared.read_text(encoding="utf-8"))
    update_progress(status_path, "timeline_assets_prepared", prepared_payload.get("duration_seconds"), prepared_timeline=prepared)
    permit = project_dir / f"{stem}_正式渲染许可.json"
    probe_report = project_dir / f"{stem}_编码探测.json"
    prepared_payload["finalize_permit_path"] = str(permit.resolve())
    write_json(prepared, prepared_payload)
    write_json(permit, {
        "source": "fast_pipeline finalize",
        "profile": "final",
        "timeline_sha256": _sha256(prepared),
        "render_output_path": str(render_output.resolve()),
        "output_video_path": str(output_video.resolve()),
    })
    _run("preflight.py", ["--timeline", str(prepared), "--asset-index", str(asset_index), "--report", str(preflight)])
    update_progress(status_path, "preflight_passed", preflight_report=preflight)
    renderer = renderer_script(prepared_payload)
    render_arguments = ["--timeline", str(prepared), "--encoder", "auto", "--probe-report", str(probe_report), "--finalize-permit", str(permit), "--output", str(render_output)]
    if renderer == "render_continuous_timeline.py":
        render_arguments[2:2] = ["--profile", "final"]
    else:
        render_arguments.extend(["--segment-dir", str(project_dir / "segments")])
    _run(renderer, render_arguments)
    render_output.replace(output_video)
    update_progress(status_path, "formal_render_complete", output_video=output_video, encoder_probe_report=probe_report)
    _run("export_asset_ledger.py", ["--timeline", str(prepared), "--output", str(ledger)])
    review_arguments = ["--video", str(output_video), "--timeline", str(prepared), "--report", str(first_review)]
    if prepared_payload.get("reference_audio_path"):
        review_arguments.extend(["--reference-audio", str(prepared_payload["reference_audio_path"])])
    if prepared_payload.get("audio_path"):
        review_arguments.extend(["--source-audio", str(prepared_payload["audio_path"])])
    _run("review_render.py", review_arguments, {0, 2})
    validate_first_review(first_review)
    review_notes_template = project_dir / f"{stem}_目检记录模板.json"
    _run("make_review_notes_template.py", [
        "--timeline", str(prepared), "--contact-sheet", str(first_review.with_suffix(".jpg")),
        "--output", str(review_notes_template),
    ])
    end_stage(metrics_path, "render_review")
    update_progress(status_path, "first_review_ready", first_review=first_review, contact_sheet=first_review.with_suffix(".jpg"))
    return {
        "prepared_timeline": prepared,
        "preflight_report": preflight,
        "asset_ledger": ledger,
        "first_review": first_review,
        "finalize_permit": permit,
        "encoder_probe_report": probe_report,
        "contact_sheet": first_review.with_suffix(".jpg"),
        "review_notes_template": review_notes_template,
        "skipped_news_overlay_ids": skipped_news,
    }


def approve(
    video: Path,
    timeline: Path,
    contact_sheet: Path,
    review_notes: Path,
    approval_path: Path,
    final_report: Path,
    metrics_path: Path | None = None,
    reference_audio: Path | None = None,
    source_audio: Path | None = None,
    status_path: Path | None = None,
) -> dict:
    if metrics_path:
        start_stage(metrics_path, "approval_final_review")
    try:
        _run("make_visual_approval.py", [
            "--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet),
            "--review-notes", str(review_notes), "--output", str(approval_path),
        ])
        timeline_payload = json.loads(timeline.read_text(encoding="utf-8"))
        review_arguments = [
            "--video", str(video), "--timeline", str(timeline), "--contact-sheet", str(contact_sheet),
            "--visual-approval", str(approval_path), "--report", str(final_report),
        ]
        resolved_reference = reference_audio or (Path(timeline_payload["reference_audio_path"]) if timeline_payload.get("reference_audio_path") else None)
        resolved_source = source_audio or (Path(timeline_payload["audio_path"]) if timeline_payload.get("audio_path") else None)
        if resolved_reference:
            review_arguments.extend(["--reference-audio", str(resolved_reference)])
        if resolved_source:
            review_arguments.extend(["--source-audio", str(resolved_source)])
        _run("review_render.py", review_arguments)
        if status_path:
            update_progress(status_path, "visual_approval_complete", visual_approval=approval_path, final_review=final_report)
        return {"approval": approval_path, "final_report": final_report}
    finally:
        if metrics_path:
            end_stage(metrics_path, "approval_final_review")


def deliver(
    video: Path,
    timeline: Path,
    preflight: Path,
    ledger: Path,
    final_review: Path,
    status: Path,
    gate_report: Path,
    metrics_path: Path,
) -> dict:
    """Open the terminal state only after the fail-closed delivery gate passes."""
    result = _run("delivery_gate.py", [
        "--video", str(video),
        "--timeline", str(timeline),
        "--preflight", str(preflight),
        "--ledger", str(ledger),
        "--final-review", str(final_review),
        "--output", str(gate_report),
    ])
    payload = json.loads(result.stdout)
    if payload.get("terminal_allowed") is not True:
        raise RuntimeError("delivery gate returned without terminal permission")
    commit_ledger(ledger, timeline.parent)
    complete_run(metrics_path)
    complete_status(status, gate_report, payload)
    return payload


def research(
    index_dir: Path,
    queries: list[str],
    top_k: int,
    clip_duration: float,
    device: str,
    history_root: Path = MATERIAL_DELIVERIES_ROOT,
    current_project: Path | None = None,
    categories: list[str] | None = None,
    review_dir: Path | None = None,
    metrics_path: Path | None = None,
    rejected_asset_ids: set[str] | None = None,
) -> dict:
    """Run local visual retrieval for the user's fixed copy."""
    if metrics_path:
        start_stage(metrics_path, "assets")
    try:
        visual_candidates = search_many(index_dir, queries, top_k, clip_duration, device=device, categories=categories)
        query_results = visual_candidates.get("queries", [])
        eligible_groups = filter_candidate_groups(
            [item.get("candidates", []) for item in query_results],
            index_path=MATERIAL_INDEX,
            usage_path=MATERIAL_USAGE,
            deliveries_root=history_root,
            current_project=current_project,
            rejected_asset_ids=rejected_asset_ids,
            min_duration=clip_duration,
        )
        for query_result, candidates in zip(query_results, eligible_groups):
            query_result["eligible_candidates"] = candidates
        if review_dir is not None:
            all_candidates = [candidate for item in visual_candidates.get("queries", []) for candidate in item.get("eligible_candidates", [])]
            prepared = prepare_candidate_previews(all_candidates, review_dir)
            prepared_by_key = {
                candidate_preview_key(item): {
                    key: item[key] for key in ("prepared_visual", "preview_cache_hit", "review_clip_path", "review_frames")
                }
                for item in prepared
            }
            for query_result in visual_candidates.get("queries", []):
                query_result["eligible_candidates"] = [
                    {**candidate, **prepared_by_key[preview_key]}
                    for candidate in query_result.get("eligible_candidates", [])
                    if (preview_key := candidate_preview_key(candidate)) in prepared_by_key
                ]
        if metrics_path:
            end_stage(metrics_path, "assets")
    except Exception:
        if metrics_path:
            end_stage(metrics_path, "assets", note="failed")
        raise
    eligible = [{**item, "candidates": item.get("eligible_candidates", [])} for item in visual_candidates.get("queries", [])]
    return {
        "source": "fast_pipeline research",
        "queries": queries,
        "visual_candidates": visual_candidates,
        "eligible_visual_candidates": {"model_id": visual_candidates.get("model_id"), "queries": eligible},
        "search_execution": "shared_query_cache_or_model",
    }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--script", required=True)
    timing = init.add_mutually_exclusive_group(required=True)
    timing.add_argument("--duration", type=float)
    timing.add_argument("--audio")
    init.add_argument("--output-dir", required=True)
    finish = sub.add_parser("finalize")
    finish.add_argument("--timeline", required=True)
    finish.add_argument("--asset-index", required=True)
    finish.add_argument("--overlay-dir", required=True)
    finish.add_argument("--output-video", required=True)
    finish.add_argument("--project-dir", required=True)
    finish.add_argument("--metrics", required=True)
    finish.add_argument("--status", required=True)
    approval = sub.add_parser("approve")
    approval.add_argument("--video", required=True)
    approval.add_argument("--timeline", required=True)
    approval.add_argument("--contact-sheet", required=True)
    approval.add_argument("--review-notes", required=True)
    approval.add_argument("--approval", required=True)
    approval.add_argument("--final-report", required=True)
    approval.add_argument("--metrics", required=True)
    approval.add_argument("--status", required=True)
    approval.add_argument("--reference-audio")
    approval.add_argument("--source-audio")
    delivery = sub.add_parser("deliver")
    delivery.add_argument("--video", required=True)
    delivery.add_argument("--timeline", required=True)
    delivery.add_argument("--preflight", required=True)
    delivery.add_argument("--ledger", required=True)
    delivery.add_argument("--final-review", required=True)
    delivery.add_argument("--status", required=True)
    delivery.add_argument("--gate-report", required=True)
    delivery.add_argument("--metrics", required=True)
    status_parser = sub.add_parser("status")
    status_parser.add_argument("--status", required=True)
    status_parser.add_argument("--state", required=True, choices=("cancelled", "blocked_external"))
    status_parser.add_argument("--reason", required=True)
    status_parser.add_argument("--correction-exhausted", action="store_true")
    research_parser = sub.add_parser("research")
    research_parser.add_argument("--index-dir", default=str(VISUAL_SEMANTIC_CACHE))
    research_parser.add_argument("--query", action="append", required=True)
    research_parser.add_argument("--top-k", type=int, default=DEFAULT_CANDIDATE_LIMIT)
    research_parser.add_argument("--clip-duration", type=float, default=5.0)
    research_parser.add_argument("--device", default="auto")
    research_parser.add_argument("--category", action="append", default=[])
    research_parser.add_argument("--history-root", default=str(MATERIAL_DELIVERIES_ROOT))
    research_parser.add_argument("--current-project", required=True)
    research_parser.add_argument("--review-dir")
    research_parser.add_argument("--metrics")
    research_parser.add_argument("--reject-asset-id", action="append", default=[])
    research_parser.add_argument("--output")
    research_parser.add_argument("--status", required=True)
    args = parser.parse_args()
    try:
        if args.command == "init":
            result = initialize(Path(args.script), Path(args.output_dir), args.duration, Path(args.audio) if args.audio else None)
        elif args.command == "finalize":
            result = finalize(Path(args.timeline), Path(args.asset_index), Path(args.overlay_dir), Path(args.output_video), Path(args.project_dir), Path(args.metrics), Path(args.status))
        elif args.command == "approve":
            result = approve(
                Path(args.video), Path(args.timeline), Path(args.contact_sheet), Path(args.review_notes), Path(args.approval),
                Path(args.final_report), Path(args.metrics),
                Path(args.reference_audio) if args.reference_audio else None,
                Path(args.source_audio) if args.source_audio else None,
                Path(args.status),
            )
        elif args.command == "deliver":
            result = deliver(
                Path(args.video), Path(args.timeline), Path(args.preflight), Path(args.ledger),
                Path(args.final_review), Path(args.status), Path(args.gate_report), Path(args.metrics),
            )
        elif args.command == "status":
            result = close_status(Path(args.status), args.state, args.reason, args.correction_exhausted)
        else:
            project = Path(args.current_project)
            result = research(
                Path(args.index_dir), args.query, args.top_k,
                args.clip_duration, args.device, Path(args.history_root),
                project, args.category or None,
                Path(args.review_dir) if args.review_dir else project / "候选预览",
                Path(args.metrics) if args.metrics else None,
                set(args.reject_asset_id),
            )
            if args.output:
                write_json(Path(args.output), result)
        status_path = getattr(args, "status", None)
        if status_path and args.command not in {"deliver", "status"}:
            write_success_status(Path(status_path), {
                "research": "research_complete",
                "finalize": "first_review_ready",
                "approve": "visual_approval_review_passed",
            }[args.command])
    except Exception as error:
        status_path = getattr(args, "status", None)
        if status_path and args.command not in {"deliver", "status"}:
            write_failure_status(Path(status_path), error, args.command)
        raise
    print(json.dumps(_json_ready(result), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
