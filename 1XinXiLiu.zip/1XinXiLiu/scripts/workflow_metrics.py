#!/usr/bin/env python3
"""Track end-to-end infoflow production time against stage budgets."""
from __future__ import annotations

import argparse
import time
from pathlib import Path

from speed_common import load_json, write_json


DEFAULT_BUDGETS = {
    "news": 360.0,
    "assets": 300.0,
    "timeline": 240.0,
    "render_review": 120.0,
}


def start_run(path: Path, title: str, target_duration: float, now: float | None = None, budgets: dict | None = None) -> dict:
    timestamp = time.time() if now is None else now
    state = {
        "version": 1,
        "title": title,
        "target_duration_seconds": float(target_duration),
        "started_at_epoch": timestamp,
        "budgets_seconds": {**DEFAULT_BUDGETS, **(budgets or {})},
        "stages": {},
    }
    write_json(path, state)
    return state


def start_stage(path: Path, stage: str, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    timestamp = time.time() if now is None else now
    state.setdefault("stages", {})[stage] = {"started_at_epoch": timestamp}
    write_json(path, state)
    return state


def end_stage(path: Path, stage: str, now: float | None = None, note: str | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    item = state.setdefault("stages", {}).get(stage)
    if not item or "started_at_epoch" not in item:
        raise ValueError(f"stage not started: {stage}")
    timestamp = time.time() if now is None else now
    item["ended_at_epoch"] = timestamp
    item["elapsed_seconds"] = round(timestamp - float(item["started_at_epoch"]), 3)
    if note:
        item["note"] = note
    write_json(path, state)
    return state


def complete_run(path: Path, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    state["completed_at_epoch"] = time.time() if now is None else now
    state["completed"] = True
    write_json(path, state)
    return state


def build_report(path: Path, now: float | None = None) -> dict:
    state = load_json(path, None)
    if state is None:
        raise FileNotFoundError(f"metrics state not found: {path}")
    timestamp = float(state.get("completed_at_epoch") or (time.time() if now is None else now))
    budgets = state.get("budgets_seconds", DEFAULT_BUDGETS)
    stages = {}
    for name, item in state.get("stages", {}).items():
        elapsed = item.get("elapsed_seconds")
        if elapsed is None:
            elapsed = round(timestamp - float(item["started_at_epoch"]), 3)
        budget = float(budgets.get(name, 0.0))
        stages[name] = {
            **item,
            "elapsed_seconds": elapsed,
            "budget_seconds": budget,
            "over_budget": bool(budget and elapsed > budget),
        }
    total = round(timestamp - float(state["started_at_epoch"]), 3)
    return {**state, "stages": stages, "total_elapsed_seconds": total}


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    start = sub.add_parser("start")
    start.add_argument("--state", required=True)
    start.add_argument("--title", required=True)
    start.add_argument("--duration", type=float, required=True)
    stage_start = sub.add_parser("stage-start")
    stage_start.add_argument("--state", required=True)
    stage_start.add_argument("--stage", required=True, choices=sorted(DEFAULT_BUDGETS))
    stage_end = sub.add_parser("stage-end")
    stage_end.add_argument("--state", required=True)
    stage_end.add_argument("--stage", required=True, choices=sorted(DEFAULT_BUDGETS))
    stage_end.add_argument("--note")
    report = sub.add_parser("report")
    report.add_argument("--state", required=True)
    report.add_argument("--output")
    complete = sub.add_parser("complete")
    complete.add_argument("--state", required=True)
    args = parser.parse_args()
    state_path = Path(args.state)
    if args.command == "start":
        result = start_run(state_path, args.title, args.duration)
    elif args.command == "stage-start":
        result = start_stage(state_path, args.stage)
    elif args.command == "stage-end":
        result = end_stage(state_path, args.stage, note=args.note)
    elif args.command == "complete":
        result = complete_run(state_path)
    else:
        result = build_report(state_path)
        if args.output:
            write_json(Path(args.output), result)
    print(args.output if getattr(args, "output", None) else state_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
