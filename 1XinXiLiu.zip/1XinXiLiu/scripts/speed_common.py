#!/usr/bin/env python3
"""Shared cache and toolchain helpers for the infoflow workflow."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

from runtime_config import FFMPEG_OVERRIDE, FFPROBE_OVERRIDE

def find_ffmpeg(explicit: str | None = None) -> str:
    configured = explicit or FFMPEG_OVERRIDE
    if configured:
        path = Path(configured).expanduser()
        if path.is_file():
            return str(path.resolve())
        found = shutil.which(configured)
        if found:
            return found
        raise FileNotFoundError(f"configured ffmpeg not found: {configured}")
    found = shutil.which("ffmpeg")
    if found:
        return found
    raise FileNotFoundError("ffmpeg not found; set INFOFLOW_FFMPEG or pass --ffmpeg")


def find_ffprobe(explicit: str | None = None, ffmpeg: str | None = None) -> str:
    configured = explicit or FFPROBE_OVERRIDE
    if configured:
        path = Path(configured).expanduser()
        if path.is_file():
            return str(path.resolve())
        found = shutil.which(configured)
        if found:
            return found
        raise FileNotFoundError(f"configured ffprobe not found: {configured}")
    if ffmpeg:
        sibling = Path(ffmpeg).with_name("ffprobe.exe" if os.name == "nt" else "ffprobe")
        if sibling.is_file():
            return str(sibling.resolve())
    found = shutil.which("ffprobe")
    if found:
        return found
    raise FileNotFoundError("ffprobe not found; set INFOFLOW_FFPROBE")


def resolve_duration(duration: float | None = None, audio_path: Path | None = None) -> float:
    if (duration is None) == (audio_path is None):
        raise ValueError("provide exactly one of duration or audio")
    if duration is not None:
        if duration <= 0:
            raise ValueError("duration must be > 0")
        return float(duration)
    audio_path = Path(audio_path)
    if not audio_path.is_file():
        raise FileNotFoundError(audio_path)
    result = subprocess.run(
        [find_ffprobe(ffmpeg=find_ffmpeg()), "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path)],
        capture_output=True, text=True, encoding="utf-8", errors="replace", check=True,
    )
    value = float(result.stdout.strip())
    if value <= 0:
        raise ValueError("audio duration must be > 0")
    return value


def stable_json(data: object) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def content_key(data: object, length: int = 16) -> str:
    return hashlib.sha256(stable_json(data).encode("utf-8")).hexdigest()[:length]


def quick_hash(path: Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    size = path.stat().st_size
    with path.open("rb") as handle:
        digest.update(handle.read(block_size))
        if size > block_size:
            handle.seek(max(0, size - block_size))
            digest.update(handle.read(block_size))
    digest.update(str(size).encode("ascii"))
    return digest.hexdigest()


def load_json(path: Path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
