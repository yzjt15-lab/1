#!/usr/bin/env python3
"""Bind an explicit visual approval to exact rendered artifacts."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from speed_common import write_json


CHECKS = {"vertical_layout", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _reviewed_shots(timeline: dict, notes: dict) -> dict:
    expected = {str(shot.get("id", "")) for shot in timeline.get("shots", [])}
    reviewed = notes.get("shots")
    if not isinstance(reviewed, dict) or set(reviewed) != expected:
        raise ValueError("review notes must cover exactly every timeline shot")
    required = ("visible_subject", "visible_action", "visible_location", "visible_equipment")
    declared_matches = 0
    by_id = {str(shot.get("id", "")): shot for shot in timeline.get("shots", [])}
    for shot_id, observation in reviewed.items():
        if not isinstance(observation, dict) or observation.get("semantic_match") is not True:
            raise ValueError(f"review notes {shot_id}: semantic_match=true is required")
        if any(not str(observation.get(field, "")).strip() for field in required):
            raise ValueError(f"review notes {shot_id}: visible subject/action/location/equipment are required")
        evidence = observation.get("evidence_frames")
        if not isinstance(evidence, list) or not evidence or any(not str(label).startswith(f"{shot_id}-") for label in evidence):
            raise ValueError(f"review notes {shot_id}: contact-sheet evidence_frames are required")
        declared = by_id[shot_id].get("script_semantics", {})
        if all(str(observation.get(f"visible_{key}", "")).strip() == str(declared.get(key, "")).strip() for key in ("subject", "action", "location", "equipment")):
            declared_matches += 1
    if reviewed and declared_matches == len(reviewed):
        raise ValueError("review notes appear copied from declared script semantics; record what is actually visible")
    return reviewed


def make_approval(video: Path, timeline: Path, contact_sheet: Path, review_notes: Path) -> dict:
    data = json.loads(timeline.read_text(encoding="utf-8"))
    notes = json.loads(review_notes.read_text(encoding="utf-8"))
    if notes.get("contact_sheet_sha256") != sha256(contact_sheet):
        raise ValueError("review notes are not bound to this contact sheet")
    reviewed = _reviewed_shots(data, notes)
    checks = notes.get("checks")
    if not isinstance(checks, dict) or any(checks.get(name) is not True for name in CHECKS):
        raise ValueError("review notes must confirm all visual checks")
    return {
        "approved_shot_ids": [shot.get("id") for shot in data.get("shots", [])],
        "checks": {name: True for name in sorted(CHECKS)},
        "shot_checks": reviewed,
        "hashes": {
            "video_sha256": sha256(video),
            "timeline_sha256": sha256(timeline),
            "contact_sheet_sha256": sha256(contact_sheet),
            "review_notes_sha256": sha256(review_notes),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--contact-sheet", required=True)
    parser.add_argument("--review-notes", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        approval = make_approval(Path(args.video), Path(args.timeline), Path(args.contact_sheet), Path(args.review_notes))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise SystemExit(str(exc))
    write_json(Path(args.output), approval)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
