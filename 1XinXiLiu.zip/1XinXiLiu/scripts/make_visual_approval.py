#!/usr/bin/env python3
"""Bind an explicit visual approval to exact rendered artifacts."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from speed_common import write_json


CHECKS = {"title_bar", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def make_approval(video: Path, timeline: Path, contact_sheet: Path, confirmed: set[str] | None = None) -> dict:
    data = json.loads(timeline.read_text(encoding="utf-8"))
    return {
        "approved_shot_ids": [shot.get("id") for shot in data.get("shots", [])],
        "checks": {name: name in (confirmed or set()) for name in sorted(CHECKS)},
        "hashes": {
            "video_sha256": sha256(video),
            "timeline_sha256": sha256(timeline),
            "contact_sheet_sha256": sha256(contact_sheet),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--contact-sheet", required=True)
    parser.add_argument("--confirm", action="append", default=[], choices=sorted(CHECKS))
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    confirmed = set(args.confirm)
    if confirmed != CHECKS:
        raise SystemExit("all five --confirm checks are required after visual inspection")
    approval = make_approval(Path(args.video), Path(args.timeline), Path(args.contact_sheet), confirmed)
    write_json(Path(args.output), approval)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
