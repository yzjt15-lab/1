#!/usr/bin/env python3
"""Build an incremental, provenance-aware video asset index."""
from __future__ import annotations

import argparse
import os
import re
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from speed_common import DEFAULT_EXCLUDED_DIRS, file_signature, find_ffmpeg, load_json, quick_hash, write_json


VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv", ".mxf", ".webm", ".avi", ".m4v"}
TOKEN_RE = re.compile(r"[\w\u4e00-\u9fff]+", re.UNICODE)
GENERATED_DIR_MARKERS = ("渲染", "片段", "素材帧", "复核帧", "代理", "重制", "融合版", "cache", "temp", "frames", "render", "proxy", "output")


def is_excluded_dir(name: str) -> bool:
    folded = name.casefold()
    return folded in DEFAULT_EXCLUDED_DIRS or any(marker in folded for marker in GENERATED_DIR_MARKERS)


def iter_videos(roots: list[Path]):
    for root in roots:
        if root.is_file() and root.suffix.lower() in VIDEO_EXTENSIONS:
            yield root.resolve()
            continue
        if not root.exists():
            continue
        for current, dirs, files in os.walk(root):
            dirs[:] = [name for name in dirs if not is_excluded_dir(name)]
            for name in files:
                path = Path(current) / name
                if path.suffix.lower() in VIDEO_EXTENSIONS:
                    yield path.resolve()


def ffmpeg_probe(path: Path, ffmpeg: str | None = None) -> dict:
    command = [find_ffmpeg(ffmpeg), "-hide_banner", "-i", str(path), "-frames:v", "1", "-f", "null", "NUL"]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    text = result.stderr
    duration_match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    video_match = re.search(r"Video:\s*([^,]+).*?(\d{2,5})x(\d{2,5}).*?(\d+(?:\.\d+)?)\s*fps", text)
    duration = None
    if duration_match:
        duration = int(duration_match[1]) * 3600 + int(duration_match[2]) * 60 + float(duration_match[3])
    return {
        "duration": duration,
        "codec": video_match[1].strip() if video_match else None,
        "width": int(video_match[2]) if video_match else None,
        "height": int(video_match[3]) if video_match else None,
        "fps": float(video_match[4]) if video_match else None,
        "probe_ok": bool(duration_match and video_match),
    }


def _ledger_map(paths: list[Path]) -> dict[str, dict]:
    merged: dict[str, dict] = {}
    for path in paths:
        raw = load_json(path, {})
        items = raw if isinstance(raw, list) else raw.get("assets", [])
        for item in items:
            local = item.get("local_path") or item.get("path")
            if local:
                merged[str(Path(local).resolve()).casefold()] = item
    return merged


def _copy_ledger_fields(item: dict, ledger: dict) -> None:
    for key in ("id", "source_url", "publisher", "source_description", "license", "segments", "tags"):
        if ledger.get(key):
            item[key] = ledger[key]


def _keywords(path: Path) -> list[str]:
    values = TOKEN_RE.findall(" ".join(path.parts[-3:]).replace("_", " ").replace("-", " "))
    return sorted({value.casefold() for value in values if len(value) > 1})


def build_index(roots: list[Path], cache_path: Path, probe=ffmpeg_probe, ledgers: list[Path] | None = None, workers: int = 1) -> dict:
    old = load_json(cache_path, {"assets": []})
    old_by_path = {item["path"].casefold(): item for item in old.get("assets", [])}
    provenance = _ledger_map(ledgers or [])
    assets = []
    changed = []
    for path in sorted(set(iter_videos(roots)), key=lambda item: str(item).casefold()):
        signature = file_signature(path)
        previous = old_by_path.get(signature["path"].casefold())
        if previous and all(previous.get(key) == signature[key] for key in ("size", "mtime_ns")):
            refreshed = dict(previous)
            ledger = provenance.get(signature["path"].casefold(), {})
            if ledgers:
                for key in ("source_url", "publisher", "source_description", "license", "segments", "tags"):
                    refreshed.pop(key, None)
            _copy_ledger_fields(refreshed, ledger)
            assets.append(refreshed)
            continue
        changed.append((path, signature))

    def inspect(entry):
        path, signature = entry
        metadata = probe(path)
        item = {**signature, **metadata, "quick_hash": quick_hash(path), "keywords": _keywords(path)}
        ledger = provenance.get(signature["path"].casefold(), {})
        _copy_ledger_fields(item, ledger)
        item.setdefault("id", "asset-" + item["quick_hash"][:12])
        return item

    if changed:
        with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
            assets.extend(pool.map(inspect, changed))
    assets.sort(key=lambda item: item["path"].casefold())
    result = {"version": 2, "roots": [str(Path(root).resolve()) for root in roots], "assets": assets}
    write_json(cache_path, result)
    return result


def rank_assets(assets: list[dict], keywords: list[str], require_provenance: bool = False) -> list[dict]:
    wanted = {word.casefold() for word in keywords}
    ranked = []
    for item in assets:
        if require_provenance and not all(item.get(key) for key in ("source_url", "publisher", "source_description")):
            continue
        tags = {str(word).casefold() for word in item.get("keywords", [])}
        score = len(wanted & tags)
        if score:
            ranked.append((score, item.get("duration") or 10**9, item.get("size") or 10**18, item))
    ranked.sort(key=lambda row: (-row[0], row[1], row[2], row[3]["path"].casefold()))
    return [row[3] for row in ranked]


def _term_score(wanted: list[str], values: list[str]) -> int:
    haystack = " ".join(str(value).casefold() for value in values)
    return sum(1 for term in wanted if term.casefold() in haystack)


def rank_segments(assets: list[dict], keywords: list[str], require_provenance: bool = False) -> list[dict]:
    """Return shot-level candidates with ranges ready to copy into a timeline."""
    ranked = []
    for asset in assets:
        if require_provenance and not all(asset.get(key) for key in ("source_url", "publisher", "source_description")):
            continue
        asset_values = list(asset.get("keywords", [])) + list(asset.get("tags", []))
        for index, segment in enumerate(asset.get("segments", []), start=1):
            start = float(segment.get("start", -1))
            end = float(segment.get("end", -1))
            if start < 0 or end <= start:
                continue
            duration = asset.get("duration")
            if duration is not None and end > float(duration) + 0.001:
                continue
            values = asset_values + list(segment.get("keywords", [])) + [
                segment.get("subject", ""), segment.get("action", ""), segment.get("visual", "")
            ]
            score = _term_score(keywords, values)
            if not score:
                continue
            candidate = {
                "asset_id": asset.get("id"),
                "path": asset.get("path"),
                "source_in": start,
                "source_out": end,
                "duration": round(end - start, 3),
                "segment_id": segment.get("id") or f"{asset.get('id')}-seg-{index:03d}",
                "keywords": segment.get("keywords", []),
                "subject": segment.get("subject"),
                "action": segment.get("action"),
                "visual": segment.get("visual"),
                "source_url": asset.get("source_url"),
                "publisher": asset.get("publisher"),
                "source_description": asset.get("source_description"),
            }
            ranked.append((score, candidate["duration"], asset.get("size") or 10**18, candidate))
    ranked.sort(key=lambda row: (-row[0], row[1], row[2], str(row[3]["path"]).casefold()))
    return [row[3] for row in ranked]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", action="append", required=True)
    parser.add_argument("--index", required=True)
    parser.add_argument("--ledger", action="append", default=[])
    parser.add_argument("--ffmpeg")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--search-keyword", action="append", default=[])
    parser.add_argument("--search-output")
    parser.add_argument("--search-segments", action="store_true")
    args = parser.parse_args()
    result = build_index([Path(value) for value in args.root], Path(args.index), probe=lambda path: ffmpeg_probe(path, args.ffmpeg), ledgers=[Path(value) for value in args.ledger], workers=args.workers)
    if args.search_keyword:
        search = rank_segments if args.search_segments else rank_assets
        ranked = search(result["assets"], args.search_keyword, False)
        destination = Path(args.search_output or (str(args.index) + ".candidates.json"))
        write_json(destination, {"keywords": args.search_keyword, "level": "segment" if args.search_segments else "asset", "candidates": ranked})
        print(destination)
    print(args.index)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
