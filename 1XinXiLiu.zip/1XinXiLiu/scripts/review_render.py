#!/usr/bin/env python3
"""Run technical delivery checks and emit a per-shot review report."""
import argparse
import json
import re
import subprocess
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from make_visual_approval import OBSERVATION_FIELDS, sha256
from speed_common import find_ffmpeg, find_ffprobe


REQUIRED_VISUAL_CHECKS = {"title_bar", "disclaimer", "no_subtitles", "keyword_match", "no_black_or_placeholder"}
FRAME_TOLERANCE_SECONDS = 1 / 30 + 1e-6


def duration_matches(expected: float, measured: float) -> bool:
    return abs(float(expected) - float(measured)) <= FRAME_TOLERANCE_SECONDS


def read_json_object(path: str, label: str, errors: list[str]) -> dict:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"{label} could not be read: {exc}")
        return {}
    if not isinstance(value, dict):
        errors.append(f"{label} root must be a JSON object")
        return {}
    return value


def build_review_rows(shots: list[dict], approved_ids: set[str]) -> list[dict]:
    return [{"id": shot.get("id"), "chapter_id": shot.get("chapter_id"), "information_task": shot.get("information_task"), "start": shot.get("start"), "end": shot.get("end"), "keyword": shot.get("keyword"), "checked": shot.get("id") in approved_ids} for shot in shots]


def same_path(left: str | None, right: str | None) -> bool:
    if not left or not right:
        return False
    try:
        return Path(left).resolve() == Path(right).resolve()
    except (OSError, TypeError, ValueError):
        return False


def validate_reference_audio_contract(timeline: dict, reference_audio: str | None) -> list[str]:
    errors: list[str] = []
    timeline_audio = timeline.get("reference_audio_path")
    if not reference_audio:
        if timeline_audio:
            errors.append("timeline reference_audio_path requires --reference-audio")
        return errors
    if not same_path(timeline_audio, reference_audio):
        errors.append("reference audio does not match timeline reference_audio_path")
    segments = timeline.get("reference_audio_segments")
    if not isinstance(segments, list) or not segments:
        errors.append("reference audio segments are missing")
    for shot in timeline.get("shots", []):
        value = shot.get("reference_audio_range")
        if not isinstance(value, dict) or not isinstance(value.get("start"), (int, float)) or not isinstance(value.get("end"), (int, float)) or value["end"] <= value["start"]:
            errors.append(f"shot {shot.get('id', '?')}: reference_audio_range is invalid")
    for overlay in timeline.get("overlays", []):
        if overlay.get("role") == "hook":
            continue
        value = overlay.get("reference_audio_range")
        if not isinstance(value, dict) or not isinstance(value.get("start"), (int, float)) or not isinstance(value.get("end"), (int, float)) or value["end"] <= value["start"]:
            errors.append(f"overlay {overlay.get('id', '?')}: reference_audio_range is invalid")
        if not str(overlay.get("reference_audio_text", "")).strip() or overlay.get("audio_semantic_match") is not True:
            errors.append(f"overlay {overlay.get('id', '?')}: reference audio semantic lock is incomplete")
    return errors


def make_shot_contact_sheet(video: str, shots: list[dict], output: str, ffmpeg: str) -> None:
    points = []
    labels = []
    for shot in shots:
        start, end = float(shot["start"]), float(shot["end"])
        for suffix, moment in (("A", start + min(0.1, (end - start) / 4)), ("M", (start + end) / 2), ("B", end - min(0.1, (end - start) / 4))):
            points.append(moment)
            labels.append(f"{shot.get('id', '?')}-{suffix}")
    frame_numbers = [max(0, round(moment * 30)) for moment in points]
    if not frame_numbers:
        return
    selection = "+".join(f"eq(n\\,{number})" for number in frame_numbers)
    rows = math.ceil(len(frame_numbers) / 4)
    vf = f"select='{selection}',scale=320:-2,tile=4x{rows}"
    subprocess.run([ffmpeg, "-y", "-i", video, "-vf", vf, "-frames:v", "1", "-update", "1", output], check=True, capture_output=True)
    image = Image.open(output).convert("RGB")
    draw = ImageDraw.Draw(image)
    cell_height = image.height // rows
    font = ImageFont.load_default()
    for index, label in enumerate(labels):
        x, y = (index % 4) * 320, (index // 4) * cell_height
        draw.rectangle((x, y, x + 58, y + 18), fill="black")
        draw.text((x + 4, y + 3), label, fill="white", font=font)
    image.save(output, quality=90)


def probe(path: str) -> dict:
    try:
        ffprobe = find_ffprobe()
        cmd = [ffprobe, "-v", "error", "-show_entries", "format=duration:stream=codec_type,codec_name,duration", "-of", "json", path]
        return json.loads(subprocess.check_output(cmd, text=True, encoding="utf-8"))
    except FileNotFoundError:
        pass
    ffmpeg = find_ffmpeg()
    result = subprocess.run([ffmpeg, "-hide_banner", "-i", path, "-frames:v", "1", "-f", "null", "NUL"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    report = result.stderr
    match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", report)
    if not match:
        raise RuntimeError(f"could not read duration from ffmpeg output for {path}")
    duration = int(match.group(1)) * 3600 + int(match.group(2)) * 60 + float(match.group(3))
    streams = [{"codec_type": "audio" if re.search(r"Audio:", line) else "video"} for line in report.splitlines() if "Stream #" in line and ("Audio:" in line or "Video:" in line)]
    return {"format": {"duration": duration}, "streams": streams}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--reference-audio")
    parser.add_argument("--source-audio")
    parser.add_argument("--report", required=True)
    parser.add_argument("--contact-sheet")
    parser.add_argument("--visual-approval")
    args = parser.parse_args()
    errors: list[str] = []
    timeline = read_json_object(args.timeline, "timeline", errors)
    approval = read_json_object(args.visual_approval, "visual approval", errors) if args.visual_approval else {}
    errors.extend(validate_reference_audio_contract(timeline, args.reference_audio))
    try:
        video = probe(args.video)
        duration = float(video["format"]["duration"])
        if args.source_audio:
            audio = probe(args.source_audio)
            source_duration = float(audio["format"]["duration"])
        else:
            source_duration = float(timeline["duration_seconds"])
        target_duration = float(timeline["duration_seconds"])
        if not duration_matches(source_duration, duration):
            errors.append("video duration differs from source audio or target duration")
        if args.source_audio and not duration_matches(target_duration, source_duration):
            errors.append("source audio duration differs from timeline target duration")
        if args.source_audio and not any(item.get("codec_type") == "audio" for item in video.get("streams", [])):
            errors.append("rendered video has no audio stream")
        if not args.source_audio and any(item.get("codec_type") == "audio" for item in video.get("streams", [])):
            errors.append("rendered video unexpectedly contains audio without narration_audio")
        if args.visual_approval:
            ffmpeg = find_ffmpeg()
            decode = subprocess.run([ffmpeg, "-hide_banner", "-i", args.video, "-vf", "blackdetect=d=0.2:pix_th=0.10", "-f", "null", "NUL"], capture_output=True, text=True, encoding="utf-8", errors="replace")
            if decode.returncode != 0:
                errors.append("full decode failed: " + decode.stderr.strip()[:300])
            if "black_start:" in decode.stderr:
                errors.append("black frame interval detected")
            if any(marker in decode.stderr for marker in ("Non-monotonic DTS", "backward in time")):
                errors.append("timestamp regression detected")
    except Exception as exc:
        errors.append(f"technical review failed: {exc}")
        duration = None
        source_duration = None
        target_duration = None
    contact_sheet = args.contact_sheet or str(Path(args.report).with_suffix(".jpg"))
    if args.contact_sheet:
        if not Path(contact_sheet).is_file():
            errors.append(f"approved contact sheet missing: {contact_sheet}")
    else:
        try:
            make_shot_contact_sheet(args.video, timeline.get("shots", []), contact_sheet, find_ffmpeg())
        except Exception as exc:
            errors.append(f"contact sheet failed: {exc}")
    if args.visual_approval and not args.contact_sheet:
        errors.append("final review requires the approved authoritative contact sheet")
    if args.visual_approval:
        try:
            expected_hashes = {
                "video_sha256": sha256(Path(args.video)),
                "timeline_sha256": sha256(Path(args.timeline)),
                "contact_sheet_sha256": sha256(Path(contact_sheet)),
            }
        except OSError as exc:
            errors.append(f"visual approval artifact missing: {exc}")
        else:
            if approval.get("hashes") != expected_hashes:
                errors.append("visual approval artifact hashes do not match")
    approved_ids = set(approval.get("approved_shot_ids", []))
    observations = approval.get("shot_observations", {})
    checks = approval.get("checks", {})
    rows = build_review_rows(timeline.get("shots", []), approved_ids)
    unchecked = [row["id"] for row in rows if not row["checked"]]
    if unchecked:
        errors.append("visual approval missing for shots: " + ", ".join(unchecked))
    if args.visual_approval:
        if not isinstance(observations, dict) or set(observations) != {row["id"] for row in rows}:
            errors.append("visual observations do not cover every timeline shot exactly")
        elif any(not isinstance(item, dict) or any(not str(item.get(field, "")).strip() for field in OBSERVATION_FIELDS) for item in observations.values()):
            errors.append("visual observations are incomplete")
    missing_checks = sorted(check for check in REQUIRED_VISUAL_CHECKS if checks.get(check) is not True)
    if missing_checks:
        errors.append("visual checks missing: " + ", ".join(missing_checks))
    report = {
        "video": args.video,
        "timeline": str(Path(args.timeline).resolve()),
        "timeline_sha256": sha256(Path(args.timeline)) if Path(args.timeline).is_file() else None,
        "reference_audio": args.reference_audio,
        "source_audio": args.source_audio,
        "video_duration": duration,
        "audio_duration": source_duration if args.source_audio else None,
        "target_duration": target_duration,
        "shots": rows,
        "chapters": [{"id": chapter.get("id"), "thesis": chapter.get("thesis"), "information_plan": chapter.get("information_plan", [])} for chapter in timeline.get("chapters", [])],
        "contact_sheet": contact_sheet,
        "contact_sheet_sha256": sha256(Path(contact_sheet)) if Path(contact_sheet).is_file() else None,
        "visual_approval": args.visual_approval,
        "visual_approval_sha256": sha256(Path(args.visual_approval)) if args.visual_approval and Path(args.visual_approval).is_file() else None,
        "errors": errors,
        "ok": not errors,
    }
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
