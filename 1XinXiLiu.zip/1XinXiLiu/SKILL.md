---
name: producing-keyword-linked-infoflow-video
description: Create Chinese 9:16 information-flow videos with a large central 16:9-derived window, synchronized blurred projections, verified news screenshots, and seven approved information-page types. Use for Chinese copy timed by either a target duration or supplied audio; 制作关键词信息流视频、财经短视频、信息页视频。
---

# 关键词信息流视频

## 入口与权威边界

- 开始前读取全局日志；文件名使用 `YYYY-MM-DD_类型_<文案文件名>.扩展名`，类型只能为工程、视频、音频、图片、文档，不表示子目录。正式视频默认写入当前用户的 `Videos/Codex`。
- `manage-material-library` 是候选资格、五字段检索、168 小时去重和使用台账的唯一权威。不得另建索引、资格规则或台账。
- 画面语义检索复用曲线 Skill 的 `visual_semantic_index.py`；`INFOFLOW_VISUAL_SEMANTIC_INDEX` 可覆盖路径。加载时必须验证接口版本，缺失或版本不符即停止素材检索。
- 用户文案是事实、数字与画面检索语义的唯一内容来源；网页只用于寻找匹配画面或真实新闻截图，不得借搜索结果改写用户文案。
- 本 Skill 与曲线 Skill 共用输入、素材、时间线、新闻、渲染、复审和交付规则；唯一业务差异是本 Skill 使用钩子、事实、新闻、数据、数字、因果、对比七类信息页，不使用五类曲线图表。

## 输入与资源

必填：完整中文文案，以及目标时长或音频二选一。时间线必须显式写入 `audio_delivery_mode`：目标时长使用 `silent` 且不设置 `audio_path`；音频使用 `narration`，以实测时长和节奏建立时间轴，并把该 `audio_path` 作为旁白进入成片。人物或参考视频可选。

先确认 `scripts/`、`references/`、`assets/approved-pages/` 以及 Python、FFmpeg、FFprobe 可用。读取 `references/七类信息页固定标准.json`，逐项校验七类页面的唯一批准文件名、SHA-256、`1080×830` 尺寸及 `central_clear_window` 角色，并实际查看当前所用类型的参考图。模板文件名只允许出现在该清单中；代码必须从清单派生映射。缺文件、哈希不符、尺寸或类型错配时停止受影响分支。普通生产不得重建批准页；只有用户明确授权时才可运行参考页重建入口。

按需读取 `references/timeline-schema.md`、`references/review-contract.md` 和 `references/speed-workflow.md`。

## 文案到信息页

根据用户原文直接生成 `overlays[]`；`overlays[]` 是信息页数量、类型、位置和跳过结果的唯一权威。不保存独立信息页规划 JSON，也不设置生成前批准状态。编码前在对用户可见的进度中列出预计信息页总数及每页类型、原文区间和出现时间。

## 生产流程

1. 从文案建立 `chapters[]` 与 `overlays[]`。每章保存原文、区间和五字段语义；每张非钩子页直接以 `chapter_id`、`information_task`、`script_range` 绑定原文章节。
2. 并行准备三路：素材候选、真实新闻截图、信息页。三路只在时间线合并时汇合，不得反推或改写章节证据。
3. 素材分支先 `audit`，再把所有章节的主体、动作、地点、设备和关键词作为一次 `fast_pipeline.py research` 批量检索；每个查询默认最多 8 条，全部查询共用同一工程 `候选预览` 目录，并由素材库统一过滤资格、去重和生成可复用的 3 秒 MP4 与 A/M/B。只为最终拟入轴候选做真实区间目检和联系表。初次批量检索后只允许针对缺口章节再做一次批量纠正，并排除已目检拒绝的资产；不得多轮直调素材库默认搜索。每个镜头必须保存候选资产、选片理由、`source_in/out`、帧证据和清洁度证据。没有合格候选时保留原章节和主张，预检失败并阻止全片渲染；不得删章、改写为泛化 B-roll 或捏造证据。一次纠正仍无候选时，列出章节 ID、五字段和缺少的资源，状态为 `blocked_external`。
4. 新闻检索累计最多 5 分钟；达到 5 分钟仍没有合格截图就不生成该新闻页，章节与视频镜头继续。不得用假新闻页、占位页、其他信息页或 `broll` 冒充新闻页。新闻只登记在 `overlays[]`，中央页仅等比显示 `screenshot_path`，不得增加其他绘制元素。计时命令与正式入口见 `references/speed-workflow.md`。
5. 其他信息页只使用清单对应的批准版式，并只呈现用户原文可支持的内容。没有足够内容或数据就不生成该页，不得补造。
6. 合并后执行准备、时间线校验和预检；只有正式入口可渲染，随后生成权威联系表、逐镜复审、批准和交付门禁。任何时间线、素材、叠层或音频变更都会使旧批准失效。

## 素材与时间线门禁

- 入轴素材必须是素材库合格候选：横版 16:9、至少 1280×720、源片大于 4 秒、可解码、默认近 168 小时未使用、五字段完整且有真实帧证据。只有用户明确授权某一工程绕过七日去重时，才可在 `dedupe_audit` 写入 `lookback_hours:0`、`user_authorized_exception:true` 和具体 `exception_reason`；该例外只作用于该工程，不豁免任何其他质量、语义、帧证据或清洁度门禁。
- `watermark_free`、`embedded_subtitles_free`、`platform_overlay_free` 必须均为 `true`；不合格素材只能换源，不能裁切、遮挡或压暗后使用。
- 每镜必须有 `chapter_id`、`asset_id`、五字段语义、`script_range`、`information_task`、候选凭据、选片理由和覆盖镜头时长的 `source_in/out`。
- 选片清单、时间线、索引与资产台账必须绑定同一路径、哈希和实际选段；正式采用后才登记使用。

## 页面合同

页面类型只能是 `hook`、真实 `news`、`fact`、`data`、`number`、`causal`、`comparison`。页面固定 4.0 秒。终版固定 1080×1920；中央清晰窗口 1080×830、顶部 `y=604`。上下模糊层只能来自同一时刻的原始视频，并在页面叠加前生成；页面只覆盖中央窗口。免责声明只由全局透明层持续显示一次，24 px，位于 `y=604` 上方 8 px、右边距 62 px。

钩子页只使用 `thesis/judgment/evidence` 三层正文；事实、数据、数字、因果和对比页只绘制正文、数值、标签与结论。对比页使用 `left_label/right_label`。新闻页只显示真实截图。每张页面的 `reference_template` 只能从固定标准清单读取。

## 渲染与交付

- 总时长 `>=90` 秒或真实视频输入超过 12 条时使用分段渲染。每段允许 1–5 个镜头且不超过 25 秒；找不到不切开页面的边界时停止。
- 正式渲染前以最终时间线和实际叠层做 3 秒编码探测；硬件编码失败只回退一次软件编码。
- 全过程保持可恢复状态；只有全部预检、联系表、逐镜观察、视觉批准、完整解码与交付门禁通过后才可交付。
- 钩子必须是底层真实画面持续运动上的逐帧揭示；每行对比度至少 `4.5:1`。禁止静态图冒充动画或绘制整块黑底。
- 不得重复新闻页、复用已用素材、用文件名代替视觉证据、伪造批准或用旧门禁批准新版本。
