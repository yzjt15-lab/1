---
name: producing-keyword-linked-infoflow-video
description: Use when a user provides a Chinese script, target duration, and title for a 16:9 information-flow video, with optional reference or narration audio.
---

# 关键词关联信息流视频

## 启动与环境

- 把本文件所在目录解析为 `SKILL_ROOT`，所有 `scripts/`、`references/`、`assets/` 均相对它解析。
- 把 `scripts/runtime_config.py` 作为本 Skill 运行路径的唯一代码定义。默认从当前用户目录推导；迁移时使用 `INFOFLOW_USER_ROOT`、`INFOFLOW_CONFIG_ROOT`、`INFOFLOW_SKILLS_ROOT`、`INFOFLOW_MATERIAL_LIBRARY_ROOT`、`INFOFLOW_MATERIAL_LIBRARY_SCRIPTS`、`INFOFLOW_DOCUMENT_OUTPUT_DIR`、`INFOFLOW_VIDEO_OUTPUT_DIR`、`INFOFLOW_VISUAL_SEMANTIC_INDEX`、`INFOFLOW_VISUAL_SEMANTIC_CACHE`、`INFOFLOW_FFMPEG`、`INFOFLOW_FFPROBE` 覆盖。不得在其他脚本新增用户名或机器专用绝对路径。
- 开始任务时读取 `INFOFLOW_CONFIG_ROOT/Codex_Workspace/01_全局复利与踩坑日志.md`；只按其写入规则记录真实错误、阻塞或可复用经验。
- 使用 `date_project/video|audio|image|document_title` 命名。正式视频写入配置的 `VIDEO_OUTPUT_DIR`；其他产物写入调用方指定的工程目录。
- 开始制作前确认 `scripts/fast_pipeline.py`、`scripts/runtime_config.py`、`scripts/preflight.py`、`scripts/validate_timeline.py`、两个时间线渲染器、台账/复审/交付脚本以及三个引用文档存在。缺少核心资源或外部命令时，进入[执行状态主规则](#执行状态主规则)，不得伪造成功或临时绕过门禁。
- 视觉检索脚本必须满足 `SEMANTIC_INDEX_API_VERSION=1` 且暴露可调用的 `search_many`；接口不符立即停止。

## 主规则索引

- [用户文案主规则](#用户文案主规则)：信息页内容边界。
- [来源字段主规则](#来源字段主规则)：URL、作者、许可与署名字段。
- [五项语义与时间线主规则](#五项语义与时间线主规则)：唯一字段集合和镜头合同。
- [素材资格主规则](#素材资格主规则)：统一素材库、168 小时去重与使用登记。
- [视觉页面主规则](#视觉页面主规则)：七类页面、钩子、标题栏和底栏。
- [统一交付主规则](#统一交付主规则)：唯一编排顺序与哈希门禁。
- [执行状态主规则](#执行状态主规则)：重试、阻塞和可操作退出报告。

其他章节只能链接这些定义，不得重述、缩减或创建例外。

## 用户文案主规则

- 把用户提供的文案、标题和时间轴作为 `fact/news/data/number/comparison/causal` 信息页的唯一内容来源，直接使用；不做真实性检索、交叉核验或一致性判断，也不要求绑定可核验来源。
- 仅为匹配既定文案的真实画面或新闻页面截图进行搜索；不得因搜索结果改写、删除或阻断用户内容。
- 不擅自改写已确认文案。缺少音频时仍按文案、时长和标题推进；只有用户明确要求重定时时才改变已确认时间。

## 来源字段主规则

- 把原始 URL、发布者、作者、许可类型、署名要求和来源说明视为可选的 best-effort 字段：可取得时登记，不可取得时省略，不得编造。
- 不把来源字段缺失单独作为入库、预检、渲染、批准或交付阻断条件。素材仍必须通过[素材资格主规则](#素材资格主规则)。
- 不绕过登录、机器人策略、访问控制或版权限制；只使用可直接取得或用户提供的授权文件。

## 五项语义与时间线主规则

- 唯一五项语义字段为 `subject/action/location/equipment/keywords`。每镜的 `script_semantics`、`semantic_fields` 与 `theme_mapping` 逐项保持一致。
- 时间线顶层必须有 `chapters[]`、`main_thesis`、`main_evidence_id`、`evidence_kind`、`duration_seconds`、`selection_manifest_path`、`selection_manifest_sha256` 和 `dedupe_audit`；新闻只登记在 `overlays[]`。每镜必须有 `chapter_id`、五项语义、`information_task`、`script_range`、`asset_id`、`selection_mode: semantic_index`、`candidate_asset_ids`、非空 `selection_reason` 与合法 `source_in/source_out`。
- `information_task` 只允许 `fact/news/data/number/comparison/causal/broll`。`hook` 是独立 overlay role，不占用 `information_task`；信息页必须以 `chapter_id/evidence_id` 绑定本章计划。
- 同一素材全片只出现一次；实拍镜头为 `2.0–5.0` 秒；信息页固定 `4.0` 秒并叠加在相关连续实拍上。时间线、素材、叠层或音频变化后，使所有下游批准和门禁失效。
- 使用 [references/timeline-schema.md](references/timeline-schema.md) 作为字段合同；让 `validate_timeline.py` 和 `preflight.py` 执行全部确定性校验。

## 素材资格主规则

- 只通过 `manage-material-library` 工作流执行入库、索引、五项语义筛选、168 小时去重、永久排除、正式使用登记和完整性审计。冲突时以该 Skill 为准。
- 先调用统一素材库做分类检索，再用 `fast_pipeline.py research` 进行视觉排序并交给全局 `filter_candidates()` 复核。只从 `eligible_visual_candidates` 选片；没有合格候选时才精确扩展检索或下载。
- 下载前把候选绑定到具体缺口镜头及五项查询；默认尝试一次 1080p，再尝试一次同源 720p，仍失败即换候选。完成后立即用 `ffprobe` 验证，随后通过全局 `ingest` 入库；不得直接复制到素材库。
- 逐帧检查实际 `source_in/source_out`，排除黑场、彩条、占位、片头、加载页、水印、烧录字幕和平台覆盖。只在 `deliver` 成功后调用全局 `commit_ledger()`。

## 视觉页面主规则

- 合法信息页只有 `fact/news/data/number/comparison/causal`，另有独立 `hook`。所有自制文字使用简体中文，不显示“事实页/数据页”等类别角标，不烧录字幕。
- 读取 `references/七类信息页固定标准.json`，校验其绑定的七张参考图 SHA-256，并实际查看当前页面类型样图。缺文件、哈希不符、类型错配或未查看样图时停止。
- 统一使用深蓝/黑/金体系、顶部黑栏黄线和底部留空黑栏。顶部标题栏从 `0.0` 秒覆盖到末帧，免责声明固定在顶部标题栏最右侧；底部栏不得放文字、来源或免责声明。
- 钩子页使用暗化真实画面与三层居中文字，`0.25–1.0` 秒逐帧揭示，第 `1.0` 秒完整出现；保留 `frame_pattern`。对比度低于 `4.5:1` 时加深整幅背景，仍失败则预检失败。
- 详细页面布局、逐镜复审和批准文件使用 [references/review-contract.md](references/review-contract.md) 与固定标准清单；不得在本文件重复布局细则。

## 统一交付主规则

- 唯一顺序为：`init -> 语义/章节规划 -> 三路准备/research -> 合并时间线 -> finalize(内部 preflight) -> 目检 authoritative_contact_sheet -> make_visual_approval -> approve/final review -> deliver`。
- `candidate_review_sheet` 仅用于候选选片；`authoritative_contact_sheet` 由 `finalize` 针对当前候选生成并绑定视频和准备后时间线。两者不得混用或覆盖。
- 只有 `fast_pipeline.py finalize` 可向配置的正式视频目录写入候选 MP4；其他渲染器只能写 preview 或由 finalize 管理的中间文件。
- `deliver` 必须核验当前视频、准备后时间线、预检、台账、最终复审及其 SHA-256。只有退出码 `0` 且 `terminal_allowed=true` 才能交付；其他 MP4 均为 preview。
- 使用 [references/speed-workflow.md](references/speed-workflow.md) 的命令入口，使用 [references/review-contract.md](references/review-contract.md) 完成逐镜复审。不得直接调用独立脚本改变上述顺序。

## 执行状态主规则

- `init` 写入 `in_progress`；只有 `deliver` 成功写入 `complete`。生产子命令必须传同一 `--status`；外部工具或输入不可取得时统一写入 `blocked_external`。
- 不设通用“三次重试”。下载、编码探测和渲染分别使用本流程的专用预算；同一根因不得在不同章节叠加重试次数。
- NVENC 探测失败时只回退一次到 `libx264 / veryfast / CRF 19`；软件编码探测失败立即停止。其他错误直接返回状态报告，不承诺自动重试。
- 失败报告必须包含 `state`、`blocking_domain`、`retryable`、`gate_errors` 和可执行的 `next_actions`。修复最早受影响输入后重新生成全部下游产物，不得复用旧批准。

## 音频与输出

- 区分 `reference_audio` 与 `narration_audio`：前者仅用于语义/节奏参考，后者才是成片音轨。没有 narration 时允许静音成片；不得擅自配音或把 reference 写入成片。
- 用户给逐句时间时直接采用；只有文案和总时长时按语义断句和有效字数分配，首句从 `0.0` 开始，末句结束等于目标时长。
- 端到端计时必须覆盖新闻、素材、时间线、渲染和复审；不得以局部编码耗时替代总耗时。
