import json
import subprocess
import sys
import unittest
from pathlib import Path


class SharedWorkflowContractTests(unittest.TestCase):
    def snapshot(self, scripts: Path) -> dict:
        code = """
import json
import delivery_gate
import fast_pipeline
import preflight
import review_render
import workflow_metrics
print(json.dumps({
    'budgets': workflow_metrics.DEFAULT_BUDGETS,
    'delivery_tolerance': delivery_gate.FRAME_TOLERANCE_SECONDS,
    'review_tolerance': review_render.FRAME_TOLERANCE_SECONDS,
    'fast_pipeline_gates': [hasattr(fast_pipeline, name) for name in ('omit_timed_out_news', 'close_status', 'update_progress', 'complete_status')],
    'preflight_gates': [hasattr(preflight, name) for name in ('derived_source_id', 'has_pillarbox', 'validate_selection_manifest')],
    'audio_contract': review_render.validate_reference_audio_contract({
        'reference_audio_path': 'a.wav', 'reference_audio_segments': [{'start': 0.0, 'end': 1.0}],
        'shots': [{'id': 's1', 'reference_audio_range': {'start': 0.0, 'end': 1.0}}],
        'overlays': [{'id': 'p1', 'role': 'page', 'reference_audio_range': {'start': 0.0, 'end': 1.0}, 'reference_audio_text': '文本', 'audio_semantic_match': True}],
    }, 'a.wav'),
}, sort_keys=True))
"""
        result = subprocess.run([sys.executable, "-c", code], cwd=scripts, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(0, result.returncode, result.stderr)
        return json.loads(result.stdout)

    def test_shared_production_gates_match_curve_skill(self):
        info_scripts = Path(__file__).resolve().parents[1] / "scripts"
        curve_scripts = info_scripts.parents[1] / "1QuXian" / "scripts"
        self.assertEqual(self.snapshot(curve_scripts), self.snapshot(info_scripts))


if __name__ == "__main__":
    unittest.main()
