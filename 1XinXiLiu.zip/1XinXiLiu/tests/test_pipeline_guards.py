#!/usr/bin/env python3
"""Contract checks for the production timeline gates."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from unittest import mock
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, ImageChops

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from preflight import run_preflight
from fast_pipeline import ExternalBlockError, OFFICIAL_OUTPUT_DIR, _load_shared_visual_index, _run, initialize, main, omit_timed_out_news, renderer_script, research, write_failure_status, write_success_status
from delivery_gate import failure_details
from make_visual_approval import CHECKS, make_approval
from render_continuous_timeline import build_ffmpeg_command, enforce_render_policy, select_encoder_with_probe
from review_render import duration_matches, main as review_main
from render_segmented_timeline import split_timeline
from validate_timeline import validate
from export_asset_ledger import make_ledger
from prepare_timeline_assets import prepare
from render_overlay_templates import render_overlay
from reference_page_renderer import PAGE_SIZE, render_page
from render_continuous_timeline import audio_codec_args
from workflow_metrics import DEFAULT_BUDGETS, start_run, start_stage


def timeline(duration: float = 8.0) -> dict:
    assets = []
    shots = []
    for index in range(2):
        asset_id = f"a{index}"
        assets.append({
            "id": asset_id, "local_path": f"asset-{index}.mp4", "sha256": str(index) * 64,
            "status": "unused", "use_count": 0, "delivered_at": None, "last_used_at": None,
            "seven_day_eligible": True, "dedupe_clear": True,
            "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
            "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
            "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
        })
        shots.append({
            "id": f"s{index}", "start": index * 4.0, "end": (index + 1) * 4.0,
            "source_in": 0.0, "source_out": 4.0, "keyword": "行情",
            "subject": "市场", "action": "变化", "result": "形成信号",
            "asset_id": asset_id, "selection_mode": "semantic_index",
            "script_semantics": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "semantic_fields": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "theme_mapping": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "information_task": "data",
            "script_range": {"start": index * 4.0, "end": (index + 1) * 4.0},
            "chapter_id": "c01",
            "selection_reason": "主体、动作、地点、设备与当前文案匹配",
            "candidate_asset_ids": [asset_id],
        })
    return {
        "script_path": "script.md",
        "duration_seconds": duration, "audio_path": None, "audio_delivery_mode": "silent", "assets": assets, "shots": shots,
        "chapters": [{
            "id": "c01", "start": 0.0, "end": duration, "thesis": "市场信号",
        }],
        "dedupe_audit": {"lookback_hours": 168, "checked_at": datetime.now(timezone.utc).isoformat()},
        "overlays": [
            {
                "id": "hook", "type": "hook", "role": "hook", "start": 0.0, "end": 4.0,
                "chapter_id": "c01", "script_range": {"start": 0.0, "end": 4.0},
                "background_shot_id": "s0", "image_path": "hook.png", "frame_pattern": "hook/%04d.png",
                "chinese_text": "市场信号", "hook_color_fallback": "white",
                "hook_text_colors": {line: {"color": "#FFFFFF", "opacity": 1.0} for line in ("thesis", "judgment", "evidence")},
                "hook_contrast": {line: {"background_luminance": 0.02, "contrast_ratio": 17.5} for line in ("thesis", "judgment", "evidence")},
            },
            {
                "id": "info", "type": "data", "start": 4.0, "end": 8.0,
                "chapter_id": "c01", "information_task": "data", "script_range": {"start": 4.0, "end": 8.0},
                "background_shot_id": "s1", "image_path": "info.png", "chinese_text": "资金正在进场",
                "content_blocks": ["机构减空", "现货流入"],
                "left_series": [3500, 3600, 3700], "right_series": [-30000, 0, 30000],
            },
        ],
    }


class TimelineGuardTests(unittest.TestCase):
    def test_renderer_icons_are_deterministic(self):
        for config in (
            {"type": "fact", "content_blocks": ["多头增加", "空头回落"]},
            {"type": "causal", "content_blocks": ["机构增多", "净多头上升", "指数挑战3960"]},
        ):
            self.assertEqual(hashlib.sha256(render_page(config).tobytes()).digest(), hashlib.sha256(render_page(config).tobytes()).digest())

    def test_data_page_rejects_invented_series(self):
        with self.assertRaisesRegex(ValueError, "left_series and right_series"):
            render_page({"type": "data"})

    def test_comparison_does_not_require_bull_bear_without_explicit_theme(self):
        page = render_page({"type": "comparison", "left_label": "方案一", "left_value": "62%", "right_label": "方案二", "right_value": "38%", "conclusion": "方案一占优"})
        self.assertEqual(PAGE_SIZE, page.size)

    def test_information_pages_keep_approved_macro_scale(self):
        expected_bounds = {"fact": (22, 31, 1058, 799), "data": (22, 54, 1058, 776), "number": (22, 28, 1058, 801), "causal": (22, 29, 1058, 800), "comparison": (22, 104, 1058, 726)}
        configs = (
            {"type": "fact", "content_blocks": ["多头增加", "空头回落"]},
            {"type": "data", "content_blocks": ["指数", "净多头"], "left_series": [3500, 3600], "right_series": [-30000, 0]},
            {"type": "number", "primary_value": "3960"},
            {"type": "causal", "content_blocks": ["机构增多", "净多头上升", "指数挑战"]},
            {"type": "comparison", "left_value": "62%", "right_value": "38%", "conclusion": "方案一占优"},
        )
        for config in configs:
            bbox = render_page(config).getchannel("A").getbbox()
            self.assertEqual(expected_bounds[config["type"]], bbox)

    def test_command_wraps_content_in_reference_vertical_layout(self):
        data = {"duration_seconds": 1.0, "chrome_path": "chrome.png", "assets": [{"id": "a", "local_path": "source.mp4"}], "shots": [{"id": "s", "asset_id": "a", "start": 0.0, "end": 1.0, "source_in": 0.0}], "overlays": []}
        command = build_ffmpeg_command(data, "output.mp4", "final", "ffmpeg", "libx264")
        graph = command[command.index("-filter_complex") + 1]
        self.assertIn("scale=1080:1920", graph)
        self.assertIn("scale=1080:830", graph)
        self.assertIn("overlay=0:604", graph)
        self.assertIn("setsar=1", graph)

    def test_information_page_preserves_video_backdrop_and_one_global_disclaimer(self):
        data = {"duration_seconds": 1.0, "chrome_path": "chrome.png", "assets": [{"id": "a", "local_path": "source.mp4"}], "shots": [{"id": "s", "asset_id": "a", "start": 0.0, "end": 1.0, "source_in": 0.0}], "overlays": [{"type": "data", "image_path": "page.png", "start": 0.0, "end": 1.0}]}
        command = build_ffmpeg_command(data, "output.mp4", "final", "ffmpeg", "libx264")
        graph = command[command.index("-filter_complex") + 1]
        self.assertIn("[base]split=2[bgsrc][centersrc]", graph)
        self.assertIn("[center][img0]overlay=0:0", graph)
        self.assertIn("[blurred][ov0]overlay=0:604[vertical]", graph)
        self.assertNotIn("pagebg0", graph)
        self.assertEqual(1, graph.count("[chrome]overlay=0:0"))

    def test_shared_index_requires_the_declared_contract(self):
        with tempfile.TemporaryDirectory() as folder:
            valid = Path(folder) / "valid_index.py"
            valid.write_text("SEMANTIC_INDEX_API_VERSION = 1\ndef search_many(*args, **kwargs): return {}\n", encoding="utf-8")
            self.assertTrue(callable(_load_shared_visual_index(valid)))
            invalid = Path(folder) / "invalid_index.py"
            invalid.write_text("def search_many(*args, **kwargs): return {}\n", encoding="utf-8")
            with self.assertRaisesRegex(ImportError, "contract mismatch"):
                _load_shared_visual_index(invalid)

    def test_init_writes_in_progress_status_without_completing_metrics(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            script = root / "2026-08-12_文档_测试文案.md"
            script.write_text("第一句。第二句。", encoding="utf-8")
            result = initialize(script, root, duration=8.0, date_text="2026-08-12")
            status = __import__("json").loads(Path(result["status_path"]).read_text(encoding="utf-8"))
            metrics = __import__("json").loads(Path(result["metrics_path"]).read_text(encoding="utf-8"))
            timelines = list(root.glob("*_时间轴.json"))
            self.assertEqual("2026-08-12_文档_测试文案_执行状态.json", Path(result["status_path"]).name)
            self.assertEqual("2026-08-12_文档_测试文案_端到端耗时.json", Path(result["metrics_path"]).name)
        self.assertEqual("in_progress", status["state"])
        self.assertFalse(status["terminal_allowed"])
        self.assertNotIn("completed", metrics)
        self.assertFalse(timelines)

    def test_successful_stage_updates_and_clears_shared_status(self):
        with tempfile.TemporaryDirectory() as folder:
            status = Path(folder) / "status.json"
            status.write_text(json.dumps({"state": "in_progress", "terminal_allowed": False, "gate_errors": ["old"]}), encoding="utf-8")
            write_success_status(status, "first_review_ready")
            payload = json.loads(status.read_text(encoding="utf-8"))
        self.assertEqual("first_review_ready", payload["current_stage"])
        self.assertNotIn("gate_errors", payload)

    def test_external_failure_report_is_actionable(self):
        failure = failure_details(["ffprobe is required"])
        self.assertEqual("in_progress", failure["state"])
        self.assertTrue(failure["next_actions"])

    def test_pipeline_external_failure_updates_shared_status(self):
        with tempfile.TemporaryDirectory() as folder:
            status = Path(folder) / "status.json"
            write_failure_status(status, FileNotFoundError("visual index unavailable"), "research")
            payload = json.loads(status.read_text(encoding="utf-8"))
        self.assertEqual("in_progress", payload["state"])
        self.assertEqual("research_failed", payload["current_stage"])

    def test_internal_contract_failure_is_not_mislabeled_external(self):
        with tempfile.TemporaryDirectory() as folder:
            status = Path(folder) / "status.json"
            write_failure_status(status, RuntimeError("timeline contract is invalid"), "finalize")
            payload = json.loads(status.read_text(encoding="utf-8"))
        self.assertEqual("in_progress", payload["state"])
        self.assertEqual("finalize", payload["blocking_domain"])

    def test_child_missing_dependency_becomes_typed_external_failure(self):
        result = mock.Mock(returncode=1, stdout="", stderr="FileNotFoundError: ffmpeg not found")
        with mock.patch("fast_pipeline.subprocess.run", return_value=result), self.assertRaises(ExternalBlockError):
            _run("render_continuous_timeline.py", [])

    def test_news_registry_is_rejected(self):
        data = timeline()
        data["news"] = []
        self.assertTrue(any("news[] is forbidden" in error for error in validate(data)))

    def test_news_overlay_requires_direct_screenshot_path(self):
        data = timeline()
        data["overlays"][1]["type"] = "news"
        data["overlays"][1]["information_task"] = "news"
        self.assertTrue(any("screenshot_path is required" in error for error in validate(data)))

    def test_news_timeout_omits_only_the_missing_page(self):
        data = timeline()
        data["overlays"][1].update({"type": "news", "information_task": "news"})
        original_shots = json.loads(json.dumps(data["shots"]))
        with tempfile.TemporaryDirectory() as folder:
            metrics = Path(folder) / "metrics.json"
            start_run(metrics, 8.0, now=0.0)
            start_stage(metrics, "news", now=10.0)
            with self.assertRaisesRegex(ValueError, "continue retrieval until 300s"):
                omit_timed_out_news(data, metrics, now=309.999)
            normalized, skipped = omit_timed_out_news(data, metrics, now=310.0)
        self.assertEqual(["info"], skipped)
        self.assertEqual(["hook"], [item["id"] for item in normalized["overlays"]])
        self.assertEqual(original_shots, normalized["shots"])
        self.assertEqual(2, len(data["overlays"]))

    def test_missing_news_timer_cannot_bypass_the_budget(self):
        data = timeline()
        data["overlays"][1].update({"type": "news", "information_task": "news"})
        with tempfile.TemporaryDirectory() as folder:
            metrics = Path(folder) / "metrics.json"
            start_run(metrics, 8.0, now=0.0)
            with self.assertRaisesRegex(ValueError, "start the news timer"):
                omit_timed_out_news(data, metrics, now=500.0)

    def test_visual_approval_requires_per_shot_review(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            video, contact, timeline_path = root / "video.mp4", root / "contact.jpg", root / "timeline.json"
            video.write_bytes(b"video")
            contact.write_bytes(b"contact")
            notes = root / "notes.json"
            timeline_path.write_text(json.dumps({"shots": [{"id": "s01"}]}), encoding="utf-8")
            base = {"contact_sheet_sha256": hashlib.sha256(contact.read_bytes()).hexdigest(), "checks": {name: True for name in CHECKS}}
            notes.write_text(json.dumps({**base, "shots": {}}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "cover exactly every timeline shot"):
                make_approval(video, timeline_path, contact, notes)
            observations = {"s01": {"visible_subject": "晶圆", "visible_action": "搬运", "visible_location": "洁净室", "visible_equipment": "机械臂", "semantic_match": True, "evidence_frames": ["s01-A", "s01-M", "s01-B"]}}
            notes.write_text(json.dumps({**base, "shots": observations}), encoding="utf-8")
            approval = make_approval(video, timeline_path, contact, notes)
        self.assertEqual(observations, approval["shot_checks"])

    def test_malformed_visual_approval_still_writes_review_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            video = root / "video.mp4"
            timeline_path = root / "timeline.json"
            contact = root / "contact.jpg"
            approval = root / "approval.json"
            report = root / "report.json"
            video.write_bytes(b"video")
            contact.write_bytes(b"contact")
            timeline_path.write_text(json.dumps({"duration_seconds": 1.0, "shots": []}), encoding="utf-8")
            approval.write_text("{bad json", encoding="utf-8")
            argv = ["review_render.py", "--video", str(video), "--timeline", str(timeline_path), "--report", str(report), "--contact-sheet", str(contact), "--visual-approval", str(approval)]
            probe_result = {"format": {"duration": 1.0}, "streams": [{"codec_type": "video"}]}
            decode_result = mock.Mock(returncode=0, stderr="")
            with mock.patch("sys.argv", argv), mock.patch("review_render.probe", return_value=probe_result), mock.patch("review_render.find_ffmpeg", return_value="ffmpeg"), mock.patch("review_render.subprocess.run", return_value=decode_result):
                code = review_main()
            payload = json.loads(report.read_text(encoding="utf-8"))
        self.assertEqual(2, code)
        self.assertTrue(any("visual approval could not be read" in error for error in payload["errors"]))

    def test_encoder_fallback_is_probed_before_selection(self):
        attempts = []

        def probe(encoder):
            attempts.append(encoder)
            return encoder == "libx264"

        selected = select_encoder_with_probe("h264_nvenc", probe)
        self.assertEqual("libx264", selected)
        self.assertEqual(["h264_nvenc", "libx264"], attempts)

    def test_software_encoder_failure_stops_render(self):
        with self.assertRaisesRegex(RuntimeError, "probe failed"):
            select_encoder_with_probe("libx264", lambda _encoder: False)

    def test_preparation_preserves_valid_white_hook_contrast(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            prepared = prepare(data, Path(folder), size=(320, 180))
            pattern = prepared["overlays"][0]["frame_pattern"]
            first, complete = Path(pattern % 0), Path(pattern % 30)
            self.assertTrue(first.is_file() and complete.is_file())
            self.assertNotEqual(hashlib.sha256(first.read_bytes()).digest(), hashlib.sha256(complete.read_bytes()).digest())
        hook = prepared["overlays"][0]
        self.assertEqual("white", hook["hook_color_fallback"])
        self.assertTrue(all(hook["hook_contrast"][line]["contrast_ratio"] >= 4.5 for line in ("thesis", "judgment", "evidence")))
        manifest = json.loads((Path(__file__).resolve().parents[1] / "references" / "七类信息页固定标准.json").read_text(encoding="utf-8"))
        self.assertEqual(Path(manifest["templates"]["hook"]["file"]).name, hook["reference_template"])
        self.assertEqual(Path(manifest["templates"]["data"]["file"]).name, prepared["overlays"][1]["reference_template"])

    def test_preparation_rejects_conflicting_reference_template(self):
        data = timeline()
        data["overlays"][1]["reference_template"] = "wrong.png"
        with tempfile.TemporaryDirectory() as folder, self.assertRaisesRegex(ValueError, "reference_template must be"):
            prepare(data, Path(folder), size=(320, 180))

    def test_all_self_authored_information_types_keep_their_own_contracts(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            configs = {
                "hook": {"type": "hook", "thesis": "市场信号", "chinese_text": "结构改善"},
                "fact": {"type": "fact", "content_blocks": ["多头增加", "空头回落"], "conclusion": "资金偏多"},
                "data": {"type": "data", "content_blocks": ["多头增仓", "净多头"], "left_series": [3500, 3600, 3700], "right_series": [-30000, 0, 30000]},
                "number": {"type": "number", "primary_value": "3960", "unit": "点", "conclusion": "观察成交量"},
                "comparison": {"type": "comparison", "left_label": "多头", "left_value": "+1.8万手", "right_label": "空头", "right_value": "-0.6万手", "conclusion": "多头占优"},
                "causal": {"type": "causal", "content_blocks": ["机构增多", "净多上升", "挑战压力"], "conclusion": "动能增强"},
            }
            for kind, config in configs.items():
                output = render_overlay(config, root, size=(1920, 1080))
                self.assertTrue(output.is_file(), kind)
                self.assertGreater(output.stat().st_size, 500, kind)
                if kind != "hook":
                    with Image.open(output) as page:
                        alpha = page.convert("RGBA").getchannel("A")
                        self.assertIsNone(alpha.crop((0, 0, 32, page.height)).getbbox(), f"{kind} crossed the left safe area")
                        self.assertIsNone(alpha.crop((page.width - 32, 0, page.width, page.height)).getbbox(), f"{kind} crossed the right safe area")
            with self.assertRaisesRegex(ValueError, "screenshot_path"):
                render_overlay({"type": "news"}, root, size=(640, 360))
            screenshot = root / "news.png"
            original = Image.new("RGBA", (640, 360), (23, 47, 89, 255)); original.save(screenshot)
            with Image.open(render_overlay({"type": "news", "screenshot_path": str(screenshot)}, root, size=(640, 360))) as rendered:
                self.assertIsNone(ImageChops.difference(original, rendered.convert("RGBA")).getbbox())

    def test_pcm_audio_falls_back_to_aac_for_mp4(self):
        with mock.patch("render_continuous_timeline.subprocess.run") as run:
            run.return_value.returncode = 0
            run.return_value.stdout = "pcm_s16le\n"
            self.assertEqual(["-c:a", "aac", "-b:a", "192k"], audio_codec_args("voice.wav", "ffmpeg"))

    def test_seamless_information_pages_are_allowed(self):
        self.assertFalse(validate(timeline()))

    def test_duplicate_information_text_is_rejected(self):
        data = timeline()
        data["overlays"][1]["chinese_text"] = data["overlays"][0]["chinese_text"]
        self.assertTrue(any("duplicate information content" in error for error in validate(data)))

    def test_legitimate_copy_is_not_rejected_for_generic_words(self):
        data = timeline()
        data["overlays"][1]["chinese_text"] = "演示模板正在更新"
        self.assertFalse(validate(data))

    def test_hook_requires_dynamic_frame_pattern(self):
        data = timeline()
        del data["overlays"][0]["frame_pattern"]
        self.assertTrue(any("frame_pattern" in error for error in validate(data)))

    def test_missing_seven_day_audit_is_rejected(self):
        data = timeline()
        del data["dedupe_audit"]
        self.assertTrue(any("seven-day dedupe audit" in error for error in validate(data)))

    def test_unclean_asset_is_rejected(self):
        data = timeline()
        data["assets"][0]["embedded_subtitles_free"] = False
        self.assertTrue(any("visual cleanliness gate" in error for error in validate(data)))

    def test_planning_fields_are_required(self):
        for field in ("script_semantics", "semantic_fields", "theme_mapping", "information_task", "script_range", "chapter_id", "selection_reason"):
            data = timeline()
            del data["shots"][0][field]
            self.assertTrue(any(field in error for error in validate(data)), field)

    def test_semantic_mirrors_must_match_all_five_fields(self):
        data = timeline()
        data["shots"][0]["theme_mapping"]["keywords"] = "不一致关键词"
        self.assertTrue(any("semantic mirrors disagree on keywords" in error for error in validate(data)))

    def test_fact_information_page_is_allowed(self):
        data = timeline()
        data["overlays"][1]["type"] = "fact"
        data["overlays"][1]["information_task"] = "fact"
        self.assertFalse(validate(data))

    def test_white_hook_fallback_still_requires_measured_contrast(self):
        data = timeline()
        del data["overlays"][0]["hook_contrast"]
        self.assertTrue(any("white fallback" in error for error in validate(data)))

    def test_information_page_range_cannot_cross_chapters(self):
        data = timeline()
        data["chapters"].append({
            "id": "c02", "start": 8.0, "end": 9.0, "thesis": "第二章",
        })
        data["overlays"][1]["chapter_id"] = "c02"
        self.assertTrue(any("script_range must stay within chapter" in error for error in validate(data)))

    def test_long_broll_run_is_allowed_when_each_cut_is_2_to_5_seconds(self):
        data = timeline(12.0)
        data["shots"] = []
        data["assets"] = []
        for index in range(3):
            asset_id = f"b{index}"
            data["assets"].append({
                "id": asset_id, "local_path": f"{asset_id}.mp4", "sha256": str(index + 3) * 64,
                "status": "unused", "use_count": 0, "delivered_at": None, "last_used_at": None,
                "seven_day_eligible": True, "dedupe_clear": True,
                "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
                "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
                "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
            })
            data["shots"].append({
                "id": f"b{index}", "start": index * 4.0, "end": (index + 1) * 4.0, "source_in": 0.0, "source_out": 4.0,
                "keyword": "市场", "subject": "交易员", "action": "观察", "result": "形成信号", "asset_id": asset_id,
                "selection_mode": "semantic_index", "script_semantics": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "semantic_fields": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "theme_mapping": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "information_task": "broll", "script_range": {"start": index * 4.0, "end": (index + 1) * 4.0}, "chapter_id": "c01",
                "selection_reason": "当前章节的交易员观察行情实拍", "candidate_asset_ids": [asset_id],
            })
        data["overlays"][0]["background_shot_id"] = "b0"
        data["overlays"][1]["background_shot_id"] = "b1"
        self.assertFalse(validate(data))

    def test_broll_cut_shorter_than_two_seconds_is_rejected(self):
        data = timeline()
        data["shots"][0]["information_task"] = "broll"
        data["shots"][0]["end"] = 1.5
        data["shots"][0]["source_out"] = 1.5
        data["shots"][1]["start"] = 1.5
        self.assertTrue(any("broll duration" in error for error in validate(data)))

    def test_false_global_eligibility_credential_is_rejected(self):
        data = timeline()
        asset = data["assets"][1]
        asset["seven_day_eligible"] = False
        self.assertTrue(any("seven-day dedupe status" in error for error in validate(data)))

    def test_historical_delivered_hash_is_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            ledger = root / "2026-08-06_文档_旧片_asset-ledger.json"
            ledger.write_text('{"assets":[{"sha256":"' + "0" * 64 + '"}]}', encoding="utf-8")
            import hashlib, json
            gate = {
                "terminal_allowed": True,
                "checked_at": datetime.now(timezone.utc).isoformat(),
                "sha256": {"ledger": hashlib.sha256(ledger.read_bytes()).hexdigest()},
            }
            (root / "2026-08-06_文档_旧片_交付门禁.json").write_text(json.dumps(gate), encoding="utf-8")
            errors = run_preflight(data, require_files=False, history_root=root)
        self.assertTrue(any("material identity was used" in error for error in errors))

    def test_page_template_reference_assets_are_hash_bound(self):
        from preflight import verify_page_template_assets
        manifest = json.loads((Path(__file__).resolve().parents[1] / "references" / "七类信息页固定标准.json").read_text(encoding="utf-8"))
        self.assertEqual(2, manifest["schema_version"])
        for item in manifest["templates"].values():
            self.assertEqual({"file", "sha256", "width", "height", "role"}, set(item))
        self.assertEqual([], verify_page_template_assets())

    def test_duplicate_overlay_files_are_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            duplicate = Path(folder) / "same.png"
            duplicate.write_bytes(b"same")
            data["overlays"][0]["image_path"] = str(duplicate)
            data["overlays"][1]["image_path"] = str(duplicate)
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("duplicate information image" in error for error in errors))

    def test_selected_asset_must_come_from_research_candidates(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            manifest = Path(folder) / "research.json"
            manifest.write_text(
                json.dumps({"source": "fast_pipeline research", "eligible_visual_candidates": {"queries": []}}),
                encoding="utf-8",
            )
            data["selection_manifest_path"] = str(manifest)
            data["selection_manifest_sha256"] = hashlib.sha256(manifest.read_bytes()).hexdigest()
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("missing selected candidate" in error for error in errors))

    def test_research_candidate_requires_matching_fresh_full_hash(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            manifest = Path(folder) / "research.json"
            candidates = [
                {
                    "asset_id": item["id"], "local_path": item["local_path"], "sha256": item["sha256"],
                    "seven_day_eligible": True, "frame_evidence": f"{item['id']}.jpg", "source_in": 0.0, "source_out": 4.0,
                }
                for item in data["assets"]
            ]
            candidates[0]["seven_day_eligible"] = False
            manifest.write_text(json.dumps({"source": "fast_pipeline research", "eligible_visual_candidates": {"queries": [{"candidates": candidates}]}}), encoding="utf-8")
            data["selection_manifest_path"] = str(manifest)
            data["selection_manifest_sha256"] = hashlib.sha256(manifest.read_bytes()).hexdigest()
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("not seven-day eligible" in error for error in errors))

    def test_research_records_full_hash_and_excludes_delivered_asset(self):
        with tempfile.TemporaryDirectory() as folder:
            fresh = Path(folder) / "fresh.mp4"
            stale = Path(folder) / "stale.mp4"
            fresh.write_bytes(b"fresh")
            stale.write_bytes(b"stale")
            result = {"model_id": "test", "queries": [{"query": "测试", "candidates": [
                {"asset_id": "fresh", "path": str(fresh), "provenance_complete": True},
                {"asset_id": "stale", "path": str(stale), "provenance_complete": True},
            ]}]}
            filtered = [{**result["queries"][0]["candidates"][0], "sha256": hashlib.sha256(b"fresh").hexdigest(), "seven_day_eligible": True}]
            prepared = [{**filtered[0], "prepared_visual": True, "preview_cache_hit": False, "review_clip_path": str(Path(folder) / "preview.mp4"), "review_frames": [{"label": label, "path": str(Path(folder) / f"{label}.jpg")} for label in "AMB"]}]
            with mock.patch("fast_pipeline.search_many", return_value=result) as search, mock.patch("fast_pipeline.filter_candidate_groups", return_value=[filtered]) as gate, mock.patch("fast_pipeline.prepare_candidate_previews", return_value=prepared) as previews:
                report = research(Path(folder), ["测试"], 2, 5.0, "cpu", Path(folder), categories=["股市与市场"], review_dir=Path(folder), rejected_asset_ids={"rejected"})
            gate.assert_called_once()
            previews.assert_called_once_with(filtered, Path(folder))
            self.assertEqual(["股市与市场"], search.call_args.kwargs["categories"])
            self.assertEqual({"rejected"}, gate.call_args.kwargs["rejected_asset_ids"])
        candidates = report["eligible_visual_candidates"]["queries"][0]["candidates"]
        self.assertEqual(["fresh"], [item["asset_id"] for item in candidates])
        self.assertEqual(hashlib.sha256(b"fresh").hexdigest(), candidates[0]["sha256"])
        self.assertTrue(candidates[0]["prepared_visual"])

    def test_research_cli_defaults_to_the_project_preview_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            project, output, status = Path(folder), Path(folder) / "research.json", Path(folder) / "status.json"
            status.write_text("{}", encoding="utf-8")
            argv = ["fast_pipeline.py", "research", "--query", "测试", "--current-project", str(project), "--output", str(output), "--status", str(status)]
            with mock.patch("sys.argv", argv), mock.patch("fast_pipeline.research", return_value={"queries": []}) as run, mock.patch("fast_pipeline.write_success_status"):
                self.assertEqual(0, main())
            self.assertEqual(project / "候选预览", run.call_args.args[8])

    def test_approval_final_review_has_a_budget(self):
        self.assertIn("approval_final_review", DEFAULT_BUDGETS)

    def test_continuous_renderer_rejects_long_timeline(self):
        data = timeline(120.0)
        data["shots"][-1]["end"] = 120.0
        with self.assertRaisesRegex(ValueError, "segmented"):
            build_ffmpeg_command(data, "out.mp4", ffmpeg="ffmpeg")

    def test_renderer_requests_exact_frame_count(self):
        command = build_ffmpeg_command(timeline(), "out.mp4", ffmpeg="ffmpeg")
        frames_index = command.index("-frames:v")
        self.assertEqual(command[frames_index + 1], "240")

    def test_duration_tolerance_is_two_frames(self):
        self.assertTrue(duration_matches(120.0, 120.06))
        self.assertFalse(duration_matches(120.0, 120.07))

    def test_formal_entry_selects_segmented_renderer_for_long_timeline(self):
        self.assertEqual(renderer_script(timeline(120.0)), "render_segmented_timeline.py")
        self.assertEqual(renderer_script(timeline()), "render_continuous_timeline.py")

    def test_renderer_cannot_write_official_output_even_with_forged_permit(self):
        with self.assertRaisesRegex(ValueError, "only fast_pipeline finalize"):
            enforce_render_policy(
                timeline(),
                OFFICIAL_OUTPUT_DIR / "forged.mp4",
                "final",
                "forged-permit.json",
            )

    def test_asset_ledger_keeps_semantics_and_direct_page_bindings(self):
        data = timeline()
        data["shots"][0]["overlay_id"] = "hook"
        data["shots"][1]["overlay_id"] = "info"
        ledger = make_ledger(data)
        first, second = ledger["uses"]
        for item in (first, second):
            self.assertIn("chapter_id", item)
            self.assertIn("script_semantics", item)
            self.assertIn("information_task", item)
            self.assertIn("script_range", item)
            self.assertIn("overlay_ids", item)

    def test_segmenter_preserves_all_shots_without_large_segments(self):
        data = timeline(100.0)
        data["shots"] = []
        data["assets"] = []
        data["overlays"] = []
        for index in range(20):
            data["shots"].append({"id": f"s{index}", "start": index * 5.0, "end": (index + 1) * 5.0, "asset_id": f"a{index}"})
            data["assets"].append({"id": f"a{index}", "local_path": f"a{index}.mp4"})
        segments = split_timeline(data)
        self.assertEqual(sum(len(item["shots"]) for item in segments), 20)
        self.assertTrue(all(len(item["shots"]) <= 5 and item["duration_seconds"] <= 25.0 for item in segments))


if __name__ == "__main__":
    unittest.main()
