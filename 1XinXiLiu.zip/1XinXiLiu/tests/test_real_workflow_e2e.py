import hashlib
import json
import os
import shutil
import subprocess
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "scripts" / "fast_pipeline.py"
RUN_E2E = os.environ.get("RUN_REAL_E2E") == "1"
WORK_ROOT = Path(os.environ.get("INFOFLOW_E2E_ROOT", r"C:\Users\28723\Documents\New project\2026-08-12_工程_1XinXiLiu真实端到端复核"))
VIDEO_ROOT = Path(r"C:\Users\28723\Videos\Codex")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_json(*args: str) -> dict:
    result = subprocess.run([sys.executable, str(PIPELINE), *args], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.returncode:
        raise AssertionError(result.stdout + "\n" + result.stderr)
    return json.loads(result.stdout)


@unittest.skipUnless(RUN_E2E, "set RUN_REAL_E2E=1 to render real short and segmented MP4 workflows")
class RealWorkflowE2ETests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            raise unittest.SkipTest("ffmpeg and ffprobe are required")
        WORK_ROOT.mkdir(parents=True, exist_ok=True)

    def build_fixture(self, name: str, shot_count: int, narration: bool = False) -> dict:
        project = WORK_ROOT / name
        assets_dir = project / "assets"
        overlays_dir = project / "overlays" / "hook"
        assets_dir.mkdir(parents=True, exist_ok=True)
        overlays_dir.mkdir(parents=True, exist_ok=True)
        script = project / f"2026-08-12_文档_{name}_文案.md"
        script.write_text("工作流真实视频端到端复核。", encoding="utf-8")
        initialized = run_json("init", "--script", str(script), "--duration", str(shot_count * 5), "--title", name, "--output-dir", str(project))

        assets, shots = [], []
        checked_at = datetime.now(timezone.utc).isoformat()
        for index in range(shot_count):
            asset_id = f"asset-{index + 1:02d}"
            path = assets_dir / f"2026-08-12_视频_{name}_动态测试素材_{index + 1:02d}.mp4"
            subprocess.run([
                "ffmpeg", "-y", "-f", "lavfi", "-i", f"testsrc2=size=640x360:rate=30:duration=5,hue=h={index * 8}",
                "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(path),
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            semantic = {"subject": "动态测试画面", "action": "连续运动", "location": "测试环境", "equipment": "视频编码器", "keywords": "工作流 真实视频 复核"}
            assets.append({
                "id": asset_id, "local_path": str(path), "sha256": sha256(path), "status": "unused", "use_count": 0,
                "delivered_at": None, "last_used_at": None, "dedupe_clear": True, "dedupe_checked_at": checked_at,
                "seven_day_eligible": True, "watermark_free": True, "embedded_subtitles_free": True,
                "platform_overlay_free": True, "cleanliness_checked_at": checked_at,
                "cleanliness_evidence": "generated moving integration-test source is visually clean",
            })
            start, end = index * 5.0, (index + 1) * 5.0
            shots.append({
                "id": f"s{index + 1:02d}", "chapter_id": "c01", "start": start, "end": end,
                "source_in": 0.0, "source_out": 5.0, "keyword": "工作流复核", "subject": "动态测试画面",
                "action": "连续运动", "result": "验证真实渲染链路", "asset_id": asset_id,
                "selection_mode": "semantic_index", "script_semantics": semantic, "semantic_fields": semantic,
                "theme_mapping": semantic, "information_task": "broll", "script_range": {"start": start, "end": end},
                "selection_reason": "真实 MP4 集成测试镜头覆盖连续运动、编码和拼接", "candidate_asset_ids": [asset_id],
            })

        from PIL import Image, ImageDraw
        for frame in range(31):
            image = Image.new("RGBA", (1920, 1080), (0, 0, 0, 0))
            ImageDraw.Draw(image).rectangle((160, 390, 160 + frame * 30, 610), fill=(255, 255, 255, 210))
            image.save(overlays_dir / f"{frame:04d}.png")

        manifest = project / f"2026-08-12_文档_{name}_选片凭据.json"
        manifest.write_text(json.dumps({"source": "fast_pipeline research", "eligible_visual_candidates": []}, ensure_ascii=False), encoding="utf-8")
        duration = shot_count * 5.0
        timeline = project / f"2026-08-12_文档_{name}_时间轴.json"
        audio_path = None
        if narration:
            audio_path = project / f"2026-08-12_音频_{name}_旁白测试.wav"
            subprocess.run([
                "ffmpeg", "-y", "-f", "lavfi", "-i", f"sine=frequency=440:sample_rate=48000:duration={duration}",
                "-c:a", "pcm_s16le", str(audio_path),
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        payload = {
            "title": name, "script_path": str(script), "duration_seconds": duration, "audio_path": str(audio_path) if audio_path else None,
            "main_thesis": "真实工作流可以完成闭环", "main_evidence_id": "evidence-c01", "evidence_kind": "judgment",
            "selection_manifest_path": str(manifest), "selection_manifest_sha256": sha256(manifest),
            "dedupe_audit": {"lookback_hours": 168, "checked_at": checked_at},
            "chapters": [{"id": "c01", "start": 0.0, "end": duration, "thesis": "真实渲染链路复核", "information_plan": [{"id": "evidence-c01", "task": "broll", "reason": "技术集成测试只验证真实视频管线", "script_range": {"start": 0.0, "end": duration}}]}],
            "shots": shots, "assets": assets, "news": [],
            "overlays": [{
                "id": "hook", "type": "hook", "role": "hook", "chapter_id": "c01", "evidence_id": "evidence-c01",
                "start": 0.0, "end": 4.0, "chinese_text": "真实工作流闭环复核", "background_shot_id": "s01",
                "image_path": str(overlays_dir / "0000.png"), "frame_pattern": str(overlays_dir / "%04d.png"),
                "hook_color_fallback": "white",
                "hook_text_colors": {line: {"color": "#FFFFFF", "opacity": 1.0} for line in ("thesis", "judgment", "evidence")},
                "hook_contrast": {line: {"background_luminance": 0.02, "contrast_ratio": 17.5} for line in ("thesis", "judgment", "evidence")},
            }],
        }
        timeline.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        asset_index = project / f"2026-08-12_文档_{name}_素材索引.json"
        asset_index.write_text(json.dumps({"assets": [{"path": item["local_path"], "duration": 5.0} for item in assets]}, ensure_ascii=False), encoding="utf-8")
        return {"project": project, "timeline": timeline, "asset_index": asset_index, **initialized}

    def run_workflow(self, name: str, shot_count: int, narration: bool = False) -> None:
        fixture = self.build_fixture(name, shot_count, narration)
        output = VIDEO_ROOT / f"2026-08-12_视频_{name}.mp4"
        finalized = run_json(
            "finalize", "--timeline", str(fixture["timeline"]), "--asset-index", str(fixture["asset_index"]),
            "--overlay-dir", str(fixture["project"] / "rendered-overlays"), "--output-video", str(output),
            "--project-dir", str(fixture["project"]), "--metrics", str(fixture["metrics_path"]),
        )
        approval = fixture["project"] / f"2026-08-12_文档_{name}_视觉批准.json"
        final_review = fixture["project"] / f"2026-08-12_文档_{name}_最终复审.json"
        run_json(
            "approve", "--video", str(output), "--timeline", finalized["prepared_timeline"],
            "--contact-sheet", finalized["contact_sheet"], "--approval", str(approval),
            "--final-report", str(final_review), "--metrics", str(fixture["metrics_path"]),
        )
        gate = fixture["project"] / f"2026-08-12_文档_{name}_终态门禁.json"
        delivered = run_json(
            "deliver", "--video", str(output), "--timeline", finalized["prepared_timeline"],
            "--preflight", finalized["preflight_report"], "--ledger", finalized["asset_ledger"],
            "--final-review", str(final_review), "--status", str(fixture["status_path"]),
            "--gate-report", str(gate), "--metrics", str(fixture["metrics_path"]),
        )
        self.assertTrue(delivered["terminal_allowed"])
        probe = json.loads(Path(finalized["encoder_probe_report"]).read_text(encoding="utf-8"))
        self.assertTrue(probe["attempts"] and probe["attempts"][-1]["ok"])
        metrics = json.loads(Path(fixture["metrics_path"]).read_text(encoding="utf-8"))
        self.assertTrue(metrics["completed"])
        self.assertTrue(output.is_file() and output.stat().st_size > 0)
        streams = json.loads(subprocess.check_output([
            "ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name", "-of", "json", str(output),
        ], text=True, encoding="utf-8"))["streams"]
        audio = [item for item in streams if item.get("codec_type") == "audio"]
        if narration:
            self.assertEqual("aac", audio[0]["codec_name"])
        else:
            self.assertFalse(audio)

    def test_short_continuous_workflow(self):
        self.run_workflow("工作流短片真实端到端复核", 2)

    def test_long_segmented_workflow(self):
        self.run_workflow("工作流长片真实端到端复核", 13)

    def test_pcm_narration_is_muxed_as_aac(self):
        self.run_workflow("工作流旁白真实端到端复核", 2, narration=True)


if __name__ == "__main__":
    unittest.main()
