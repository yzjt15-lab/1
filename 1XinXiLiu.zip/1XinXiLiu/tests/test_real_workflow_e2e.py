import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PIPELINE = ROOT / "scripts" / "fast_pipeline.py"
sys.path.insert(0, str(ROOT / "scripts"))
from speed_common import quick_hash
RUN_E2E = os.environ.get("RUN_REAL_E2E") == "1"
WORK_ROOT: Path | None = None
VIDEO_ROOT: Path | None = None


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_json(*args: str) -> dict:
    result = subprocess.run(
        [sys.executable, str(PIPELINE), *args], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace",
        env={**os.environ, "INFOFLOW_E2E_OUTPUT_DIR": str(VIDEO_ROOT)},
    )
    if result.returncode:
        raise AssertionError(result.stdout + "\n" + result.stderr)
    return json.loads(result.stdout)


@unittest.skipUnless(RUN_E2E, "set RUN_REAL_E2E=1 to render real short and segmented MP4 workflows")
class RealWorkflowE2ETests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            raise unittest.SkipTest("ffmpeg and ffprobe are required")
        cls._temporary_dir = tempfile.TemporaryDirectory(prefix="codex-infoflow-e2e-")
        cls.addClassCleanup(cls._temporary_dir.cleanup)
        global WORK_ROOT, VIDEO_ROOT
        WORK_ROOT = Path(cls._temporary_dir.name)
        VIDEO_ROOT = WORK_ROOT / "video_output"
        WORK_ROOT.mkdir(parents=True, exist_ok=True)
        VIDEO_ROOT.mkdir(parents=True, exist_ok=True)

    def build_fixture(self, name: str, shot_count: int, narration: bool = False) -> dict:
        project = WORK_ROOT / name
        assets_dir = project / "assets"
        overlays_dir = project / "overlays" / "hook"
        assets_dir.mkdir(parents=True, exist_ok=True)
        overlays_dir.mkdir(parents=True, exist_ok=True)
        script = project / f"2026-08-12_文档_{name}_文案.md"
        script.write_text("工作流真实视频端到端复核。", encoding="utf-8")
        initialized = run_json("init", "--script", str(script), "--duration", str(shot_count * 5), "--output-dir", str(project))

        assets, shots = [], []
        checked_at = datetime.now(timezone.utc).isoformat()
        for index in range(shot_count):
            asset_id = f"{name}-asset-{index + 1:02d}"
            path = assets_dir / f"2026-08-12_视频_{name}_动态测试素材_{index + 1:02d}.mp4"
            subprocess.run([
                "ffmpeg", "-y", "-f", "lavfi", "-i", f"testsrc2=size=640x360:rate=30:duration=5,hue=h={index * 8}",
                "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(path),
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            frame_evidence = assets_dir / f"2026-08-12_图片_{name}_帧证据_{index + 1:02d}.jpg"
            subprocess.run([
                "ffmpeg", "-y", "-ss", "2.5", "-i", str(path), "-frames:v", "1", str(frame_evidence),
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            semantic = {"subject": "动态测试画面", "action": "连续运动", "location": "测试环境", "equipment": "视频编码器", "keywords": "工作流 真实视频 复核"}
            assets.append({
                "id": asset_id, "local_path": str(path), "sha256": sha256(path), "quick_hash": quick_hash(path), "status": "unused", "use_count": 0,
                "delivered_at": None, "last_used_at": None, "dedupe_clear": True, "dedupe_checked_at": checked_at,
                "seven_day_eligible": True, "watermark_free": True, "embedded_subtitles_free": True,
                "platform_overlay_free": True, "cleanliness_checked_at": checked_at,
                "cleanliness_evidence": "generated moving integration-test source is visually clean", "frame_evidence": str(frame_evidence),
                **semantic,
            })
            start, end = index * 5.0, (index + 1) * 5.0
            shots.append({
                "id": f"s{index + 1:02d}", "chapter_id": "c01", "start": start, "end": end,
                "source_in": 0.0, "source_out": 5.0, "keyword": "工作流复核", "subject": "动态测试画面",
                "action": "连续运动", "result": "验证真实渲染链路", "asset_id": asset_id,
                "selection_mode": "semantic_index", "script_semantics": semantic, "semantic_fields": semantic,
                "theme_mapping": semantic, "information_task": "broll", "script_range": {"start": start, "end": end},
                "selection_reason": "真实 MP4 集成测试镜头覆盖连续运动、编码和拼接", "candidate_asset_ids": [asset_id],
            })

        from PIL import Image, ImageDraw
        for frame in range(31):
            image = Image.new("RGBA", (1920, 1080), (0, 0, 0, 0))
            ImageDraw.Draw(image).rectangle((160, 390, 160 + frame * 30, 610), fill=(255, 255, 255, 210))
            image.save(overlays_dir / f"{frame:04d}.png")

        manifest = project / f"2026-08-12_文档_{name}_选片凭据.json"
        manifest.write_text(json.dumps({
            "source": "fast_pipeline research",
            "eligible_visual_candidates": {"queries": [{"query": name, "candidates": [
                {
                    "asset_id": item["id"], "local_path": item["local_path"], "sha256": item["sha256"], "seven_day_eligible": True,
                    "frame_evidence": item["frame_evidence"], "source_in": 0.0, "source_out": 5.0,
                } for item in assets
            ]}]},
        }, ensure_ascii=False), encoding="utf-8")
        duration = shot_count * 5.0
        timeline = project / f"2026-08-12_文档_{name}_时间轴.json"
        audio_path = None
        if narration:
            audio_path = project / f"2026-08-12_音频_{name}_旁白测试.wav"
            subprocess.run([
                "ffmpeg", "-y", "-f", "lavfi", "-i", f"sine=frequency=440:sample_rate=48000:duration={duration}",
                "-c:a", "pcm_s16le", str(audio_path),
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        payload = {
            "script_path": str(script), "duration_seconds": duration, "audio_path": str(audio_path) if audio_path else None,
            "audio_delivery_mode": "narration" if audio_path else "silent",
            "selection_manifest_path": str(manifest), "selection_manifest_sha256": sha256(manifest),
            "dedupe_audit": {"lookback_hours": 168, "checked_at": checked_at},
            "chapters": [{"id": "c01", "start": 0.0, "end": duration, "thesis": "真实渲染链路复核"}],
            "shots": shots, "assets": assets,
            "overlays": [{
                "id": "hook", "type": "hook", "role": "hook", "chapter_id": "c01", "script_range": {"start": 0.0, "end": 4.0},
                "start": 0.0, "end": 4.0, "chinese_text": "真实工作流闭环复核", "background_shot_id": "s01",
                "image_path": str(overlays_dir / "0000.png"), "frame_pattern": str(overlays_dir / "%04d.png"),
                "hook_color_fallback": "white",
                "hook_text_colors": {line: {"color": "#FFFFFF", "opacity": 1.0} for line in ("thesis", "judgment", "evidence")},
                "hook_contrast": {line: {"background_luminance": 0.02, "contrast_ratio": 17.5} for line in ("thesis", "judgment", "evidence")},
            }],
        }
        timeline.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        asset_index = project / f"2026-08-12_文档_{name}_素材索引.json"
        asset_index.write_text(json.dumps({"assets": [{**item, "path": item["local_path"], "duration": 5.0} for item in assets]}, ensure_ascii=False), encoding="utf-8")
        return {"project": project, "timeline": timeline, "asset_index": asset_index, **initialized}

    def run_workflow(self, name: str, shot_count: int, narration: bool = False) -> None:
        fixture = self.build_fixture(name, shot_count, narration)
        output = VIDEO_ROOT / f"2026-08-12_视频_{name}.mp4"
        finalized = run_json(
            "finalize", "--timeline", str(fixture["timeline"]), "--asset-index", str(fixture["asset_index"]),
            "--overlay-dir", str(fixture["project"] / "rendered-overlays"), "--output-video", str(output),
            "--project-dir", str(fixture["project"]), "--metrics", str(fixture["metrics_path"]), "--status", str(fixture["status_path"]),
        )
        self.assertEqual("first_review_ready", json.loads(Path(fixture["status_path"]).read_text(encoding="utf-8"))["current_stage"])
        approval = fixture["project"] / f"2026-08-12_文档_{name}_视觉批准.json"
        review_notes = Path(finalized["review_notes_template"])
        notes = json.loads(review_notes.read_text(encoding="utf-8"))
        notes["checks"] = {name: True for name in notes["checks"]}
        for shot_id, observation in notes["shots"].items():
            observation.update({"visible_subject": "测试主体", "visible_action": "测试动作", "visible_location": "测试地点", "visible_equipment": "测试设备", "semantic_match": True})
        review_notes.write_text(json.dumps(notes, ensure_ascii=False), encoding="utf-8")
        final_review = fixture["project"] / f"2026-08-12_文档_{name}_最终复审.json"
        run_json(
            "approve", "--video", str(output), "--timeline", finalized["prepared_timeline"],
            "--contact-sheet", finalized["contact_sheet"], "--review-notes", str(review_notes), "--approval", str(approval),
            "--final-report", str(final_review), "--metrics", str(fixture["metrics_path"]), "--status", str(fixture["status_path"]),
        )
        self.assertEqual("visual_approval_review_passed", json.loads(Path(fixture["status_path"]).read_text(encoding="utf-8"))["current_stage"])
        gate = fixture["project"] / f"2026-08-12_文档_{name}_终态门禁.json"
        delivered = run_json(
            "deliver", "--video", str(output), "--timeline", finalized["prepared_timeline"],
            "--preflight", finalized["preflight_report"], "--ledger", finalized["asset_ledger"],
            "--final-review", str(final_review), "--status", str(fixture["status_path"]),
            "--gate-report", str(gate), "--metrics", str(fixture["metrics_path"]),
        )
        self.assertTrue(delivered["terminal_allowed"])
        probe = json.loads(Path(finalized["encoder_probe_report"]).read_text(encoding="utf-8"))
        self.assertTrue(probe["attempts"] and probe["attempts"][-1]["ok"])
        metrics = json.loads(Path(fixture["metrics_path"]).read_text(encoding="utf-8"))
        self.assertTrue(metrics["completed"])
        self.assertIn("approval_final_review", metrics["stages"])
        self.assertIn("elapsed_seconds", metrics["stages"]["approval_final_review"])
        self.assertTrue(output.is_file() and output.stat().st_size > 0)
        streams = json.loads(subprocess.check_output([
            "ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name,width,height,sample_aspect_ratio", "-of", "json", str(output),
        ], text=True, encoding="utf-8"))["streams"]
        video = next(item for item in streams if item.get("codec_type") == "video")
        self.assertEqual((1080, 1920), (video["width"], video["height"]))
        self.assertEqual("1:1", video["sample_aspect_ratio"])
        audio = [item for item in streams if item.get("codec_type") == "audio"]
        if narration:
            self.assertEqual("aac", audio[0]["codec_name"])
        else:
            self.assertFalse(audio)

    def test_short_continuous_workflow(self):
        self.run_workflow("e2e_short_continuous", 2)

    def test_long_segmented_workflow(self):
        self.run_workflow("e2e_long_segmented", 13)

    def test_pcm_narration_is_muxed_as_aac(self):
        self.run_workflow("e2e_pcm_narration", 2, narration=True)


if __name__ == "__main__":
    unittest.main()
