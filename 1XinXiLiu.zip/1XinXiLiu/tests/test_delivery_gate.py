import json
import hashlib
import subprocess
import sys
import tempfile
import unittest
import shutil
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "delivery_gate.py"
FAST_PIPELINE = Path(__file__).resolve().parents[1] / "scripts" / "fast_pipeline.py"


class DeliveryGateCliTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.video = self.root / "final.mp4"
        self.timeline = self.root / "timeline.json"
        self.preflight = self.root / "preflight.json"
        self.asset_index = self.root / "asset-index.json"
        self.ledger = self.root / "ledger.json"
        self.review = self.root / "review.json"
        self.status = self.root / "status.json"
        self.report = self.root / "gate.json"
        self.metrics = self.root / "metrics.json"
        self.permit = self.root / "finalize-permit.json"
        self.contact_sheet = self.root / "contact.jpg"
        self.approval = self.root / "approval.json"
        self.status.write_text(json.dumps({"state": "in_progress", "terminal_allowed": False}), encoding="utf-8")
        self.metrics.write_text(json.dumps({"started_at_epoch": 1, "stages": {}, "budgets_seconds": {}}), encoding="utf-8")

        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            self.skipTest("ffmpeg is required for real MP4 delivery-gate tests")
        subprocess.run([
            ffmpeg, "-y", "-f", "lavfi", "-i", "color=c=blue:s=32x32:r=30:d=10",
            "-an", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
            str(self.video),
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.timeline.write_text(json.dumps({
            "duration_seconds": 10.0,
            "finalize_permit_path": str(self.permit),
            "shots": [
                {"id": "s01", "start": 0.0, "end": 5.0, "asset_id": "a01"},
                {"id": "s02", "start": 5.0, "end": 10.0, "asset_id": "a02"},
            ],
        }), encoding="utf-8")
        self.permit.write_text(json.dumps({
            "source": "fast_pipeline finalize",
            "profile": "final",
            "timeline_sha256": hashlib.sha256(self.timeline.read_bytes()).hexdigest(),
            "output_video_path": str(self.video.resolve()),
        }), encoding="utf-8")
        timeline_hash = hashlib.sha256(self.timeline.read_bytes()).hexdigest()
        self.asset_index.write_text(json.dumps({"assets": []}), encoding="utf-8")
        self.preflight.write_text(json.dumps({
            "timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash,
            "asset_index": str(self.asset_index.resolve()), "asset_index_sha256": hashlib.sha256(self.asset_index.read_bytes()).hexdigest(),
            "ok": True, "errors": [],
        }), encoding="utf-8")
        self.ledger.write_text(json.dumps({
            "asset_count": 2,
            "assets": [
                {"id": "a01", "source_url": "https://example.com/1", "publisher": "P1", "local_path": "a.mp4", "source_description": "one", "sha256": "1" * 64},
                {"id": "a02", "source_url": "https://example.com/2", "publisher": "P2", "local_path": "b.mp4", "source_description": "two", "sha256": "2" * 64},
            ],
            "uses": [
                {"shot_id": "s01", "asset_id": "a01", "keyword": "芯片"},
                {"shot_id": "s02", "asset_id": "a02", "keyword": "数据中心"},
            ],
            "timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash,
        }), encoding="utf-8")
        self.contact_sheet.write_bytes(b"contact-sheet")
        self.approval.write_text(json.dumps({"hashes": {
            "video_sha256": hashlib.sha256(self.video.read_bytes()).hexdigest(),
            "timeline_sha256": timeline_hash,
            "contact_sheet_sha256": hashlib.sha256(self.contact_sheet.read_bytes()).hexdigest(),
        }}), encoding="utf-8")
        self.review.write_text(json.dumps({
            "video": str(self.video),
            "timeline": str(self.timeline.resolve()), "timeline_sha256": timeline_hash,
            "video_duration": 10.0,
            "target_duration": 10.0,
            "shots": [{"id": "s01", "checked": True, "semantic_checked": True}, {"id": "s02", "checked": True, "semantic_checked": True}],
            "contact_sheet": str(self.contact_sheet), "contact_sheet_sha256": hashlib.sha256(self.contact_sheet.read_bytes()).hexdigest(),
            "visual_approval": str(self.approval), "visual_approval_sha256": hashlib.sha256(self.approval.read_bytes()).hexdigest(),
            "errors": [],
            "ok": True,
        }), encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def run_gate(self):
        return subprocess.run([
            sys.executable, str(SCRIPT),
            "--video", str(self.video),
            "--timeline", str(self.timeline),
            "--preflight", str(self.preflight),
            "--ledger", str(self.ledger),
            "--final-review", str(self.review),
            "--output", str(self.report),
        ], capture_output=True, text=True, encoding="utf-8")

    def test_complete_artifacts_open_terminal_gate_and_hash_every_input(self):
        result = self.run_gate()
        self.assertEqual(0, result.returncode, result.stderr)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(report["ok"])
        self.assertTrue(report["terminal_allowed"])
        self.assertEqual({"video", "timeline", "preflight", "ledger", "final_review"}, set(report["sha256"]))

    def test_failed_final_review_keeps_workflow_in_progress(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review.update({"ok": False, "errors": ["black frame"]})
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertFalse(report["terminal_allowed"])

    def test_missing_source_file_hash_blocks_delivery(self):
        ledger = json.loads(self.ledger.read_text(encoding="utf-8"))
        ledger["assets"][1].pop("sha256")
        self.ledger.write_text(json.dumps(ledger), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("source file hash" in item for item in report["errors"]))

    def test_missing_optional_source_fields_does_not_block_delivery(self):
        ledger = json.loads(self.ledger.read_text(encoding="utf-8"))
        for asset in ledger["assets"]:
            asset.pop("source_url", None)
            asset.pop("publisher", None)
            asset.pop("source_description", None)
        self.ledger.write_text(json.dumps(ledger), encoding="utf-8")
        result = self.run_gate()
        self.assertEqual(0, result.returncode, result.stderr)

    def test_review_for_another_video_blocks_delivery(self):
        review = json.loads(self.review.read_text(encoding="utf-8"))
        review["video"] = str(self.root / "old.mp4")
        self.review.write_text(json.dumps(review), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("different video" in item for item in report["errors"]))

    def test_corrupt_video_bytes_are_blocked(self):
        self.video.write_bytes(b"not-an-mp4")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("probeable MP4" in item for item in report["errors"]))

    def test_visual_approval_modified_after_review_is_blocked(self):
        approval = json.loads(self.approval.read_text(encoding="utf-8"))
        approval["tampered"] = True
        self.approval.write_text(json.dumps(approval), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("visual approval hash" in item for item in report["errors"]))

    def test_preflight_for_another_timeline_is_blocked(self):
        preflight = json.loads(self.preflight.read_text(encoding="utf-8"))
        preflight["timeline_sha256"] = "0" * 64
        self.preflight.write_text(json.dumps(preflight), encoding="utf-8")
        result = self.run_gate()
        self.assertNotEqual(0, result.returncode)
        report = json.loads(self.report.read_text(encoding="utf-8"))
        self.assertTrue(any("preflight does not belong" in item for item in report["errors"]))

    def test_fast_pipeline_deliver_is_guarded_by_the_same_gate(self):
        result = subprocess.run([
            sys.executable, str(FAST_PIPELINE), "deliver",
            "--video", str(self.video),
            "--timeline", str(self.timeline),
            "--preflight", str(self.preflight),
            "--ledger", str(self.ledger),
            "--final-review", str(self.review),
            "--status", str(self.status),
            "--gate-report", str(self.report),
            "--metrics", str(self.metrics),
        ], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(0, result.returncode, result.stderr)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["terminal_allowed"])


if __name__ == "__main__":
    unittest.main()
