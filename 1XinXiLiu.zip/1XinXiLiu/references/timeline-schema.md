# 时间线合同

```json
{
  "script_path": "C:/project/文案.txt",
  "duration_seconds": 60.0,
  "audio_path": null,
  "audio_delivery_mode": "silent",
  "chapters": [{"id": "c01", "start": 0.0, "end": 8.0, "thesis": "原文章节"}],
  "shots": [{
    "id": "s01", "chapter_id": "c01", "start": 0.0, "end": 4.0,
    "asset_id": "asset-01", "information_task": "fact",
    "script_range": {"start": 0.0, "end": 4.0}
  }],
  "overlays": [{
    "id": "page-01", "type": "fact", "chapter_id": "c01",
    "information_task": "fact", "script_range": {"start": 0.0, "end": 4.0},
    "background_shot_id": "s01", "start": 0.0, "end": 4.0,
    "chinese_text": "机构资金持续流入", "content_blocks": ["机构增仓", "成交活跃"]
  }]
}
```

只接受中文文案与“目标时长或音频”二选一。目标时长对应 `audio_path:null`、`audio_delivery_mode:silent`；音频对应实测时长、`audio_path` 和 `audio_delivery_mode:narration`。

每章须有唯一 `id`、连续 `start/end` 和非空 `thesis`。非钩子页面直接在 `overlays[]` 中以 `chapter_id`、`information_task`、`script_range` 绑定原文章节。准备后的正式时间线不得保留无截图新闻页。

每镜必须保存五字段语义镜像、候选清单、选片理由、素材路径与哈希、`source_in/out`、168 小时审计和清洁度证据。`dedupe_audit={lookback_hours:168,checked_at:<带时区时间>}`；仅当用户明确授权某一工程例外时，允许 `lookback_hours:0`，且必须同时记录 `user_authorized_exception:true` 与非空 `exception_reason`，并且不修改全局默认规则。页面固定 4.0 秒，镜头连续覆盖总时长。分段渲染每段 1–5 镜且不超过 25 秒。

信息页字段：`fact/data/causal` 使用 `content_blocks`；`number` 使用含数字的 `primary_value`，可含 `unit/conclusion`；`comparison` 使用不同的 `left_value/right_value`、`left_label/right_label` 与 `conclusion`；`news` 只使用真实 `screenshot_path`；`hook` 使用 `thesis/judgment/evidence`。所有 `reference_template` 文件名从固定标准清单读取。
