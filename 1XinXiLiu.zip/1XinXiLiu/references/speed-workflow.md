# 提速工作流

本文件只说明执行命令与性能策略；规范定义以 `../SKILL.md` 的“主规则索引”为准。

## 运行配置

默认路径由 `scripts/runtime_config.py` 从当前用户目录推导。只在迁移或工具不在 `PATH` 时设置：

```powershell
$env:INFOFLOW_CONFIG_ROOT = "<配置根目录>"
$env:INFOFLOW_SKILLS_ROOT = "<技能根目录>"
$env:INFOFLOW_MATERIAL_LIBRARY_ROOT = "<素材库目录>"
$env:INFOFLOW_MATERIAL_LIBRARY_SCRIPTS = "<素材库脚本目录>"
$env:INFOFLOW_DOCUMENT_OUTPUT_DIR = "<交付文档检索目录>"
$env:INFOFLOW_VIDEO_OUTPUT_DIR = "<正式视频目录>"
$env:INFOFLOW_VISUAL_SEMANTIC_INDEX = "<visual_semantic_index.py>"
$env:INFOFLOW_VISUAL_SEMANTIC_CACHE = "<画面语义缓存目录>"
$env:INFOFLOW_FFMPEG = "<ffmpeg 可执行文件>"
$env:INFOFLOW_FFPROBE = "<ffprobe 可执行文件>"
```

Python 使用启动当前流程的解释器。字体使用系统字体查找逻辑。缓存目录由每个工程显式传入，不是来源台账。

## 命令入口

```powershell
python scripts/fast_pipeline.py init --script <文案.md> --duration <秒> --title <标题> --output-dir <工程目录>
python scripts/fast_pipeline.py research --query <关键词一> --query <关键词二> --top-k 12 --output <研究包.json> --status <执行状态.json>
python scripts/fast_pipeline.py finalize --timeline <时间轴.json> --asset-index <索引.json> --overlay-dir <叠层目录> --output-video <日期_视频_标题.mp4> --project-dir <工程目录> --metrics <耗时.json> --status <执行状态.json>
python scripts/fast_pipeline.py approve --video <成片.mp4> --timeline <准备后时间轴.json> --contact-sheet <联系表.jpg> --approval <视觉批准.json> --final-report <最终复审.json> --metrics <耗时.json> --status <执行状态.json>
python scripts/fast_pipeline.py deliver --video <成片.mp4> --timeline <准备后时间轴.json> --preflight <预检报告.json> --ledger <asset-ledger.json> --final-review <最终复审.json> --status <执行状态.json> --gate-report <终态门禁.json> --metrics <耗时.json>
```

不得把初始化、后台进程启动、文件开始增长或首次联系表生成当成完成。

## 三路准备与汇合

时间线骨架完成后并行准备：

```text
真实视频检索与登记       ─┐
新闻页面匹配与截图       ─┼─→ 合并时间线 → 语义确认 → 预检 → 编码探测 → 渲染
数据/数字/VS/因果页生成  ─┘
```

三路只服务于用户既定文案，不进行事实核验，也不把搜索结果变成内容审核门禁。失败只处理对应分支，不重做已成功分支。

## 素材与语义索引

素材库脚本路径来自 `INFOFLOW_MATERIAL_LIBRARY_SCRIPTS`。先用主体、动作、地点、设备、关键词筛选，再检查连续解码、选段时长、画面洁净度、源文件 SHA-256 与 168 小时去重。来源字段可记录但不是入轴条件。

```powershell
python "$env:INFOFLOW_MATERIAL_LIBRARY_SCRIPTS\material_library.py" search --subject <主体> --action <动作> --location <地点> --equipment <设备> --keyword <关键词> --output <候选.json>
python "$env:INFOFLOW_VISUAL_SEMANTIC_INDEX" build --asset-index <asset-index.json> --output-dir <语义索引目录> --interval 3 --max-samples 24 --batch-size 32
```

共享语义脚本必须满足 `SEMANTIC_INDEX_API_VERSION = 1` 且暴露 `search_many`；不满足时立即报错，不静默降级。模型、文件大小与 `mtime_ns` 未变化时复用向量，只增量处理新增或修改素材。

## 时间线与渲染

1. 完成五项语义和候选确认，再建立时间线。
2. 用 `prepare_timeline_assets.py` 生成标题栏、免责声明和信息页；新闻截图也登记在 `overlays[]`，禁止另建 `news[]`。
3. 用 `preflight.py` 校验素材绑定、镜头连续性、选段范围、信息页和七日去重。
4. 总时长小于 90 秒且真实视频不超过 12 条时连续渲染；否则按镜头边界分段，每段 4–5 镜、最多 25 秒，再无损拼接。
5. 正式渲染前用最终时间线、分辨率、叠层和编码器做 3 秒探测。硬件编码失败即切换已验证的软件档，不重复启动整片任务。
6. 首审只生成每镜开头/中点/结尾联系表；视觉批准后只做一次完整解码。

只修改报告或台账且像素未变时不重渲染；任何影响像素的终版修改都必须重新渲染和复审。

## 计时与故障报告

`workflow_metrics.py` 从完整输入到齐开始计时。默认预算：新闻页 360 秒、素材 300 秒、时间线 240 秒、渲染复审 120 秒。预算超时用于暴露瓶颈，不授权降低素材匹配或交付门禁。

重试、阻塞状态和交付许可只按 `SKILL.md` 的“执行状态主规则”与“统一交付主规则”执行。

## 性能基准

历史机器数据只能作为线索，不能作为跨机器承诺。更换驱动、GPU 或 FFmpeg 后运行：

```powershell
python scripts/benchmark_encoder.py --output <缓存\encoder-benchmark.json>
```

端到端报告必须区分语义索引、素材整理、页面制作、编码与复审；不得用单项编码耗时代替总体耗时。
