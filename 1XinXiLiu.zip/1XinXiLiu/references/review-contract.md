# 复审合同

交付前逐条确认：

1. 每个 `shots[]` 均有章节 ID、五项语义、素材、源文件哈希与不超过 5 秒的时长；真实实拍镜头均为 2–5 秒且五项语义一致。来源字段按“来源字段主规则”可选。
2. 每个素材 ID 只出现一次；每个替代素材有明确原因。
3. 每个新闻节点有真实截图路径。
4. 每个信息页固定 4.0 秒、有真实视频背景并绑定本章证据；逐章核对“当前文案/信息页/底层实拍”为同一主题。信息页只按章节证据计划出现，不用固定秒数插页；同一数据链路的连续数据图首尾直接衔接，不插入纯真实视频空档。
5. 所有显性文案均为简体中文；无英文卡片或“数据页/对比页”等类别标签。对比结构允许使用白色圆形 `VS` 视觉标识。
6. 顶部标题条及其最右侧免责声明存在，底部黑栏保持完全留空；无烧录字幕。
7. 成片可完整解码，时间戳递增。有输入音频时，音频时长与输入一致；无输入音频时，允许成片无音轨，成片时长必须与 `duration_seconds` 一致。
8. 复审报告必须包含每个镜头的检查行；不得以三个抽帧取代全片检查。
9. `端到端耗时.json` 必须覆盖新闻、素材、时间线和渲染复审阶段；任何超时阶段必须记录原因。局部编码耗时不能代替端到端耗时。

## 视觉批准文件

`review_render.py` 不得自动把镜头写为已检查。第一次运行生成每镜联系表；代理查看后创建：

```json
{
  "approved_shot_ids": ["s01", "s02"],
  "shot_observations": {
    "s01": {"visible_subject": "晶圆", "visible_action": "机械臂搬运", "visible_location": "洁净室", "visible_equipment": "晶圆搬运设备"},
    "s02": {"visible_subject": "技术人员", "visible_action": "检查设备", "visible_location": "实验室", "visible_equipment": "检测仪器"}
  },
  "checks": {
    "title_bar": true,
    "disclaimer": true,
    "no_subtitles": true,
    "keyword_match": true,
    "no_black_or_placeholder": true
  }
}
```

实际查看联系表后，先写逐镜观察 JSON；每镜必须包含 `visible_subject/visible_action/visible_location/visible_equipment`。再运行 `make_visual_approval.py --video <成片> --timeline <时间线> --contact-sheet <联系表> --observations <逐镜观察.json> --confirm title_bar --confirm disclaimer --confirm no_subtitles --confirm keyword_match --confirm no_black_or_placeholder --output <批准.json>`；文件绑定三项 SHA-256。`fast_pipeline.py approve` 只接受已经存在的批准文件，不得自行确认。缺少任一镜头、观察字段、检查项或哈希时复审失败。首次无批准运行只生成三帧/镜头的带 ID 权威联系表，不做完整解码；批准后复审才做唯一一次完整解码。
