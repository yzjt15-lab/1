---
name: rendering-keyframe-videos-locally
description: Use when producing or revising MP4 information-flow videos without Premiere, 剪映, browser automation, or cloud editors. Builds deterministic local timelines with Python-authored keyframes and FFmpeg encoding, then verifies the exported video.
---

# Rendering Keyframe Videos Locally

Use Python to express timed layout/keyframe parameters and local FFmpeg to decode, composite, encode, and validate. Do not claim “pure Python encoding”: H.264 plus AAC multiplexing requires an encoder; this workflow uses the local bundled FFmpeg binary only.

## Workflow

1. Inspect source dimensions, fps, audio, and duration.
2. Create a timeline manifest: each event has source, start, duration, role, and no-reuse ID.
3. For a transform reveal, write three states per element: `initial`, `settle`, and `hold`. Interpolate `x/y/scale/rotation/opacity` with FFmpeg expressions or generated overlays; never simulate motion by repeated frozen images.
4. For a folded wall, start central panels first, then neighbors, then the outside panels. Hold the final wall and transition directly to the next relevant video; do not expand the wall to fullscreen.
5. Encode H.264/AAC at the source fps. Run full decode verification and collect dimensions/duration/audio in the manifest.

## Constraints

- No GUI dependency: do not open or automate Premiere, 剪映, or a browser.
- Use only local files placed in scope; do not download media without a separate user request.
- Keep a unique source ledger and cap each cut at the requested maximum duration.
- Before delivery, run `scripts/verify_render.py` with the output path and FFmpeg path.

## Example

```powershell
python verify_render.py --ffmpeg C:\tools\ffmpeg.exe --video C:\project\render.mp4
```

## Failure handling

If the encoder process exceeds the shell time budget, launch it as one bounded render step, inspect the partial output and process state, then continue from completed intermediates. Do not discard successfully rendered intermediate video.
