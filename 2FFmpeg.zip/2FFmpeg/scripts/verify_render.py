import argparse
import json
import re
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--ffmpeg", required=True)
parser.add_argument("--video", required=True)
args = parser.parse_args()

video = Path(args.video)
if not video.is_file() or video.stat().st_size == 0:
    raise SystemExit("missing or empty video")

probe = subprocess.run(
    [args.ffmpeg, "-v", "error", "-i", str(video), "-f", "null", "NUL"],
    capture_output=True,
    text=True,
)
if probe.returncode:
    raise SystemExit(probe.stderr.strip() or "full decode failed")

meta = subprocess.run(
    [args.ffmpeg, "-hide_banner", "-i", str(video)],
    capture_output=True,
    text=True,
)
# FFmpeg returns 1 when no output is specified; its stderr still carries stream metadata.
summary = meta.stderr
duration = re.search(r"Duration: ([0-9:.]+)", summary)
video_stream = re.search(r"Video: .*?, (\d{2,5}x\d{2,5}).*?(\d+(?:\.\d+)? fps)?", summary)
audio_stream = re.search(r"Audio:", summary)
if not duration or not video_stream:
    raise SystemExit("unable to read duration or video stream metadata")
print(json.dumps({
    "path": str(video), "bytes": video.stat().st_size,
    "duration": duration.group(1), "dimensions": video_stream.group(1),
    "fps": video_stream.group(2) or None, "has_audio": bool(audio_stream)
}, ensure_ascii=False))
