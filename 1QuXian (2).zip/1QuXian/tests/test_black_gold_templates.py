import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from render_market_chart import render
from render_overlay_templates import render_hook_frames, render_news_page


class BlackGoldTemplatesTest(unittest.TestCase):
    def test_all_approved_chart_golden_pages_exist(self):
        reference = ROOT / "assets" / "reference-pages"
        expected = {"2026-08-12_图片_钩子页黑金模板.png", "2026-08-12_图片_新闻页黑金模板.png", "2026-08-12_图片_相对涨跌图模板.png", "2026-08-12_图片_期货持仓图模板.png", "2026-08-12_图片_双轴趋势图模板.png", "2026-08-12_图片_K线波浪图模板.png", "2026-08-12_图片_斐波那契图模板.png", "2026-08-12_图片_图表页黑金模板.png"}
        self.assertEqual(expected, {path.name for path in reference.glob("*.png")})
        for path in reference.glob("*.png"):
            with Image.open(path) as sample:
                self.assertAlmostEqual(sample.width / sample.height, 16 / 9, places=2)

    def test_reference_pages_and_renderers(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            stable, pattern = render_hook_frames({"hook_lines": ["机构继续加多", "3960 是关键压力位", "资金结构仍偏多"]}, out)
            with Image.open(stable) as sample:
                self.assertEqual(sample.size, (1920, 1080))
            self.assertNotEqual((Path(pattern.replace("%04d", "0000"))).read_bytes(), stable.read_bytes())
            screenshot = out / "real.png"
            Image.new("RGB", (1200, 700), "white").save(screenshot)
            with Image.open(render_news_page({"headline": "市场快讯"}, screenshot, out)) as sample:
                self.assertEqual(sample.size, (1920, 1080))
            configs = {
                "relative_return": {"series": [{"label": "上证", "values": [0, -2, 3]}, {"label": "沪深300", "values": [0, -1, 2]}]},
                "futures_position": {"series": [{"label": "多头", "values": [10, 20]}, {"label": "空头", "values": [8, 16]}], "labels": ["IF", "IH"]},
                "dual_axis_trend": {"series": [{"label": "估值", "values": [25, 15, 20]}, {"label": "盈利", "values": [-20, 0, 40]}]},
                "kline_wave": {"ohlc": [{"open": 10, "high": 12, "low": 9, "close": 11}, {"open": 11, "high": 14, "low": 10, "close": 13}], "annotations": [{"text": "量能放大百分之十"}]},
                "kline_fibonacci": {"ohlc": [{"open": 10, "high": 12, "low": 9, "close": 11}, {"open": 11, "high": 14, "low": 10, "close": 13}]},
            }
            for kind, payload in configs.items():
                config = {"id": kind, "chart_kind": kind, "title": kind, "data_metric": "数值", "data_interval": "区间", **payload}
                with Image.open(render(config, out)) as sample:
                    self.assertEqual(sample.size, (1920, 1080))


if __name__ == "__main__":
    unittest.main()
