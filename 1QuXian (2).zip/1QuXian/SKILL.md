---
name: producing-market-curve-infoflow-video
description: Create Chinese 9:16 market videos with a large central 16:9-derived video window, synchronized blurred projections, verified news screenshots, and five approved chart-page types. Use for finance scripts with a title, duration, and optional reference audio; 制作曲线财经信息流视频、财经短视频、市场分析视频、行情解读视频。
---

# 曲线财经信息流视频

## 入口与权威边界

- 开始前读取全局日志；文件名格式为 `YYYY-MM-DD_类型_标题.扩展名`，例如 `2026-08-14_视频_3900支撑复盘.mp4`；类型只能为工程、视频、音频、图片、文档，不表示子目录。正式视频默认写入当前用户的 `Videos/Codex`。
- `manage-material-library` 是候选资格、五字段检索、168 小时去重和使用台账的唯一权威。默认使用同级 `1SuCaiKu/scripts/material_library.py`，不得另建索引、资格规则或台账。
- 可移植配置：`CURVE_VIDEO_OUTPUT_DIR` 覆盖正式视频目录；`CURVE_MATERIAL_LIBRARY_SCRIPTS` 覆盖素材库脚本目录；`CURVE_FFMPEG` 覆盖 FFmpeg；`CURVE_FONT_REGULAR` 与 `CURVE_FONT_BOLD` 覆盖中文字体。目录、工具或中文字体不存在时显式停止并报告变量名，不能静默降级。
- 本 skill 只负责市场页面、时间线、渲染、视觉复审与交付。素材库不可用时，禁止正式选材和交付；可对不含新素材的页面、时间线和脚本做预演，不能伪造候选或绕过去重。
- 用户文案是事实、数字、标题和时间线的唯一内容来源；网页只用于寻找匹配画面或真实新闻截图，不得借搜索结果改写用户文案。

## 输入与资源

必填：完整中文文案、目标时长、中文标题，以及明确的音频交付选择：`audio_delivery_mode: narration`（必须提供旁白 `audio_path`）或 `silent`（明确交付无声）。`reference_audio`、人物或参考视频可选；`reference_audio` 只用于切点对齐，除非用户明确要求，否则不进成片。预检缺少音频选择会失败，不能默认交付静音。

先确认本 skill 的 `scripts/`、`references/`、`assets/approved-pages/` 以及 Python、FFmpeg、FFprobe 可用。命令必须从 `SKILL_ROOT` 执行并先运行 `--help`。核心资源缺失时报告确切路径并停止受影响分支；不得临时伪造同名脚本。

按需读取：

- `references/timeline-schema.md`：时间线字段与资产台账。
- `references/chart-schema.md`：图表数据链与页面字段。
- `references/review-contract.md`：权威联系表、逐镜观察和批准。
- `references/speed-workflow.md`：可恢复的并行生产与命令顺序。

## 生产流程

1. 从文案建立 `chapters[]`：每章写主张、证据、文案区间、五字段语义（主体、动作、地点、设备、关键词）和唯一 `information_task`（`fact/news/data/number/comparison/causal/broll`）。没有匹配参考页所需的可核实数据或新闻截图时，停止受影响章节，不得生成通用信息页、降为纯素材或补造行情数据。
2. 并行准备三路：素材候选、真实新闻截图、图表清单。三路只在时间线合并时汇合，不得反推或改写章节证据。
3. 素材分支先 `audit`，再以主体、动作、地点、设备、关键词精确 `search`；只为最终拟入轴候选做真实区间目检和联系表。每个镜头必须保存候选资产、选片理由、`source_in/out`、帧证据和清洁度证据。没有合格候选时保留原章节和主张，预检失败并阻止全片渲染；不得删章、改写为泛化 B-roll 或捏造证据。一次允许的纠正检索仍无候选时，列出章节 ID、五字段和缺少的资源，状态为 `blocked_external`。
4. 新闻只登记在 `overlays[]`，不得使用 `news[]`；只能使用真实截图，且同一页面只登记一次。
5. 图表只使用已批准版式，按章节证据生成；没有可核实数据就登记跳过原因，不得用装饰图替代数据页。
6. 合并后执行 `prepare_timeline_assets.py`、`validate_timeline.py` 与 `preflight.py`。失败只能修复对应输入或换用合格资产，不能忽略错误。
7. 只由 `fast_pipeline.py finalize` 进入正式渲染；随后生成权威联系表、逐镜复审、批准和 `delivery_gate.py`。任何时间线、素材、叠层或音频变更都会使旧批准失效。

## 不可放松的素材与时间线门禁

- 入轴素材必须来自素材库合格候选：横版 16:9、至少 1280x720、源片大于 4 秒、可解码、默认近 168 小时未使用、五字段（主体、动作、地点、设备、关键词）完整，并有实际帧证据。只有用户明确授权某一工程绕过七日去重时，才可在 `dedupe_audit` 写入 `lookback_hours:0`、`user_authorized_exception:true` 和具体 `exception_reason`；该例外只作用于该工程，不豁免任何其他质量、语义、帧证据或清洁度门禁。
- `watermark_free`、`embedded_subtitles_free`、`platform_overlay_free` 必须均为 `true`；水印、烧录字幕、平台角标或无证据素材必须换源，不能裁切、遮挡或压暗后使用。
- 每个镜头必须有 `chapter_id`、`asset_id`、五字段语义、`script_range`、`information_task`、候选凭据、非空选片理由与覆盖镜头时长的 `source_in/out`。
- 选片清单、时间线、素材库索引和资产台账必须绑定到同一文件路径、文件哈希与实际选段；正式采用后才 `commit`，候选与预览不得占用使用台账。

## 页面合同

页面类型只能是 `hook`、真实 `news` 和 `chart`。钩子与新闻固定 4.0 秒；图表固定 4.5 秒。终版固定为 1080×1920：中央清晰窗口为 1080×830、顶部 `y=604`，上下使用中央画面同帧放大模糊投影；实拍等比填满并左右裁切。页面合成前缩入裁切安全区，文字和结构必须完整可见。信息页 PNG/帧中严禁绘制免责声明或“参考”等说明词；唯一的 `内容仅为个人观点，不构成投资建议` 由 `chrome_path` 全局透明层持续显示在中央清晰窗口顶部与上方模糊层的交界处（`y=604` 上方 8 px、右边距 38 px），不得随页面出现、消失或移动。

每张页面必须写入下列唯一 `reference_template` 文件名；准备器和预检会拒绝不匹配或不存在的引用。不得把图表页、新闻页或钩子页互相挪用，不能使用通用折线、柱状或 K 线替代：

- `hook`：`2026-08-12_图片_钩子页黑金模板.png`。
- `news`：`2026-08-12_图片_新闻页黑金模板.png`。
- `relative_return`：`2026-08-12_图片_相对涨跌图模板.png`。
- `futures_position`：`2026-08-12_图片_期货持仓图模板.png`。
- `dual_axis_trend`：`2026-08-12_图片_双轴趋势图模板.png`。
- `kline_wave`：`2026-08-12_图片_K线波浪图模板.png`。
- `kline_fibonacci`：`2026-08-12_图片_斐波那契图模板.png`。

- `relative_return`：多线相对涨跌、百分比零轴、右侧图例。
- `futures_position`：蓝金分组持仓柱、数据标签、净多/净空结论。
- `dual_axis_trend`：金色左轴、青色右轴、顶部图例、关键拐点。
- `kline_wave`：K 线、均线、成交量、波浪和支撑阻力。
- `kline_fibonacci`：K 线、完整回撤位、0.618 高亮和关键支撑。

旧通用信息页已删除，不得回退、临时重建或以任意图片路径代替上述映射。参考图不得保留旧顶部黑框、页内警示语或“内容仅供参考”等参考词；由透明全局层在中央窗口上方只显示一次免责声明。图表保留黄金样图自身合同。图表、新闻和钩子均绑定当前章节真实画面；无数据、无新闻或无匹配素材时，不增加空页，不以泛化 B-roll 冒充证据。

## 渲染、超时与交付安全阀

- 总时长 `>=90` 秒或真实视频输入 `>12` 条时，必须使用 `render_segmented_timeline.py`。`split_timeline()` 对每一段都强制不超过 5 个镜头和 25 秒；即使短片因章节拆分产生更多镜头，也继续切分，找不到不切开页面的边界即停止。一次只渲染一段，确认可解码后再开始下一段。以局部时间线、编码器、入轴素材哈希和叠层哈希生成指纹；只有指纹未变且片段可完整解码时才能复用。
- 正式渲染前必须用最终时间线和实际叠层做一次 3 秒编码探测。环境匹配已验证档时先试 NVENC；失败、超时或初始化异常时仅回退一次 `libx264 / veryfast / CRF 19` 并重做探测。回退仍失败即停止正式渲染，不得盲选编码器或反复重试。
- `preflight.py` 必须显式覆盖：七日去重、动态钩子、章节连续性、证据/页面唯一性、每镜源区间覆盖、透明免责声明资产（`chrome_path`）、目标时长、横版有效画面与清洁度；最终联系表复审再核验竖屏模糊投影布局和声明实际可见。脚本缺任何一项时先补测试和实现，再允许 `finalize`。
- `finalize` 与 `approve` 必须接收 `init` 返回的同一 `--status` 文件，并在准备、预检、渲染、首次复审和视觉批准成功后更新可恢复检查点；全过程保持 `in_progress/terminal_allowed=false`。只有状态控制器可写为 `complete`、用户取消的 `cancelled`，或纠正序列耗尽后的 `blocked_external`；不能把等待、开始或单次超时写成最终状态。
- 交付只认 `terminal_allowed=true` 的最终报告，且报告内 MP4 SHA-256 必须与实际交付文件一致。联系表、批准、交付报告和 MP4 任一变更都要求重新复审。
- 钩子必须是有真实画面持续运动的逐帧揭示，不得以静态 PNG 冒充动画；不得绘制整块黑底，文字直接叠在底层画面上并使用描边保证可读。默认颜色格式固定为：`thesis=#F2C86B` 金色、`judgment=#F8F9FB` 白色、`evidence=#C6CCD3` 灰色，透明度按 thesis > judgment > evidence；每行与背景对比度至少 `4.5:1`，并在首帧、中帧、结尾帧验证可读性。缺少颜色字段时，`prepare_timeline_assets.py` 自动写入上述参考图调色板；只有调色板实测不合格时才使用 `hook_color_fallback: "white"`。
- 端到端目标为 20 分钟（扣除已记录的用户等待），用于进度管理，不是自动停产条件。第 10 分钟未开始正式渲染时，报告恢复点和唯一阻塞点；只要契约、授权和资源允许，可继续生产。超时不降低标准。
- 下载、编码或单个按需资源失败时，只按 `speed-workflow.md` 的一次纠正/回退序列处理；20 分钟不是会话上限。若一次纠正后仍等待外部素材、权限或服务，写 `blocked_external`，报告恢复点、章节/资源缺口和所需授权；不得把仍可推进的超时标记为 `blocked_external`。
- 最终文件必须完整解码，满足 1080x1920、CFR、yuv420p、`+faststart`，并通过联系表、逐镜观察、批准和交付门禁。仅在全部通过后交付视频链接和资产台账。

## 禁止捷径

不得重复同一新闻页、复用已用素材、用文件名或目录代替视觉证据、手工伪造批准、用旧门禁批准新版本，或为了节奏降低语义、时长、图表、新闻或画面洁净要求。
