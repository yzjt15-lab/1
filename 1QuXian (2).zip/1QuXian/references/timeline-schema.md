# 时间轴合同：钩子、新闻与图表

时间轴只允许三种 overlay `type`：`hook`、`news`、`chart`。`fact/data/number/comparison/causal` 只能出现在 `information_task` 中表达信息语义；任一值作为 overlay `type` 时，`preflight.py` 必须失败。`hook/news` 固定 `4.0` 秒；图表页固定 `4.5` 秒。每张页面必须写入唯一 `reference_template`：hook 对应 `2026-08-12_图片_钩子页黑金模板.png`，news 对应 `2026-08-12_图片_新闻页黑金模板.png`，五种 chart 分别对应同名语义的相对涨跌、期货持仓、双轴趋势、K线波浪、斐波那契模板。旧的通用信息页模板已删除；缺少匹配参考页或可核实证据必须失败，禁止补造行情数据、回退到通用双卡页或使用旧顶部黑框/页内警示语，终版由透明全局层统一显示一条警示语。

## 顶层必填

- `title`、`script_path`、`main_thesis`、`main_evidence_id`、`evidence_kind`、`duration_seconds`、`audio_delivery_mode`
- `chapters[]`、`assets[]`、`shots[]`、`overlays[]`
- `dedupe_audit={lookback_hours:168,checked_at:<带时区时间>}`；仅当用户明确授权某一工程例外时，允许 `lookback_hours:0`，且必须同时记录 `user_authorized_exception:true` 与非空 `exception_reason`。该例外不修改全局默认规则。
- `chart_inventory[]`：必须恰好覆盖五个图表种类，每项为 `generated` 或带原因的 `skipped`

```json
{
  "chart_inventory": [
    {"chart_kind": "relative_return", "status": "generated", "overlay_ids": ["chart-01"]},
    {"chart_kind": "futures_position", "status": "skipped", "skip_reason": "用户文案没有持仓数据"},
    {"chart_kind": "dual_axis_trend", "status": "skipped", "skip_reason": "用户文案没有双指标时间序列"},
    {"chart_kind": "kline_wave", "status": "skipped", "skip_reason": "用户文案没有波浪结构或K线范围"},
    {"chart_kind": "kline_fibonacci", "status": "skipped", "skip_reason": "用户文案没有高低点或回撤位"}
  ]
}
```

## 章节、镜头与素材

每章须有唯一 `id`、连续 `start/end`、非空 `thesis` 和 `information_plan[]`。计划任务可为 `news`、`fact`、`data`、`number`、`comparison`、`causal` 或 `broll`：`news` 仅在检索命中真实截图时绑定新闻页；未命中时改为 `broll` 并写 `reason: news_search_no_match`；前五种非新闻任务只能绑定图表页；`broll` 必须有非空 `reason`。

每个镜头必须保存：

- `id`、`asset_id`、`chapter_id`、`start/end`、`source_in/source_out`
- `script_range`、`information_task`、`selection_mode: semantic_index`
- `candidate_asset_ids[]` 与非空 `selection_reason`
- `script_semantics`、`semantic_fields`、`theme_mapping`，三者均含 `subject/action/location/equipment/keywords` 且逐项一致

素材必须记录 `local_path`、源文件哈希、洁净检查和七日去重结果。来源字段可选。同一素材只能入轴一次；真实 `broll` 镜头为 2–5 秒，所有镜头不得超过 5 秒；时间轴连续并精确结束于 `duration_seconds`。

## 固定参考页与三种页面

`reference_template` 是页面语义的强制映射：`chart_kind=relative_return/futures_position/dual_axis_trend/kline_wave/kline_fibonacci` 分别使用 `2026-08-12_图片_相对涨跌图模板.png`、`2026-08-12_图片_期货持仓图模板.png`、`2026-08-12_图片_双轴趋势图模板.png`、`2026-08-12_图片_K线波浪图模板.png`、`2026-08-12_图片_斐波那契图模板.png`。不得以任意项目图片代替。

钩子页固定 4.0 秒，从 0.0 秒开始，且全片恰好一张：

```json
{
  "id": "hook-01", "type": "hook", "role": "hook", "start": 0.0, "end": 4.0,
  "chapter_id": "c01", "evidence_id": "e01", "background_shot_id": "s01",
  "chinese_text": "主旨、判断和证据", "frame_pattern": "hook-01/%04d.png",
  "reference_template": "2026-08-12_图片_钩子页黑金模板.png"
}
```

新闻页固定 4.0 秒，必须绑定真实截图和 `task: news` 的同章证据：

```json
{
  "id": "news-01", "type": "news", "start": 8.0, "end": 12.0,
  "chapter_id": "c02", "evidence_id": "e02", "background_shot_id": "s03",
  "chinese_text": "新闻标题", "image_path": "news-01.png",
  "reference_template": "2026-08-12_图片_新闻页黑金模板.png"
}
```

图表页固定 4.5 秒；这是对信息页 4.0 秒默认值的显式特例与覆盖。字段合同与配置格式见 `chart-schema.md`：

```json
{
  "id": "chart-01", "type": "chart", "information_task": "data",
  "chart_kind": "relative_return", "data_chain_id": "chain-01",
  "data_interval": "一月至七月", "data_metric": "累计涨跌幅", "source_state": "user_copy",
  "start": 12.0, "end": 16.5, "chapter_id": "c03", "evidence_id": "e03",
  "background_shot_id": "s04", "chinese_text": "指数相对表现", "image_path": "chart-01.png",
  "reference_template": "2026-08-12_图片_相对涨跌图模板.png"
}
```

每张新闻页和图表页必须通过 `chapter_id/evidence_id` 绑定同章、同任务证据。页面必须有真实视频背景；`chinese_text`、图像路径和内容哈希全片唯一。钩子/新闻页相邻可无缝衔接，图表同链必须无缝衔接，页面不得重叠。

`audio_delivery_mode` 只能是 `silent` 或 `narration`：前者明确交付无声且不得设置 `audio_path`；后者必须设置 `audio_path`。存在 `reference_audio_path` 时，保存 `reference_audio_segments[]`，每个镜头保存 `reference_audio_range`，每张非钩子页保存 `reference_audio_range`、`reference_audio_text` 和 `audio_semantic_match: true`。`audio_path` 只保存旁白音频。
