"""Single source of truth for page semantics and approved reference images."""
from pathlib import Path

REFERENCE_PAGES = Path(__file__).resolve().parents[1] / "assets" / "reference-pages"
PAGE_REFERENCE_FILENAMES = {
    "hook": "2026-08-12_图片_钩子页黑金模板.png",
    "news": "2026-08-12_图片_新闻页黑金模板.png",
    "relative_return": "2026-08-12_图片_相对涨跌图模板.png",
    "futures_position": "2026-08-12_图片_期货持仓图模板.png",
    "dual_axis_trend": "2026-08-12_图片_双轴趋势图模板.png",
    "kline_wave": "2026-08-12_图片_K线波浪图模板.png",
    "kline_fibonacci": "2026-08-12_图片_斐波那契图模板.png",
}
