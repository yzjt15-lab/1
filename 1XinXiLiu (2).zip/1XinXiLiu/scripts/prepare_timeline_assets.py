#!/usr/bin/env python3
"""Generate persistent chrome and missing self-authored overlays."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from render_overlay_templates import render_overlay
from speed_common import write_json

HOOK_LINES = ("thesis", "judgment", "evidence")


def _hook_colors_are_valid(overlay: dict) -> bool:
    colors, contrast = overlay.get("hook_text_colors"), overlay.get("hook_contrast")
    if not isinstance(colors, dict) or not isinstance(contrast, dict):
        return False
    entries = [colors.get(line) for line in HOOK_LINES]
    checks = [contrast.get(line) for line in HOOK_LINES]
    if not all(isinstance(item, dict) and isinstance(item.get("color"), str) and isinstance(item.get("opacity"), (int, float)) for item in entries):
        return False
    if len({item["color"].upper() for item in entries}) != len(HOOK_LINES):
        return False
    if not (entries[0]["opacity"] > entries[1]["opacity"] > entries[2]["opacity"]):
        return False
    return all(isinstance(item, dict) and isinstance(item.get("contrast_ratio"), (int, float)) and item["contrast_ratio"] >= 4.5 for item in checks)


def _apply_white_hook_fallback(overlay: dict) -> None:
    if overlay.get("role") != "hook" or _hook_colors_are_valid(overlay):
        return
    contrast = overlay.get("hook_contrast")
    if overlay.get("hook_color_fallback") == "white" and isinstance(contrast, dict) and all(
        isinstance(contrast.get(line), dict) and isinstance(contrast[line].get("contrast_ratio"), (int, float)) and contrast[line]["contrast_ratio"] >= 4.5
        for line in HOOK_LINES
    ):
        return
    overlay["hook_color_fallback"] = "white"
    overlay["hook_text_colors"] = {line: {"color": "#FFFFFF", "opacity": 1.0} for line in HOOK_LINES}
    overlay["hook_color_fallback_reason"] = "missing_or_invalid_color_contract"


def prepare(timeline: dict, overlay_dir: Path, size=(1920, 1080)) -> dict:
    prepared = json.loads(json.dumps(timeline, ensure_ascii=False))
    chrome = render_overlay({"type": "chrome", "template_version": 4, "disclaimer": "内容仅为个人观点，不构成投资建议"}, overlay_dir, (1080, 1920))
    prepared["chrome_path"] = str(chrome.resolve())
    overlays = prepared.setdefault("overlays", [])
    for overlay in overlays:
        _apply_white_hook_fallback(overlay)
        if overlay.get("type") == "news":
            continue
        if overlay.get("type") not in {"hook", "fact", "data", "number", "comparison", "causal"}:
            continue
        if overlay.get("type") != "hook":
            raise ValueError("generic information-page renderer was removed; an approved reference-template renderer is required")
        if not overlay.get("image_path"):
            overlay["image_path"] = str(render_overlay(overlay, overlay_dir, size).resolve())
    return prepared


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", required=True)
    parser.add_argument("--overlay-dir", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    timeline = json.loads(Path(args.timeline).read_text(encoding="utf-8"))
    prepared = prepare(timeline, Path(args.overlay_dir))
    write_json(Path(args.output), prepared)
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
