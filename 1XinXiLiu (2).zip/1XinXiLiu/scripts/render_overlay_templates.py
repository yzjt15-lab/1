#!/usr/bin/env python3
"""Render only the global disclaimer and dynamic hook; information pages are reference-gated."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from speed_common import content_key


def _font(size: int):
    for path in (Path(r"C:\Windows\Fonts\msyh.ttc"), Path(r"C:\Windows\Fonts\simhei.ttf")):
        if path.is_file():
            return ImageFont.truetype(str(path), size, index=0)
    return ImageFont.load_default()


def render_overlay(config: dict, output_dir: Path, size=(1920, 1080)) -> Path:
    kind = config.get("type")
    if kind not in {"chrome", "hook"}:
        raise ValueError("generic information-page renderer was removed; use an approved reference-template renderer")
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / f"ov_{content_key({'kind': kind, 'size': size, 'config': config}, 20)}.png"
    if output.exists():
        return output
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    width, height = size
    if kind == "chrome":
        text = config.get("disclaimer", "内容仅为个人观点，不构成投资建议")
        font = _font(max(18, round(width * 29 / 1080)))
        box = draw.textbbox((0, 0), text, font=font)
        draw.text((width - box[2] - round(width * 38 / 1080), round(height * 604 / 1920) - round(height * 8 / 1920) - (box[3] - box[1])), text, font=font, fill=(247, 250, 255, 255))
    else:
        for text, y, color, scale in zip((config.get(key, "") for key in ("thesis", "judgment", "evidence")), (.34, .51, .66), ((255, 222, 151, 255), (247, 250, 255, 255), (210, 215, 225, 235)), (11, 14, 20)):
            if text:
                font = _font(max(24, width // scale)); box = draw.textbbox((0, 0), str(text), font=font)
                draw.text(((width - box[2]) / 2, height * y - (box[3] - box[1]) / 2), str(text), font=font, fill=color)
    image.save(output)
    return output
