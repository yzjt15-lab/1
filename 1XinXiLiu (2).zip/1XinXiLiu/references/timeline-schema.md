# 时间轴 JSON 合同

```json
{
  "project_path": "C:\\project",
  "title": "商业航天 | 太空房东",
  "script_path": "C:\\project\\script.md",
  "duration_seconds": 50.0,
  "audio_path": null,
  "main_thesis": "商业航天正在形成数据服务闭环",
  "main_evidence_id": "evidence-c01-01",
  "evidence_kind": "data",
  "selection_manifest_path": "C:\\project\\research.json",
  "selection_manifest_sha256": "研究包哈希",
  "chapters": [
    {
      "id": "c01",
      "start": 0.0,
      "end": 14.0,
      "thesis": "遥感卫星把观测能力转化为可订阅的数据服务",
      "information_plan": [
        {
          "id": "evidence-c01-01",
          "task": "causal",
          "claim": "采集能力形成可订阅的数据服务",
          "script_range": {"start": 0.0, "end": 14.0}
        }
      ]
    }
  ],
  "dedupe_audit": {"lookback_hours": 168, "checked_at": "2026-08-06T10:00:00+08:00"},
  "shots": [
    {
      "id": "s01",
      "chapter_id": "c01",
      "start": 0.0,
      "end": 3.8,
      "source_in": 12.0,
      "source_out": 15.8,
      "keyword": "卫星数据",
      "subject": "遥感卫星",
      "action": "采集",
      "result": "形成可订阅数据服务",
      "asset_id": "nasa-earth-observation-001",
      "selection_mode": "semantic_index",
      "script_semantics": {"subject": "遥感卫星", "action": "采集", "location": "近地轨道", "equipment": "光学载荷", "keywords": "卫星 遥感 数据"},
      "candidate_asset_ids": ["nasa-earth-observation-001"],
      "semantic_fields": {"subject": "遥感卫星", "action": "采集", "location": "近地轨道", "equipment": "光学载荷", "keywords": "卫星 遥感 数据"},
      "theme_mapping": {"subject": "遥感卫星", "action": "采集", "location": "近地轨道", "equipment": "光学载荷", "keywords": "卫星 遥感 数据"},
      "information_task": "causal",
      "script_range": {"start": 0.0, "end": 3.8},
      "selection_reason": "主体、动作、地点、设备与当前章节匹配",
      "overlay_id": null,
      "visual": "卫星与地球观测实拍"
    }
  ],
  "assets": [
    {
      "id": "nasa-earth-observation-001",
      "source_url": "https://example.org/source",
      "publisher": "NASA",
      "local_path": "C:\\project\\assets\\satellite.mp4",
      "source_description": "公开官方视频",
      "sha256": "源文件哈希",
      "status": "unused",
      "use_count": 0,
      "dedupe_clear": true,
      "dedupe_checked_at": "2026-08-06T10:00:00+08:00",
      "segments": [
        {
          "id": "earth-observation-001",
          "start": 12.0,
          "end": 17.0,
          "keywords": ["遥感卫星", "地球观测"],
          "subject": "遥感卫星",
          "action": "采集地表数据",
          "visual": "卫星与地球观测实拍"
        }
      ],
      "replacement": false,
      "replacement_reason": null
    }
  ],
  "overlays": [
    {
      "id": "hook",
      "type": "hook",
      "role": "hook",
      "chapter_id": "c01",
      "evidence_id": "evidence-c01-01",
      "start": 0.0,
      "end": 4.0,
      "chinese_text": "商业航天形成数据服务闭环",
      "background_shot_id": "s01",
      "image_path": "C:\\project\\overlays\\hook\\0000.png",
      "frame_pattern": "C:\\project\\overlays\\hook\\%04d.png",
      "hook_color_fallback": "white",
      "hook_text_colors": {
        "thesis": {"color": "#FFFFFF", "opacity": 1.0},
        "judgment": {"color": "#FFFFFF", "opacity": 1.0},
        "evidence": {"color": "#FFFFFF", "opacity": 1.0}
      },
      "hook_contrast": {
        "thesis": {"background_luminance": 0.02, "contrast_ratio": 17.5},
        "judgment": {"background_luminance": 0.02, "contrast_ratio": 17.5},
        "evidence": {"background_luminance": 0.02, "contrast_ratio": 17.5}
      }
    },
    {
      "id": "card01",
      "type": "causal",
      "chapter_id": "c01",
      "evidence_id": "evidence-c01-01",
      "start": 10.0,
      "end": 14.0,
      "chinese_text": "火箭 → 卫星 → 数据服务",
      "page_title": "产业闭环",
      "content_blocks": ["火箭降低发射成本", "卫星形成数据服务"],
      "background_shot_id": "s04",
      "image_path": "C:\\project\\overlays\\card01.png"
    }
  ]
}
```

`title`、`script_path`、`main_thesis`、`main_evidence_id`、`evidence_kind`、`duration_seconds`、`chapters[]`、`selection_manifest_path`、`selection_manifest_sha256` 和 168 小时 `dedupe_audit` 必填。新闻页只登记在 `overlays[]`，出现顶层 `news[]` 即拒绝。每章须有唯一 `id`、连续时间区间、非空 `thesis` 和非空 `information_plan`；计划证据包含唯一 `id`、任务、主张和章节内的文案区间。纯实拍章节只可登记 `task: "broll"` 与非空 `reason`。每个镜头必须引用其所属 `chapter_id`，并且文案区间完全落在该章；`script_semantics`、`semantic_fields` 和 `theme_mapping` 必须同时包含主体、动作、地点、设备、关键词五项且逐项一致。每个信息页必须以 `chapter_id/evidence_id` 绑定本章同任务证据，钩子页可引用本章任一证据。`audio_path` 可为 `null`，只保存旁白音频；参考音频使用可选的 `reference_audio_path`。存在参考音频时，时间轴还必须保存非空 `reference_audio_segments[]`，每镜保存合法 `reference_audio_range`，每张非钩子信息页保存 `reference_audio_range`、`reference_audio_text` 和 `audio_semantic_match: true`。无音频时最后一个镜头的 `end` 必须等于 `duration_seconds`。素材必须记录 `local_path`、源文件哈希及去重结果；`source_url`、`publisher`、`source_description` 可选，不构成入轴门槛。同一 `asset_id` 不能出现在两个镜头。`end - start` 不得超过 5 秒；`information_task: "broll"` 的真实实拍镜头必须为 `2–5` 秒。每镜选段统一使用 `shots[].source_in/source_out`；必须满足 `source_out = source_in + end - start` 且不超过索引中的源视频时长。渲染器和预检只认这组字段，不在 `assets[]` 存选段。替代素材必须同时有 `replacement: true` 和非空 `replacement_reason`。所有信息页固定 4 秒；允许前一页 `end` 等于后一页 `start` 的无缝衔接，不允许时间重叠。`fact/data/causal` 使用非空 `page_title` 与至少两个 `content_blocks[]`；`number` 使用非空 `page_title` 与包含数字的 `primary_value`，且二者不得相同；`comparison` 使用非空 `page_title/left_value/right_value/conclusion`，左右值不得相同。各类型字段与对应参考图结构必须保持一致。

素材库侧车可逐步补齐 `segments[]`，每段登记 `start/end/keywords/subject/action/visual`；统一素材库检索返回合法候选，视觉语义索引给出建议 `source_in/source_out`。没有段级登记不代表素材可直接使用，只能回退到候选联系表人工确认一次。
