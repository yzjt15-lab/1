#!/usr/bin/env python3
"""Regression checks for the timeline gates that previously allowed bad renders."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from unittest import mock
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from preflight import run_preflight
from fast_pipeline import ExternalBlockError, OFFICIAL_OUTPUT_DIR, _load_shared_visual_index, _run, initialize, recommended_structure_template, renderer_script, research, write_failure_status
from delivery_gate import failure_details
from make_visual_approval import CHECKS, make_approval
from render_continuous_timeline import build_ffmpeg_command, enforce_render_policy, select_encoder_with_probe
from review_render import duration_matches, main as review_main
from render_segmented_timeline import split_timeline
from validate_timeline import validate
from export_asset_ledger import make_ledger
from prepare_timeline_assets import prepare
from render_overlay_templates import render_overlay
from render_continuous_timeline import audio_codec_args
from workflow_metrics import DEFAULT_BUDGETS


def timeline(duration: float = 8.0) -> dict:
    assets = []
    shots = []
    for index in range(2):
        asset_id = f"a{index}"
        assets.append({
            "id": asset_id, "local_path": f"asset-{index}.mp4", "sha256": str(index) * 64,
            "status": "unused", "use_count": 0, "delivered_at": None, "last_used_at": None,
            "seven_day_eligible": True, "dedupe_clear": True,
            "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
            "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
            "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
        })
        shots.append({
            "id": f"s{index}", "start": index * 4.0, "end": (index + 1) * 4.0,
            "source_in": 0.0, "source_out": 4.0, "keyword": "行情",
            "subject": "市场", "action": "变化", "result": "形成信号",
            "asset_id": asset_id, "selection_mode": "semantic_index",
            "script_semantics": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "semantic_fields": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "theme_mapping": {"subject": "市场", "action": "变化", "location": "交易所", "equipment": "行情屏", "keywords": "行情 信号"},
            "information_task": "data",
            "script_range": {"start": index * 4.0, "end": (index + 1) * 4.0},
            "chapter_id": "c01",
            "selection_reason": "主体、动作、地点、设备与当前文案匹配",
            "candidate_asset_ids": [asset_id],
        })
    return {
        "title": "测试", "script_path": "script.md", "main_thesis": "市场信号",
        "main_evidence_id": "evidence-c01-data", "evidence_kind": "data",
        "duration_seconds": duration, "assets": assets, "shots": shots,
        "chapters": [{
            "id": "c01", "start": 0.0, "end": duration, "thesis": "市场信号",
            "information_plan": [{
                "id": "evidence-c01-data", "task": "data", "claim": "资金正在进场",
                "script_range": {"start": 0.0, "end": duration},
            }],
        }],
        "dedupe_audit": {"lookback_hours": 168, "checked_at": datetime.now(timezone.utc).isoformat()},
        "overlays": [
            {
                "id": "hook", "type": "hook", "role": "hook", "start": 0.0, "end": 4.0,
                "chapter_id": "c01", "evidence_id": "evidence-c01-data",
                "background_shot_id": "s0", "image_path": "hook.png", "frame_pattern": "hook/%04d.png",
                "chinese_text": "市场信号", "hook_color_fallback": "white",
                "hook_text_colors": {line: {"color": "#FFFFFF", "opacity": 1.0} for line in ("thesis", "judgment", "evidence")},
                "hook_contrast": {line: {"background_luminance": 0.02, "contrast_ratio": 17.5} for line in ("thesis", "judgment", "evidence")},
            },
            {
                "id": "info", "type": "data", "start": 4.0, "end": 8.0,
                "chapter_id": "c01", "evidence_id": "evidence-c01-data",
                "background_shot_id": "s1", "image_path": "info.png", "chinese_text": "资金正在进场",
                "page_title": "资金动向", "content_blocks": ["机构减空", "现货流入"],
            },
        ],
    }


class TimelineGuardTests(unittest.TestCase):
    def test_command_wraps_content_in_reference_vertical_layout(self):
        data = {"duration_seconds": 1.0, "chrome_path": "chrome.png", "assets": [{"id": "a", "local_path": "source.mp4"}], "shots": [{"id": "s", "asset_id": "a", "start": 0.0, "end": 1.0, "source_in": 0.0}], "overlays": []}
        command = build_ffmpeg_command(data, "output.mp4", "final", "ffmpeg", "libx264")
        graph = command[command.index("-filter_complex") + 1]
        self.assertIn("scale=1080:1920", graph)
        self.assertIn("scale=1080:830", graph)
        self.assertIn("overlay=0:604", graph)
        self.assertIn("setsar=1", graph)

    def test_information_page_preserves_video_backdrop_and_one_global_disclaimer(self):
        data = {"duration_seconds": 1.0, "chrome_path": "chrome.png", "assets": [{"id": "a", "local_path": "source.mp4"}], "shots": [{"id": "s", "asset_id": "a", "start": 0.0, "end": 1.0, "source_in": 0.0}], "overlays": [{"type": "data", "image_path": "page.png", "start": 0.0, "end": 1.0}]}
        command = build_ffmpeg_command(data, "output.mp4", "final", "ffmpeg", "libx264")
        graph = command[command.index("-filter_complex") + 1]
        self.assertIn("scale=1406:1080", graph)
        self.assertNotIn("pagebg0", graph)
        self.assertEqual(1, graph.count("[chrome]overlay=0:0"))

    def test_shared_index_requires_the_declared_contract(self):
        with tempfile.TemporaryDirectory() as folder:
            valid = Path(folder) / "valid_index.py"
            valid.write_text("SEMANTIC_INDEX_API_VERSION = 1\ndef search_many(*args, **kwargs): return {}\n", encoding="utf-8")
            self.assertTrue(callable(_load_shared_visual_index(valid)))
            invalid = Path(folder) / "invalid_index.py"
            invalid.write_text("def search_many(*args, **kwargs): return {}\n", encoding="utf-8")
            with self.assertRaisesRegex(ImportError, "contract mismatch"):
                _load_shared_visual_index(invalid)

    def test_init_writes_in_progress_status_without_completing_metrics(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            script = root / "script.md"
            script.write_text("第一句。第二句。", encoding="utf-8")
            result = initialize(script, 8.0, "初始化测试", root, None, date_text="2026-08-12")
            status = __import__("json").loads(Path(result["status_path"]).read_text(encoding="utf-8"))
            metrics = __import__("json").loads(Path(result["metrics_path"]).read_text(encoding="utf-8"))
            timelines = list(root.glob("*_时间轴.json"))
        self.assertEqual("in_progress", status["state"])
        self.assertFalse(status["terminal_allowed"])
        self.assertNotIn("completed", metrics)
        self.assertFalse(timelines)

    def test_fast_template_duration_boundaries_are_code_enforced(self):
        self.assertIsNone(recommended_structure_template(54.99))
        self.assertIsNotNone(recommended_structure_template(55.0))
        self.assertIsNotNone(recommended_structure_template(60.24))
        self.assertIsNone(recommended_structure_template(60.25))

    def test_external_failure_report_is_actionable(self):
        failure = failure_details(["ffprobe is required"])
        self.assertEqual("blocked_external", failure["state"])
        self.assertTrue(failure["next_actions"])

    def test_pipeline_external_failure_updates_shared_status(self):
        with tempfile.TemporaryDirectory() as folder:
            status = Path(folder) / "status.json"
            write_failure_status(status, FileNotFoundError("visual index unavailable"), "research")
            payload = json.loads(status.read_text(encoding="utf-8"))
        self.assertEqual("blocked_external", payload["state"])
        self.assertEqual("research_failed", payload["current_stage"])

    def test_internal_contract_failure_is_not_mislabeled_external(self):
        with tempfile.TemporaryDirectory() as folder:
            status = Path(folder) / "status.json"
            write_failure_status(status, RuntimeError("main_thesis is required"), "finalize")
            payload = json.loads(status.read_text(encoding="utf-8"))
        self.assertEqual("in_progress", payload["state"])
        self.assertEqual("finalize", payload["blocking_domain"])

    def test_child_missing_dependency_becomes_typed_external_failure(self):
        result = mock.Mock(returncode=1, stdout="", stderr="FileNotFoundError: ffmpeg not found")
        with mock.patch("fast_pipeline.subprocess.run", return_value=result), self.assertRaises(ExternalBlockError):
            _run("render_continuous_timeline.py", [])

    def test_news_registry_is_rejected(self):
        data = timeline()
        data["news"] = []
        self.assertTrue(any("news[] is forbidden" in error for error in validate(data)))

    def test_visual_approval_requires_per_shot_observations(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            video, contact, timeline_path = root / "video.mp4", root / "contact.jpg", root / "timeline.json"
            video.write_bytes(b"video")
            contact.write_bytes(b"contact")
            timeline_path.write_text(json.dumps({"shots": [{"id": "s01"}]}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "cover every timeline shot"):
                make_approval(video, timeline_path, contact, {}, CHECKS)
            with self.assertRaisesRegex(ValueError, "root must be a JSON object"):
                make_approval(video, timeline_path, contact, [], CHECKS)
            observations = {"s01": {"visible_subject": "晶圆", "visible_action": "搬运", "visible_location": "洁净室", "visible_equipment": "机械臂"}}
            approval = make_approval(video, timeline_path, contact, observations, CHECKS)
        self.assertEqual(observations, approval["shot_observations"])

    def test_malformed_visual_approval_still_writes_review_report(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            video = root / "video.mp4"
            timeline_path = root / "timeline.json"
            contact = root / "contact.jpg"
            approval = root / "approval.json"
            report = root / "report.json"
            video.write_bytes(b"video")
            contact.write_bytes(b"contact")
            timeline_path.write_text(json.dumps({"duration_seconds": 1.0, "shots": []}), encoding="utf-8")
            approval.write_text("{bad json", encoding="utf-8")
            argv = ["review_render.py", "--video", str(video), "--timeline", str(timeline_path), "--report", str(report), "--contact-sheet", str(contact), "--visual-approval", str(approval)]
            probe_result = {"format": {"duration": 1.0}, "streams": [{"codec_type": "video"}]}
            decode_result = mock.Mock(returncode=0, stderr="")
            with mock.patch("sys.argv", argv), mock.patch("review_render.probe", return_value=probe_result), mock.patch("review_render.find_ffmpeg", return_value="ffmpeg"), mock.patch("review_render.subprocess.run", return_value=decode_result):
                code = review_main()
            payload = json.loads(report.read_text(encoding="utf-8"))
        self.assertEqual(2, code)
        self.assertTrue(any("visual approval could not be read" in error for error in payload["errors"]))

    def test_encoder_fallback_is_probed_before_selection(self):
        attempts = []

        def probe(encoder):
            attempts.append(encoder)
            return encoder == "libx264"

        selected = select_encoder_with_probe("h264_nvenc", probe)
        self.assertEqual("libx264", selected)
        self.assertEqual(["h264_nvenc", "libx264"], attempts)

    def test_software_encoder_failure_stops_render(self):
        with self.assertRaisesRegex(RuntimeError, "probe failed"):
            select_encoder_with_probe("libx264", lambda _encoder: False)

    def test_preparation_preserves_valid_white_hook_contrast(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            prepared = prepare(data, Path(folder), size=(320, 180))
        hook = prepared["overlays"][0]
        self.assertEqual("white", hook["hook_color_fallback"])
        self.assertTrue(all(hook["hook_contrast"][line]["contrast_ratio"] >= 4.5 for line in ("thesis", "judgment", "evidence")))

    def test_all_self_authored_information_types_keep_their_own_contracts(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            configs = {
                "hook": {"type": "hook", "title": "市场信号", "chinese_text": "结构改善"},
                "fact": {"type": "fact", "page_title": "持仓事实", "content_blocks": ["多头增加", "空头回落"], "conclusion": "资金偏多"},
                "data": {"type": "data", "page_title": "持仓变化", "content_blocks": ["多头增仓", "空头减仓", "净多头"], "values": ["1.8万手", "0.6万手", "2.4万手"], "conclusion": "结构改善"},
                "number": {"type": "number", "page_title": "关键压力位", "primary_value": "3960", "unit": "点", "conclusion": "观察成交量"},
                "comparison": {"type": "comparison", "page_title": "多空力量", "left_title": "多头", "left_value": "+1.8万手", "right_title": "空头", "right_value": "-0.6万手", "conclusion": "多头占优"},
                "causal": {"type": "causal", "page_title": "资金逻辑", "content_blocks": ["机构增多", "净多上升", "挑战压力"], "conclusion": "动能增强"},
            }
            for kind, config in configs.items():
                output = render_overlay(config, root, size=(1920, 1080))
                self.assertTrue(output.is_file(), kind)
                self.assertGreater(output.stat().st_size, 500, kind)
            with self.assertRaisesRegex(ValueError, "authentic screenshot"):
                render_overlay({"type": "news"}, root, size=(640, 360))

    def test_pcm_audio_falls_back_to_aac_for_mp4(self):
        with mock.patch("render_continuous_timeline.subprocess.run") as run:
            run.return_value.returncode = 0
            run.return_value.stdout = "pcm_s16le\n"
            self.assertEqual(["-c:a", "aac", "-b:a", "192k"], audio_codec_args("voice.wav", "ffmpeg"))

    def test_seamless_information_pages_are_allowed(self):
        self.assertFalse(validate(timeline()))

    def test_duplicate_information_text_is_rejected(self):
        data = timeline()
        data["overlays"][1]["chinese_text"] = data["overlays"][0]["chinese_text"]
        self.assertTrue(any("duplicate information content" in error for error in validate(data)))

    def test_hook_requires_dynamic_frame_pattern(self):
        data = timeline()
        del data["overlays"][0]["frame_pattern"]
        self.assertTrue(any("frame_pattern" in error for error in validate(data)))

    def test_missing_seven_day_audit_is_rejected(self):
        data = timeline()
        del data["dedupe_audit"]
        self.assertTrue(any("seven-day dedupe audit" in error for error in validate(data)))

    def test_unclean_asset_is_rejected(self):
        data = timeline()
        data["assets"][0]["embedded_subtitles_free"] = False
        self.assertTrue(any("visual cleanliness gate" in error for error in validate(data)))

    def test_planning_fields_are_required(self):
        for field in ("script_semantics", "semantic_fields", "theme_mapping", "information_task", "script_range", "chapter_id", "selection_reason"):
            data = timeline()
            del data["shots"][0][field]
            self.assertTrue(any(field in error for error in validate(data)), field)

    def test_semantic_mirrors_must_match_all_five_fields(self):
        data = timeline()
        data["shots"][0]["theme_mapping"]["keywords"] = "不一致关键词"
        self.assertTrue(any("semantic mirrors disagree on keywords" in error for error in validate(data)))

    def test_fact_information_page_is_allowed(self):
        data = timeline()
        data["chapters"][0]["information_plan"][0]["task"] = "fact"
        data["overlays"][1]["type"] = "fact"
        self.assertFalse(validate(data))

    def test_white_hook_fallback_still_requires_measured_contrast(self):
        data = timeline()
        del data["overlays"][0]["hook_contrast"]
        self.assertTrue(any("white fallback" in error for error in validate(data)))

    def test_planned_information_page_requires_same_chapter_evidence(self):
        data = timeline()
        data["overlays"][1]["evidence_id"] = "not-planned"
        self.assertTrue(any("evidence_id" in error for error in validate(data)))

    def test_information_page_cannot_reference_another_chapter(self):
        data = timeline()
        data["chapters"].append({
            "id": "c02", "start": 8.0, "end": 9.0, "thesis": "第二章",
            "information_plan": [{"id": "evidence-c02", "task": "data", "claim": "第二章数据", "script_range": {"start": 8.0, "end": 9.0}}],
        })
        data["overlays"][1]["evidence_id"] = "evidence-c02"
        self.assertTrue(any("another chapter" in error for error in validate(data)))

    def test_long_broll_run_is_allowed_when_each_cut_is_2_to_5_seconds(self):
        data = timeline(12.0)
        data["shots"] = []
        data["assets"] = []
        for index in range(3):
            asset_id = f"b{index}"
            data["assets"].append({
                "id": asset_id, "local_path": f"{asset_id}.mp4", "sha256": str(index + 3) * 64,
                "status": "unused", "use_count": 0, "delivered_at": None, "last_used_at": None,
                "seven_day_eligible": True, "dedupe_clear": True,
                "dedupe_checked_at": datetime.now(timezone.utc).isoformat(),
                "watermark_free": True, "embedded_subtitles_free": True, "platform_overlay_free": True,
                "cleanliness_checked_at": datetime.now(timezone.utc).isoformat(), "cleanliness_evidence": "contact sheet confirmed a clean selected range",
            })
            data["shots"].append({
                "id": f"b{index}", "start": index * 4.0, "end": (index + 1) * 4.0, "source_in": 0.0, "source_out": 4.0,
                "keyword": "市场", "subject": "交易员", "action": "观察", "result": "形成信号", "asset_id": asset_id,
                "selection_mode": "semantic_index", "script_semantics": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "semantic_fields": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "theme_mapping": {"subject": "交易员", "action": "观察", "location": "交易所", "equipment": "行情屏", "keywords": "市场 信号"},
                "information_task": "broll", "script_range": {"start": index * 4.0, "end": (index + 1) * 4.0}, "chapter_id": "c01",
                "selection_reason": "当前章节的交易员观察行情实拍", "candidate_asset_ids": [asset_id],
            })
        data["overlays"][0]["background_shot_id"] = "b0"
        data["overlays"][1]["background_shot_id"] = "b1"
        self.assertFalse(validate(data))

    def test_broll_cut_shorter_than_two_seconds_is_rejected(self):
        data = timeline()
        data["shots"][0]["information_task"] = "broll"
        data["shots"][0]["end"] = 1.5
        data["shots"][0]["source_out"] = 1.5
        data["shots"][1]["start"] = 1.5
        self.assertTrue(any("broll duration" in error for error in validate(data)))

    def test_false_global_eligibility_credential_is_rejected(self):
        data = timeline()
        asset = data["assets"][1]
        asset["seven_day_eligible"] = False
        self.assertTrue(any("seven-day dedupe status" in error for error in validate(data)))

    def test_historical_delivered_hash_is_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            ledger = root / "2026-08-06_文档_旧片_asset-ledger.json"
            ledger.write_text('{"assets":[{"sha256":"' + "0" * 64 + '"}]}', encoding="utf-8")
            import hashlib, json
            gate = {
                "terminal_allowed": True,
                "checked_at": datetime.now(timezone.utc).isoformat(),
                "sha256": {"ledger": hashlib.sha256(ledger.read_bytes()).hexdigest()},
            }
            (root / "2026-08-06_文档_旧片_交付门禁.json").write_text(json.dumps(gate), encoding="utf-8")
            errors = run_preflight(data, require_files=False, history_root=root)
        self.assertTrue(any("material identity was used" in error for error in errors))

    def test_page_template_reference_assets_are_hash_bound(self):
        from preflight import verify_page_template_assets
        self.assertEqual([], verify_page_template_assets())

    def test_number_page_rejects_duplicate_title_and_value(self):
        data = timeline()
        data["overlays"][1].update({"type": "number", "page_title": "3960", "primary_value": "3960"})
        self.assertTrue(any("must differ" in error for error in validate(data)))

    def test_duplicate_overlay_files_are_rejected(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            duplicate = Path(folder) / "same.png"
            duplicate.write_bytes(b"same")
            data["overlays"][0]["image_path"] = str(duplicate)
            data["overlays"][1]["image_path"] = str(duplicate)
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("duplicate information image" in error for error in errors))

    def test_selected_asset_must_come_from_research_candidates(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            manifest = Path(folder) / "research.json"
            manifest.write_text(
                json.dumps({"source": "fast_pipeline research", "eligible_visual_candidates": {"queries": []}}),
                encoding="utf-8",
            )
            data["selection_manifest_path"] = str(manifest)
            data["selection_manifest_sha256"] = hashlib.sha256(manifest.read_bytes()).hexdigest()
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("absent from research candidates" in error for error in errors))

    def test_research_candidate_requires_matching_fresh_full_hash(self):
        data = timeline()
        with tempfile.TemporaryDirectory() as folder:
            manifest = Path(folder) / "research.json"
            candidates = [
                {"asset_id": item["id"], "sha256": item["sha256"], "seven_day_eligible": True}
                for item in data["assets"]
            ]
            candidates[0]["seven_day_eligible"] = False
            manifest.write_text(json.dumps({"source": "fast_pipeline research", "eligible_visual_candidates": {"queries": [{"candidates": candidates}]}}), encoding="utf-8")
            data["selection_manifest_path"] = str(manifest)
            data["selection_manifest_sha256"] = hashlib.sha256(manifest.read_bytes()).hexdigest()
            errors = run_preflight(data, require_files=False)
        self.assertTrue(any("not seven-day eligible" in error for error in errors))

    def test_research_records_full_hash_and_excludes_delivered_asset(self):
        with tempfile.TemporaryDirectory() as folder:
            fresh = Path(folder) / "fresh.mp4"
            stale = Path(folder) / "stale.mp4"
            fresh.write_bytes(b"fresh")
            stale.write_bytes(b"stale")
            result = {"model_id": "test", "queries": [{"query": "测试", "candidates": [
                {"asset_id": "fresh", "path": str(fresh), "provenance_complete": True},
                {"asset_id": "stale", "path": str(stale), "provenance_complete": True},
            ]}]}
            filtered = [{**result["queries"][0]["candidates"][0], "sha256": hashlib.sha256(b"fresh").hexdigest(), "seven_day_eligible": True}]
            with mock.patch("fast_pipeline.search_many", return_value=result) as search, mock.patch("fast_pipeline.filter_candidates", return_value=filtered) as gate:
                report = research(Path(folder), ["测试"], 2, 5.0, "cpu", Path(folder), categories=["股市与市场"])
            gate.assert_called_once()
            self.assertEqual(["股市与市场"], search.call_args.kwargs["categories"])
        candidates = report["eligible_visual_candidates"]["queries"][0]["candidates"]
        self.assertEqual(["fresh"], [item["asset_id"] for item in candidates])
        self.assertEqual(hashlib.sha256(b"fresh").hexdigest(), candidates[0]["sha256"])

    def test_approval_final_review_has_a_budget(self):
        self.assertIn("approval_final_review", DEFAULT_BUDGETS)

    def test_internal_production_wording_is_rejected(self):
        data = timeline()
        data["title"] = "内部样品"
        self.assertTrue(any("internal production wording" in error for error in validate(data)))

    def test_continuous_renderer_rejects_long_timeline(self):
        data = timeline(120.0)
        data["shots"][-1]["end"] = 120.0
        with self.assertRaisesRegex(ValueError, "segmented"):
            build_ffmpeg_command(data, "out.mp4", ffmpeg="ffmpeg")

    def test_renderer_requests_exact_frame_count(self):
        command = build_ffmpeg_command(timeline(), "out.mp4", ffmpeg="ffmpeg")
        frames_index = command.index("-frames:v")
        self.assertEqual(command[frames_index + 1], "240")

    def test_duration_tolerance_is_one_frame(self):
        self.assertTrue(duration_matches(120.0, 120.03))
        self.assertFalse(duration_matches(120.0, 120.04))

    def test_formal_entry_selects_segmented_renderer_for_long_timeline(self):
        self.assertEqual(renderer_script(timeline(120.0)), "render_segmented_timeline.py")
        self.assertEqual(renderer_script(timeline()), "render_continuous_timeline.py")

    def test_renderer_cannot_write_official_output_even_with_forged_permit(self):
        with self.assertRaisesRegex(ValueError, "only fast_pipeline finalize"):
            enforce_render_policy(
                timeline(),
                OFFICIAL_OUTPUT_DIR / "forged.mp4",
                "final",
                "forged-permit.json",
            )

    def test_asset_ledger_keeps_semantics_and_evidence_bindings(self):
        data = timeline()
        data["shots"][0]["overlay_id"] = "hook"
        data["shots"][1]["overlay_id"] = "info"
        ledger = make_ledger(data)
        first, second = ledger["uses"]
        for item in (first, second):
            self.assertIn("chapter_id", item)
            self.assertIn("script_semantics", item)
            self.assertIn("information_task", item)
            self.assertIn("script_range", item)
            self.assertIn("overlay_ids", item)
        self.assertEqual("evidence-c01-data", second["evidence_id"])

    def test_hook_top_level_evidence_contract_is_required(self):
        data = timeline()
        data.pop("main_evidence_id", None)
        data.pop("evidence_kind", None)
        errors = validate(data)
        self.assertTrue(any("main_evidence_id" in error for error in errors))
        self.assertTrue(any("evidence_kind" in error for error in errors))

    def test_segmenter_preserves_all_shots_without_large_segments(self):
        data = timeline(100.0)
        data["shots"] = []
        data["assets"] = []
        data["overlays"] = []
        for index in range(20):
            data["shots"].append({"id": f"s{index}", "start": index * 5.0, "end": (index + 1) * 5.0, "asset_id": f"a{index}"})
            data["assets"].append({"id": f"a{index}", "local_path": f"a{index}.mp4"})
        segments = split_timeline(data)
        self.assertEqual(sum(len(item["shots"]) for item in segments), 20)
        self.assertTrue(all(len(item["shots"]) <= 5 and item["duration_seconds"] <= 25.0 for item in segments))


if __name__ == "__main__":
    unittest.main()
